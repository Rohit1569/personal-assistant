'use client';

import React from 'react';

export default function WorkInProgress({
  title = 'Work in progress',
  message = "We're building this feature. Please check back soon.",
  overlay = false,          // true → fixed overlay; false → full-page section
  className = '',           // optional class overrides
}) {
  const Container = ({ children }) =>
    overlay ? (
      <div className={`fixed inset-0 z-[1000] bg-white/85 backdrop-blur-sm ${className}`}>
        {children}
      </div>
    ) : (
      <div className={`min-h-[60vh] w-full ${className}`}>{children}</div>
    );

  return (
    <Container>
      <div className="h-full w-full flex items-center justify-center px-6">
        <div className="flex flex-col items-center gap-4 text-center">
          {/* Spinner */}
          {/* <div
            className="h-10 w-10 animate-spin rounded-full border-4 border-slate-200 border-t-red-600"
            aria-hidden="true"
          /> */}
          {/* Title */}
          <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
          {/* Message */}
          <p className="max-w-md text-sm text-slate-600">{message}</p>
        </div>
      </div>
    </Container>
  );
}
