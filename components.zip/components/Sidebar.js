'use client'
import { MessageSquare, ShieldAlert, Flame, Droplets, Activity, Package, ChevronRight } from 'lucide-react'

const HISTORY = [
  { id: 1, type: 'Good Save',           text: 'LOTO missing on executor…',       date: 'Today',     icon: ShieldAlert, color: 'text-green-600' },
  { id: 2, type: 'Near Miss',           text: 'Forklift near-miss at loading…',  date: 'Yesterday', icon: Activity,    color: 'text-amber-600' },
  { id: 3, type: 'Environmental Release', text: 'Minor chemical spill in QC…',    date: 'Apr 27',    icon: Droplets,    color: 'text-blue-600' },
  { id: 4, type: 'First Aid',           text: 'Minor laceration on hand…',       date: 'Apr 24',    icon: Flame,       color: 'text-red-500' },
  { id: 5, type: 'Property Damage',     text: 'Conveyor belt motor failure…',    date: 'Apr 21',    icon: Package,     color: 'text-purple-600' },
]

export default function Sidebar({ onReset }) {
  return (
    <aside className="w-64 bg-warm-50 border-r border-warm-200 flex flex-col flex-shrink-0 hidden lg:flex">
      {/* New chat */}
      <div className="p-4 border-b border-warm-200">
        <button
          onClick={onReset}
          className="w-full flex items-center justify-center gap-2 bg-red-500 text-white text-[13px] font-bold py-2.5 rounded-xl hover:bg-red-600 transition-colors shadow-sm"
        >
          <MessageSquare size={14} />
          New Report
        </button>
      </div>

      {/* History */}
      <div className="flex-1 overflow-y-auto p-3">
        <p className="text-[10px] font-bold text-warm-500 uppercase tracking-widest px-1 mb-2">Recent Reports</p>
        <div className="space-y-1">
          {HISTORY.map(item => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                className="w-full flex items-start gap-2.5 px-3 py-2.5 rounded-xl text-left hover:bg-warm-100 transition-colors group"
              >
                <Icon size={14} className={`${item.color} mt-0.5 flex-shrink-0`} />
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] font-bold text-warm-600 mb-0.5">{item.type}</div>
                  <div className="text-[12px] text-warm-700 truncate">{item.text}</div>
                  <div className="text-[10px] text-warm-400 mt-0.5">{item.date}</div>
                </div>
                <ChevronRight size={12} className="text-warm-300 group-hover:text-warm-500 flex-shrink-0 mt-1" />
              </button>
            )
          })}
        </div>
      </div>

      {/* User footer */}
      <div className="p-4 border-t border-warm-200">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-[12px] font-bold flex-shrink-0">
            AS
          </div>
          <div className="min-w-0">
            <div className="text-[12px] font-bold text-warm-800 truncate">Ankita Sharma</div>
            <div className="text-[10px] text-warm-500 truncate">Pune – EHS&S</div>
          </div>
        </div>
      </div>
    </aside>
  )
}
