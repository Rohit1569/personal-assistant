// Compact 3-column checkbox grid used by the Root Cause and CAPA modals.
export default function CauseCheckGroup({ items, selected, onToggle }) {
  return (
    <div className="grid grid-cols-1 gap-x-6 gap-y-2 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((item) => {
        const checked = selected.has(item);
        return (
          <label key={item} className="flex cursor-pointer items-start gap-2 text-[13.5px] text-jnj-ink/90">
            <input type="checkbox" checked={checked} onChange={() => onToggle(item)} className="mt-0.5 h-[15px] w-[15px] flex-shrink-0 rounded accent-jnj-red" />
            <span className={checked ? "font-semibold text-jnj-ink" : ""}>{item}</span>
          </label>
        );
      })}
    </div>
  );
}
