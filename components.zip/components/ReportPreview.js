'use client'

import { useState, useEffect } from 'react'
import { BotAvatar } from './Avatars'
/* ─────────────────────────────────────────────
   Icons
───────────────────────────────────────────── */
const IconSparkles = ({ className = 'w-3 h-3' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
    <path d="M5 3v4" /><path d="M19 17v4" /><path d="M3 5h4" /><path d="M17 19h4" />
  </svg>
)
const IconRotate = ({ className = 'w-3 h-3' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" />
  </svg>
)
const IconCheck = ({ className = 'w-3 h-3' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12" />
  </svg>
)
const IconX = ({ className = 'w-2.5 h-2.5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
  </svg>
)
const IconLock = ({ className = 'w-2.5 h-2.5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
  </svg>
)

/* ─────────────────────────────────────────────
   Constants
───────────────────────────────────────────── */
const ENHANCEABLE = new Set([
  'What Happened',
  'What action(s) did you take?',
  'What action(s) do you suggest?',
  'What do you think caused this Incident?',
  'What could you have done to prevent this?',
  'Immediate Corrective Action',
  'Comments',
  'Description',
])

const REQUIRED_FIELDS = new Set([
  'Event Type',
  'Site Location',
  'Department',
  'Responsible Department',
  'Date and Time of Event',
  'What Happened',
  'J&J Company',
  'J&J site',
  'Reported On Behalf Of',
  'Default Good Save Reviewer',
  'Default Incident Reviewer',
  'Report in Confidence?',
  'Select Different Reviewer?',
  'Date and Time Reported',
  'Company',
  'Location'
])

const READONLY_FIELDS = new Set([
  'Default Incident Reviewer',
  'Reported On Behalf Of - Supervisor',
])

const DATETIME_FIELDS = new Set([
  'Date and Time of Event',
  'Date and Time Reported',
])

// Maps backend field names to display labels shown in UI
const FIELD_LABELS = {
  "Describe 'Other' Responsible Department": 'Describe Other',
  'What Happened': 'What happened?',
  'Location': 'J&J Site',
  'Company': 'J&J Company',
}


/* ─────────────────────────────────────────────
   UTC → local timezone formatter
───────────────────────────────────────────── */
function formatUtcToLocal(rawValue) {
  if (!rawValue || typeof rawValue !== 'string') return rawValue
  let iso = rawValue.trim().replace(' ', 'T')
  if (!/[Zz]$/.test(iso) && !/[+-]\d{2}:\d{2}$/.test(iso)) iso += 'Z'
  const date = new Date(iso)
  if (isNaN(date.getTime())) return rawValue
  try {
    return new Intl.DateTimeFormat(undefined, {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', timeZoneName: 'short',
    }).format(date)
  } catch {
    return rawValue
  }
}

/* ─────────────────────────────────────────────
   EnhancePopover
───────────────────────────────────────────── */
const ENHANCE_URL = 'http://awsdjynval000a.jnj.com:8080/curve-chatbot/enhance_what_happened'

function EnhancePopover({ originalText, onAccept, onClose }) {
  const [status, setStatus] = useState('loading')
  const [text, setText] = useState('')

  const run = async () => {
    setStatus('loading'); setText('')
    try {
      const res = await fetch(ENHANCE_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ What_Happened: originalText, language: 'English' }),
      })
      if (!res.ok) throw new Error()
      const data = await res.json()
      setText(data?.What_Happened_Enhanced || '')
    } catch {
      setText('Failed to enhance text. Please try again.')
    } finally {
      setStatus('done')
    }
  }

  useEffect(() => { run() }, [])

  return (
    <div className="absolute z-50 left-0 w-72 sm:w-80 rounded-xl overflow-hidden border border-purple-200 bg-white shadow-xl"
      style={{ top: 'calc(100% + 6px)', animation: 'popIn .16s ease-out both' }}>
      {/* header */}
      <div className="flex items-center justify-between px-3 py-2 bg-gradient-to-r from-violet-600 to-purple-700">
        <span className="flex items-center gap-1.5 text-white text-xs font-bold tracking-wide">
          <IconSparkles className="w-2.5 h-2.5" /> AI SUGGESTION
        </span>
        <button onClick={onClose} className="text-white/60 hover:text-white text-sm leading-none bg-transparent border-none cursor-pointer">✕</button>
      </div>
      {/* body */}
      <div className="p-3">
        {status === 'loading'
          ? (
            <div className="flex flex-col gap-2">
              {[100, 80, 62].map((w, i) => (
                <div key={i} className="h-2 rounded" style={{ width: `${w}%`, background: 'linear-gradient(90deg,#f3f4f6 25%,#e5e7eb 50%,#f3f4f6 75%)', backgroundSize: '300% 100%', animation: 'shimmer 1.4s infinite' }} />
              ))}
              <p className="text-xs text-gray-400 text-center mt-1">Enhancing…</p>
            </div>
          )
          : (
            <textarea
              value={text}
              onChange={e => setText(e.target.value)}
              rows={4}
              className="w-full border border-purple-200 rounded-lg px-2.5 py-2 text-xs text-gray-800 leading-relaxed resize-none outline-none bg-violet-50/30"
            />
          )
        }
      </div>
      {/* footer */}
      <div className="flex justify-between items-center px-3 pb-3 pt-2 border-t border-gray-100">
        <button onClick={run} className="flex items-center gap-1 text-xs text-violet-600 font-semibold bg-transparent border-none cursor-pointer">
          <IconRotate /> Regenerate
        </button>
        <button onClick={() => onAccept(text)}
          className="px-4 py-1 text-xs font-bold text-white rounded-full cursor-pointer border-none"
          style={{ background: 'linear-gradient(135deg,#7C3AED,#6D28D9)', boxShadow: '0 3px 8px rgba(124,58,237,0.35)' }}>
          Insert
        </button>
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────
   RowCell
───────────────────────────────────────────── */
function RowCell({ rowKey, value, onSave, accentColor }) {
  const isReadonly   = READONLY_FIELDS.has(rowKey)
  const isDatetime   = DATETIME_FIELDS.has(rowKey)
  const canEnhance   = ENHANCEABLE.has(rowKey) && !isReadonly
  const displayValue = isDatetime ? formatUtcToLocal(value) : value

  const [draft, setDraft]     = useState(displayValue)
  const [editing, setEditing] = useState(false)
  const [hovered, setHovered] = useState(false)
  const [showAI, setShowAI]   = useState(false)

  useEffect(() => { if (!editing) setDraft(displayValue) }, [value, editing])

  const commit = () => { onSave(rowKey, draft); setEditing(false) }
  const cancel = () => { setDraft(displayValue); setEditing(false) }

  /* Read-only */
  if (isReadonly) {
    return (
      <div className="flex items-center gap-2 px-2.5 py-1.5 bg-gray-100 rounded-lg border border-gray-200 cursor-not-allowed select-none">
        <IconLock className="w-2.5 h-2.5 text-gray-400 shrink-0" />
        <span className="text-xs text-gray-500 font-medium flex-1">{displayValue}</span>
      </div>
    )
  }

  return (
    <div className="relative w-full">
      {/* AI sparkle — fixed top-left, never moves */}
      {canEnhance && value && (
        <button
          onClick={() => setShowAI(v => !v)}
          title="Enhance with AI"
          className="absolute left-1.5 top-1.5 w-5 h-5 rounded-full flex items-center justify-center cursor-pointer border-none z-10 transition-all duration-200"
          style={{
            background: showAI
              ? 'linear-gradient(135deg,#7C3AED,#6D28D9)'
              : 'linear-gradient(135deg,#C4B5FD,#818CF8)',
            boxShadow: showAI ? '0 0 8px rgba(124,58,237,0.5)' : '0 1px 4px rgba(124,58,237,0.22)',
          }}
        >
          <IconSparkles className="w-2.5 h-2.5 text-white" />
        </button>
      )}

      <input
        type="text"
        value={draft}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onFocus={() => setEditing(true)}
        onChange={e => { setDraft(e.target.value); setEditing(true) }}
        placeholder="Enter value…"
        className="w-full text-xs font-normal text-gray-900 rounded-lg outline-none transition-all duration-200 cursor-text"
        style={{
          paddingTop: '6px',
          paddingBottom: '6px',
          paddingLeft: canEnhance ? '30px' : '10px',
          paddingRight: '10px',
          background: editing || hovered ? '#ffffff' : '#F7F8FA',
          border: editing
            ? `2px solid ${accentColor}`
            : hovered
              ? `1.5px solid ${accentColor}`
              : '1.5px dashed #D1D5DB',
          boxShadow: editing
            ? `0 0 0 3px ${accentColor}18`
            : hovered
              ? `0 0 0 2px ${accentColor}0D`
              : 'none',
        }}
      />

      {editing && (
        <div className="flex gap-1.5 mt-1">
          <button onClick={commit}
            className="flex items-center gap-1 px-2.5 py-1 text-white text-xs font-bold rounded-md cursor-pointer border-none"
            style={{ background: '#059669', boxShadow: '0 2px 5px rgba(5,150,105,0.28)' }}>
            <IconCheck /> Confirm
          </button>
          <button onClick={cancel}
            className="flex items-center gap-1 px-2.5 py-1 text-gray-600 text-xs font-semibold rounded-md cursor-pointer bg-white border border-gray-200">
            <IconX /> Cancel
          </button>
        </div>
      )}

      {showAI && (
        <EnhancePopover
          originalText={value}
          onAccept={v => { setDraft(v); onSave(rowKey, v); setShowAI(false) }}
          onClose={() => setShowAI(false)}
        />
      )}
    </div>
  )
}


/* ─────────────────────────────────────────────
   ReportPreview — default export

   Props:
     report  — object  — key/value map from backend
                         datetime values must be UTC strings
     time    — string? — optional timestamp string
───────────────────────────────────────────── */
export default function ReportPreview({ report: initialReport, time }) {
  const [report, setReport] = useState(initialReport || {})

  useEffect(() => {
    if (initialReport) setReport(initialReport)
  }, [initialReport])

  const handleSave = (key, val) => setReport(prev => ({ ...prev, [key]: val }))

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap');
        * { box-sizing: border-box; font-family: 'DM Sans', sans-serif; }
        @keyframes popIn   { from { opacity:0; transform:scale(.95) translateY(-4px) } to { opacity:1; transform:scale(1) translateY(0) } }
        @keyframes shimmer { from { background-position:300% 0 } to { background-position:-300% 0 } }
      `}</style>

      <div className="w-full rounded-xl overflow-hidden border border-gray-200 shadow-sm">

        {/* ── Header ── */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-red-500">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 shrink-0 rounded-lg flex items-center justify-center bg-white/15">
              <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>
                <rect x="8" y="2" width="8" height="4" rx="1"/>
              </svg>
            </div>
            <div>
              <p className="text-white/60 text-xs font-medium leading-none mb-0.5">Incident Management System</p>
              <h2 className="text-white text-sm font-semibold leading-tight">Event Report</h2>
            </div>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-3 items-center">
            {[
              { icon: <span className="text-red-300 font-bold text-xs">*</span>, label: 'Required' },
              { icon: <IconSparkles className="w-2.5 h-2.5 text-white/70" />, label: 'AI-enhanceable' },
              { icon: <IconLock className="w-2.5 h-2.5 text-white/70" />, label: 'Read-only' },
            ].map((item, i) => (
              <span key={i} className="flex items-center gap-1 text-white/65 text-xs">
                {item.icon} {item.label}
              </span>
            ))}
          </div>
        </div>

        {/* ── Form — exact backend order ── */}
        <div className="bg-white">
          {Object.entries(report).map(([key, val]) => (
            <div key={key} className="flex flex-col sm:flex-row items-start gap-1 sm:gap-0 px-3 sm:px-4 py-2 bg-white">
              <div className="shrink-0 sm:w-44 sm:w-[20%] sm:pr-3 pt-1.5">
                <span className="block text-xs font-semibold text-gray-600 leading-snug text-right">
                  {FIELD_LABELS[key] ?? key}
                  {REQUIRED_FIELDS.has(key) && (
                    <span className="text-red-500 ml-0.5 font-bold">*</span>
                  )}
                </span>
              </div>
              <div className="w-full sm:flex-1">
                <RowCell
                  rowKey={key}
                  value={String(val ?? '')}
                  onSave={handleSave}
                  accentColor="#B91C1C"
                />
              </div>
            </div>
          ))}
        </div>

      </div>

      {time && (
        <span className="block text-xs text-gray-400 mt-1.5">{time}</span>
      )}
    </>
  )
}