// // components/FieldInput.jsx (Cleaned - No employeeSearch handler)

// "use client";

// import { useEffect, useMemo, useRef, useState } from "react";
// import {
//   ChevronDown,
//   Search,
//   Check,
//   X,
// } from "lucide-react";

// function SearchableSelect({
//   id,
//   value,
//   options = [],
//   onChange,
//   placeholder = "Select...",
//   disabled = false,
//   loading = false,
//   hasMore = false,
//   onLoadMore,
//   onSearch,
//   onOpen,
// }) {
//   const [open, setOpen] = useState(false);
//   const [search, setSearch] = useState("");
//   const [displayOptions, setDisplayOptions] = useState(
//     options
//   );

//   const containerRef = useRef(null);
//   const scrollContainerRef = useRef(null);
//   const scrollTimeoutRef = useRef(null);

//   useEffect(() => {
//     console.log("SearchableSelect - options updated:", options);
//     setDisplayOptions(options);
//   }, [options]);

//   const filtered = useMemo(() => {
//     if (onSearch) {
//       return displayOptions;
//     }

//     if (!search.trim()) return displayOptions;

//     return displayOptions.filter((opt) => {
//       const optLabel =
//         typeof opt === "string" ? opt : opt.label;
//       return String(optLabel)
//         .toLowerCase()
//         .includes(search.toLowerCase());
//     });
//   }, [displayOptions, search, onSearch]);

//   useEffect(() => {
//     const handleClickOutside = (e) => {
//       if (
//         !containerRef.current?.contains(e.target)
//       ) {
//         setOpen(false);
//       }
//     };

//     document.addEventListener(
//       "mousedown",
//       handleClickOutside
//     );

//     return () => {
//       document.removeEventListener(
//         "mousedown",
//         handleClickOutside
//       );
//       if (scrollTimeoutRef.current) {
//         clearTimeout(scrollTimeoutRef.current);
//       }
//     };
//   }, []);

//   const handleSelect = (option) => {
//     const selectedValue =
//       typeof option === "string" ? option : option.value;
//     onChange(selectedValue);
//     setOpen(false);
//     setSearch("");
//   };

//   const handleSearch = (term) => {
//     setSearch(term);

//     if (onSearch) {
//       console.log("Calling onSearch with term:", term);
//       onSearch(term);
//     }
//   };

//   const handleScroll = (e) => {
//     const container = e.target;
//     const isAtBottom =
//       container.scrollHeight - container.scrollTop <=
//       container.clientHeight + 50;

//     if (
//       isAtBottom &&
//       hasMore &&
//       !loading &&
//       onLoadMore
//     ) {
//       if (scrollTimeoutRef.current) {
//         clearTimeout(scrollTimeoutRef.current);
//       }

//       scrollTimeoutRef.current = setTimeout(() => {
//         onLoadMore();
//       }, 300);
//     }
//   };

//   const handleOpenChange = (newOpen) => {
//     console.log("Dropdown open state changed to:", newOpen);
//     setOpen(newOpen);

//     if (newOpen && onOpen) {
//       console.log("Calling onOpen callback");
//       onOpen();
//     }
//   };

//   const getOptionLabel = (option) => {
//     if (typeof option === "string") return option;
//     return option.label || option.value;
//   };

//   const getOptionValue = (option) => {
//     if (typeof option === "string") return option;
//     return option.value;
//   };

//   return (
//     <div ref={containerRef} className="w-full">
//       <button
//         id={id}
//         type="button"
//         disabled={disabled}
//         onClick={() => {
//           if (!disabled) {
//             handleOpenChange(!open);
//             setSearch("");
//           }
//         }}
//         className={`
//           flex
//           h-10
//           w-full
//           items-center
//           gap-2
//           rounded-lg
//           px-3
//           text-left
//           transition-all

//           ${
//             disabled
//               ? "cursor-not-allowed border border-gray-200 bg-gray-100 opacity-60"
//               : open
//               ? "border-2 border-red-700 bg-white shadow-[0_0_0_3px_rgba(185,28,28,0.1)]"
//               : "border border-slate-300 bg-white hover:border-slate-400"
//           }
//         `}
//       >
//         <span
//           className={`flex-1 truncate text-sm ${
//             value
//               ? "font-medium text-gray-900"
//               : "text-gray-400"
//           }`}
//         >
//           {value || placeholder}
//         </span>

//         {value && !disabled && (
//           <span
//             onMouseDown={(e) => {
//               e.preventDefault();
//               e.stopPropagation();
//               onChange("");
//             }}
//             className="
//               flex
//               h-5
//               w-5
//               items-center
//               justify-center
//               rounded-full
//               bg-gray-100
//               hover:bg-red-100
//             "
//           >
//             <X className="h-3 w-3 text-gray-500" />
//           </span>
//         )}

//         <ChevronDown
//           className={`h-4 w-4 text-gray-500 transition-transform ${
//             open ? "rotate-180" : ""
//           }`}
//         />
//       </button>

//       {open && (
//         <div
//           className="
//             mt-2
//             overflow-hidden
//             rounded-xl
//             border
//             border-gray-200
//             bg-white
//             shadow-xl
//             z-50
//           "
//         >
//           {(displayOptions.length > 5 || onSearch) && (
//             <div className="border-b border-gray-100 bg-gray-50 p-2 sticky top-0 z-10">
//               <div
//                 className="
//                   flex
//                   items-center
//                   gap-2
//                   rounded-lg
//                   border
//                   border-gray-200
//                   bg-white
//                   px-3
//                   py-2
//                 "
//               >
//                 <Search className="h-4 w-4 text-gray-400" />

//                 <input
//                   value={search}
//                   onChange={(e) =>
//                     handleSearch(e.target.value)
//                   }
//                   placeholder="Search..."
//                   autoFocus={open && onSearch}
//                   className="
//                     flex-1
//                     bg-transparent
//                     text-sm
//                     outline-none
//                     placeholder:text-gray-400
//                   "
//                 />
//               </div>
//             </div>
//           )}

//           <div
//             ref={scrollContainerRef}
//             className="max-h-64 overflow-y-auto"
//             onScroll={handleScroll}
//           >
//             {loading && filtered.length === 0 ? (
//               <div className="px-4 py-6 text-center text-sm text-gray-400">
//                 <div className="flex items-center justify-center gap-2">
//                   <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
//                   <span>Loading...</span>
//                 </div>
//               </div>
//             ) : filtered.length === 0 ? (
//               <div className="px-4 py-6 text-center text-sm text-gray-400">
//                 No options found
//               </div>
//             ) : (
//               filtered.map((option) => {
//                 const optionValue = getOptionValue(option);
//                 const optionLabel = getOptionLabel(option);
//                 const selected = optionValue === value;

//                 return (
//                   <button
//                     key={optionValue}
//                     type="button"
//                     onClick={() => handleSelect(option)}
//                     className={`
//                       flex
//                       w-full
//                       items-center
//                       gap-3
//                       px-3
//                       py-2
//                       text-left
//                       text-sm
//                       transition-colors

//                       ${
//                         selected
//                           ? "bg-red-50 text-red-700"
//                           : "text-gray-700 hover:bg-gray-50"
//                       }
//                     `}
//                   >
//                     <span
//                       className={`
//                         h-2
//                         w-2
//                         rounded-full

//                         ${
//                           selected
//                             ? "bg-red-600"
//                             : "bg-transparent"
//                         }
//                       `}
//                     />

//                     <span className="flex-1 truncate">
//                       {optionLabel}
//                     </span>

//                     {selected && (
//                       <Check className="h-4 w-4" />
//                     )}
//                   </button>
//                 );
//               })
//             )}

//             {loading && filtered.length > 0 && (
//               <div className="px-4 py-2 text-center text-sm text-gray-400">
//                 <div className="flex items-center justify-center gap-2">
//                   <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
//                   <span>Loading more...</span>
//                 </div>
//               </div>
//             )}
//           </div>

//           <div
//             className="
//               border-t
//               border-gray-100
//               bg-gray-50
//               px-3
//               py-1
//               text-right
//               text-xs
//               text-gray-400
//             "
//           >
//             {filtered.length} options
//             {hasMore && onSearch && (
//               <span className="ml-2">• Scroll for more</span>
//             )}
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// function AutoResizeTextarea({
//   value,
//   onChange,
//   ...props
// }) {
//   const ref = useRef(null);

//   useEffect(() => {
//     if (ref.current) {
//       ref.current.style.height = "auto";
//       ref.current.style.height =
//         `${ref.current.scrollHeight}px`;
//     }
//   }, [value]);

//   return (
//     <textarea
//       ref={ref}
//       value={value}
//       onChange={onChange}
//       {...props}
//     />
//   );
// }

// export default function FieldInput({
//   field,
//   value,
//   onChange,
// }) {
//   const setValue = (val) =>
//     onChange(field.key, val);

//   return (
//     <div
//       className="
//         grid
//         grid-cols-1
//         md:grid-cols-[22%_1fr]
//         items-start
//       "
//     >
//       <div
//         className="
//           px-3
//           py-2
//           text-left
//           md:text-right
//           text-xs
//           font-semibold
//           text-gray-600
//           leading-snug
//           break-words
//         "
//       >
//         {field.label}

//         {field.required && (
//           <span className="ml-1 text-red-500">
//             *
//           </span>
//         )}
//       </div>

//       <div className="px-2 py-1 min-w-0">
//         {field.type === "readonly" && (
//           <div
//             className="
//               flex
//               min-h-[40px]
//               items-center
//               rounded-lg
//               border
//               border-gray-200
//               bg-gray-100
//               px-3
//               text-sm
//               text-gray-600
//             "
//           >
//             {value || "—"}
//           </div>
//         )}

//         {field.type === "datetime" && (
//           <input
//             type="datetime-local"
//             value={value}
//             onChange={(e) => setValue(e.target.value)}
//             className="
//               h-10
//               max-w-sm
//               rounded-lg
//               border
//               border-slate-300
//               bg-white
//               px-3
//               text-sm
//               text-gray-900
//               shadow-sm
//               outline-none
//               hover:border-slate-400
//               focus:border-red-600
//               focus:ring-2
//               focus:ring-red-100
//             "
//           />
//         )}

//         {field.type === "text" && (
//           <input
//             id={field.key}
//             type="text"
//             value={value}
//             onChange={(e) =>
//               setValue(e.target.value)
//             }
//             className="
//               h-10
//               w-full
//               rounded-lg
//               border
//               border-slate-300
//               bg-white
//               px-3
//               text-sm
//               text-gray-900
//               shadow-sm
//               outline-none
//               transition-all
//               hover:border-slate-400
//               focus:border-red-600
//               focus:ring-2
//               focus:ring-red-100
//             "
//           />
//         )}

//         {field.type === "checkbox-group" && (
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
//             {field.options.map((option) => (
//               <label
//                 key={option}
//                 className="flex items-center gap-2 text-sm"
//               >
//                 <input
//                   type="checkbox"
//                   checked={value.has(option)}
//                   onChange={() => field.onToggle(option)}
//                   className="h-4 w-4"
//                 />
//                 <span>{option}</span>
//               </label>
//             ))}
//           </div>
//         )}

//         {field.type === "radio" && (
//           <div className="flex items-center gap-6">
//             {field.options?.map((option) => (
//               <label
//                 key={option}
//                 className="flex items-center gap-2 cursor-pointer"
//               >
//                 <input
//                   type="radio"
//                   name={field.key}
//                   value={option}
//                   checked={value === option}
//                   onChange={() => setValue(option)}
//                   className="
//                     h-4
//                     w-4
//                     border-gray-300
//                     text-red-600
//                     focus:ring-red-500
//                   "
//                 />
//                 <span className="text-sm text-gray-700">
//                   {option}
//                 </span>
//               </label>
//             ))}
//           </div>
//         )}

//         {field.type === "textarea" && (
//           <AutoResizeTextarea
//             id={field.key}
//             value={value}
//             onChange={(e) =>
//               setValue(e.target.value)
//             }
//             className="
//               w-full
//               min-h-[42px]
//               overflow-hidden
//               rounded-lg
//               border
//               border-slate-300
//               bg-white
//               px-3
//               py-2
//               text-sm
//               text-gray-900
//               shadow-sm
//               outline-none
//               transition-all
//               hover:border-slate-400
//               focus:border-red-600
//               focus:ring-2
//               focus:ring-red-100
//               resize-none
//             "
//           />
//         )}

//         {field.type === "date" && (
//           <input
//             type="date"
//             value={value}
//             onChange={(e) =>
//               setValue(e.target.value)
//             }
//             className="
//               h-10
//               max-w-xs
//               rounded-lg
//               border
//               border-slate-300
//               bg-white
//               px-3
//               text-sm
//               text-gray-900
//               shadow-sm
//               outline-none
//               hover:border-slate-400
//               focus:border-red-600
//               focus:ring-2
//               focus:ring-red-100
//             "
//           />
//         )}

//         {field.type === "time" && (
//           <input
//             type="time"
//             value={value}
//             onChange={(e) =>
//               setValue(e.target.value)
//             }
//             className="
//               h-10
//               max-w-xs
//               rounded-lg
//               border
//               border-slate-300
//               bg-white
//               px-3
//               text-sm
//               text-gray-900
//               shadow-sm
//               outline-none
//               hover:border-slate-400
//               focus:border-red-600
//               focus:ring-2
//               focus:ring-red-100
//             "
//           />
//         )}

//         {field.type === "select" && (
//           <SearchableSelect
//             id={field.key}
//             value={value}
//             options={field.options || []}
//             onChange={setValue}
//             placeholder={
//               field.placeholder || "Select..."
//             }
//             disabled={field.disabled || false}
//             loading={field.loading || false}
//             hasMore={field.hasMore || false}
//             onLoadMore={field.onLoadMore}
//             onSearch={field.onSearch}
//             onOpen={field.onOpen}
//           />
//         )}

//         {field.hint && (
//           <p className="mt-1 text-xs text-gray-500">
//             {field.hint}
//           </p>
//         )}
//       </div>
//     </div>
//   );
// }



// components/FieldInput.jsx (updated - supports checkboxContainerClass)
//
// Backward-compatible:
// - If field.checkboxContainerClass is not provided, existing responsive multi-column layout is used.
// - Checkbox checked detection supports Set or Array.
// - Nested sub-options still supported via field.subOptionsMap / field.subKey / field.subValue / field.onToggleSub.
// components/FieldInput.jsx
"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, Search, Check, X } from "lucide-react";
import { useTranslation } from "@/lib/i18n";

function SearchableSelect({
  id,
  value,
  options = [],
  onChange,
  placeholder,
  disabled = false,
  invalid = false,
  loading = false,
  hasMore = false,
  onLoadMore,
  onSearch,
  onOpen,
}) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  // Options may be plain strings or { value, label }. The stored value is always
  // the canonical `value`; only the label is shown (and translated).
  const selectedLabel = useMemo(() => {
    if (value === undefined || value === null || value === "") return "";
    const match = (options || []).find((opt) => (typeof opt === "string" ? opt : opt?.value) === value);
    if (!match) return String(value);
    return typeof match === "string" ? match : match.label ?? match.value;
  }, [options, value]);
  const [displayOptions, setDisplayOptions] = useState(options);

  const containerRef = useRef(null);
  const scrollContainerRef = useRef(null);
  const scrollTimeoutRef = useRef(null);

  useEffect(() => {
    setDisplayOptions(options);
  }, [options]);

  const filtered = useMemo(() => {
    if (onSearch) return displayOptions;
    if (!search.trim()) return displayOptions;
    return displayOptions.filter((opt) => {
      const optLabel = typeof opt === "string" ? opt : opt.label;
      return String(optLabel).toLowerCase().includes(search.toLowerCase());
    });
  }, [displayOptions, search, onSearch]);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (!containerRef.current?.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      if (scrollTimeoutRef.current) clearTimeout(scrollTimeoutRef.current);
    };
  }, []);

  const handleSelect = (option) => {
    const selectedValue = typeof option === "string" ? option : option.value;
    onChange(selectedValue);
    setOpen(false);
    setSearch("");
  };

  const handleSearch = (term) => {
    setSearch(term);
    if (onSearch) onSearch(term);
  };

  const handleScroll = (e) => {
    const container = e.target;
    const isAtBottom =
      container.scrollHeight - container.scrollTop <= container.clientHeight + 50;
    if (isAtBottom && hasMore && !loading && onLoadMore) {
      if (scrollTimeoutRef.current) clearTimeout(scrollTimeoutRef.current);
      scrollTimeoutRef.current = setTimeout(() => onLoadMore(), 300);
    }
  };

  return (
    <div ref={containerRef} className="w-full">
      <button
        id={id}
        type="button"
        disabled={disabled}
        onClick={() => {
          if (!disabled) {
            setOpen(!open);
            setSearch("");
            if (!open && onOpen) onOpen();
          }
        }}
        className={`
          flex h-10 w-full items-center gap-2 rounded-lg px-3 text-left transition-all
          ${
            disabled
              ? "cursor-not-allowed border border-gray-200 bg-gray-100 opacity-60"
              : invalid
              ? "border-2 border-red-500 bg-white"
              : open
              ? "border-2 border-red-700 bg-white shadow-[0_0_0_3px_rgba(185,28,28,0.1)]"
              : "border border-slate-300 bg-white hover:border-slate-400"
          }
        `}
      >
        <span className={`flex-1 truncate text-sm ${value ? "font-medium text-gray-900" : "text-gray-400"}`}>
          {selectedLabel || placeholder || t("common.selectPlaceholder")}
        </span>

        {value && !disabled && (
          <span
            onMouseDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onChange("");
            }}
            className="flex h-5 w-5 items-center justify-center rounded-full bg-gray-100 hover:bg-red-100"
          >
            <X className="h-3 w-3 text-gray-500" />
          </span>
        )}

        <ChevronDown className={`h-4 w-4 text-gray-500 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="mt-2 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-xl z-50">
          {(displayOptions.length > 5 || onSearch) && (
            <div className="border-b border-gray-100 bg-gray-50 p-2 sticky top-0 z-10">
              <div className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 py-2">
                <Search className="h-4 w-4 text-gray-400" />
                <input
                  value={search}
                  onChange={(e) => handleSearch(e.target.value)}
                  placeholder={t("common.searchPlaceholder")}
                  autoFocus={open && onSearch}
                  className="flex-1 bg-transparent text-sm outline-none placeholder:text-gray-400"
                />
              </div>
            </div>
          )}

          <div ref={scrollContainerRef} className="max-h-64 overflow-y-auto" onScroll={handleScroll}>
            {loading && filtered.length === 0 ? (
              <div className="px-4 py-6 text-center text-sm text-gray-400">
                <div className="flex items-center justify-center gap-2">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                  <span>{t("common.loading")}</span>
                </div>
              </div>
            ) : filtered.length === 0 ? (
              <div className="px-4 py-6 text-center text-sm text-gray-400">{t("common.noOptions")}</div>
            ) : (
              filtered.map((option) => {
                const optionValue = typeof option === "string" ? option : option.value;
                const optionLabel = typeof option === "string" ? option : option.label || option.value;
                const selected = optionValue === value;
                return (
                  <button
                    key={optionValue}
                    type="button"
                    onClick={() => handleSelect(option)}
                    className={`flex w-full items-center gap-3 px-3 py-2 text-left text-sm transition-colors ${
                      selected ? "bg-red-50 text-red-700" : "text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    <span className={`${selected ? "bg-red-600" : "bg-transparent"} h-2 w-2 rounded-full`} />
                    <span className="flex-1 truncate">{optionLabel}</span>
                    {selected && <Check className="h-4 w-4" />}
                  </button>
                );
              })
            )}

            {loading && filtered.length > 0 && (
              <div className="px-4 py-2 text-center text-sm text-gray-400">
                <div className="flex items-center justify-center gap-2">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                  <span>{t("common.loadingMore")}</span>
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-gray-100 bg-gray-50 px-3 py-1 text-right text-xs text-gray-400">
            {t("common.optionsCount", { count: filtered.length })}
            {hasMore && onSearch && <span className="ml-2">• {t("common.scrollForMore")}</span>}
          </div>
        </div>
      )}
    </div>
  );
}

function AutoResizeTextarea({ value, onChange, ...props }) {
  const ref = useRef(null);
  useEffect(() => {
    if (ref.current) {
      ref.current.style.height = "auto";
      ref.current.style.height = `${ref.current.scrollHeight}px`;
    }
  }, [value]);
  return <textarea ref={ref} value={value} onChange={onChange} {...props} />;
}

const INPUT_OK =
  "border-slate-300 hover:border-slate-400 focus:border-red-600 focus:ring-2 focus:ring-red-100";
const INPUT_ERR = "border-red-500 bg-red-50/30 focus:border-red-600 focus:ring-2 focus:ring-red-100";
const DISABLED = "disabled:cursor-not-allowed disabled:bg-gray-100 disabled:text-gray-500";

export default function FieldInput({ field, value, onChange }) {
  const setValue = (val) => onChange(field.key, val);
  const invalid = Boolean(field?.error);
  const stateCls = `${invalid ? INPUT_ERR : INPUT_OK} ${DISABLED}`;
  const errorId = invalid ? `${field.key}-error` : undefined;
  const optionLabel = (option) =>
    typeof field.getOptionLabel === "function" ? field.getOptionLabel(option) : option;

  // Common props extraction with safe defaults
  const {
    placeholder,
    disabled,
    min,
    max,
    step,
    inputMode,
    pattern,
  } = field || {};

  return (
    <div className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start">
      <div className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
        {field.label}
        {field.required && <span className="ml-1 text-red-500">*</span>}
      </div>

      <div className="px-2 py-1 min-w-0">
        {field.type === "readonly" && (
          <div className="flex min-h-[40px] items-center rounded-lg border border-gray-200 bg-gray-100 px-3 text-sm text-gray-600">
            {field.displayValue ?? (value || "—")}
          </div>
        )}

        {field.type === "datetime" && (
          <input
            type="datetime-local"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            disabled={disabled}
            min={min}
            max={max}
            step={step}
            aria-invalid={invalid || undefined}
            aria-describedby={errorId}
            className={`h-10 max-w-sm rounded-lg border bg-white px-3 text-sm text-gray-900 shadow-sm outline-none ${stateCls}`}
          />
        )}

        {field.type === "text" && (
          <input
            id={field.key}
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={placeholder}
            disabled={disabled}
            inputMode={inputMode}
            pattern={pattern}
            aria-invalid={invalid || undefined}
            aria-describedby={errorId}
            className={`h-10 w-full rounded-lg border bg-white px-3 text-sm text-gray-900 shadow-sm outline-none transition-all ${stateCls}`}
          />
        )}

        {field.type === "checkbox-group" && (
          <>
            <div className={field.checkboxContainerClass || "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2"}>
              {field.options.map((option, optionIndex) => {
                const checked =
                  value && typeof value.has === "function"
                    ? value.has(option)
                    : Array.isArray(value)
                    ? value.includes(option)
                    : false;

                const checkboxClass =
                  field.checkboxClass || "h-4 w-4 mt-1 accent-red-600 bg-white border border-gray-300 rounded";
                const labelClass =
                  field.checkboxLabelClass ||
                  "grid grid-cols-[24px_1fr] items-start gap-2 text-sm cursor-pointer bg-transparent p-2 rounded";

                const handleTopToggle = () => {
                  if (typeof field.onToggle === "function") {
                    field.onToggle(option);
                    if (checked && field.subKey && field.subOptionsMap && field.subOptionsMap[option]) {
                      onChange(field.subKey, []);
                    }
                    return;
                  }
                  const currentArr = Array.isArray(value) ? [...value] : [];
                  const set = new Set(currentArr);
                  if (set.has(option)) set.delete(option);
                  else set.add(option);
                  const newArr = Array.from(set);
                  setValue(newArr);
                };

                return (
                  <div key={`${option}-${optionIndex}`} className="w-full">
                    <label className={labelClass}>
                      <input type="checkbox" checked={checked} onChange={handleTopToggle} className={checkboxClass} />
                      <span className="whitespace-normal break-words text-gray-700">{optionLabel(option)}</span>
                    </label>

                    {field.subOptionsMap &&
                      Array.isArray(field.subOptionsMap[option]) &&
                      checked && (
                        <div className="mt-2 ml-8 md:ml-10">
                          <div className="grid grid-cols-1 gap-1">
                            {field.subOptionsMap[option].map((subOpt, subIndex) => {
                              const subArr = Array.isArray(field.subValue) ? field.subValue : [];
                              const subChecked = subArr.includes(subOpt);

                              const handleSubToggle = () => {
                                if (typeof field.onToggleSub === "function") {
                                  field.onToggleSub(subOpt);
                                  return;
                                }
                                if (!field.subKey) return;
                                const cur = Array.isArray(field.subValue) ? [...field.subValue] : [];
                                const setSub = new Set(cur);
                                if (setSub.has(subOpt)) setSub.delete(subOpt);
                                else setSub.add(subOpt);
                                const newSubArr = Array.from(setSub);
                                onChange(field.subKey, newSubArr);
                              };

                              return (
                                <label
                                  key={`${subOpt}-${subIndex}`}
                                  className="grid grid-cols-[20px_1fr] gap-3 items-start text-sm cursor-pointer px-2 py-1 rounded hover:bg-red-50"
                                >
                                  <input
                                    type="checkbox"
                                    checked={subChecked}
                                    onChange={handleSubToggle}
                                    className={
                                      field.subCheckboxClass ||
                                      "h-4 w-4 mt-0.5 accent-red-600 bg-white border border-gray-300 rounded"
                                    }
                                  />
                                  <span className="text-gray-700 whitespace-normal break-words">{optionLabel(subOpt)}</span>
                                </label>
                              );
                            })}
                          </div>
                        </div>
                      )}
                  </div>
                );
              })}
            </div>
          </>
        )}

        {field.type === "radio" && (
          <div className="flex items-center gap-6">
            {field.options?.map((option) => {
              const optValue = typeof option === "string" ? option : option.value;
              const optLabel = typeof option === "string" ? option : option.label ?? option.value;
              return (
                <label key={optValue} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name={field.key}
                    value={optValue}
                    checked={value === optValue}
                    disabled={disabled}
                    onChange={() => setValue(optValue)}
                    className="h-4 w-4 border-gray-300 text-red-600 focus:ring-red-500"
                  />
                  <span className="text-sm text-gray-700">{optLabel}</span>
                </label>
              );
            })}
          </div>
        )}

        {field.type === "textarea" && (
          <AutoResizeTextarea
            id={field.key}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={placeholder}
            disabled={disabled}
            aria-invalid={invalid || undefined}
            aria-describedby={errorId}
            className={`w-full min-h-[42px] overflow-hidden rounded-lg border bg-white px-3 py-2 text-sm text-gray-900 shadow-sm outline-none transition-all resize-none ${stateCls}`}
          />
        )}

        {field.type === "date" && (
          <input
            type="date"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            disabled={disabled}
            min={min}
            max={max}
            aria-invalid={invalid || undefined}
            aria-describedby={errorId}
            className={`h-10 max-w-xs rounded-lg border bg-white px-3 text-sm text-gray-900 shadow-sm outline-none ${stateCls}`}
          />
        )}

        {field.type === "time" && (
          <input
            type="time"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            disabled={disabled}
            min={min}
            max={max}
            step={step}
            aria-invalid={invalid || undefined}
            aria-describedby={errorId}
            className={`h-10 max-w-xs rounded-lg border bg-white px-3 text-sm text-gray-900 shadow-sm outline-none ${stateCls}`}
          />
        )}

        {field.type === "select" && (
          <SearchableSelect
            id={field.key}
            value={value}
            options={field.options || []}
            onChange={setValue}
            placeholder={field.placeholder}
            disabled={field.disabled || false}
            invalid={invalid}
            loading={field.loading || false}
            hasMore={field.hasMore || false}
            onLoadMore={field.onLoadMore}
            onSearch={field.onSearch}
            onOpen={field.onOpen}
          />
        )}

        {field.hint && <p className="mt-1 text-xs text-gray-500">{field.hint}</p>}
        {invalid && (
          <p id={errorId} role="alert" className="mt-1 text-xs font-medium text-red-600">
            {field.error}
          </p>
        )}
      </div>
    </div>
  );
}
