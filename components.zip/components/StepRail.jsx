"use client";

import { AlertTriangle } from "lucide-react";
import { sectionStatus, STATUS_DOT } from "@/lib/status";
import { useTranslation } from "@/lib/i18n";

export default function StepRail({ sections, values, currentStep, onJump, invalidSections = {} }) {
  const { t } = useTranslation();
  const pct = Math.round(((currentStep + 1) / sections.length) * 100);

  return (
    <nav aria-label={t("stepRail.ariaLabel")} className="rounded-xl border border-jnj-line bg-white shadow-card">
      <div className="flex items-center justify-between gap-4 border-b border-jnj-line px-4 py-3">
        <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-jnj-slate">{t("stepRail.title")}</p>
        <div className="flex items-center gap-3 sm:w-64">
          <div className="h-1 flex-1 overflow-hidden rounded-full bg-jnj-line/70">
            <div className="h-full rounded-full bg-jnj-red transition-all duration-300" style={{ width: `${pct}%` }} />
          </div>
          <span className="flex-shrink-0 text-[11px] font-medium tabular-nums text-jnj-slate">
            {currentStep + 1} / {sections.length}
          </span>
        </div>
      </div>

      <div className="flex flex-wrap gap-2.5 p-4">
        {sections.map((s, i) => {
          const st = sectionStatus(s, values);
          const dot = STATUS_DOT[st.status];
          const isActive = i === currentStep;
          const missing = st.missing.length;
          const hasError = Object.keys(invalidSections[s.id] || {}).length > 0;
          const title = t(`sections.${s.id}`);

          const tooltip = hasError
            ? t("stepRail.hasErrors", { title })
            : st.total === 0
            ? title
            : missing > 0
            ? t("stepRail.missingRequired", { count: missing })
            : t("stepRail.allRequiredFilled", { title });

          return (
            <button
              key={s.id}
              onClick={() => onJump(i)}
              aria-current={isActive ? "step" : undefined}
              title={tooltip}
              className={`flex min-w-[140px] flex-1 items-center gap-2.5 rounded-lg border p-3 text-left transition ${
                isActive
                  ? "border-jnj-red bg-red-50/60 shadow-sm ring-1 ring-jnj-red/30"
                  : "border-jnj-line bg-white hover:border-jnj-red/40 hover:bg-jnj-mist/50"
              }`}
            >
              <span
                className={`grid h-7 w-7 flex-shrink-0 place-items-center rounded-full text-xs font-semibold tabular-nums transition ${
                  isActive ? "bg-jnj-red text-white" : "bg-white text-jnj-slate ring-1 ring-inset ring-jnj-line"
                }`}
              >
                {i + 1}
              </span>

              <span
                className={`min-w-0 flex-1 truncate text-xs leading-tight ${
                  isActive ? "font-semibold text-jnj-ink" : "text-jnj-ink/80"
                }`}
              >
                {title}
              </span>

              {hasError ? (
                <AlertTriangle className="h-4 w-4 flex-shrink-0 text-red-600" aria-label={t("stepRail.errorIcon")} />
              ) : (
                st.total > 0 &&
                (missing > 0 ? (
                  <span className="inline-flex h-5 min-w-[20px] flex-shrink-0 items-center justify-center rounded-full bg-amber-100 px-1.5 text-[11px] font-bold tabular-nums text-amber-700 ring-1 ring-inset ring-amber-200">
                    {missing}
                  </span>
                ) : (
                  <span className="h-2 w-2 flex-shrink-0 rounded-full" style={{ background: dot }} />
                ))
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
