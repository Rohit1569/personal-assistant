// components/modals/ErrorTrapAnalysisModal.jsx

"use client";

import { useState, useEffect } from "react";
import { Save, AlertCircle, ChevronDown } from "lucide-react";
import { ModalShell, ModalSubsection } from "./ModalShell";
import FieldInput from "@/components/FieldInput";
import { getErrorTrapsByCategory } from "@/lib/errorTrapApi";
import { ERROR_TRAP_CATEGORIES } from "@/app/constants/errorTraps";

const DEFAULT_FORM = {
  errorTrapCategory: "",
  errorTrap: "",
  why: "",
};

// Helper: normalize whatever we have into a valid category ID
const resolveCategoryId = (raw) => {
  if (!raw) return "";

  // Try to find a match by id, label, or "id. label"
  const found = ERROR_TRAP_CATEGORIES.find((cat) => {
    return (
      cat.id === raw ||
      cat.label === raw ||
      `${cat.id}. ${cat.label}` === raw ||
      (typeof raw === "string" && raw.startsWith(`${cat.id}.`))
    );
  });

  if (found) return found.id;

  // Fallback: extract leading digits before a dot, e.g., "02. Something"
  const match = typeof raw === "string" ? raw.match(/^(\d+)\./) : null;
  return match ? match[1] : "";
};

export default function ErrorTrapAnalysisModal({
  initialData = null,
  onClose,
  onSave,
}) {
  console.log(initialData, ">>>>>>>>>>>>>>>>>>>>>>>>");

  // As requested: category id comes from initialData.errorTrap (e.g., "04. ...") -> "04"
  const initialCategoryId = initialData?.errorTrap
    ? resolveCategoryId(initialData.errorTrap)
    : "";

  // As requested: keep initializer exactly as-is; errorTrap shows trapCategory text in the dropdown
  const [form, setForm] = useState(
    initialData
      ? {
          errorTrapCategory: initialCategoryId, // expected to be "04"
          errorTrap: initialData.trapCategory, // keep this text as-is for display
          why: initialData.analysis || "",
        }
      : DEFAULT_FORM
  );

  console.log(form, "llllllllllllllllllllllllllllllll");

  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [errorTrapOptions, setErrorTrapOptions] = useState([]);
  const [fetchingTraps, setFetchingTraps] = useState(false);
  const [trapError, setTrapError] = useState(null);

  const isEdit = !!initialData;

  const setField = (key, value) => {
    setForm((prev) => ({
      ...prev,
      [key]: key === "errorTrapCategory" ? resolveCategoryId(value) : value,
    }));

    if (errors[key]) {
      setErrors((prev) => ({
        ...prev,
        [key]: "",
      }));
    }
  };

  // Fetch error traps when category changes
  useEffect(() => {
    const catId = resolveCategoryId(form.errorTrapCategory);

    if (!catId) {
      setErrorTrapOptions([]);
      setTrapError(null);
      return;
    }

    const fetchTraps = async () => {
      setFetchingTraps(true);
      setTrapError(null);

      try {
        const traps = await getErrorTrapsByCategory(catId);
        // Normalize values to strings for reliable comparison
        const normalized = (traps || []).map((t) => ({
          value: String(t.value),
          label: t.label,
        }));
        setErrorTrapOptions(normalized);

        // IMPORTANT: Do NOT clear errorTrap here; keep preloaded text visible
        // setForm((prev) => ({ ...prev, errorTrap: "" }));
      } catch (error) {
        console.error("Error fetching traps:", error);
        setTrapError(
          "Failed to load error traps. Please select a valid category or try again."
        );
        setErrorTrapOptions([]);
      } finally {
        setFetchingTraps(false);
      }
    };

    fetchTraps();
  }, [form.errorTrapCategory]);

  const validateForm = () => {
    const newErrors = {};

    if (!form.errorTrapCategory) {
      newErrors.errorTrapCategory = "Error Trap Category is required";
    }

    if (!form.errorTrap) {
      newErrors.errorTrap = "Error Trap is required";
    }

    if (!form.why || form.why.trim() === "") {
      newErrors.why = "Why is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) return;

    setSaving(true);
    try {
      const normalized = {
        ...form,
        errorTrapCategory: resolveCategoryId(form.errorTrapCategory),
      };
      await onSave(normalized, false);
    } finally {
      setSaving(false);
    }
  };

  const handleSaveAndAddEntry = async () => {
    if (!validateForm()) return;

    setSaving(true);
    try {
      const normalized = {
        ...form,
        errorTrapCategory: resolveCategoryId(form.errorTrapCategory),
      };
      await onSave(normalized, true);
      // Reset form for next entry
      setForm(DEFAULT_FORM);
      setErrors({});
      setErrorTrapOptions([]);
    } finally {
      setSaving(false);
    }
  };

  const toolbarBtn =
    "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";

  const isCategorySelected = !!form.errorTrapCategory;

  const fields = [
    {
      key: "errorTrapCategory",
      label: "Error Trap Category",
      type: "select",
      options: ERROR_TRAP_CATEGORIES.map((cat) => ({
        value: cat.id,
        label: cat.label,
      })),
      required: true,
      description:
        "Please select an error trap category - if there is more than 1, you need to add them one by one.",
    },
    {
      key: "errorTrap",
      label: "Error Trap",
      type: "select",
      options: errorTrapOptions,
      required: true,
      disabled: !isCategorySelected || fetchingTraps,
      description: "Select an error trap from the list below",
    },
    {
      key: "why",
      label: "Why?",
      type: "textarea",
      required: true,
      description:
        'Do a deep dive into key areas and indicate an answer to one of the questions: "What contributed to... What made it complex to... Who is responsible for... Who manages... Who is impacted... When did this..."',
    },
  ];

  const renderRow = (field, content, required) => {
    return (
      <div
        className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start"
        key={field.key}
      >
        <div className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
          {field.label}
          {required && <span className="ml-1 text-red-500">*</span>}
        </div>
        <div className="px-2 py-1 min-w-0">{content}</div>
      </div>
    );
  };

  return (
    <ModalShell
      title={
        isEdit
          ? `Error Trap Analysis Details (${initialData.id})`
          : "New Error Trap Analysis"
      }
      onClose={onClose}
      maxWidth="max-w-6xl"
    >
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
        <button
          onClick={handleSave}
          disabled={saving}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red transition hover:text-jnj-red-dark disabled:opacity-50"
        >
          <Save className="h-4 w-4" />
          Save
        </button>

        {/* Optional: this currently only closes; rename if intentional */}
        <button
          onClick={onClose}
          disabled={saving}
          className={`${toolbarBtn} disabled:opacity-50`}
        >
          Save & Exit
        </button>

        <button
          onClick={handleSaveAndAddEntry}
          disabled={saving}
          className={`${toolbarBtn} disabled:opacity-50`}
        >
          Save & Add Entry
        </button>

        <button
          onClick={onClose}
          disabled={saving}
          className={`${toolbarBtn} disabled:opacity-50`}
        >
          Cancel
        </button>
      </div>

      <div className="max-h-[75vh] overflow-y-auto px-5 py-5">
        <h3 className="text-lg font-bold tracking-tight text-jnj-ink mb-6">
          {isEdit
            ? "Error Trap Analysis Details"
            : "New Error Trap Analysis"}
        </h3>

        <ModalSubsection title="Error Trap Analysis Details">
          <div className="mb-6 text-sm text-gray-600">
            <p>
              For more information about Error Traps, click here.{" "}
              <a href="#" className="text-blue-600 hover:underline">
                LINK
              </a>
            </p>
          </div>

          <div className="space-y-2 mb-4">
            {trapError && (
              <div className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700 flex items-center gap-2">
                <AlertCircle className="h-4 w-4 flex-shrink-0" />
                {trapError}
              </div>
            )}
          </div>

          <div className="space-y-4">
            {fields.map((field) => {
              const required = field.required || false;
              const disabled = field.disabled || false;

              // Error Trap Category - Radio buttons
              if (field.key === "errorTrapCategory") {
                return (
                  <div key={field.key}>
                    <div className="mb-2">
                      <label className="text-sm font-semibold text-gray-700">
                        <span className="text-red-500">*</span>{" "}
                        {field.label}
                      </label>
                      {field.description && (
                        <p className="text-xs text-gray-500 mt-1">
                          {field.description}
                        </p>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                      {ERROR_TRAP_CATEGORIES.map((category) => (
                        <label
                          key={category.id}
                          className="flex items-start gap-3 cursor-pointer hover:bg-gray-50 p-2 rounded transition"
                        >
                          <input
                            type="radio"
                            name="errorTrapCategory"
                            value={category.id}
                            checked={
                              form.errorTrapCategory === category.id
                            }
                            onChange={() =>
                              setField(
                                "errorTrapCategory",
                                category.id
                              )
                            }
                            className="mt-1 w-4 h-4 text-blue-600"
                          />
                          <span className="text-sm text-gray-700">
                            {category.label}
                          </span>
                        </label>
                      ))}
                    </div>

                    {errors.errorTrapCategory && (
                      <p className="text-red-500 text-sm">
                        {errors.errorTrapCategory}
                      </p>
                    )}
                  </div>
                );
              }

              // Error Trap - Select Dropdown
              if (field.key === "errorTrap") {
                // Try to find a matching option by value or label
                const match =
                  errorTrapOptions.find(
                    (o) => String(o.value) === String(form.errorTrap)
                  ) ||
                  errorTrapOptions.find(
                    (o) => String(o.label) === String(form.errorTrap)
                  );

                // If we have a match, use its value; otherwise keep select empty and show a placeholder
                const selectValue = match ? String(match.value) : "";

                // Placeholder should surface the preloaded text when there is no match
                const placeholderText = !isCategorySelected
                  ? "-- Select a category first --"
                  : fetchingTraps
                  ? "Loading error traps..."
                  : errorTrapOptions.length === 0
                  ? "No error traps available"
                  : match
                  ? "-- Select an Error Trap --"
                  : String(
                      form.errorTrap || "-- Select an Error Trap --"
                    );

                return renderRow(
                  field,
                  <div>
                    <div className="relative">
                      <select
                        value={selectValue}
                        onChange={(e) =>
                          setField("errorTrap", String(e.target.value))
                        }
                        disabled={disabled}
                        className={`w-full px-4 py-2.5 border rounded-lg font-medium transition appearance-none cursor-pointer pr-10 ${
                          disabled
                            ? "bg-gray-100 border-gray-300 text-gray-400 cursor-not-allowed opacity-60"
                            : "bg-white border-gray-300 text-gray-700 hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-jnj-red focus:border-transparent"
                        }`}
                      >
                        <option value="">{placeholderText}</option>

                        {errorTrapOptions.map((trap) => (
                          <option
                            key={trap.value}
                            value={String(trap.value)}
                          >
                            {trap.label}
                          </option>
                        ))}
                      </select>

                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                        <ChevronDown
                          className={`h-5 w-5 transition ${
                            disabled
                              ? "text-gray-400"
                              : "text-gray-600"
                          }`}
                        />
                      </div>
                    </div>

                    {errors.errorTrap && (
                      <p className="text-red-500 text-sm mt-2">
                        {errors.errorTrap}
                      </p>
                    )}
                  </div>,
                  required
                );
              }

              // Why - Textarea
              if (field.key === "why") {
                return renderRow(
                  field,
                  <div>
                    <textarea
                      value={form.why}
                      onChange={(e) =>
                        setField("why", e.target.value)
                      }
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-jnj-red focus:border-transparent resize-none"
                      placeholder="Enter your analysis..."
                    />
                    {errors.why && (
                      <p className="text-red-500 text-sm mt-2">
                        {errors.why}
                      </p>
                    )}
                  </div>,
                  required
                );
              }

              return null;
            })}
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
              <div className="flex-shrink-0 pt-0.5">
                <svg
                  className="w-5 h-5 text-blue-600"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                    clipRule="evenodd"
                  />
                </svg>
              </div>
              <p className="text-sm text-blue-900">
                If you have multiple possibilities, you need to create all
                separate items for this, by clicking 'Save and Add Entry' on
                top of this window.
              </p>
            </div>
          </div>
        </ModalSubsection>
      </div>
    </ModalShell>
  );
}
