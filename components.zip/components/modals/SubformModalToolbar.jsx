"use client";

import { CheckCircle2, Save } from "lucide-react";
import { useTranslation } from "@/lib/i18n";
import { SAVE_MODES } from "@/lib/subformRecords";

/**
 * Standard subform toolbar.
 *
 *   Save            -> onSave(SAVE_MODES.SAVE)            persist, stay open
 *   Save & Exit     -> onSave(SAVE_MODES.SAVE_AND_EXIT)   persist, add to grid, close
 *   Save & Add Entry-> onSave(SAVE_MODES.SAVE_AND_ADD)    persist, add to grid, blank entry
 *   Cancel          -> onCancel()
 */
export default function SubformModalToolbar({
  onSave,
  onCancel,
  busy = false,
  lastSavedAt,
  saveAndAddDisabled = false,
  saveAndAddDisabledReason,
}) {
  const { t } = useTranslation();
  const linkBtn =
    "text-sm font-medium text-jnj-slate transition hover:text-jnj-red disabled:cursor-not-allowed disabled:opacity-40";

  const savedTime = lastSavedAt
    ? new Date(lastSavedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    : null;

  return (
    <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
      <button
        type="button"
        disabled={busy}
        onClick={() => onSave(SAVE_MODES.SAVE)}
        className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red transition hover:text-jnj-red-dark disabled:opacity-40"
      >
        <Save className="h-4 w-4" />
        {t("actions.save")}
      </button>

      <button type="button" disabled={busy} onClick={() => onSave(SAVE_MODES.SAVE_AND_EXIT)} className={linkBtn}>
        {t("actions.saveAndExit")}
      </button>

      <button
        type="button"
        disabled={busy || saveAndAddDisabled}
        title={saveAndAddDisabled ? saveAndAddDisabledReason : undefined}
        onClick={() => onSave(SAVE_MODES.SAVE_AND_ADD)}
        className={linkBtn}
      >
        {t("actions.saveAndAddEntry")}
      </button>

      <button type="button" disabled={busy} onClick={onCancel} className={linkBtn}>
        {t("actions.cancel")}
      </button>

      {savedTime && (
        <span className="ml-auto inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700" role="status">
          <CheckCircle2 className="h-3.5 w-3.5" />
          {t("subform.savedAt", { time: savedTime })}
        </span>
      )}
    </div>
  );
}
