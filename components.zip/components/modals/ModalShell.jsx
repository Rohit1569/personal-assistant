"use client";

import { X, Info } from "lucide-react";
import { useTranslation } from "@/lib/i18n";

export function ModalShell({ title, onClose, children, maxWidth = "max-w-3xl" }) {
  const { t } = useTranslation();
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-jnj-ink/40 p-4 animate-overlay" onMouseDown={onClose}>
      <div className={`my-8 w-full ${maxWidth} overflow-hidden rounded-xl bg-white shadow-float animate-panel`} onMouseDown={(e) => e.stopPropagation()}>
        {/* Title bar */}
        <div className="flex items-center justify-between bg-[#1e6ec8] px-4 py-2.5">
          <span className="text-sm font-semibold text-white">{title}</span>
          <button onClick={onClose} aria-label={t("actions.close")} className="grid h-6 w-6 place-items-center rounded text-white/85 transition hover:bg-white/20 hover:text-white">
            <X className="h-4 w-4" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function ModalSubsection({ title, children }) {
  return (
    <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line first:mt-4">
      <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
        <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
          <Info className="h-3.5 w-3.5" />
        </span>
        <h4 className="text-sm font-bold text-jnj-ink">{title}</h4>
      </div>
      <div className="space-y-4 px-4 py-4">{children}</div>
    </div>
  );
}

// Small shared privacy note used across modals.
export function PrivacyNote({ children }) {
  return (
    <div className="mt-3 flex items-start gap-2.5 rounded-lg bg-sky-50/70 px-3.5 py-2.5 text-xs leading-relaxed text-sky-900 ring-1 ring-inset ring-sky-100">
      <Info className="mt-0.5 h-4 w-4 flex-shrink-0 text-sky-500" />
      <span>{children}</span>
    </div>
  );
}
