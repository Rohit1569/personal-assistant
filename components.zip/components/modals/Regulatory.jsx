// components/modals/Regulatory.jsx
"use client";

import { useEffect, useState } from "react";
import { Save, Paperclip, Pencil } from "lucide-react";

import { ModalShell, ModalSubsection, PrivacyNote } from "./ModalShell";
import FieldInput from "@/components/FieldInput";
import SubformTable from "@/components/SubformTable";

import {
  YES_NO_OPTIONS,
  IDENTIFIED_BY_OPTIONS,
  COMPANY_OPTIONS,
  AGENCY_TYPES,
  OUTCOME_OPTIONS,
  PENALTY_STATUS_OPTIONS,
} from "@/app/constants/regulatory";

import { getRegulatoryByIds, getFindingsByRegulatoryIds } from "@/lib/regulatoryApi";
import FindingsModal from "./FindingsModal";

/* ---------- helpers ---------- */

const DEFAULT_FORM = {
  identifiedBy: "",
  regulatoryReporting: "",
  companyType: "",
  contractorCompanyName: "",
  agencyType: "",
  agencyTypeOther: "",
  agencyName: "",
  reportedDate: "",
  inspectionDate: "",
  incidentRelated: "",
  penaltyAmount: "",
  penaltyStatus: "",
  amountPaid: "",
  paymentDate: "",
  payeeName: "",
  sif: "",
  escalationRequired: "No",
  comments: "",
  sensitiveInformation: "No",
  outcomes: [], // multi-select (kept for compatibility; UI uses Set)
  outcomeOther: "",
};

const isProvided = (v) =>
  v !== undefined && v !== null && String(v).trim() !== "";

const toYesNo = (val) => {
  if (val === true || val === 1 || String(val).toLowerCase() === "yes") return "Yes";
  if (val === false || val === 0 || String(val).toLowerCase() === "no") return "No";
  return val == null ? "" : String(val);
};

// Format ISO/date string to yyyy-mm-dd (for input[type="date"])
const toDateInput = (d) => {
  if (!d) return "";
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return "";
  const yyyy = dt.getFullYear();
  const mm = String(dt.getMonth() + 1).padStart(2, "0");
  const dd = String(dt.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
};

const norm = (s) => String(s || "").trim().toLowerCase();
const mapCaptionToOption = (caption, options) => {
  if (!caption) return "";
  const c = norm(caption);
  return (
    options.find((o) => norm(o) === c) ||
    options.find((o) => norm(o).includes(c) || c.includes(norm(o))) ||
    ""
  );
};

// Derive penalty status from "paid" fields if present (fallback)
const derivePenaltyStatus = (amountPaid, paymentDate) => {
  const paid =
    (typeof amountPaid === "number" && amountPaid > 0) ||
    (typeof amountPaid === "string" && Number(amountPaid) > 0) ||
    Boolean(paymentDate);

  if (paid) {
    const paidOpt =
      PENALTY_STATUS_OPTIONS.find((o) => norm(o) === "paid") || "Paid";
    return paidOpt;
  }
  return "";
};

// Labels used for conditional logic (ensure they match your constants)
const SELF_IDENTIFIED_LABEL = "Self-Identified/Inspection";
const CONTRACTOR_COMPANY_LABEL = "Contractor Company";
const AGENCY_OTHER_LABEL = "Other (Please Specify)";
const OUTCOME_OTHER_LABEL =
  OUTCOME_OPTIONS.find((o) => norm(o).includes("other")) || "Other (specify)";
const OUTCOME_PENALTY_LABEL =
  OUTCOME_OPTIONS.find((o) => norm(o) === "penalty or fine") || "Penalty or Fine";

const TODAY_YYYY_MM_DD = toDateInput(new Date());
const isDateOnOrBeforeToday = (dateStr) => {
  if (!dateStr) return true;
  const sel = new Date(dateStr);
  const today = new Date();
  sel.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);
  return sel <= today;
};

/* ---------- component ---------- */

export default function NewRegulatoryEventModal({
  onClose,
  incidentMasterNo,
  incidentRecordNo,
  eventId,
  recordNo,
}) {
  const [form, setForm] = useState(DEFAULT_FORM);
  const [loading, setLoading] = useState(false);
  const [outcomes, setOutcomes] = useState(new Set());

  // Findings state (shown when incidentRelated === "Yes")
  const [findingsLoading, setFindingsLoading] = useState(false);
  const [findingsRows, setFindingsRows] = useState([]);
  const [showFindingsModal, setShowFindingsModal] = useState(false);
  const [selectedFindingRow, setSelectedFindingRow] = useState(null);
  const [editingFindingRecordNo, setEditingFindingRecordNo] = useState(null);

  // prefer new props, fallback to legacy
  const masterNo = isProvided(incidentMasterNo) ? incidentMasterNo : eventId;
  const detailNo = isProvided(incidentRecordNo) ? incidentRecordNo : recordNo;
  const isEdit = isProvided(masterNo) && isProvided(detailNo);

  const setField = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const toggleOutcome = (val) => {
    setOutcomes((prev) => {
      const next = new Set(prev);
      next.has(val) ? next.delete(val) : next.add(val);
      return next;
    });
  };

  useEffect(() => {
    let cancelled = false;

    if (!isEdit) {
      setForm(DEFAULT_FORM);
      setOutcomes(new Set());
      setLoading(false);
      return;
    }

    const load = async () => {
      try {
        setLoading(true);
        const data = await getRegulatoryByIds(masterNo, detailNo);
        if (cancelled) return;

        if (data) {
          // Map core fields from API
          const identifiedBy =
            mapCaptionToOption(data?.Source?.Caption, IDENTIFIED_BY_OPTIONS) ||
            data?.Source?.Caption ||
            "";

          const regulatoryReporting = toYesNo(data?.RegRptRequired);

          const companyType =
            mapCaptionToOption(data?.IsThisRegRep?.RCRelatedComp, COMPANY_OPTIONS) ||
            data?.IsThisRegRep?.RCRelatedComp ||
            "";

          const contractorCompanyName = data?.ContComName || "";

          const agencyType =
            mapCaptionToOption(data?.RegulatorAgency?.Caption, AGENCY_TYPES) ||
            data?.RegulatorAgency?.Caption ||
            "";

          const agencyTypeOther = data?.OTHRegAgency || "";

          const agencyName = data?.AgencyName || "";
          const reportedDate = toDateInput(data?.DTReprtedAgency);
          const inspectionDate = toDateInput(data?.DateofIdentfctn);

          const incidentRelated = toYesNo(data?.FndingsReported); // Were findings reported/identified as a result of this Incident?
          const comments = data?.Commnt || data?.Description || "";
          const sif = toYesNo(data?.JJSIFReg);
          const escalationRequired = toYesNo(data?.Escalation) || "No";
          const sensitiveInformation = toYesNo(data?.Sensitive) || "No";

          const penaltyAmount =
            data?.ftheIncidentUSD != null ? String(data.ftheIncidentUSD) : "";

          const amountPaid =
            data?.thAmountPaidUSD != null ? String(data.thAmountPaidUSD) : "";

          const paymentDate = toDateInput(data?.EthePaymentDate);
          const payeeName = data?.tNameofthePayee || "";

          // Penalty status from API (preferred), fallback to derived if absent
          const penaltyStatusFromApi =
            mapCaptionToOption(data?.UndeNegotiation?.Caption, PENALTY_STATUS_OPTIONS) ||
            derivePenaltyStatus(data?.thAmountPaidUSD, data?.EthePaymentDate) ||
            "";

          // Outcomes mapping strictly from frothisIncident (API source of truth)
          const outcomeSeed = new Set();
          if (Array.isArray(data?.frothisIncident)) {
            data.frothisIncident.forEach((o) => {
              const mapped = mapCaptionToOption(o?.Caption, OUTCOME_OPTIONS);
              if (mapped) outcomeSeed.add(mapped);
            });
          }

          const outcomeOther = data?.SpeOtherOutcome || "";

          // Enforce: Penalty or Fine outcome must be selected when assessed/under negotiation/paid
          const mustSelectPenaltyOutcome =
            Number(penaltyAmount) > 0 ||
            norm(penaltyStatusFromApi).includes("negotiation") ||
            norm(penaltyStatusFromApi).includes("paid") ||
            Number(amountPaid) > 0 ||
            Boolean(paymentDate);

          if (mustSelectPenaltyOutcome) {
            outcomeSeed.add(OUTCOME_PENALTY_LABEL);
          }

          setOutcomes(outcomeSeed);

          setForm((prev) => ({
            ...prev,
            identifiedBy,
            regulatoryReporting,
            companyType,
            contractorCompanyName,
            agencyType,
            agencyTypeOther,
            agencyName,
            reportedDate,
            inspectionDate,
            incidentRelated,
            penaltyAmount,
            penaltyStatus: penaltyStatusFromApi,
            amountPaid,
            paymentDate,
            payeeName,
            sif,
            escalationRequired,
            comments,
            sensitiveInformation,
            outcomeOther,
          }));
        } else {
          setForm(DEFAULT_FORM);
          setOutcomes(new Set());
        }
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error("Error loading Regulatory record:", e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [isEdit, masterNo, detailNo]);

  // Enforce business rule:
  // If identifiedBy is not "Self-Identified/Inspection":
  // - regulatoryReporting is not mandatory, is disabled, and value must be "Yes".
  useEffect(() => {
    const isSelf = form.identifiedBy === SELF_IDENTIFIED_LABEL;
    if (!isSelf && form.regulatoryReporting !== "Yes") {
      setForm((p) => ({ ...p, regulatoryReporting: "Yes" }));
    }
  }, [form.identifiedBy, form.regulatoryReporting]);

  // Enforce: Date of Identification must be on or before today
  useEffect(() => {
    if (form.inspectionDate && !isDateOnOrBeforeToday(form.inspectionDate)) {
      setForm((p) => ({ ...p, inspectionDate: TODAY_YYYY_MM_DD }));
    }
  }, [form.inspectionDate]);

  // Load Findings when incidentRelated === "Yes" and IDs present
  useEffect(() => {
    let cancelled = false;

    async function loadFindings() {
      if (!isEdit) {
        setFindingsRows([]);
        return;
      }
      if (form.incidentRelated !== "Yes") {
        setFindingsRows([]);
        return;
      }

      try {
        setFindingsLoading(true);
        const { findings } = await getFindingsByRegulatoryIds(masterNo, detailNo);
        if (cancelled) return;

        // Add pencil icon and row keys
        const rowsWithUi = findings.map((row, index) => ({
          ...row,
          edit: (
            <button
              type="button"
              onClick={() => handleEditFinding(row)}
              className="inline-flex items-center text-jnj-slate hover:text-jnj-red"
              title="Edit Finding"
            >
              <Pencil className="h-4 w-4" />
            </button>
          ),
          _rowKey: row.findingNo ?? `${row.description}-${index}`,
        }));

        setFindingsRows(rowsWithUi);
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error("Error loading Findings:", e);
        setFindingsRows([]);
      } finally {
        if (!cancelled) setFindingsLoading(false);
      }
    }

    loadFindings();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isEdit, masterNo, detailNo, form.incidentRelated]);

  // Auto-select "Penalty or Fine" outcome when penalty fields indicate assessed/negotiation/paid
  useEffect(() => {
    const mustSelectPenaltyOutcome =
      Number(form.penaltyAmount) > 0 ||
      norm(form.penaltyStatus).includes("negotiation") ||
      norm(form.penaltyStatus).includes("paid") ||
      Number(form.amountPaid) > 0 ||
      Boolean(form.paymentDate);

    if (mustSelectPenaltyOutcome && !outcomes.has(OUTCOME_PENALTY_LABEL)) {
      setOutcomes((prev) => {
        const next = new Set(prev);
        next.add(OUTCOME_PENALTY_LABEL);
        return next;
      });
    }
  }, [form.penaltyAmount, form.penaltyStatus, form.amountPaid, form.paymentDate, outcomes]);

  const handleAddFinding = () => {
    setSelectedFindingRow(null);
    setEditingFindingRecordNo(null);
    setShowFindingsModal(true);
  };

  const handleEditFinding = (row) => {
    setSelectedFindingRow(row);
    setEditingFindingRecordNo(row?.findingNo ?? null);
    setShowFindingsModal(true);
  };

  const handleDeleteFinding = (rowId) => {
    setFindingsRows((prev) => prev.filter((r) => r.id !== rowId));
  };

  const handleSaveFinding = (formData, addAnother) => {
    // Update existing (by findingNo) or add new
    if (formData?.recordNo || editingFindingRecordNo) {
      const key = String(formData?.recordNo ?? editingFindingRecordNo);
      setFindingsRows((prev) =>
        prev.map((r) =>
          String(r.findingNo) === key
            ? {
                ...r,
                description: formData.description,
                findingType: formData.findingType,
                complianceActivity: formData.complianceActivity,
                repeated: formData.repeated,
                classificationPriority: formData.classificationPriority,
                numNonCompliances: formData.numNonCompliances,
                status: formData.status,
              }
            : r
        )
      );
    } else if (selectedFindingRow) {
      setFindingsRows((prev) =>
        prev.map((r) =>
          r.id === selectedFindingRow.id
            ? {
                ...r,
                description: formData.description,
                findingType: formData.findingType,
                complianceActivity: formData.complianceActivity,
                repeated: formData.repeated,
                classificationPriority: formData.classificationPriority,
                numNonCompliances: formData.numNonCompliances,
                status: formData.status,
              }
            : r
        )
      );
    } else {
      const newRow = {
        id: Math.random(),
        findingNo: formData.recordNo ?? "",
        description: formData.description,
        findingType: formData.findingType,
        complianceActivity: formData.complianceActivity,
        repeated: formData.repeated,
        classificationPriority: formData.classificationPriority,
        numNonCompliances: formData.numNonCompliances,
        status: formData.status,
      };
      setFindingsRows((prev) => [...prev, newRow]);
    }

    if (!addAnother) {
      setShowFindingsModal(false);
      setSelectedFindingRow(null);
      setEditingFindingRecordNo(null);
    }
  };

  const toolbarBtn =
    "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";

  const isOutcomeChecked = (label) => outcomes.has(label);

  const findingsColumns = [
    { key: "edit", label: "" },
    { key: "findingNo", label: "Finding No." },
    { key: "description", label: "Description" },
    { key: "findingType", label: "Finding Type" },
    { key: "complianceActivity", label: "Compliance Activity" },
    { key: "repeated", label: "Repeated?" },
    { key: "classificationPriority", label: "Classification/Priority" },
    { key: "numNonCompliances", label: "# Non-Compliances" },
    { key: "status", label: "Status" },
  ];

  const showFindings = form.incidentRelated === "Yes";

  // Conditional flags
  const isSelfIdentified = form.identifiedBy === SELF_IDENTIFIED_LABEL;
  const isContractorCompany = form.companyType === CONTRACTOR_COMPANY_LABEL;
  const isAgencyOther = form.agencyType === AGENCY_OTHER_LABEL;
  const isPenaltyOutcomeSelected =
    isOutcomeChecked(OUTCOME_PENALTY_LABEL) ||
    Array.from(outcomes).some((o) => norm(o) === "penalty or fine");
  const isOutcomeOtherSelected =
    isOutcomeChecked(OUTCOME_OTHER_LABEL) ||
    Array.from(outcomes).some((o) => norm(o).includes("other"));
  const penaltyStatusIsRescindedOrPaid =
    norm(form.penaltyStatus).includes("rescinded") || norm(form.penaltyStatus).includes("paid");

  const inspectionDateError =
    form.inspectionDate && !isDateOnOrBeforeToday(form.inspectionDate)
      ? "Date of Identification must be on or before Today."
      : "";

  return (
    <ModalShell
      title={isEdit ? `Regulatory Event (${detailNo})` : "Add Entry"}
      onClose={onClose}
      maxWidth="max-w-7xl"
    >
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
        <button className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red">
          <Save className="h-4 w-4" />
          Save
        </button>

        <button className={toolbarBtn}>Save & Exit</button>

        <button onClick={onClose} className={toolbarBtn}>
          Cancel
        </button>
      </div>

      <div className="max-h-[85vh] overflow-y-auto px-5 py-5">
        <h2 className="mb-4 text-2xl font-bold text-jnj-ink">
          {isEdit ? "Regulatory Event Detail" : "New Regulatory Event"}
        </h2>

        <PrivacyNote>This regulatory event has not been saved.</PrivacyNote>

        {/* Master Event Information */}
        <ModalSubsection title="Master Event Information">
          <FieldInput
            field={{ key: "masterRecord", label: "Master Record No.", type: "readonly" }}
            value={isProvided(masterNo) ? `Incident #${masterNo}` : "Incident # -"}
            onChange={() => {}}
          />
        </ModalSubsection>

        {loading ? (
          <div className="py-8 text-center text-sm text-slate-500">
            Loading Regulatory details...
          </div>
        ) : (
          <>
            {/* Regulatory Details */}
            <ModalSubsection title="Regulatory Details">
              <FieldInput
                field={{
                  key: "identifiedBy",
                  label: "Who Identified the Findings or did the Inspection",
                  required: true,
                  type: "select",
                  options: IDENTIFIED_BY_OPTIONS,
                }}
                value={form.identifiedBy}
                onChange={setField}
              />

              {/* Conditionally mandatory/disabled per business rule */}
              <FieldInput
                field={{
                  key: "regulatoryReporting",
                  label:
                    "Does this require regulatory reporting in your region or was this identified/reported by the regulatory agency?",
                  type: "select",
                  options: YES_NO_OPTIONS,
                  required: isSelfIdentified,
                  disabled: !isSelfIdentified, // disabled when not self-identified
                }}
                value={form.regulatoryReporting}
                onChange={setField}
              />

              <FieldInput
                field={{
                  key: "companyType",
                  label: "Is this regulatory report related to J&J or a contractor company?",
                  required: true,
                  type: "select",
                  options: COMPANY_OPTIONS,
                }}
                value={form.companyType}
                onChange={setField}
              />

              {/* Contractor Company Name (required when companyType is Contractor Company) */}
              {isContractorCompany && (
                <FieldInput
                  field={{
                    key: "contractorCompanyName",
                    label: "Contractor Company Name",
                    required: true,
                    type: "text",
                  }}
                  value={form.contractorCompanyName}
                  onChange={setField}
                />
              )}

              <FieldInput
                field={{
                  key: "agencyType",
                  label: "Select the Highest Type of Regulatory Agency",
                  required: true,
                  type: "select",
                  options: AGENCY_TYPES,
                }}
                value={form.agencyType}
                onChange={setField}
              />

              {/* Other Type of Regulatory Agency (required when agencyType is Other) */}
              {isAgencyOther && (
                <FieldInput
                  field={{
                    key: "agencyTypeOther",
                    label: "Other Type of Regulatory Agency",
                    required: true,
                    type: "text",
                  }}
                  value={form.agencyTypeOther}
                  onChange={setField}
                />
              )}

              <FieldInput
                field={{ key: "agencyName", label: "Enter the Name of the Regulatory Agency", type: "text" }}
                value={form.agencyName}
                onChange={setField}
              />

              <FieldInput
                field={{ key: "reportedDate", label: "Date and Time Reported to Agency", type: "date" }}
                value={form.reportedDate}
                onChange={setField}
              />

              <FieldInput
                field={{
                  key: "inspectionDate",
                  label: "Date and Time of Identification or Inspection",
                  required: true,
                  type: "date",
                  max: TODAY_YYYY_MM_DD, // UI enforcement: cannot select a future date
                }}
                value={form.inspectionDate}
                onChange={setField}
              />
              {inspectionDateError && (
                <div className="mt-1 text-xs text-red-600">{inspectionDateError}</div>
              )}

              <FieldInput
                field={{
                  key: "incidentRelated",
                  label: "Were findings being reported / identified as a result of this Incident?",
                  type: "select",
                  options: YES_NO_OPTIONS,
                }}
                value={form.incidentRelated}
                onChange={setField}
              />

              {/* Show guidance text when incidentRelated is Yes */}
              {form.incidentRelated === "Yes" && (
                <PrivacyNote>
                  To add findings and update the number of non-compliances being reported/identified,
                  please click Save and Create New in the Findings Section.
                </PrivacyNote>
              )}
            </ModalSubsection>

            {/* Findings (conditional) */}
            {showFindings && (
              <ModalSubsection title="Findings">
                {findingsLoading ? (
                  <div className="py-4 text-center text-sm text-slate-500">
                    Loading Findings...
                  </div>
                ) : (
                  <SubformTable
                    addLabel="Create New Finding"
                    actions={["Edit", "Delete", "List All"]}
                    columns={findingsColumns}
                    rows={findingsRows}
                    emptyText="No findings to display."
                    onAdd={(action) => {
                      if (action === "Create New Finding") {
                        handleAddFinding();
                      } else {
                        // default add button behavior
                        handleAddFinding();
                      }
                    }}
                    onRowClick={(row) => handleEditFinding(row)}
                    onAction={(action, row) => {
                      if (action === "Edit") handleEditFinding(row);
                      if (action === "Delete") handleDeleteFinding(row.id);
                    }}
                  />
                )}
              </ModalSubsection>
            )}

            {/* Outcome Details */}
            <ModalSubsection title="Outcome Details">
              <div className="grid grid-cols-1 gap-6 md:grid-cols-[24%_38%_38%]">
                <div className="text-sm font-semibold text-slate-700">
                  Select All Outcomes Resulting from this Incident
                </div>

                <div className="space-y-2">
                  {OUTCOME_OPTIONS.slice(0, Math.ceil(OUTCOME_OPTIONS.length / 2)).map((item) => (
                    <label key={item} className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={isOutcomeChecked(item)}
                        onChange={() => toggleOutcome(item)}
                      />
                      {item}
                    </label>
                  ))}
                </div>

                <div className="space-y-2">
                  {OUTCOME_OPTIONS.slice(Math.ceil(OUTCOME_OPTIONS.length / 2)).map((item) => (
                    <label key={item} className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={isOutcomeChecked(item)}
                        onChange={() => toggleOutcome(item)}
                      />
                      {item}
                    </label>
                  ))}
                </div>
              </div>

              {/* If outcomes include Other (specify) → required text field */}
              {isOutcomeOtherSelected && (
                <FieldInput
                  field={{
                    key: "outcomeOther",
                    label: "Please Specify Other Outcome",
                    required: true,
                    type: "text",
                  }}
                  value={form.outcomeOther}
                  onChange={setField}
                />
              )}

              {/* Penalty details; mandatory if "Penalty or Fine" outcome selected */}
              <FieldInput
                field={{
                  key: "penaltyAmount",
                  label: "Enter Penalties or Fines Assessed for the Incident (USD)",
                  type: "text",
                  required: isPenaltyOutcomeSelected,
                }}
                value={form.penaltyAmount}
                onChange={setField}
              />

              <FieldInput
                field={{
                  key: "penaltyStatus",
                  label: "Has the Penalty or Fine Been Paid or is it Still Under Negotiation?",
                  type: "select",
                  options: PENALTY_STATUS_OPTIONS,
                  required: isPenaltyOutcomeSelected,
                }}
                value={form.penaltyStatus}
                onChange={setField}
              />

              {/* If penalty status is "Rescinded or paid" → show additional fields */}
              {penaltyStatusIsRescindedOrPaid && (
                <>
                  <FieldInput
                    field={{
                      key: "amountPaid",
                      label: "Enter the Amount Paid (USD)",
                      type: "text",
                      required: true,
                    }}
                    value={form.amountPaid}
                    onChange={setField}
                  />

                  <FieldInput
                    field={{
                      key: "paymentDate",
                      label: "Enter the Payment/Rescinded Date",
                      type: "date",
                      required: true,
                    }}
                    value={form.paymentDate}
                    onChange={setField}
                  />

                  <FieldInput
                    field={{
                      key: "payeeName",
                      label: "Enter the Name of the Payee",
                      type: "text",
                    }}
                    value={form.payeeName}
                    onChange={setField}
                  />
                </>
              )}

              <PrivacyNote>
                To view the Severe Impact or Fatality Prevention Program click here -
                <a
                  href="https://jnj.sharepoint.com/teams/WWEHSS/incident-curve#escalation-process-for-ehs-s-incidents"
                  target="_blank"
                  rel="noreferrer"
                  className="ml-1 text-sky-600 hover:underline"
                >
                  LINK
                </a>
              </PrivacyNote>

              <FieldInput
                field={{ key: "sif", label: "J&J SIF", type: "select", options: YES_NO_OPTIONS }}
                value={form.sif}
                onChange={setField}
              />

              <PrivacyNote>
                To view the Incident Reporting Guidelines click here -
                <button className="ml-1 text-sky-600 hover:underline">LINK</button>
              </PrivacyNote>

              <div className="mt-5 border-t border-jnj-line pt-5">
                <FieldInput
                  field={{
                    key: "escalationRequired",
                    label:
                      "J&J Escalation required beyond site management (Regulatory - Escalation Guideline)",
                    type: "select",
                    options: YES_NO_OPTIONS,
                  }}
                  value={form.escalationRequired}
                  onChange={setField}
                />

                <PrivacyNote>
                  If the field "J&J Escalation required beyond site management" is YES and you wish to
                  change this, please review the fields triggering the escalation. Overrides require
                  justification in the master event.
                </PrivacyNote>
              </div>

              <div className="mt-5 border-t border-jnj-line pt-5">
                <FieldInput field={{ key: "comments", label: "Comment", type: "textarea" }} value={form.comments} onChange={setField} />
              </div>
            </ModalSubsection>

            {/* Sensitive Information */}
            <ModalSubsection title="Sensitive Information">
              <FieldInput
                field={{
                  key: "sensitiveInformation",
                  label: "Sensitive Information Included in this form?",
                  type: "select",
                  options: YES_NO_OPTIONS,
                }}
                value={form.sensitiveInformation}
                onChange={setField}
              />
            </ModalSubsection>

            {/* Attachments */}
            <ModalSubsection title="Pictures and Attachments">
              <SubformTable
                addLabel="Attach Document"
                actions={["Detach Document", "List All"]}
                columns={[
                  { key: "attachmentName", label: "Attachment Name" },
                  { key: "url", label: "URL" },
                ]}
                rows={[]}
                emptyText="No records to display."
                onAdd={() => {}}
              />

              <PrivacyNote>
                Pictures and Attachments: Do not publish or disclose pictures containing personal
                information, recognizable persons, or any other private information.
              </PrivacyNote>
            </ModalSubsection>
          </>
        )}
      </div>

      {showFindingsModal && (
        <FindingsModal
          masterRecordNo={masterNo}
          regulatoryRecordNo={detailNo}
          findingRecordNo={editingFindingRecordNo}
          initialData={selectedFindingRow}
          onClose={() => {
            setShowFindingsModal(false);
            setSelectedFindingRow(null);
            setEditingFindingRecordNo(null);
          }}
          onSave={handleSaveFinding}
        />
      )}
    </ModalShell>
  );
}
