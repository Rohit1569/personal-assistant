// components/modals/LostTimeModal.jsx

"use client";

import { useEffect, useState } from "react";
import { Save } from "lucide-react";
import { ModalShell, ModalSubsection } from "./ModalShell";
import FieldInput from "@/components/FieldInput";
import { losttimebyrecodno } from "@/lib/lostTimeApi";

const LOST_TIME_CATEGORIES = [
  "Temporary Total Disability",
  "Permanent Total Disability",
  "Permanent Partial Disability",
  "Medical Treatment Only",
];

const LOST_TIME_TYPES = [
  "Lost Workday Case",
  "Restricted Work Case",
  "Job Transfer Case",
  "Medical Treatment Only",
];

const LWDC_OPTIONS = ["Yes", "No"];

const DEFAULT_FORM = {
  fromDate: "",
  toDate: "",
  calendarDaysAway: "",
  workPercentPerDay: "100",
  numberOfDaysPerWeekRemoved: "",
  numberOfHolidays: "",
  workingDaysAway: "",
  category: "",
  type: "",
  lwdc: "No",
};

// Extract the key from OData ID, e.g. ...LostTimeObject(GUID)
function extractIdFromOdataId(odataId) {
  if (!odataId || typeof odataId !== "string") return null;
  const match = odataId.match(/$([^)]+)$$/);
  return match ? match[1] : null;
}

function fmtDateISO(dateStr) {
  if (!dateStr) return "";
  try {
    return new Date(dateStr).toISOString().split("T")[0];
  } catch {
    return "";
  }
}

export default function LostTimeModal({
  initialData = null,
  onClose,
  onSave,

  // Props for API prefill (edit mode)
  masterRecordNo,
  injuryRecordNo,
  lostTimeRecordNo, // may be numeric RecordNo or GUID key from @odata.id
}) {
  const [form, setForm] = useState(
    initialData
      ? {
          fromDate: initialData.fromDate || "",
          toDate: initialData.toDate || "",
          calendarDaysAway: initialData.calendarDaysAway || "",
          workPercentPerDay: initialData.workPercentPerDay || "100",
          numberOfDaysPerWeekRemoved: initialData.numberOfDaysPerWeekRemoved || "",
          numberOfHolidays: initialData.numberOfHolidays || "",
          workingDaysAway: initialData.workingDaysAway || "",
          category: initialData.category || "",
          type: initialData.type || "",
          lwdc: initialData.lwdc || "No",
        }
      : DEFAULT_FORM
  );

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const isEdit = Boolean(lostTimeRecordNo) || Boolean(initialData);

  // Always call the API when masterRecordNo & injuryRecordNo exist.
  useEffect(() => {
    let cancelled = false;

    async function prefill() {
      if (!masterRecordNo || !injuryRecordNo) return;

      try {
        setLoading(true);

        const data = await losttimebyrecodno(masterRecordNo, injuryRecordNo);
        const rows = Array.isArray(data?.lostTimeRecords) ? data.lostTimeRecords : [];
        if (!rows.length) return;

        // If a specific record/key was provided, try to find it; otherwise default to the first row
        let match = null;
        if (lostTimeRecordNo) {
          for (const r of rows) {
            const raw = r?.raw || {};
            const recNo = raw?.RecordNo;
            const guidFromOdata = extractIdFromOdataId(raw?.["@odata.id"]);
            const rawId = raw?.Id;

            if (
              (recNo != null && String(recNo) === String(lostTimeRecordNo)) ||
              (guidFromOdata && String(guidFromOdata) === String(lostTimeRecordNo)) ||
              (rawId && String(rawId) === String(lostTimeRecordNo))
            ) {
              match = r;
              break;
            }
          }
        }

        const row = match || rows[0];
        const raw = row?.raw || {};

        // STRICT direct mapping from API LostTime array for the three fields
        setForm({
          // Dates and computed fields from raw preferred
          fromDate: fmtDateISO(raw?.FromDate ?? row.fromDate),
          toDate: fmtDateISO(raw?.ToDate ?? row.toDate),
          calendarDaysAway: raw?.CalendarDays ?? row.calendarDaysAway ?? "",
          workingDaysAway: raw?.WorkingDaysAway ?? row.workingDaysAway ?? "",

          // EXACT mappings requested:
          // Work % / Day  -> WorkDay
          workPercentPerDay:
            raw?.WorkDay !== undefined && raw?.WorkDay !== null
              ? String(raw.WorkDay)
              : row.workDay !== undefined && row.workDay !== null
              ? String(row.workDay)
              : "",

          // Number of Days Per Week Removed -> WeektobeRemoved
          numberOfDaysPerWeekRemoved:
            raw?.WeektobeRemoved !== undefined && raw?.WeektobeRemoved !== null
              ? String(raw.WeektobeRemoved)
              : row.weekToBeRemoved !== undefined && row.weekToBeRemoved !== null
              ? String(row.weekToBeRemoved)
              : "",

          // Number of Holidays -> NumbeofHolidays
          numberOfHolidays:
            raw?.NumbeofHolidays !== undefined && raw?.NumbeofHolidays !== null
              ? String(raw.NumbeofHolidays)
              : row.numberOfHolidays !== undefined && row.numberOfHolidays !== null
              ? String(row.numberOfHolidays)
              : "",

          // Category and Type
          category: row.category ?? raw?.Category?.Value ?? "",
          type: row.type ?? raw?.Type?.Value ?? "",

          // LWDC
          lwdc: row.lwdc ?? (raw?.WorkdayCaseLWDC ? "Yes" : "No"),
        });
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error("Failed to prefill Lost Time:", e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    prefill();
    return () => {
      cancelled = true;
    };
  }, [masterRecordNo, injuryRecordNo, lostTimeRecordNo]);

  const setField = (key, value) => {
    setForm((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const validateForm = () => {
    const newErrors = {};

    if (!form.fromDate) {
      newErrors.fromDate = "From Date is required";
    }

    if (!form.toDate) {
      newErrors.toDate = "To Date is required";
    }

    if (!form.category) {
      newErrors.category = "Category is required";
    }

    if (!form.type) {
      newErrors.type = "Type is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      await onSave(
        {
          ...form,
          recordNo: lostTimeRecordNo ?? null,
        },
        false
      );
    } finally {
      setLoading(false);
    }
  };

  const handleSaveAndAddEntry = async () => {
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      await onSave(
        {
          ...form,
          recordNo: lostTimeRecordNo ?? null,
        },
        true
      );
      // Reset form for next entry
      setForm(DEFAULT_FORM);
      setErrors({});
    } finally {
      setLoading(false);
    }
  };

  const toolbarBtn =
    "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";

  // Ensure selects show prefilled values even if not in static lists
  const categoryOptions =
    form.category && !LOST_TIME_CATEGORIES.includes(form.category)
      ? [form.category, ...LOST_TIME_CATEGORIES]
      : LOST_TIME_CATEGORIES;

  const typeOptions =
    form.type && !LOST_TIME_TYPES.includes(form.type)
      ? [form.type, ...LOST_TIME_TYPES]
      : LOST_TIME_TYPES;

  return (
    <ModalShell
      title={isEdit ? "Edit Lost Time" : "Add Entry"}
      onClose={onClose}
      maxWidth="max-w-2xl"
    >
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
        <button
          onClick={handleSave}
          disabled={loading}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red transition hover:text-jnj-red-dark disabled:opacity-50"
        >
          <Save className="h-4 w-4" />
          Save
        </button>

        <button
          onClick={onClose}
          disabled={loading}
          className={`${toolbarBtn} disabled:opacity-50`}
        >
          Save & Exit
        </button>

        <button
          onClick={handleSaveAndAddEntry}
          disabled={loading}
          className={`${toolbarBtn} disabled:opacity-50`}
        >
          Save & Add Entry
        </button>

        <button
          onClick={onClose}
          disabled={loading}
          className={`${toolbarBtn} disabled:opacity-50`}
        >
          Cancel
        </button>
      </div>

      <div className="max-h-[75vh] overflow-y-auto px-5 py-5">
        <h3 className="text-lg font-bold tracking-tight text-jnj-ink mb-6">
          {isEdit ? "Edit Lost Time" : "New Lost Time"}
        </h3>

        <ModalSubsection title="Lost Time">
          {/* From Date */}
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-4 mb-4">
            <label className="text-sm font-semibold text-gray-700 pt-2">
              <span className="text-red-500">*</span> From Date
            </label>
            <div>
              <input
                type="date"
                value={form.fromDate}
                onChange={(e) => setField("fromDate", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              {errors.fromDate && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.fromDate}
                </p>
              )}
            </div>
          </div>

          {/* To Date */}
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-4 mb-4">
            <label className="text-sm font-semibold text-gray-700 pt-2">
              <span className="text-red-500">*</span> To Date
            </label>
            <div>
              <input
                type="date"
                value={form.toDate}
                onChange={(e) => setField("toDate", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              {errors.toDate && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.toDate}
                </p>
              )}
            </div>
          </div>

          {/* Number of Calendar Days Away */}
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-4 mb-4">
            <label className="text-sm font-semibold text-gray-700 pt-2">
              <span className="text-red-500">*</span> Number of
              <br />
              calendar days away
              <br />
              (J&J definition)
              <span className="ml-1 text-gray-400">ℹ</span>
            </label>
            <div>
              <input
                type="text"
                value={form.calendarDaysAway}
                onChange={(e) => setField("calendarDaysAway", e.target.value)}
                disabled
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm bg-gray-100 text-gray-600 cursor-not-allowed"
              />
              <p className="text-xs text-gray-500 mt-1">
                To update Calendar Days please click Save.
              </p>
            </div>
          </div>

          {/* Work % / Day (from WorkDay) */}
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-4 mb-4">
            <label className="text-sm font-semibold text-gray-700 pt-2">
              <span className="text-red-500">*</span> Work % / Day
              <span className="ml-1 text-gray-400">ℹ</span>
            </label>
            <div>
              <input
                type="number"
                value={form.workPercentPerDay}
                onChange={(e) => setField("workPercentPerDay", e.target.value)}
                min="0"
                max="100"
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Number of Days Per Week Removed (from WeektobeRemoved) */}
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-4 mb-4">
            <label className="text-sm font-semibold text-gray-700 pt-2">
              Number of Days
              <br />
              Per Week to be
              <br />
              Removed
              <span className="ml-1 text-gray-400">ℹ</span>
            </label>
            <div>
              <input
                type="number"
                value={form.numberOfDaysPerWeekRemoved}
                onChange={(e) => setField("numberOfDaysPerWeekRemoved", e.target.value)}
                min="0"
                max="7"
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Number of Holidays (from NumbeofHolidays) */}
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-4 mb-4">
            <label className="text-sm font-semibold text-gray-700 pt-2">
              Number of Holidays
              <span className="ml-1 text-gray-400">ℹ</span>
            </label>
            <div>
              <input
                type="number"
                value={form.numberOfHolidays}
                onChange={(e) => setField("numberOfHolidays", e.target.value)}
                min="0"
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Number of Working Days Away */}
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-4 mb-4">
            <label className="text-sm font-semibold text-gray-700 pt-2">
              Number of working
              <br />
              days away (check
              <br />
              local regulation)
              <span className="ml-1 text-gray-400">ℹ</span>
            </label>
            <div>
              <input
                type="text"
                value={form.workingDaysAway}
                onChange={(e) => setField("workingDaysAway", e.target.value)}
                disabled
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm bg-gray-100 text-gray-600 cursor-not-allowed"
              />
              <p className="text-xs text-gray-500 mt-1">
                To update Number of Working Days Away please
                click Save.
              </p>
            </div>
          </div>

          {/* Category */}
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-4 mb-4">
            <label className="text-sm font-semibold text-gray-700 pt-2">
              <span className="text-red-500">*</span> Category
              <span className="ml-1 text-gray-400">ℹ</span>
            </label>
            <div>
              <select
                value={form.category}
                onChange={(e) => setField("category", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Select a category...</option>
                {(form.category && !LOST_TIME_CATEGORIES.includes(form.category)
                  ? [form.category, ...LOST_TIME_CATEGORIES]
                  : LOST_TIME_CATEGORIES
                ).map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
              {errors.category && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.category}
                </p>
              )}
            </div>
          </div>

          {/* Type */}
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-4 mb-4">
            <label className="text-sm font-semibold text-gray-700 pt-2">
              <span className="text-red-500">*</span> Type
              <span className="ml-1 text-gray-400">ℹ</span>
            </label>
            <div>
              <select
                value={form.type}
                onChange={(e) => setField("type", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Select a type...</option>
                {(form.type && !LOST_TIME_TYPES.includes(form.type)
                  ? [form.type, ...LOST_TIME_TYPES]
                  : LOST_TIME_TYPES
                ).map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
              {errors.type && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.type}
                </p>
              )}
            </div>
          </div>

          {/* Lost Workday Case (LWDC) */}
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-4 mb-4">
            <label className="text-sm font-semibold text-gray-700 pt-2">
              Lost Workday Case
              <br />
              (LWDC)?
              <span className="ml-1 text-gray-400">ℹ</span>
            </label>
            <div>
              <select
                value={form.lwdc}
                onChange={(e) => setField("lwdc", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {LWDC_OPTIONS.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </ModalSubsection>
      </div>
    </ModalShell>
  );
}
