// components/modals/ErrorTrapModal.jsx

"use client";

import { useEffect, useMemo, useState } from "react";
import { Save, Plus, Edit2, Trash2, RefreshCw } from "lucide-react";

import { ModalShell, ModalSubsection } from "./ModalShell";
import FieldInput from "@/components/FieldInput";
import ErrorTrapAnalysisModal from "./ErrorTrapAnalysisModal";
import ErrorTrapAnalysisPlusModal from "./ErrorTrapAnalysisPlus";
import CapaModal from "./CapaModal";
import CapaSelectionModal from "./ErrorTrapsCapasDropdown";

import { getCapaActions } from "@/lib/capaApi";
import { ERROR_TRAP_TITLE_SEED, PARENT_EVENT } from "@/lib/sections";
import { getErrorTrapByRecordNo } from "@/lib/errorTrapApi";

export default function ErrorTrapModal({ recordNo, onClose, onSave, eventId }) {
  const [loading, setLoading] = useState(false);

  // Only this flag is used when refreshing the summary section (not entire page)
  const [refreshingSummary, setRefreshingSummary] = useState(false);

  const [analysisRows, setAnalysisRows] = useState([]);
  const [capaModalOpen, setCapaModalOpen] = useState(false);
  const [capaSelectionModalOpen, setCapaSelectionModalOpen] = useState(false);
  const [capas, setCapas] = useState([]);
  const [selectedAnalysisRowId, setSelectedAnalysisRowId] = useState(null);

  // Plus modal state
  const [analysisPlusModalOpen, setAnalysisPlusModalOpen] = useState(false);
  const [analysisPlusParentRowId, setAnalysisPlusParentRowId] = useState(null);

  const [form, setForm] = useState({
    title: ERROR_TRAP_TITLE_SEED,
    hopChampion: "",
  });

  const [analysisModalOpen, setAnalysisModalOpen] = useState(false);
  const [selectedAnalysisRecord, setSelectedAnalysisRecord] = useState(null);

  const set = (k, v) =>
    setForm((prev) => ({
      ...prev,
      [k]: v,
    }));

  // Load record ONLY when recordNo changes (prevents wiping unsaved rows during summary refresh)
  const loadRecord = async () => {
    if (!recordNo) {
      setForm({ title: ERROR_TRAP_TITLE_SEED, hopChampion: "" });
      setAnalysisRows([]);
      return;
    }

    try {
      setLoading(true);
      const data = await getErrorTrapByRecordNo(recordNo);
      if (!data) return;

      setForm({
        title: data.ETTitle || ERROR_TRAP_TITLE_SEED,
        hopChampion: data.HOPChampion || "",
      });

      setAnalysisRows(
        (data.IdentifieCauses || []).map((cause, index) => ({
          id: cause.RecordNo || `row-${index + 1}`,
          trapCategory: cause.HTrapCategory || "",
          errorTrap: cause.HErrorTrap || "",
          analysis: cause.Description || "",
          addCapas: cause.AddCapas || "",
          capas: cause.CAPAsforDiagram || "",
          learningCategories: cause.LearningCategories || "",
          selectedCapas: [],
          raw: cause,
        }))
      );
    } catch (error) {
      console.error("Error Trap Detail Error:", error);
    } finally {
      setLoading(false);
    }
  };

  // Load CAPAs when eventId changes
  const loadCapaTableData = async () => {
    try {
      const records = await getCapaActions(eventId);
      setCapas(records || []);
    } catch (err) {
      console.error("CAPA loader: failed to load CAPAs", err);
      setCapas([]);
    }
  };

  // Summary-only refresh: re-fetch CAPAs; DO NOT reload analysisRows or form
  const refreshSummaryOnly = async () => {
    try {
      setRefreshingSummary(true);
      await loadCapaTableData();
    } catch {
      // No-op: errors logged in loader
    } finally {
      setRefreshingSummary(false);
    }
  };

  useEffect(() => {
    loadRecord();
  }, [recordNo]);

  useEffect(() => {
    if (!eventId) {
      setCapas([]);
      return;
    }
    loadCapaTableData();
  }, [eventId]);

  const handleAddAnalysis = () => {
    setSelectedAnalysisRecord(null);
    setAnalysisModalOpen(true);
  };

  const handleEditAnalysis = (row) => {
    setSelectedAnalysisRecord(row);
    setAnalysisModalOpen(true);
  };

  const handleDeleteAnalysis = (rowId) => {
    setAnalysisRows((prev) => prev.filter((row) => row.id !== rowId));
  };

  const handleSaveAnalysis = (analysisData, addAnother) => {
    if (selectedAnalysisRecord) {
      setAnalysisRows((prev) =>
        prev.map((row) =>
          row.id === selectedAnalysisRecord.id
            ? {
                ...row,
                trapCategory: analysisData.errorTrapCategory || "",
                errorTrap: analysisData.errorTrap || "",
                analysis: analysisData.why || "",
                capas: analysisData.capas || "",
                learningCategories: analysisData.learningCategories || "",
              }
            : row
        )
      );
    } else {
      const newRow = {
        id: `row-${Date.now()}-${Math.random()}`,
        trapCategory: analysisData.errorTrapCategory || "",
        errorTrap: analysisData.errorTrap || "",
        analysis: analysisData.why || "",
        addCapas: "",
        capas: analysisData.capas || "",
        learningCategories: analysisData.learningCategories || "",
        selectedCapas: [],
        raw: analysisData,
      };
      setAnalysisRows((prev) => [...prev, newRow]);
    }

    if (!addAnother) {
      setAnalysisModalOpen(false);
      setSelectedAnalysisRecord(null);
    }
  };

  const handleOpenCapaModal = (rowId) => {
    setSelectedAnalysisRowId(rowId);
    setCapaModalOpen(true);
  };

  const handleCapaModalClose = () => {
    setCapaModalOpen(false);
    setSelectedAnalysisRowId(null);
  };

  const handleSaveCapas = (selectedCapasList) => {
    setAnalysisRows((prev) =>
      prev.map((row) =>
        row.id === selectedAnalysisRowId
          ? {
              ...row,
              selectedCapas: selectedCapasList || [],
              capas: (selectedCapasList || [])
                .map((capa) => `Action ${capa.ActionNo}`)
                .join(", "),
            }
          : row
      )
    );
    handleCapaModalClose();
  };

  const handleOpenCapaSelectionModal = (rowId) => {
    setSelectedAnalysisRowId(rowId);
    setCapaSelectionModalOpen(true);
  };

  const handleCapaSelectionModalClose = () => {
    setCapaSelectionModalOpen(false);
    setSelectedAnalysisRowId(null);
  };

  const handleSaveCapasFromSelection = (selectedCapasData) => {
    setAnalysisRows((prev) =>
      prev.map((row) => {
        if (row.id === selectedAnalysisRowId) {
          const existingActionNos = row.selectedCapas.map((c) => c.ActionNo);
          const newCapas = (selectedCapasData || []).filter(
            (c) => !existingActionNos.includes(c.ActionNo)
          );
          const mergedCapas = [...row.selectedCapas, ...newCapas];

          return {
            ...row,
            selectedCapas: mergedCapas,
            capas: mergedCapas.map((capa) => `Action ${capa.ActionNo}`).join(", "),
          };
        }
        return row;
      })
    );
    handleCapaSelectionModalClose();
  };

  const handleRemoveCapa = (rowId, actionNo) => {
    setAnalysisRows((prev) =>
      prev.map((row) => {
        if (row.id === rowId) {
          const updatedCapas = row.selectedCapas.filter((c) => c.ActionNo !== actionNo);
          return {
            ...row,
            selectedCapas: updatedCapas,
            capas: updatedCapas.map((capa) => `Action ${capa.ActionNo}`).join(", "),
          };
        }
        return row;
      })
    );
  };

  const currentRow = analysisRows.find((r) => r.id === selectedAnalysisRowId);

  // Open the Plus modal for a specific row, showing its current analysis as the parent value
  const handleOpenAnalysisPlus = (rowId) => {
    setAnalysisPlusParentRowId(rowId);
    setAnalysisPlusModalOpen(true);
  };

  // IMPORTANT: On save from Plus modal, ADD A NEW ENTRY.
  // Fetch other details from the parent row (trapCategory, errorTrap, etc.)
  // and use the user's input (why) as the analysis for the new entry.
  const handleSaveAnalysisPlus = (payload, addAnother) => {
    const parent = analysisRows.find((r) => r.id === analysisPlusParentRowId);
    if (!parent) {
      if (!addAnother) {
        setAnalysisPlusModalOpen(false);
        setAnalysisPlusParentRowId(null);
      }
      return;
    }

    const newRow = {
      id: `row-${Date.now()}-${Math.random()}`,
      // copy details from parent row
      trapCategory: parent.trapCategory || "",
      errorTrap: parent.errorTrap || "",
      // set analysis from user input in Plus modal
      analysis: String(payload?.why || "").trim(),
      // keep CAPA fields empty by default for the new row; user can add later
      addCapas: "",
      capas: "",
      // optionally copy learning categories from parent
      learningCategories: parent.learningCategories || "",
      selectedCapas: [],
      raw: {
        source: "plus",
        parentId: parent.id,
      },
    };

    setAnalysisRows((prev) => [...prev, newRow]);

    // Close or keep open based on addAnother flag
    if (!addAnother) {
      setAnalysisPlusModalOpen(false);
      setAnalysisPlusParentRowId(null);
    }
  };

  // Helpers for the Summary UI
  const truncate = (text = "", n = 50) =>
    text.length > n ? text.slice(0, n).trimEnd() + "…" : text;

  // Build display data per row without mutating analysisRows
  const summaryCards = useMemo(() => {
    // Helper: find CAPA record by ActionNo from the latest 'capas' list
    const findCapaByNo = (no) => (capas || []).find((c) => String(c.ActionNo) === String(no));

    return (analysisRows || []).map((row, idx) => {
      // Prefer row.selectedCapas. If empty, fallback to parsing row.capas like "Action 123, Action 456"
      let actionNos = [];
      if (row.selectedCapas?.length) {
        actionNos = row.selectedCapas.map((c) => c.ActionNo);
      } else if (row.capas) {
        actionNos = row.capas
          .split(",")
          .map((x) => x.replace(/Action\s*#?/i, "").trim())
          .filter(Boolean);
      }

      // Compose CAPA summary text based on latest CAPA data
      const actionsText = actionNos.length
        ? actionNos
            .map((no) => {
              const match = findCapaByNo(no);
              const desc =
                match?.ActionToPerform ||
                match?.Action ||
                match?.Description ||
                "";
              return `Action#${no}${desc ? " - " + truncate(desc, 50) : ""}`;
            })
            .join(", ")
        : "No CAPA linked";

      return {
        key: row.id || `summary-${idx}`,
        index: idx + 1,
        category: row.trapCategory || "-",
        errorTrap: row.errorTrap || "-",
        deepDive: row.analysis || "-",
        capaSummary: `${idx + 1}). Action(s) are: ${actionsText}`,
      };
    });
  }, [analysisRows, capas]);

  const toolbarBtn =
    "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";

  return (
    <>
      <ModalShell
        title={recordNo ? `Error Trap (${recordNo})` : "Add Entry"}
        onClose={onClose}
        maxWidth="max-w-7xl"
      >
        <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
          <button
            onClick={() => onSave(form, false)}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red transition hover:text-jnj-red-dark"
          >
            <Save className="h-4 w-4" />
            Save
          </button>

          <button onClick={() => onSave(form, false)} className={toolbarBtn}>
            Save & Exit
          </button>

          <button onClick={() => onSave(form, true)} className={toolbarBtn}>
            Save & Add Entry
          </button>

          <button onClick={onClose} className={toolbarBtn}>
            Cancel
          </button>
        </div>

        <div className="max-h-[75vh] overflow-y-auto px-5 py-5">
          {loading ? (
            <div className="py-8 text-center text-sm text-slate-500">
              Loading Error Trap Details...
            </div>
          ) : (
            <>
              <h3 className="text-lg font-bold tracking-tight text-jnj-ink">
                {recordNo ? "Error Trap Detail" : "New Error Trap Analysis"}
              </h3>

              <ModalSubsection title="Error Trap Details">
                <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-[250px_1fr] sm:gap-4">
                  <label className="text-sm font-medium text-jnj-ink/80 sm:text-right sm:pt-2">
                    Parent Event
                  </label>

                  <div className="sm:pt-2">
                    <span className="text-sm font-semibold text-jnj-red">
                      {PARENT_EVENT}
                    </span>
                  </div>
                </div>

                <FieldInput
                  field={{ key: "title", label: "Title", type: "textarea", rows: 3 }}
                  value={form.title}
                  onChange={set}
                />

                <FieldInput
                  field={{
                    key: "hopChampion",
                    label:
                      "HOP Champion that assisted with the Error Trap Analysis",
                    type: "text",
                    required: true,
                  }}
                  value={form.hopChampion}
                  onChange={set}
                />
              </ModalSubsection>

              <ModalSubsection title="Error Trap Analysis">
                <div className="mb-4 text-sm text-jnj-ink">
                  Each error trap that is created/selected must have at least two
                  levels of analysis.
                </div>

                <div className="mb-4 flex justify-start">
                  <button
                    onClick={handleAddAnalysis}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-jnj-red text-white text-sm font-medium hover:bg-jnj-red-dark transition"
                  >
                    <Plus className="h-4 w-4" />
                    Add Entry
                  </button>
                </div>

                <div className="overflow-x-auto rounded-lg border border-jnj-line">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-jnj-mist">
                        <th className="px-3 py-2 text-center font-semibold whitespace-nowrap w-24">
                          Actions
                        </th>
                        <th className="px-3 py-2 text-left font-semibold">
                          Error Trap Category
                        </th>
                        <th className="px-3 py-2 text-left font-semibold">
                          Error Trap
                        </th>
                        <th className="px-3 py-2 text-left font-semibold">
                          Error Trap Analysis
                        </th>
                        <th className="px-3 py-2 text-center font-semibold whitespace-nowrap">
                          Add CAPAs
                        </th>
                        <th className="px-3 py-2 text-left font-semibold">
                          CAPAs
                        </th>
                        <th className="px-3 py-2 text-left font-semibold">
                          Learning Categories
                        </th>
                      </tr>
                    </thead>

                    <tbody>
                      {analysisRows.length === 0 ? (
                        <tr>
                          <td
                            colSpan={7}
                            className="px-4 py-6 text-center text-slate-400"
                          >
                            No Error Trap Analysis records found.
                          </td>
                        </tr>
                      ) : (
                        analysisRows.map((row) => (
                          <tr
                            key={row.id}
                            className="hover:bg-gray-50 transition border-t border-jnj-line"
                          >
                            <td className="px-3 py-2 text-center sticky left-0 bg-white hover:bg-gray-50">
                              <div className="flex items-center justify-center gap-1">
                                <button
                                  onClick={() => handleEditAnalysis(row)}
                                  className="inline-flex items-center gap-1 px-2 py-1 text-blue-600 hover:bg-blue-50 rounded transition"
                                  title="Edit"
                                >
                                  <Edit2 className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => handleDeleteAnalysis(row.id)}
                                  className="inline-flex items-center gap-1 px-2 py-1 text-red-600 hover:bg-red-50 rounded transition"
                                  title="Delete"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </td>

                            <td className="px-3 py-2 text-gray-700 text-xs">
                              {row.trapCategory}
                            </td>

                            <td className="px-3 py-2 text-gray-700 text-xs">
                              {row.errorTrap}
                            </td>

                            <td className="px-3 py-2 text-gray-700 text-xs max-w-xs">
                              <div className="flex items-center gap-2">
                                <div className="truncate">{row.analysis}</div>
                                {/* Plus button to open the additional analysis modal */}
                                <button
                                  onClick={() => handleOpenAnalysisPlus(row.id)}
                                  className="h-5 w-5 inline-flex items-center justify-center rounded-full bg-jnj-red hover:bg-jnj-red-dark transition"
                                  title="Add another analysis (Why?)"
                                >
                                  <Plus className="h-3 w-3 text-white" />
                                </button>
                              </div>
                            </td>

                            <td className="px-3 py-2 text-center">
                              <button
                                onClick={() => handleOpenCapaModal(row.id)}
                                className="text-blue-600 hover:text-blue-800 text-xs font-medium hover:underline"
                              >
                                Add
                              </button>
                            </td>

                            <td className="px-3 py-2">
                              <div className="flex items-center gap-2 flex-wrap">
                                {row.selectedCapas && row.selectedCapas.length > 0 ? (
                                  <>
                                    {row.selectedCapas.map((capa) => (
                                      <div
                                        key={capa.ActionNo}
                                        className="inline-flex items-center gap-1 px-2 py-1 bg-jnj-red/10 text-jnj-red text-xs rounded border border-jnj-red/30"
                                      >
                                        <span>Action {capa.ActionNo}</span>
                                        <button
                                          onClick={() =>
                                            handleRemoveCapa(row.id, capa.ActionNo)
                                          }
                                          className="ml-1 text-jnj-red hover:text-jnj-red-dark font-bold"
                                          title="Remove"
                                        >
                                          ×
                                        </button>
                                      </div>
                                    ))}
                                    <button
                                      onClick={() =>
                                        handleOpenCapaSelectionModal(row.id)
                                      }
                                      className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-jnj-red text-white hover:bg-jnj-red-dark transition"
                                      title="Add more CAPAs"
                                    >
                                      <Plus className="h-3 w-3" />
                                    </button>
                                  </>
                                ) : (
                                  <button
                                    onClick={() =>
                                      handleOpenCapaSelectionModal(row.id)
                                    }
                                    className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-jnj-red text-white hover:bg-jnj-red-dark transition"
                                    title="Add CAPAs"
                                  >
                                    <Plus className="h-3 w-3" />
                                  </button>
                                )}
                              </div>
                            </td>

                            <td className="px-3 py-2 text-gray-700 text-xs max-w-xs truncate">
                              {row.learningCategories || "-"}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </ModalSubsection>

              {/* SUMMARY SECTION */}
              <ModalSubsection title="Error Trap Analysis">
                {/* Section top: Refresh only this area */}
                <div className="mb-4">
                  <button
                    onClick={refreshSummaryOnly}
                    disabled={refreshingSummary}
                    className="inline-flex items-center gap-2 rounded-md bg-sky-100 px-4 py-2 text-sm font-semibold text-sky-800 hover:bg-sky-200 transition"
                  >
                    <RefreshCw
                      className={`h-4 w-4 ${refreshingSummary ? "animate-spin" : ""}`}
                    />
                    {refreshingSummary ? "Refreshing..." : "Refresh"}
                  </button>
                </div>

                {/* Descriptor line */}
                <div className="text-[12px] text-jnj-ink/70 mb-4">
                  <span className="font-semibold">Error Trap Analysis</span> – auto-generated
                  summary based on analysis rows and latest CAPA updates.
                </div>

                {/* Cards per analysis row */}
                {summaryCards.length === 0 ? (
                  <div className="rounded-lg border border-dashed border-jnj-line p-5 text-sm text-slate-400">
                    Add entries above to view the summary.
                  </div>
                ) : (
                  <div className="space-y-6">
                    {summaryCards.map((card) => (
                      <div key={card.key} className="space-y-3">
                        {/* Three-box row */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          {/* Error Trap Category box */}
                          <div>
                            <div className="text-[11px] uppercase tracking-wide text-jnj-slate/70 mb-1">
                              Error Trap Category
                            </div>
                            <div className="min-h-[140px] rounded-2xl border border-emerald-200 bg-emerald-50 shadow-sm p-4 flex items-center">
                              <div className="text-sm text-emerald-900 whitespace-pre-wrap">
                                {card.category}
                              </div>
                            </div>
                          </div>

                          {/* Error Trap box */}
                          <div>
                            <div className="text-[11px] uppercase tracking-wide text-jnj-slate/70 mb-1">
                              Error Trap
                            </div>
                            <div className="min-h-[140px] rounded-2xl border border-amber-200 bg-amber-50 shadow-sm p-4 flex items-center">
                              <div className="text-sm text-amber-900 whitespace-pre-wrap">
                                {card.errorTrap}
                              </div>
                            </div>
                          </div>

                          {/* Deep dive box */}
                          <div>
                            <div className="text-[11px] uppercase tracking-wide text-jnj-slate/70 mb-1">
                              Deep dive into key areas
                            </div>
                            <div className="min-h-[140px] rounded-2xl border border-slate-200 bg-slate-50 shadow-inner p-4 flex">
                              <div className="text-sm text-slate-700 whitespace-pre-wrap">
                                {`${card.index}). ${card.deepDive}`}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* CAPA Summary pill */}
                        <div className="rounded-full border border-amber-300 bg-amber-100 text-amber-900 px-4 py-3 text-sm">
                          <span className="font-medium">CAPA Summary</span>{" "}
                          <span className="text-amber-900/80">
                            ({`Error Trap Analysis item ${card.index}`})
                          </span>
                          <div className="mt-1">
                            {card.capaSummary}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ModalSubsection>
            </>
          )}
        </div>
      </ModalShell>

      {analysisModalOpen && (
        <ErrorTrapAnalysisModal
          initialData={selectedAnalysisRecord}
          onClose={() => {
            setAnalysisModalOpen(false);
            setSelectedAnalysisRecord(null);
          }}
          onSave={handleSaveAnalysis}
        />
      )}

      {/* Plus modal mounted with the clicked row's analysis as parent value */}
      {analysisPlusModalOpen && (
        <ErrorTrapAnalysisPlusModal
          mode="add"
          parentLabel="Parent Error Trap Analysis"
          parentValue={
            analysisRows.find((r) => r.id === analysisPlusParentRowId)?.analysis || ""
          }
          onClose={() => {
            setAnalysisPlusModalOpen(false);
            setAnalysisPlusParentRowId(null);
          }}
          onSave={handleSaveAnalysisPlus}
        />
      )}

      {capaModalOpen && (
        <CapaModal
          eventId={eventId}
          onClose={handleCapaModalClose}
          onSave={handleSaveCapas}
        />
      )}

      {capaSelectionModalOpen && (
        <CapaSelectionModal
          capas={capas}
          selectedCapas={currentRow?.selectedCapas || []}
          onClose={handleCapaSelectionModalClose}
          onSave={handleSaveCapasFromSelection}
        />
      )}
    </>
  );
}
