// components/modals/ErrorTrapAnalysisPlusModal.jsx

"use client";

import { useMemo, useState } from "react";
import { Save, Info } from "lucide-react";
import { ModalShell, ModalSubsection } from "./ModalShell";
import { controlBase } from "@/lib/status";

export default function ErrorTrapAnalysisPlusModal({
  mode = "add",            // 'add' or 'edit' (optional)
  parentLabel = "Parent Error Trap Analysis",  // label before parent value
  parentValue = "",        // shows the clicked row's Error Trap Analysis
  onClose,
  onSave,
}) {
  const [why, setWhy] = useState("");
  const [notice, setNotice] = useState(null);

  const toolbarBtn = "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";
  const textareaCls = `${controlBase} resize-y`;

  // Simple validation: Why? is required
  const isValid = useMemo(() => {
    return String(why || "").trim().length > 0;
  }, [why]);

  const save = (addAnother) => {
    if (!isValid) {
      setNotice({ type: "error", text: "Please provide a response for Why? (required)." });
      return;
    }
    const payload = {
      mode,
      parentLabel,
      parentValue,
      why: String(why).trim(),
    };
    onSave?.(payload, addAnother);
    if (!addAnother) onClose?.();
    if (addAnother) {
      setWhy("");
      setNotice({ type: "info", text: "Entry saved. You can add another." });
    }
  };

  return (
    <ModalShell
      title={mode === "add" ? "New Error Trap Analysis" : "Error Trap Analysis"}
      onClose={onClose}
      maxWidth="max-w-5xl"
    >
      <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
        <button
          onClick={() => save(false)}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red transition hover:text-jnj-red-dark"
        >
          <Save className="h-4 w-4" /> Save
        </button>
        <button onClick={() => save(false)} className={toolbarBtn}>
          Save &amp; Exit
        </button>
        <button onClick={() => save(true)} className={toolbarBtn}>
          Save &amp; Add Entry
        </button>
        <button onClick={onClose} className={toolbarBtn}>
          Cancel
        </button>
      </div>

      <div className="max-h-[72vh] overflow-y-auto px-5 py-5">
        <h3 className="text-lg font-bold tracking-tight text-jnj-ink">
          {mode === "add" ? "New Error Trap Analysis" : "Error Trap Analysis"}
        </h3>

        <ModalSubsection title="Additional Error Trap Analysis Details" defaultOpen>
          {/* Parent display */}
          <div className="mb-4 flex items-center gap-3">
            <span className="text-[13.5px] font-medium text-jnj-ink/80">{parentLabel}</span>
            <span className="text-sm font-semibold text-jnj-ink">{parentValue}</span>
          </div>

          {/* Why? - required */}
          <div className="mt-2">
            <label className="mb-1.5 flex items-center gap-1 text-[13.5px] font-medium text-jnj-ink/80">
              <span>* Why?</span>
              <Info className="h-3.5 w-3.5 text-jnj-slate" aria-hidden />
            </label>
            <textarea
              rows={3}
              value={why}
              onChange={(e) => setWhy(e.target.value)}
              className={textareaCls}
              placeholder="Describe why…"
            />
            {!isValid && (
              <p className="mt-1 text-xs text-red-600">This field is required.</p>
            )}
          </div>
        </ModalSubsection>

        {notice && (
          <div
            className={`mt-3 rounded px-3 py-2 text-sm ${
              notice.type === "error"
                ? "bg-red-50 text-red-700"
                : "bg-slate-100 text-jnj-ink"
            }`}
          >
            {notice.text}
          </div>
        )}
      </div>
    </ModalShell>
  );
}
