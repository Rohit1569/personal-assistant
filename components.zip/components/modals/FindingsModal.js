// components/modals/FindingsModal.jsx
"use client";

import { useState, useEffect } from "react";
import { Save, X } from "lucide-react";
import { ModalShell, ModalSubsection } from "./ModalShell";

// Minimal findings modal to match "vehicle-like" edit behavior.
// Prefills with initialData and allows save back to parent via onSave.
export default function FindingsModal({
  onClose,
  onSave,
  masterRecordNo,
  regulatoryRecordNo,
  findingRecordNo,
  initialData = null,
}) {
  const [form, setForm] = useState({
    findingNo: "",
    description: "",
    findingType: "",
    complianceActivity: "",
    repeated: "No",
    classificationPriority: "",
    numNonCompliances: "",
    status: "",
  });

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Prefill from initialData (we already loaded list in parent)
    if (initialData) {
      setForm({
        findingNo: initialData.findingNo ?? "",
        description: initialData.description ?? "",
        findingType: initialData.findingType ?? "",
        complianceActivity: initialData.complianceActivity ?? "",
        repeated: initialData.repeated ?? "No",
        classificationPriority: initialData.classificationPriority ?? "",
        numNonCompliances: initialData.numNonCompliances ?? "",
        status: initialData.status ?? "",
      });
    }
  }, [initialData]);

  const setField = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const handleSave = async () => {
    setLoading(true);
    try {
      await onSave(
        {
          ...form,
          recordNo: findingRecordNo ?? null,
        },
        false
      );
    } finally {
      setLoading(false);
    }
  };

  const toolbarBtn =
    "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";

  return (
    <ModalShell
      title={
        findingRecordNo
          ? `Edit Finding (${findingRecordNo})`
          : "Add Finding"
      }
      onClose={onClose}
      maxWidth="max-w-3xl"
    >
      <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
        <button
          onClick={handleSave}
          disabled={loading}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red disabled:opacity-50"
        >
          <Save className="h-4 w-4" />
          Save
        </button>
        <button onClick={onClose} disabled={loading} className={`${toolbarBtn} disabled:opacity-50`}>
          Cancel
        </button>
      </div>

      <div className="max-h-[75vh] overflow-y-auto px-5 py-5">
        <ModalSubsection title="Finding">
          <div className="grid gap-4">
            <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-3">
              <label className="text-sm font-semibold text-gray-700 pt-2">Finding No.</label>
              <input
                type="text"
                value={form.findingNo}
                onChange={(e) => setField("findingNo", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                readOnly
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-3">
              <label className="text-sm font-semibold text-gray-700 pt-2">Description</label>
              <textarea
                value={form.description}
                onChange={(e) => setField("description", e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-3">
              <label className="text-sm font-semibold text-gray-700 pt-2">Finding Type</label>
              <input
                type="text"
                value={form.findingType}
                onChange={(e) => setField("findingType", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-3">
              <label className="text-sm font-semibold text-gray-700 pt-2">Compliance Activity</label>
              <input
                type="text"
                value={form.complianceActivity}
                onChange={(e) => setField("complianceActivity", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-3">
              <label className="text-sm font-semibold text-gray-700 pt-2">Repeated?</label>
              <select
                value={form.repeated}
                onChange={(e) => setField("repeated", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              >
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-3">
              <label className="text-sm font-semibold text-gray-700 pt-2">Classification/Priority</label>
              <input
                type="text"
                value={form.classificationPriority}
                onChange={(e) => setField("classificationPriority", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-3">
              <label className="text-sm font-semibold text-gray-700 pt-2"># Non-Compliances</label>
              <input
                type="number"
                value={form.numNonCompliances}
                onChange={(e) => setField("numNonCompliances", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-3">
              <label className="text-sm font-semibold text-gray-700 pt-2">Status</label>
              <input
                type="text"
                value={form.status}
                onChange={(e) => setField("status", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>
          </div>
        </ModalSubsection>
      </div>
    </ModalShell>
  );
}
