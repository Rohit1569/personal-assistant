"use client";

import { useState } from "react";
import { Info } from "lucide-react";

import { ModalShell, ModalSubsection } from "./ModalShell";
import SubformModalToolbar from "./SubformModalToolbar";
import FieldInput from "@/components/FieldInput";
import { useTranslation } from "@/lib/i18n";
import { SAVE_MODES } from "@/lib/subformRecords";
import {
  SIFP_CATEGORIES,
  SIFP_SUBCATEGORIES,
  WORKER_TYPES,
  MGMT_SYSTEMS,
  FAILURE_MODES,
} from "@/lib/sections";

export const EMPTY_SIFP_FORM = Object.freeze({
  category: "",
  subCategory: "",
  workerType: "",
  mgmtSystem: "",
  failureMode: "",
});

const REQUIRED = ["category", "subCategory", "workerType", "mgmtSystem", "failureMode"];

export function validateSifpForm(form) {
  const errors = {};
  REQUIRED.forEach((key) => {
    if (!String(form?.[key] ?? "").trim()) errors[key] = "validation.required";
  });
  return errors;
}

/**
 * SIF-P Category entry.
 *
 * @param initialForm        values to start with (edit / restored draft)
 * @param recordLabel        record number shown in the title when editing
 * @param restoredDraft      true when the form was prefilled from a saved draft
 * @param onSave(form, mode) parent persists and decides what happens next
 * @param onDiscardDraft     clears the saved (pending) draft
 */
export default function SifpCategoryModal({
  initialForm,
  recordLabel,
  restoredDraft = false,
  onSave,
  onClose,
  onDiscardDraft,
  saveAndAddDisabled = false,
}) {
  const { t, toOptions } = useTranslation();
  const [form, setForm] = useState(() => ({ ...EMPTY_SIFP_FORM, ...(initialForm || {}) }));
  const [attempted, setAttempted] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState(null);
  const [showRestored, setShowRestored] = useState(restoredDraft);

  const set = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));
  const errors = validateSifpForm(form);
  const errorFor = (key) => (attempted && errors[key] ? t(errors[key]) : undefined);

  const handleSave = (mode) => {
    setAttempted(true);
    if (Object.keys(errors).length > 0) return;
    onSave(form, mode);
    if (mode === SAVE_MODES.SAVE) setLastSavedAt(new Date().toISOString());
  };

  const select = (key, labelKey, list, values) => (
    <FieldInput
      field={{
        key,
        label: t(labelKey),
        type: "select",
        required: true,
        options: toOptions(list, values),
        error: errorFor(key),
      }}
      value={form[key]}
      onChange={set}
    />
  );

  return (
    <ModalShell
      title={recordLabel ? t("sifp.modal.titleEdit", { recordNo: recordLabel }) : t("sifp.modal.titleNew")}
      onClose={onClose}
      maxWidth="max-w-4xl"
    >
      <SubformModalToolbar
        onSave={handleSave}
        onCancel={onClose}
        lastSavedAt={lastSavedAt}
        saveAndAddDisabled={saveAndAddDisabled}
        saveAndAddDisabledReason={t("sifp.onlyOneAllowed")}
      />

      <div className="max-h-[70vh] overflow-y-auto px-5 py-5">
        {showRestored && (
          <div className="mb-4 flex flex-wrap items-center gap-3 rounded-lg bg-amber-50 px-3.5 py-2.5 text-xs text-amber-800 ring-1 ring-inset ring-amber-200">
            <span>{t("subform.restoredDraft")}</span>
            <button
              type="button"
              onClick={() => {
                onDiscardDraft?.();
                setForm({ ...EMPTY_SIFP_FORM });
                setShowRestored(false);
                setAttempted(false);
              }}
              className="font-semibold underline hover:text-amber-900"
            >
              {t("subform.discardDraft")}
            </button>
          </div>
        )}

        {attempted && Object.keys(errors).length > 0 && (
          <div role="alert" className="mb-4 rounded-lg bg-red-50 px-3.5 py-2.5 text-xs text-red-700 ring-1 ring-inset ring-red-200">
            {t("validation.fixHighlightedFields")}
          </div>
        )}

        <h3 className="text-lg font-bold tracking-tight text-jnj-ink">
          {recordLabel ? t("sifp.modal.headingEdit") : t("sifp.modal.headingNew")}
        </h3>

        <ModalSubsection title={t("sifp.modal.sectionInformation")}>
          {select("category", "sifp.fields.category", "sifpCategory", SIFP_CATEGORIES)}
          {select("subCategory", "sifp.fields.subCategory", "sifpSubCategory", SIFP_SUBCATEGORIES)}
          {select("workerType", "sifp.fields.workerType", "workerType", WORKER_TYPES)}
        </ModalSubsection>

        <ModalSubsection title={t("sifp.modal.sectionManagement")}>
          {select("mgmtSystem", "sifp.fields.mgmtSystem", "managementSystem", MGMT_SYSTEMS)}
        </ModalSubsection>

        <ModalSubsection title={t("sifp.modal.sectionFailureMode")}>
          {select("failureMode", "sifp.fields.failureMode", "failureMode", FAILURE_MODES)}
        </ModalSubsection>

        <div className="mt-4 flex items-start gap-2.5 rounded-lg bg-sky-50/70 px-3.5 py-2.5 text-xs leading-relaxed text-sky-900 ring-1 ring-inset ring-sky-100">
          <Info className="mt-0.5 h-4 w-4 flex-shrink-0 text-sky-500" />
          <span>{t("sifp.modal.documentationNote")}</span>
        </div>
      </div>
    </ModalShell>
  );
}
