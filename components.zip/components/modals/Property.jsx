// components/modals/Property.jsx
"use client";

import { useEffect, useState } from "react";
import { Save, Info, Paperclip } from "lucide-react";

import { ModalShell } from "./ModalShell";
import FieldInput from "@/components/FieldInput";
import SubformTable from "@/components/SubformTable";

import { getPropertyDamageByIds } from "@/lib/propertyApi";

/* Default option lists */
const DEFAULT_DAMAGE_SOURCE_OPTIONS = [
  "Fire",
  "Explosion",
  "Water Damage",
  "Utility Failure",
  "Equipment Failure",
  "Chemical Release",
  "Other (Specify)",
];

const FINANCIAL_LOSS_OPTIONS = ["Yes", "No"];
const INTERRUPTION_OPTIONS = ["Yes", "No"];
const YES_NO_OPTIONS = ["Yes", "No"];

const DEFAULT_SEVERITY_OPTIONS = [
  "Critical - A death",
  "Critical - A site-wide business interruption greater than 24 hours",
  "Critical - An expected hospitalization of an employee, temporary worker, contractor or sub-contractor for a significant period of time (>3 days)",
  "Critical - Equipment damage above $50K USD",
  "Major - An external fire brigade response",
  "Major - An injury that required more than first aid or an expected hospitalization of 1-2 days",
  "Major - An internal fire brigade response",
  "Major - Equipment damage >= $5K and <= $50K USD",
  "Major - Risk score on the EHS&S Risk Matrix ≥36",
  "Major - Use of an extinguishing system or extinguisher",
  "Minor - Any fires/explosions not covered above",
  "Minor - False fire alarms",
  "Minor - Injury requiring first aid",
  "Minor - System or maintenance failures causing activation of a safety device",
  "Minor - Equipment damage <$5K USD",
];

/* Helpers */
const DEFAULT_FORM = {
  propertyDamageSource: "",
  otherPropertyDamageSource: "",

  // Responders
  responderOther: "",

  // Financial loss
  financialLoss: "",
  financialLossAmount: "",

  // Business interruption
  interruptionToBusiness: "",
  businessDisruptionHours: "",

  comments: "",
  regulatoryReporting: "",
  escalationRequired: "No",
  sensitiveInformation: "No",
};

const isProvided = (v) =>
  v !== undefined && v !== null && String(v).trim() !== "";

const toYesNo = (val) => {
  if (val === true || val === 1 || String(val).toLowerCase() === "yes")
    return "Yes";
  if (val === false || val === 0 || String(val).toLowerCase() === "no")
    return "No";
  return val == null ? "" : String(val);
};

const norm = (s) => String(s || "").trim().toLowerCase();

/* Find option by flexible matching (exact, contains, token overlap) */
function findClosestOption(options, raw) {
  if (!raw) return "";
  const r = norm(raw).replace(/[^\w\s-:≥<>]/g, "").trim();

  // exact
  const exact = options.find((o) => norm(o) === r);
  if (exact) return exact;

  // contains / included
  const includesMatch = options.find(
    (o) => r.includes(norm(o)) || norm(o).includes(r)
  );
  if (includesMatch) return includesMatch;

  // token overlap
  const tokens = r.split(/\s+/).filter(Boolean);
  let best = { opt: "", score: 0 };
  options.forEach((o) => {
    const ot = norm(o).split(/\s+/);
    const score = tokens.reduce((acc, t) => (ot.includes(t) ? acc + 1 : acc), 0);
    if (score > best.score) best = { opt: o, score };
  });
  if (best.score > 0) return best.opt;

  return "";
}

export default function NewPropertyDamageModal({
  onClose,
  // Preferred edit props
  incidentMasterNo, // master Incident RecordNo
  incidentRecordNo, // Property subform RecordNo
  // Legacy fallback
  eventId,
  recordNo,
}) {
  const [form, setForm] = useState(DEFAULT_FORM);
  const [responders, setResponders] = useState(new Set());
  const [severity, setSeverity] = useState(new Set());
  const [loading, setLoading] = useState(false);

  // Make damage source and severity option lists dynamic so API-returned values show in selects/checkbox lists
  const [damageSourceOptions, setDamageSourceOptions] = useState(
    DEFAULT_DAMAGE_SOURCE_OPTIONS
  );
  const [severityOptions, setSeverityOptions] = useState(DEFAULT_SEVERITY_OPTIONS);

  const masterNo = isProvided(incidentMasterNo) ? incidentMasterNo : eventId;
  const detailNo = isProvided(incidentRecordNo) ? incidentRecordNo : recordNo;
  const isEdit = isProvided(masterNo) && isProvided(detailNo);

  // Fix setter to update dynamic keys
  const set = (key, value) =>
    setForm((prev) => ({
      ...prev,
      [key]: value,
    }));

  const toggleResponder = (value) => {
    setResponders((prev) => {
      const next = new Set(prev);
      next.has(value) ? next.delete(value) : next.add(value);
      return next;
    });
  };

  const toggleSeverity = (value) => {
    setSeverity((prev) => {
      const next = new Set(prev);
      next.has(value) ? next.delete(value) : next.add(value);
      return next;
    });
  };

  // Prefill only when IDs present (edit)
  useEffect(() => {
    let cancelled = false;

    if (!isEdit) {
      setForm(DEFAULT_FORM);
      setResponders(new Set());
      setSeverity(new Set());
      setLoading(false);
      return;
    }

    const load = async () => {
      try {
        setLoading(true);
        const data = await getPropertyDamageByIds(masterNo, detailNo);
        if (cancelled) return;

        if (data) {
          // Map DamageSource.Value -> select. If not present in options, inject it so select shows.
          const damageSourceRaw = data?.DamageSource?.Value || data?.ProDamageSource || "";
          let mappedDamageSource = "";
          if (damageSourceRaw) {
            const best = findClosestOption(damageSourceOptions, damageSourceRaw);
            if (best) {
              mappedDamageSource = best;
            } else {
              // inject raw value at front to ensure visibility and selection
              setDamageSourceOptions((prev) =>
                prev.includes(damageSourceRaw) ? prev : [damageSourceRaw, ...prev]
              );
              mappedDamageSource = damageSourceRaw;
            }
          }

          // Map responders (array)
          const responderValues = Array.isArray(data?.ResponderTypes)
            ? data.ResponderTypes.map((r) => r?.Value).filter(Boolean)
            : [];
          const responderSet = new Set(responderValues);

          // Map fire/explosion severity (array). Ensure each raw severity is present in severityOptions; inject missing ones.
          const fireSevValues = Array.isArray(data?.FireExpSev)
            ? data.FireExpSev.map((f) => f?.Value).filter(Boolean)
            : [];

          // inject any unknown severity options so they appear in UI
          fireSevValues.forEach((raw) => {
            if (raw && !severityOptions.some((o) => norm(o) === norm(raw))) {
              setSeverityOptions((prev) => (prev.includes(raw) ? prev : [raw, ...prev]));
            }
          });

          // Build severity set (match to existing options if possible)
          const severitySet = new Set();
          fireSevValues.forEach((raw) => {
            const best = findClosestOption(severityOptions, raw) || raw;
            if (best) severitySet.add(best);
          });

          // Financial Loss mapping: prefer boolean/explicit, else amount
          const finYesNo = toYesNo(data?.AcFinancialLoss) || (Number(data?.FinancialLossUS) > 0 ? "Yes" : "No");
          const finAmountNum = Number(data?.FinancialLossUS);
          const finAmount = Number.isFinite(finAmountNum) && finAmountNum > 0 ? String(Math.trunc(finAmountNum)) : "";

          // Interruption mapping: use boolean or hours
          const intrYesNo = toYesNo(data?.IntrptnBusiness) || (Number(data?.DisruptiinHours) > 0 ? "Yes" : "No");
          const hoursNum = Number(data?.DisruptiinHours);
          const intrHours = Number.isFinite(hoursNum) && hoursNum > 0 ? String(Math.trunc(hoursNum)) : "";

          // Map comments, regulatory, escalation, sensitive
          const comments = data?.DetailComments || data?.Description || "";
          const regulatoryReporting = toYesNo(data?.RegRptRequired);
          const escalationRequired = toYesNo(data?.Escalation) || "No";
          const sensitiveInformation = toYesNo(data?.Sensitive) || "No";

          // If API provides OtherResponse or ProDamageSource for free text, map them appropriately
          const otherResponseRaw = data?.OtherResponse || "";
          const proDamageSourceRaw = data?.ProDamageSource || "";

          setForm({
            propertyDamageSource: mappedDamageSource || "",
            otherPropertyDamageSource: proDamageSourceRaw || "",

            responderOther: otherResponseRaw || "",

            financialLoss: finYesNo || "",
            financialLossAmount: finAmount,

            interruptionToBusiness: intrYesNo || "",
            businessDisruptionHours: intrHours,

            comments,
            regulatoryReporting,
            escalationRequired,
            sensitiveInformation,
          });

          setResponders(responderSet);
          setSeverity(severitySet);
        } else {
          setForm(DEFAULT_FORM);
          setResponders(new Set());
          setSeverity(new Set());
        }
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error("Error loading Property Damage:", e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    load();
    return () => {
      cancelled = true;
    };
    // intentionally not including damageSourceOptions/severityOptions in deps to avoid update loops
  }, [isEdit, masterNo, detailNo]);

  // Conditional flags for UI
  const isDamageSourceOther = form.propertyDamageSource === "Other (Specify)";
  const respondersHasOther = responders.has("Other (Specify)");
  const isFinancialLossYes = form.financialLoss === "Yes";
  const isInterruptionYes = form.interruptionToBusiness === "Yes";

  const toolbarBtn = "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";

  // Build responders array for rendering (we keep a canonical list, but ensure any API values are shown as checkboxes by injecting them)
  const DEFAULT_RESPONDER_OPTIONS = [
    "Internal response team",
    "External vendor",
    "External government team",
    "Other (Specify)",
  ];

  // Ensure responders from API are present in the list (inject any unknowns)
  const combinedResponderOptions = [
    ...new Set([...DEFAULT_RESPONDER_OPTIONS, ...Array.from(responders)]),
  ];

  // Build severity checkbox list from severityOptions state
  const severityList = severityOptions;

  return (
    <ModalShell
      title={isEdit ? `Property Event (${detailNo})` : "Add Entry"}
      onClose={onClose}
      maxWidth="max-w-6xl"
    >
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
        <button className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red">
          <Save className="h-4 w-4" />
          Save
        </button>

        <button className={toolbarBtn}>Save & Exit</button>

        <button onClick={onClose} className={toolbarBtn}>
          Cancel
        </button>
      </div>

      <div className="max-h-[80vh] overflow-y-auto px-5 py-5">
        {/* Master Event Information */}
        <div className="overflow-hidden rounded-xl border border-jnj-line">
          <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
            <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
              <Info className="h-3.5 w-3.5" />
            </span>
            <h4 className="text-sm font-bold text-jnj-ink">Master Event Information</h4>
          </div>

          <div className="p-4">
            <FieldInput
              field={{ key: "masterRecord", label: "Master Record No.", type: "readonly" }}
              value={isProvided(masterNo) ? `Incident #${masterNo}` : "Incident # -"}
              onChange={() => {}}
            />
          </div>
        </div>

        {/* Loading indicator */}
        {loading ? (
          <div className="py-8 text-center text-sm text-slate-500">
            Loading Property Event details...
          </div>
        ) : (
          <>
            {/* Property Details */}
            <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
              <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                  <Info className="h-3.5 w-3.5" />
                </span>
                <h4 className="text-sm font-bold text-jnj-ink">Property Details</h4>
              </div>

              <div className="space-y-4 p-4">
                <FieldInput
                  field={{
                    key: "propertyDamageSource",
                    label: "Property Damage Source",
                    type: "select",
                    required: true,
                    options: damageSourceOptions,
                  }}
                  value={form.propertyDamageSource}
                  onChange={set}
                />

                {/* If Property Damage Source is Other (Specify) → show required text field */}
                {isDamageSourceOther && (
                  <FieldInput
                    field={{
                      key: "otherPropertyDamageSource",
                      label: "Other Property Damage Source",
                      type: "text",
                      required: true,
                    }}
                    value={form.otherPropertyDamageSource}
                    onChange={set}
                  />
                )}

                {/* Responders */}
                <div className="grid grid-cols-1 items-start md:grid-cols-[22%_1fr]">
                  <div className="px-16 py-2 text-xs font-semibold text-gray-600">
                    Responder Types
                  </div>

                  <div className="space-y-1 px-2 py-1">
                    {combinedResponderOptions.map((item) => (
                      <label key={item} className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={responders.has(item)}
                          onChange={() => toggleResponder(item)}
                        />
                        {item}
                      </label>
                    ))}
                  </div>
                </div>

                {/* If Responder Types include Other (Specify) → show required textbox */}
                {respondersHasOther && (
                  <FieldInput
                    field={{
                      key: "responderOther",
                      label: "Please Specify Other Response",
                      type: "text",
                      required: true,
                    }}
                    value={form.responderOther}
                    onChange={set}
                  />
                )}

                <FieldInput
                  field={{
                    key: "financialLoss",
                    label: "Actual/Potential Financial Loss?",
                    type: "select",
                    options: FINANCIAL_LOSS_OPTIONS,
                  }}
                  value={form.financialLoss}
                  onChange={set}
                />

                {/* If Actual/Potential Financial Loss? = Yes → required positive integer amount */}
                {isFinancialLossYes && (
                  <FieldInput
                    field={{
                      key: "financialLossAmount",
                      label: "Actual/Potential Financial Loss (US$)",
                      type: "number",
                      required: true,
                      min: 1,
                      step: 1,
                    }}
                    value={form.financialLossAmount}
                    onChange={set}
                  />
                )}

                <FieldInput
                  field={{
                    key: "interruptionToBusiness",
                    label: "Interruption to Business?",
                    type: "select",
                    options: INTERRUPTION_OPTIONS,
                  }}
                  value={form.interruptionToBusiness}
                  onChange={set}
                />

                {/* If Interruption to Business? = Yes → required hours */}
                {isInterruptionYes && (
                  <FieldInput
                    field={{
                      key: "businessDisruptionHours",
                      label: "Estimated Business Disruption (in Hours)",
                      type: "number",
                      required: true,
                      min: 1,
                      step: 1,
                    }}
                    value={form.businessDisruptionHours}
                    onChange={set}
                  />
                )}

                {/* Severity */}
                <div className="grid grid-cols-1 items-start md:grid-cols-[22%_1fr]">
                  <div className="px-16 py-2 text-xs font-semibold text-gray-600">Severity</div>
                  <div className="space-y-1 px-2 py-1">
                    {severityList.map((item) => (
                      <label key={item} className="flex items-start gap-2 text-sm text-gray-700">
                        <input
                          type="checkbox"
                          checked={severity.has(item)}
                          onChange={() => toggleSeverity(item)}
                        />
                        <span>{item}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Comments */}
            <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
              <div className="border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                <h4 className="text-sm font-bold text-jnj-ink">Comments</h4>
              </div>

              <div className="p-4">
                <FieldInput
                  field={{ key: "comments", label: "Comments", type: "textarea" }}
                  value={form.comments}
                  onChange={set}
                />
              </div>
            </div>

            {/* Regulatory Reporting */}
            <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
              <div className="border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                <h4 className="text-sm font-bold text-jnj-ink">Regulatory Reporting</h4>
              </div>

              <div className="space-y-4 p-4">
                <FieldInput
                  field={{
                    key: "regulatoryReporting",
                    label: "Does this require regulatory reporting in your region?",
                    type: "select",
                    options: YES_NO_OPTIONS,
                  }}
                  value={form.regulatoryReporting}
                  onChange={set}
                />

                <div className="ml-[22%] text-sm text-slate-600">
                  To view the Incident Reporting Guidelines click here -
                  <button className="ml-1 text-sky-600 hover:underline">LINK</button>
                </div>
              </div>
            </div>

            {/* J&J Escalation */}
            <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
              <div className="border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                <h4 className="text-sm font-bold text-jnj-ink">J&J Escalation</h4>
              </div>

              <div className="space-y-4 p-4">
                <FieldInput
                  field={{
                    key: "escalationRequired",
                    label: "J&J Escalation required beyond site management?",
                    type: "select",
                    options: YES_NO_OPTIONS,
                  }}
                  value={form.escalationRequired}
                  onChange={set}
                />

                <div className="rounded-lg border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-900">
                  If the field "J&J Escalation required beyond site management" is YES and
                  you wish to change this, review the fields in this subform that are
                  triggering this escalation.
                </div>
              </div>
            </div>

            {/* Sensitive Information */}
            <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
              <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                  <Info className="h-3.5 w-3.5" />
                </span>
                <h4 className="text-sm font-bold text-jnj-ink">Sensitive Information</h4>
              </div>

              <div className="p-4">
                <FieldInput
                  field={{
                    key: "sensitiveInformation",
                    label: "Sensitive Information Included in this form?",
                    type: "select",
                    options: YES_NO_OPTIONS,
                  }}
                  value={form.sensitiveInformation}
                  onChange={set}
                />
              </div>
            </div>

            {/* Attachments */}
            <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
              <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                  <Paperclip className="h-3.5 w-3.5" />
                </span>
                <h4 className="text-sm font-bold text-jnj-ink">Pictures and Attachments</h4>
              </div>

              <div className="p-4">
                <SubformTable
                  addLabel="Attach Document"
                  actions={["Detach Document", "List All"]}
                  columns={[
                    { key: "attachmentName", label: "Attachment Name" },
                    { key: "url", label: "URL" },
                  ]}
                  rows={[]}
                  emptyText="No records to display."
                  onAdd={() => {}}
                />
              </div>
            </div>
          </>
        )}
      </div>
    </ModalShell>
  );
}
