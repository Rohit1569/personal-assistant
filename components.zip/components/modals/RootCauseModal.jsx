"use client";

import { useEffect, useState } from "react";
import { Save } from "lucide-react";
import { ModalShell, ModalSubsection, PrivacyNote } from "./ModalShell";
import CauseCheckGroup from "@/components/CauseCheckGroup";
import SubformTable from "@/components/SubformTable";
import { controlBase } from "@/lib/status";
import {
  BEHAVIORS_CAUSES,
  CONDITIONS_CAUSES,
  SYSTEM_CAUSES,
} from "@/lib/sections";

import { getRootCauseByRecordNo, getRootCauses } from "@/lib/rootCauseApi";

export default function RootCauseModal({
  mode = "add",
  recordNo = null,   // cause RecordNo
  eventId,
  onClose,
  onSave,
}) {
  const [behaviors, setBehaviors] = useState(new Set());
  const [conditions, setConditions] = useState(new Set());
  const [system, setSystem] = useState(new Set());
  const [desc, setDesc] = useState({ behaviors: "", conditions: "", system: "" });
  const [eventName, setEventName] = useState("");

  const [prefillLoading, setPrefillLoading] = useState(false);
  const [prefillError, setPrefillError] = useState(null);

  const setD = (k, v) => setDesc((p) => ({ ...p, [k]: v }));

  const toggle = (setter) => (item) =>
    setter((p) => {
      const n = new Set(p);
      n.has(item) ? n.delete(item) : n.add(item);
      return n;
    });

  const toArrayFromOData = (res) => {
    if (Array.isArray(res)) return res;
    if (res && Array.isArray(res.value)) return res.value;
    return [];
  };

  const mapRecordToState = (rc) => {
    const toSet = (arr) => new Set((arr || []).map((i) => i?.Value).filter(Boolean));
    return {
      behaviorsSet: toSet(rc?.BehaviorsCauses),
      conditionsSet: toSet(rc?.ConditionCauses),
      systemSet: toSet(rc?.SystemCauses),
      descriptions: {
        behaviors: rc?.BasCaDescript ?? "",
        conditions: rc?.BaConDescript ?? "",
        system: rc?.SysDescription ?? "",
      },
      eventName: rc?.Event?.Name ?? "",
    };
  };

  // Prefill when editing a specific cause record by its own RecordNo
  useEffect(() => {
    let cancelled = false;

    const loadDetails = async () => {
      if (mode !== "edit" || !recordNo) return;

      setPrefillLoading(true);
      setPrefillError(null);

      try {
        // Fetch exactly one cause by its RecordNo
        let data = await getRootCauseByRecordNo(String(recordNo).trim());

        // Optional fallback: if details fetch isn't available, get list by Event and pick match
        if (!data && eventId) {
          const listRes = await getRootCauses(eventId, {});
          const list = toArrayFromOData(listRes);
          data =
            list.find((r) => String(r?.RecordNo) === String(recordNo)) ||
            list[0] ||
            null;
        }

        if (!data) throw new Error("No data returned for cause record");

        if (cancelled) return;

        const mapped = mapRecordToState(data);
        setBehaviors(mapped.behaviorsSet);
        setConditions(mapped.conditionsSet);
        setSystem(mapped.systemSet);
        setDesc(mapped.descriptions);
        setEventName(mapped.eventName || "");
      } catch (e) {
        console.error("[RootCauseModal] Prefill error:", e);
        if (!cancelled) setPrefillError("Failed to load root cause details.");
      } finally {
        if (!cancelled) setPrefillLoading(false);
      }
    };

    loadDetails();
    return () => {
      cancelled = true;
    };
  }, [mode, recordNo, eventId]);

  const toolbarBtn = "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";
  const descCls = `${controlBase} resize-y`;

  const save = (addAnother) => {
    onSave?.(
      {
        mode,
        recordNo,   // cause RecordNo
        eventId,
        behaviors: Array.from(behaviors).join("; "),
        conditions: Array.from(conditions).join("; "),
        system: Array.from(system).join("; "),
        ...desc,
        eventName,
      },
      addAnother
    );
    if (!addAnother) onClose?.();
  };

  return (
    <ModalShell
      title={mode === "add" ? "Add Entry" : `Edit Root Cause${recordNo ? ` (#${recordNo})` : ""}`}
      onClose={onClose}
      maxWidth="max-w-5xl"
    >
      <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
        <button
          onClick={() => save(false)}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red transition hover:text-jnj-red-dark"
        >
          <Save className="h-4 w-4" /> Save
        </button>
        <button onClick={() => save(false)} className={toolbarBtn}>
          Save &amp; Exit
        </button>
        <button onClick={() => save(true)} className={toolbarBtn}>
          Save &amp; Add Entry
        </button>
        <button onClick={onClose} className={toolbarBtn}>
          Cancel
        </button>
      </div>

      <div className="max-h-[72vh] overflow-y-auto px-5 py-5">
        <h3 className="text-lg font-bold tracking-tight text-jnj-ink">
          {mode === "add" ? "New Root Cause" : "Root Cause"}
        </h3>
        <p className="mt-1.5 text-[13px] text-jnj-slate">
          It is mandatory to select 1 basic OR condition cause AND it is mandatory to always select 1 system cause.
        </p>

        {prefillLoading && (
          <div className="mt-3 text-sm text-slate-500">Loading record details...</div>
        )}
        {prefillError && (
          <div className="mt-3 text-sm text-red-600">{prefillError}</div>
        )}

        <ModalSubsection title="Root Cause Details">
          {/* Event name from API */}
          <div className="flex items-center gap-3">
            <span className="text-[13.5px] font-medium text-jnj-ink/80">Event</span>
            <a
              href="#"
              onClick={(e) => e.preventDefault()}
              className="text-sm font-semibold text-jnj-red hover:underline"
              title={eventName}
            >
              {eventName || (recordNo ? `Record #${recordNo}` : "Event")}
            </a>
          </div>

          {/* Behaviors */}
          <div>
            <p className="mb-2 text-[13.5px] font-bold text-jnj-ink/80">** BASIC - Behaviors Causes</p>
            <CauseCheckGroup items={BEHAVIORS_CAUSES} selected={behaviors} onToggle={toggle(setBehaviors)} />
            <div className="mt-3.5">
              <label className="mb-1.5 block text-[13.5px] font-medium text-jnj-ink/80">
                BASIC - Behaviors Cause Description
              </label>
              <textarea
                rows={2}
                value={desc.behaviors}
                onChange={(e) => setD("behaviors", e.target.value)}
                className={descCls}
              />
            </div>
            <PrivacyNote>
              BASIC - Behaviors Cause Description: Do not publish or think carefully before publishing or disclosing personal information, such as full names (use only first names) or any other private information.
            </PrivacyNote>
          </div>

          {/* Conditions */}
          <div>
            <p className="mb-2 text-[13.5px] font-bold text-jnj-ink/80">** BASIC - Conditions Causes</p>
            <CauseCheckGroup items={CONDITIONS_CAUSES} selected={conditions} onToggle={toggle(setConditions)} />
            <div className="mt-3.5">
              <label className="mb-1.5 block text-[13.5px] font-medium text-jnj-ink/80">
                BASIC - Conditions Cause Description
              </label>
              <textarea
                rows={2}
                value={desc.conditions}
                onChange={(e) => setD("conditions", e.target.value)}
                className={descCls}
              />
            </div>
            <PrivacyNote>
              BASIC - Conditions Cause Description: Do not publish or think carefully before publishing or disclosing personal information, such as full names (use only first names) or any other private information.
            </PrivacyNote>
          </div>

          {/* System */}
          <div>
            <p className="mb-2 text-[13.5px] font-bold text-jnj-ink/80">* System Causes</p>
            <CauseCheckGroup items={SYSTEM_CAUSES} selected={system} onToggle={toggle(setSystem)} />
            <div className="mt-3.5">
              <label className="mb-1.5 block text-[13.5px] font-medium text-jnj-ink/80">
                System Cause Description
              </label>
              <textarea
                rows={2}
                value={desc.system}
                onChange={(e) => setD("system", e.target.value)}
                className={descCls}
              />
            </div>
            <PrivacyNote>
              System Cause Description: Do not publish or think carefully before publishing or disclosing personal information, such as full names (use only first names) or any other private information.
            </PrivacyNote>
          </div>
        </ModalSubsection>

        <ModalSubsection title="Pictures and Attachments">
          <SubformTable
            addLabel="Attach Document"
            actions={["Detach Document", "List All"]}
            columns={[
              { key: "attachmentName", label: "Attachment Name" },
              { key: "url", label: "URL" },
            ]}
            emptyText="No records to display."
            onAdd={() => {}}
          />
          <PrivacyNote>
            Pictures and Attachments: Do not publish or think carefully before publishing or disclosing pictures with personal information or recognizable persons on it, or any other private information.
          </PrivacyNote>
        </ModalSubsection>
      </div>
    </ModalShell>
  );
}
