// components/modals/Injury.jsx
"use client";

import { useEffect, useState, useCallback, useMemo } from "react";
import { Save, Pencil } from "lucide-react";

import { ModalShell, ModalSubsection, PrivacyNote } from "./ModalShell";
import FieldInput from "@/components/FieldInput";
import SubformTable from "@/components/SubformTable";
import OnBehalfOfDropdown from "@/components/EmployeeSearchDropdown";

import {
  YES_NO_OPTIONS,
  WORKER_TYPES,
  PRIMARY_SEVERITY,
  ADDITIONAL_SEVERITY,
  MECHANISM_GENERAL,
  EXPOSURE_TYPES,
  VEHICLE_ACCIDENT_TYPES,
  BODY_PART_OPTIONS,
  INJURY_OUTCOMES,
} from "@/app/constants/injury";

import { getInjuryIllnessByIds } from "@/lib/injuryApi";
import { getLostTimeData } from "@/lib/lostTimeApi";
import LostTimeModal from "./LostTimeModal";

/* ---------- helpers ---------- */

const DEFAULT_FORM = {
  // Header
  workerType: "",
  workRelated: "",
  // Employee search fields
  jjResponsiblePerson: "", // J&J Responsible Person (employee search)
  ghsStaff: "", // Name of GHS staff (employee search)
  ghsCaseNo: "",
  // New fields per requirements
  selectFromJJEDS: "",
  contractingCompanyContactDetails: "",
  contractorCompanyName: "",
  subcontractorCompanyName: "",
  jobTypeAffected: "",
  jobTypeOther: "",
  serviceLengthCompany: "",
  experienceRole: "",
  experienceOnSite: "",
  ageRange: "",
  // In Contractor Details (per request)
  hoursInShift: "",
  drugAlcoholTest: "",
  // Severity
  primarySeverity: "",
  additionalSeverity: [],
  jjRecordable: false,
  // Regulatory
  regulatoryReporting: "",
  escalationRequired: "No",
  sensitiveInformation: "No",
  // Mechanisms
  mechanismGeneral: [],
  exposureTo: [],
  vehicleAccidents: [],
  injuryType: "", // "Injury" | "Illness"
  outcomes: [],
  // Body parts
  bodyPartPrimary: "",
  bodyParts: [],
  // Texts
  ppeUsed: "",
  comments: "",
};

// Primary severity values that force J&J Recordable = true
const RECORDABLE_SEVERITIES = new Set([
  "J&J Minor Injury/Illness",
  "J&J Serious Injury/Illness Case (SIIC)",
  "J&J Severe Injury or Fatality (SIF)",
]);

const JOB_TYPE_OPTIONS = [
  "Carpenter",
  "Cement worker",
  "Civil",
  "Cleaner",
  "E&I",
  "Equipment installer",
  "Field staff",
  "Fire Protection/Sprinkler",
  "General Labor",
  "HVAC",
  "Insulator",
  "Insulator/lagger",
  "Iron worker",
  "IT",
  "Landscape",
  "Mechanical",
  "Operator",
  "Painter",
  "Pipefitter",
  "Plumbing",
  "Riggor",
  "Roofing",
  "Scaffolder",
  "Welder",
  "Other",
];

const EXPERIENCE_OPTIONS = ["< 1 year", "1 - 5 years", "5 - 10 years", "> 10 years"];
const AGE_RANGE_OPTIONS = ["18 - 24", "25 - 35", "36 - 45", "46 - 55", "56 - 65", "> 65"];

const isProvided = (v) => v !== undefined && v !== null && String(v).trim() !== "";

const toYesNo = (val) => {
  if (val === true || val === 1 || String(val).toLowerCase() === "yes") return "Yes";
  if (val === false || val === 0 || String(val).toLowerCase() === "no") return "No";
  return val == null ? "" : String(val);
};

const norm = (s) => String(s || "").replace(/[()]/g, "").trim().toLowerCase();

// Map incoming value to one of our option labels (best-effort fuzzy)
const mapCaptionToOption = (caption, options) => {
  if (!caption) return "";
  const n = norm(caption);
  return (
    options.find((o) => norm(o) === n) ||
    options.find((o) => norm(o).includes(n) || n.includes(norm(o))) ||
    caption
  );
};

// Extract ID from OData URL (...(GUID))
const extractIdFromOdataId = (odataId) => {
  if (!odataId || typeof odataId !== "string") return null;
  const match = odataId.match(/$([^)]+)$$/);
  return match ? match[1] : null;
};

/* ---------- component ---------- */

export default function InjuryIllnessModal({
  onClose,
  onSave, // optional: parent can pass a save handler to add/update row in table
  // Preferred props (edit mode)
  incidentMasterNo, // master Incident RecordNo (e.g., 626364)
  incidentRecordNo, // injury/illness RecordNo (e.g., 626379)
  // Legacy props (fallback)
  eventId,
  recordNo,
}) {
  const [loading, setLoading] = useState(false);
  const [lostTimeLoading, setLostTimeLoading] = useState(false);
  const [form, setForm] = useState(DEFAULT_FORM);
  const [lostTimeRows, setLostTimeRows] = useState([]);
  const [showLostTimeModal, setShowLostTimeModal] = useState(false);
  const [selectedLostTimeRecord, setSelectedLostTimeRecord] = useState(null);
  const [editingLostTimeRecordNo, setEditingLostTimeRecordNo] = useState(null);

  // Client-side validation state
  const [errors, setErrors] = useState({}); // e.g., { primarySeverity: "Required" }
  const [saving, setSaving] = useState(false);

  const masterNo = isProvided(incidentMasterNo) ? incidentMasterNo : eventId;
  const detailNo = isProvided(incidentRecordNo) ? incidentRecordNo : recordNo;
  const isEdit = isProvided(masterNo) && isProvided(detailNo);

  const setField = useCallback((key, value) => {
    setForm((prev) => ({
      ...prev,
      [key]: value,
    }));
    // Clear field-level error on change
    setErrors((prev) => {
      if (!prev) return {};
      const next = { ...prev };
      if (next[key]) delete next[key];
      return next;
    });
  }, []);

  const toggleInArray = (key, value) => {
    setForm((prev) => {
      const exists = prev[key]?.includes(value);
      return {
        ...prev,
        [key]: exists ? prev[key].filter((v) => v !== value) : [...prev[key], value],
      };
    });
  };

  // Auto-control J&J Recordable based on selected primary severity.
  // Also ensure the checkbox is disabled in UI; users cannot override.
  useEffect(() => {
    const isRecordable = RECORDABLE_SEVERITIES.has(form.primarySeverity);
    if (form.jjRecordable !== isRecordable) {
      setForm((prev) => ({ ...prev, jjRecordable: isRecordable }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.primarySeverity]);

  // Prefill from API only when both IDs are present (edit)
  useEffect(() => {
    let cancelled = false;
    if (!isEdit) {
      setForm(DEFAULT_FORM);
      setLoading(false);
      return;
    }

    const load = async () => {
      try {
        setLoading(true);
        const data = await getInjuryIllnessByIds(masterNo, detailNo);
        if (cancelled) return;

        if (data) {
          // Mechanisms
          const mechGeneral = (Array.isArray(data.ofInjuryGeneral) ? data.ofInjuryGeneral : [])
            .map((m) => mapCaptionToOption(m?.Caption || m?.Value, MECHANISM_GENERAL))
            .filter(Boolean);

          const exposure = (Array.isArray(data.InjurExposureTo) ? data.InjurExposureTo : [])
            .map((m) => mapCaptionToOption(m?.Caption || m?.Value, EXPOSURE_TYPES))
            .filter(Boolean);

          const vehicles = (Array.isArray(data.VehicleAccident) ? data.VehicleAccident : [])
            .map((m) => mapCaptionToOption(m?.Caption || m?.Value, VEHICLE_ACCIDENT_TYPES))
            .filter(Boolean);

          // Injury type
          const injuryType = data?.InjuryorIllness?.Caption || data?.InjuryorIllness?.Value || "";

          // Outcomes
          const outcomes = (Array.isArray(data.InjuryIlOutcome) ? data.InjuryIlOutcome : [])
            .map((o) => mapCaptionToOption(o?.Caption || o?.Value, INJURY_OUTCOMES))
            .filter(Boolean);

          // Severity
          const primarySeverity = mapCaptionToOption(data?.SevSingleSelect?.Name, PRIMARY_SEVERITY);
          const additionalSeverity = (Array.isArray(data.SeveMultiSelect) ? data.SeveMultiSelect : [])
            .map((s) => mapCaptionToOption(s?.Name, ADDITIONAL_SEVERITY))
            .filter(Boolean);

          // Body parts
          const bodyPartPrimary = data?.sevBPIINs?.RecordName || "";
          const bodyParts = (Array.isArray(data.BPIINs) ? data.BPIINs : [])
            .map((b) => b?.RecordName)
            .filter(Boolean);

          setForm((prev) => ({
            ...prev,
            workerType: data?.JJWorkerType?.EmployeeType || "",
            workRelated: toYesNo(data?.InciWorkRelated),
            jjResponsiblePerson: prev.jjResponsiblePerson || "",
            ghsStaff: prev.ghsStaff || "",
            ghsCaseNo: data?.GHSCaseNo || "",
            primarySeverity: primarySeverity || "",
            additionalSeverity,
            // jjRecordable will be recalculated by the useEffect on primarySeverity
            regulatoryReporting: toYesNo(data?.RegRptRequired),
            escalationRequired: toYesNo(data?.Escalation) || "No",
            sensitiveInformation: toYesNo(data?.Sensitive) || "No",
            mechanismGeneral: mechGeneral,
            exposureTo: exposure,
            vehicleAccidents: vehicles,
            injuryType,
            outcomes,
            bodyPartPrimary,
            bodyParts,
            ppeUsed: data?.traininreceived || "",
            comments: data?.Comments || "",
          }));
        } else {
          setForm(DEFAULT_FORM);
        }
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error("Error loading Injury/Illness data:", e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [isEdit, masterNo, detailNo]);

  // Load Lost Time data
  useEffect(() => {
    let cancelled = false;
    if (!isEdit) {
      setLostTimeRows([]);
      return;
    }

    const loadLostTime = async () => {
      try {
        setLostTimeLoading(true);
        const data = await getLostTimeData(masterNo, detailNo);
        if (cancelled) return;

        const rows = (data.lostTimeRecords || []).map((lt, idx) => {
          const raw = lt.raw || {};
          const recordNo = raw.RecordNo ?? null;
          const fallbackId = extractIdFromOdataId(raw?.["@odata.id"]) || raw?.Id || null;
          return {
            ...lt,
            id: lt.id ?? idx + 1,
            lostTimeRecordNo: recordNo ?? fallbackId,
          };
        });

        setLostTimeRows(rows);
      } catch (error) {
        // eslint-disable-next-line no-console
        console.error("Error loading Lost Time data:", error);
        setLostTimeRows([]);
      } finally {
        if (!cancelled) setLostTimeLoading(false);
      }
    };

    loadLostTime();
    return () => {
      cancelled = true;
    };
  }, [isEdit, masterNo, detailNo]);

  const handleAddLostTime = () => {
    setSelectedLostTimeRecord(null);
    setEditingLostTimeRecordNo(null);
    setShowLostTimeModal(true);
  };

  const handleEditLostTime = (row) => {
    setSelectedLostTimeRecord(row);
    setEditingLostTimeRecordNo(row?.lostTimeRecordNo ?? null);
    setShowLostTimeModal(true);
  };

  const handleDeleteLostTime = (rowId) => {
    setLostTimeRows((prev) => prev.filter((row) => row.id !== rowId));
  };

  const toolbarBtn = "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";

  // Normalize compare for body part display vs API "(Back)" variant
  const isBodyPartChecked = (label) => form.bodyParts?.some((bp) => norm(bp) === norm(label));
  const isBodyPartPrimary = (label) => norm(form.bodyPartPrimary) === norm(label);

  // Build rows for SubformTable with leading pencil icon to edit
  const lostTimeRowsWithEdit = lostTimeRows.map((row, index) => ({
    ...row,
    edit: (
      <button
        type="button"
        onClick={() => handleEditLostTime(row)}
        className="inline-flex items-center text-jnj-slate hover:text-jnj-red"
        title="Edit Lost Time"
      >
        <Pencil className="h-4 w-4" />
      </button>
    ),
    _rowKey: row.lostTimeRecordNo ?? `${row.fromDate}-${row.toDate}-${index}`,
  }));

  // Work type case helpers
  const workerNorm = useMemo(() => norm(form.workerType), [form.workerType]);
  const isVisitorOrOther = workerNorm.includes("visitor") || workerNorm.includes("other");
  const isAgencyWorker =
    workerNorm.includes("agency worker") ||
    workerNorm.includes("agency") ||
    workerNorm.includes("non-j&j employee") ||
    workerNorm.includes("non j&j employee");
  const isContractor = workerNorm.includes("contractor");

  // Render helper for custom rows (consistent layout)
  const renderRow = (field, content, required) => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start" key={field.key}>
        <div className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
          {field.label}
          {required ? <span className="ml-1 text-red-500">*</span> : null}
        </div>
        <div className="px-2 py-1 min-w-0 overflow-visible">{content}</div>
      </div>
    );
  };

  // Form validation
  const validate = () => {
    const nextErrors = {};
    if (!isProvided(form.primarySeverity)) {
      nextErrors.primarySeverity = "Primary Classification is required";
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  // add this helper near other helpers
const buildParentPayload = (detailNo, form) => {
  const primary = form.primarySeverity || "";
  const sif = primary.toLowerCase().includes("sif") ? "Yes" : "No";
  return {
    // identifiers expected by parent table
    recordNo: detailNo || "",
    incidentNo: detailNo || "",

    // canonical fields used by the table
    incidentType: "Injury / Illness",
    regulatoryReporting: form.regulatoryReporting || "No",
    nov: "No",
    escalationRequired: form.escalationRequired || "No",
    sensitiveInfo: form.sensitiveInformation || "No",
    lwdc: form.jjRecordable ? "Yes" : "No",
    sif,

    // extras (optional)
    jjRecordable: !!form.jjRecordable,
    primarySeverity: primary,
  };
};

  // Save handlers
  const emitSavedEvent = (payload) => {
    try {
      const evt = new CustomEvent("injury:saved", { detail: payload });
      window.dispatchEvent(evt);
    } catch {}
  };





 // replace your existing handleSave in Injury.jsx
const handleSave = async (exitAfter = false) => {
  if (!validate()) return;

  try {
    setSaving(true);

    const payload = buildParentPayload(detailNo, form);

    if (typeof onSave === "function") {
      await onSave(payload); // IMPORTANT: send normalized payload, not raw form
    } else {
      // optional fallback event
      const evt = new CustomEvent("injury:saved", { detail: payload });
      window.dispatchEvent(evt);
    }

    if (exitAfter) onClose?.();
  } finally {
    setSaving(false);
  }
};


  return (
    <ModalShell
      title={isEdit ? `Injury / Illness (${detailNo})` : "Add Entry"}
      onClose={onClose}
      maxWidth="max-w-7xl"
    >
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
        <button
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red disabled:opacity-50"
          onClick={() => handleSave(false)}
          disabled={saving}
        >
          <Save className="h-4 w-4" />
          Save
        </button>
        <button
          className={`${toolbarBtn} disabled:opacity-50`}
          onClick={() => handleSave(true)}
          disabled={saving}
        >
          Save & Exit
        </button>
        <button onClick={onClose} className={toolbarBtn}>
          Cancel
        </button>
      </div>

      {/* SCROLLABLE CONTENT */}
      <div className="max-h-[85vh] overflow-y-auto px-5 py-5">
        <h2 className="mb-4 text-2xl font-bold text-jnj-ink">
          {isEdit ? "Injury/Illness Detail" : "New Injury/Illness Event"}
        </h2>

        {loading ? (
          <div className="py-8 text-center text-sm text-slate-500">Loading Injury/Illness details...</div>
        ) : (
          <>
            {/* Master Event */}
            <ModalSubsection title="Master Event Information">
              {renderRow(
                { key: "masterRecord", label: "Master Record No." },
                <div className="text-sm text-gray-800">
                  {isProvided(masterNo) ? `Incident #${masterNo}` : "Incident # -"}
                </div>
              )}
            </ModalSubsection>

            {/* Injured Worker Details */}
            <ModalSubsection title="Injured Worker Details">
              <FieldInput
                field={{
                  key: "workerType",
                  label: "Worker Type",
                  type: "select",
                  required: true,
                  options: WORKER_TYPES,
                }}
                value={form.workerType}
                onChange={setField}
              />

              {/* Case 1: Visitor/Other -> show J&J Responsible Person (employee search) */}
              {isVisitorOrOther &&
                renderRow(
                  { key: "jjResponsiblePerson", label: "J&J Responsible Person" },
                  <div className="relative z-50">
                    <OnBehalfOfDropdown
                      value={form.jjResponsiblePerson ?? ""}
                      onSelect={(employee) => setField("jjResponsiblePerson", employee)}
                    />
                  </div>
                )}

              {/* Case 2: Agency worker supervised by J&J */}
              {isAgencyWorker && (
                <>
                  <FieldInput
                    field={{
                      key: "selectFromJJEDS",
                      label: "Select from JJEDS?",
                      type: "select",
                      options: YES_NO_OPTIONS,
                    }}
                    value={form.selectFromJJEDS}
                    onChange={setField}
                  />
                  <FieldInput
                    field={{
                      key: "contractingCompanyContactDetails",
                      label: "Contracting Company - Contact Details",
                      type: "textarea",
                    }}
                    value={form.contractingCompanyContactDetails}
                    onChange={setField}
                  />
                  {renderRow(
                    { key: "jjResponsiblePerson_agency", label: "J&J Responsible Person" },
                    <div className="relative z-50">
                      <OnBehalfOfDropdown
                        value={form.jjResponsiblePerson ?? ""}
                        onSelect={(employee) => setField("jjResponsiblePerson", employee)}
                      />
                    </div>
                  )}
                </>
              )}

              {/* Case 3: Contractor (Embedded or Non-Embedded) */}
              {isContractor && (
                <>
                  <FieldInput
                    field={{
                      key: "selectFromJJEDS",
                      label: "Select from JJEDS?",
                      type: "select",
                      options: YES_NO_OPTIONS,
                    }}
                    value={form.selectFromJJEDS}
                    onChange={setField}
                  />
                  <FieldInput
                    field={{
                      key: "contractingCompanyContactDetails",
                      label: "Contracting Company - Contact Details",
                      type: "textarea",
                    }}
                    value={form.contractingCompanyContactDetails}
                    onChange={setField}
                  />
                  {renderRow(
                    { key: "jjResponsiblePerson_contractor", label: "J&J Responsible Person" },
                    <div className="relative z-50">
                      <OnBehalfOfDropdown
                        value={form.jjResponsiblePerson ?? ""}
                        onSelect={(employee) => setField("jjResponsiblePerson", employee)}
                      />
                    </div>
                  )}
                </>
              )}
            </ModalSubsection>

            {/* Contractor Details (only for contractors) */}
            {isContractor && (
              <ModalSubsection title="Contractor Details">
                <FieldInput
                  field={{
                    key: "contractorCompanyName",
                    label: "* Contractor Company/CM Firm Name",
                    type: "text",
                    required: true,
                  }}
                  value={form.contractorCompanyName}
                  onChange={setField}
                />
                <FieldInput
                  field={{
                    key: "subcontractorCompanyName",
                    label: "Subcontractor Company Name",
                    type: "text",
                  }}
                  value={form.subcontractorCompanyName}
                  onChange={setField}
                />
                <FieldInput
                  field={{
                    key: "jobTypeAffected",
                    label: "* Job Type of Affected Individual",
                    type: "select",
                    required: true,
                    options: JOB_TYPE_OPTIONS,
                  }}
                  value={form.jobTypeAffected}
                  onChange={setField}
                />
                {norm(form.jobTypeAffected) === "other" && (
                  <FieldInput
                    field={{
                      key: "jobTypeOther",
                      label: "* Job Type (Other)",
                      type: "text",
                      required: true,
                    }}
                    value={form.jobTypeOther}
                    onChange={setField}
                  />
                )}
                <FieldInput
                  field={{
                    key: "serviceLengthCompany",
                    label: "* Service Length in Contractor Company",
                    type: "select",
                    required: true,
                    options: EXPERIENCE_OPTIONS,
                  }}
                  value={form.serviceLengthCompany}
                  onChange={setField}
                />
                <FieldInput
                  field={{
                    key: "experienceRole",
                    label: "* Experience in Role",
                    type: "select",
                    required: true,
                    options: EXPERIENCE_OPTIONS,
                  }}
                  value={form.experienceRole}
                  onChange={setField}
                />
                <FieldInput
                  field={{
                    key: "experienceOnSite",
                    label: "* Experience on Site",
                    type: "select",
                    required: true,
                    options: EXPERIENCE_OPTIONS,
                  }}
                  value={form.experienceOnSite}
                  onChange={setField}
                />
                <FieldInput
                  field={{
                    key: "ageRange",
                    label: "* Age Range",
                    type: "select",
                    required: true,
                    options: AGE_RANGE_OPTIONS,
                  }}
                  value={form.ageRange}
                  onChange={setField}
                />
                {/* Required and placed inside Contractor Details as requested */}
                <FieldInput
                  field={{
                    key: "hoursInShift",
                    label: "* Hours in the shift when the incident/SIF-P occurred",
                    type: "text",
                    required: true,
                  }}
                  value={form.hoursInShift}
                  onChange={setField}
                />
                <FieldInput
                  field={{
                    key: "drugAlcoholTest",
                    label: "Drug & Alcohol Test Performed?",
                    type: "select",
                    options: YES_NO_OPTIONS,
                  }}
                  value={form.drugAlcoholTest}
                  onChange={setField}
                />
              </ModalSubsection>
            )}

            {/* Injury/Illness Details */}
            <ModalSubsection title="Injury/Illness Details">
              <PrivacyNote>
                To view the Injury and Illness Recordkeeping and Reporting Guideline click here -
                <button className="ml-1 text-sky-600 hover:underline">LINK</button>
              </PrivacyNote>

              <FieldInput
                field={{
                  key: "workRelated",
                  label: "Is Incident Work Related?",
                  type: "select",
                  options: YES_NO_OPTIONS,
                }}
                value={form.workRelated}
                onChange={setField}
              />
              {norm(form.workRelated) === "no" && (
                <div className="mt-2 rounded-md bg-amber-50 p-2 text-xs text-amber-700">
                  Please contact local EHS to discuss this to confirm if this should be tracked as "Not being work related".
                </div>
              )}
            </ModalSubsection>

            {/* Mechanism of Injury */}
            <ModalSubsection title="Mechanism of Injury">
              <p className="text-sm text-slate-600">
                Select all the applicable Mechanism of Injury categories from the lists below.
              </p>

              {/* General */}
              <div className="grid grid-cols-1 gap-6 pt-4 md:grid-cols-[24%_1fr]">
                <div className="text-sm font-semibold text-slate-700">General</div>
                <div className="grid gap-2 md:grid-cols-2">
                  {MECHANISM_GENERAL.map((item) => (
                    <label key={item} className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={form.mechanismGeneral.includes(item)}
                        onChange={() => toggleInArray("mechanismGeneral", item)}
                      />
                      {item}
                    </label>
                  ))}
                </div>
              </div>

              {/* Exposure To */}
              <div className="grid grid-cols-1 gap-6 pt-6 md:grid-cols-[24%_1fr]">
                <div className="text-sm font-semibold text-slate-700">Exposure To</div>
                <div className="grid gap-2 md:grid-cols-2">
                  {EXPOSURE_TYPES.map((item) => (
                    <label key={item} className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={form.exposureTo.includes(item)}
                        onChange={() => toggleInArray("exposureTo", item)}
                      />
                      {item}
                    </label>
                  ))}
                </div>
              </div>

              {/* Vehicle Accident */}
              <div className="grid grid-cols-1 gap-6 pt-6 md:grid-cols-[24%_1fr]">
                <div className="text-sm font-semibold text-slate-700">Vehicle Accident</div>
                <div className="grid gap-2 md:grid-cols-2">
                  {VEHICLE_ACCIDENT_TYPES.map((item) => (
                    <label key={item} className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={form.vehicleAccidents.includes(item)}
                        onChange={() => toggleInArray("vehicleAccidents", item)}
                      />
                      {item}
                    </label>
                  ))}
                </div>
              </div>

              {/* Injury Or Illness */}
              <div className="mt-6 border-t border-jnj-line pt-6">
                <div className="grid grid-cols-1 gap-6 md:grid-cols-[24%_1fr]">
                  <div className="text-sm font-semibold text-slate-700">
                    * Injury or Illness? <span className="text-red-500">*</span>
                  </div>
                  <div className="flex gap-10">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="injuryType"
                        checked={form.injuryType === "Injury"}
                        onChange={() => setField("injuryType", "Injury")}
                      />
                      Injury
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="injuryType"
                        checked={form.injuryType === "Illness"}
                        onChange={() => setField("injuryType", "Illness")}
                      />
                      Illness
                    </label>
                  </div>
                </div>
              </div>
            </ModalSubsection>

            {/* Injury Severity */}
            <ModalSubsection title="Injury Severity">
              <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
                <div>
                  <h5 className="mb-3 font-semibold">
                    * Injury Severity - Primary Classifications (Single-Select) <span className="text-red-500">*</span>
                  </h5>
                  {PRIMARY_SEVERITY.map((item) => (
                    <label key={item} className="mb-2 flex items-center gap-2">
                      <input
                        type="radio"
                        name="severity"
                        checked={form.primarySeverity === item}
                        onChange={() => setField("primarySeverity", item)}
                      />
                      {item}
                    </label>
                  ))}
                  {errors.primarySeverity ? (
                    <div className="mt-2 text-xs text-red-600">{errors.primarySeverity}</div>
                  ) : null}
                </div>

                <div>
                  <label className="flex items-center gap-2 font-semibold">
                    {/* J&J Recordable is controlled by severity selection and is disabled */}
                    <input type="checkbox" checked={form.jjRecordable} disabled />
                    J&J Recordable
                  </label>
                  <div className="mt-2 text-xs text-gray-500">
                    This field is automatically set based on Primary Severity selection and cannot be edited.
                  </div>
                  <div className="mt-2 text-xs text-gray-600">
                    Auto-checked when Primary Severity is any of:
                    <ul className="list-disc ml-5">
                      <li>J&J Minor Injury/Illness</li>
                      <li>J&J Serious Injury/Illness Case (SIIC)</li>
                      <li>J&J Severe Injury or Fatality (SIF)</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="mt-5 rounded-lg bg-gray-50 p-3 text-sm">
                Select one primary severity classification and any additional classifications that apply.
              </div>

              <div className="mt-5">
                <h5 className="mb-3 font-semibold">Additional Classification</h5>
                {ADDITIONAL_SEVERITY.map((item) => (
                  <label key={item} className="mb-2 flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={form.additionalSeverity.includes(item)}
                      onChange={() => toggleInArray("additionalSeverity", item)}
                    />
                    {item}
                  </label>
                ))}
              </div>
            </ModalSubsection>

            {/* Outcomes */}
            <ModalSubsection title="Injury/Illness Outcomes">
              <div className="mb-2 text-sm font-semibold text-slate-700">Injury/Illness Outcome</div>
              <div className="grid gap-2 md:grid-cols-2">
                {INJURY_OUTCOMES.map((item) => (
                  <label key={item} className="flex items-start gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={form.outcomes.includes(item)}
                      onChange={() => toggleInArray("outcomes", item)}
                    />
                    <span>{item}</span>
                  </label>
                ))}
              </div>
            </ModalSubsection>

            {/* Regulatory Reporting */}
            <ModalSubsection title="Regulatory Reporting">
              {renderRow(
                {
                  key: "ghsStaff",
                  label: "Name of GHS staff involved in the injury severity classification",
                },
                <div className="relative z-50">
                  <OnBehalfOfDropdown
                    value={form.ghsStaff ?? ""}
                    onSelect={(employee) => setField("ghsStaff", employee)}
                  />
                </div>
              )}
              <FieldInput field={{ key: "ghsCaseNo", label: "GHS Case No", type: "text" }} value={form.ghsCaseNo} onChange={setField} />
              <FieldInput
                field={{
                  key: "regulatoryReporting",
                  label: "Does this require regulatory reporting in your region?",
                  type: "select",
                  options: YES_NO_OPTIONS,
                }}
                value={form.regulatoryReporting}
                onChange={setField}
              />
            </ModalSubsection>

            {/* J&J Escalation */}
            <ModalSubsection title="J&J Escalation">
              <FieldInput
                field={{
                  key: "escalationRequired",
                  label: "J&J Escalation required beyond site management?",
                  type: "select",
                  options: YES_NO_OPTIONS,
                }}
                value={form.escalationRequired}
                onChange={setField}
              />
              <PrivacyNote>
                If J&J Escalation is set to YES, review the fields triggering the escalation before overriding.
              </PrivacyNote>
            </ModalSubsection>

            {/* Injured Body Part */}
            <ModalSubsection title="Injured Body Part">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-[22%_1fr]">
                <div className="text-xs font-semibold text-gray-600">Most Severely Injured Body Part</div>
                <div className="grid gap-2 md:grid-cols-2">
                  {BODY_PART_OPTIONS.map((item) => (
                    <label key={item} className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="bodyPartPrimary"
                        checked={isBodyPartPrimary(item)}
                        onChange={() => setField("bodyPartPrimary", item)}
                      />
                      {item}
                    </label>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-[22%_1fr]">
                <div className="text-xs font-semibold text-gray-600">Injuries / Illness Body Parts</div>
                <div className="grid gap-2 md:grid-cols-2">
                  {BODY_PART_OPTIONS.map((item) => (
                    <label key={item} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={isBodyPartChecked(item)}
                        onChange={() => toggleInArray("bodyParts", item)}
                      />
                      {item}
                    </label>
                  ))}
                </div>
              </div>
            </ModalSubsection>

            {/* Comments */}
            <ModalSubsection title="Comments">
              <FieldInput
                field={{ key: "ppeUsed", label: "PPE used or training received?", type: "textarea" }}
                value={form.ppeUsed}
                onChange={setField}
              />
              <FieldInput
                field={{ key: "comments", label: "Comments", type: "textarea" }}
                value={form.comments}
                onChange={setField}
              />
              <PrivacyNote>Comments: Do not publish or disclose personal or confidential information.</PrivacyNote>
            </ModalSubsection>

            {/* Lost Time */}
            <ModalSubsection title="Lost Time">
              {lostTimeLoading ? (
                <div className="py-4 text-center text-sm text-slate-500">Loading Lost Time...</div>
              ) : (
                <SubformTable
                  addLabel="Add Lost Time"
                  actions={["Edit", "Delete", "List All"]}
                  columns={[
                    { key: "edit", label: "" }, // pencil icon at start
                    { key: "fromDate", label: "From Date" },
                    { key: "toDate", label: "To Date" },
                    { key: "calendarDaysAway", label: "Calendar Days Away (J&J)" },
                    { key: "workingDaysAway", label: "Working Days Away (Regulatory)" },
                    { key: "category", label: "Category" },
                    { key: "type", label: "Type" },
                    { key: "lwdc", label: "Lost Workday Case (LWDC)?" },
                  ]}
                  rows={lostTimeRowsWithEdit}
                  emptyText="No records to display."
                  onAdd={(action) => {
                    if (action === "Add Lost Time") {
                      handleAddLostTime();
                    }
                  }}
                  onRowClick={(row) => handleEditLostTime(row)}
                  onAction={(action, row) => {
                    if (action === "Edit") handleEditLostTime(row);
                    if (action === "Delete") handleDeleteLostTime(row.id);
                  }}
                />
              )}
            </ModalSubsection>

            {/* Sensitive Information */}
            <ModalSubsection title="Sensitive Information">
              <FieldInput
                field={{
                  key: "sensitiveInformation",
                  label: "Sensitive Information Included in this form?",
                  type: "select",
                  options: YES_NO_OPTIONS,
                }}
                value={form.sensitiveInformation}
                onChange={setField}
              />
            </ModalSubsection>

            {/* Pictures and Attachments */}
            <ModalSubsection title="Pictures and Attachments">
              <SubformTable
                addLabel="Attach Document"
                actions={["Detach Document", "List All"]}
                columns={[
                  { key: "attachmentName", label: "Attachment Name" },
                  { key: "url", label: "URL" },
                ]}
                rows={[]}
                emptyText="No records to display."
                onAdd={() => {}}
              />
              <PrivacyNote>
                Do not upload images containing personal data, recognizable individuals, or confidential information.
              </PrivacyNote>
            </ModalSubsection>
          </>
        )}
      </div>

      {showLostTimeModal && (
        <LostTimeModal
          masterRecordNo={masterNo}
          injuryRecordNo={detailNo}
          lostTimeRecordNo={editingLostTimeRecordNo}
          initialData={selectedLostTimeRecord}
          onClose={() => {
            setShowLostTimeModal(false);
            setSelectedLostTimeRecord(null);
            setEditingLostTimeRecordNo(null);
          }}
          onSave={(data, addAnother) => {
            // Persist row in table before closing
            const incomingRecordNo = data?.recordNo ?? editingLostTimeRecordNo ?? null;

            if (incomingRecordNo) {
              setLostTimeRows((prev) =>
                prev.map((row) =>
                  row.lostTimeRecordNo === incomingRecordNo
                    ? {
                        ...row,
                        fromDate: data.fromDate,
                        toDate: data.toDate,
                        calendarDaysAway: data.calendarDaysAway,
                        workingDaysAway: data.workingDaysAway,
                        category: data.category,
                        type: data.type,
                        lwdc: data.lwdc,
                      }
                    : row
                )
              );
            } else if (selectedLostTimeRecord) {
              setLostTimeRows((prev) =>
                prev.map((row) =>
                  row.id === selectedLostTimeRecord.id
                    ? {
                        ...row,
                        fromDate: data.fromDate,
                        toDate: data.toDate,
                        calendarDaysAway: data.calendarDaysAway,
                        workingDaysAway: data.workingDaysAway,
                        category: data.category,
                        type: data.type,
                        lwdc: data.lwdc,
                      }
                    : row
                )
              );
            } else {
              const newRow = {
                id: Math.random(),
                lostTimeRecordNo: data?.recordNo ?? null,
                fromDate: data.fromDate,
                toDate: data.toDate,
                calendarDaysAway: data.calendarDaysAway,
                workingDaysAway: data.workingDaysAway,
                category: data.category,
                type: data.type,
                lwdc: data.lwdc,
              };
              setLostTimeRows((prev) => [...prev, newRow]);
            }

            if (!addAnother) {
              setShowLostTimeModal(false);
              setSelectedLostTimeRecord(null);
              setEditingLostTimeRecordNo(null);
            }
          }}
        />
      )}
    </ModalShell>
  );
}
