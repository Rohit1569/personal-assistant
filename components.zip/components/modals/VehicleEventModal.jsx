// components/modals/VehicleEventModal.jsx
"use client";

import { useEffect, useState } from "react";
import { Save, Info, Paperclip, Pencil } from "lucide-react";

import { ModalShell } from "./ModalShell";
import SubformTable from "@/components/SubformTable";
import InvolvedVehicleModal from "./InvolvedVehicle";
import {
  getVehicleIncidentByIds,
  getVehicleDriversForIncident,
} from "@/lib/vehicleApi";

/* Option lists copied from your sequence (order preserved) */
const YES_NO_OPTIONS = ["Yes", "No"];

/* TODO: Replace with your actual Franchise list from backend or constants */
const FRANCHISE_OPTIONS = [
  "Pharmaceutical",
  "MedTech",
  "Consumer Health",
  "Vision Care",
  "Other",
];

const INCIDENT_CHARACTERISTICS = [
  "Vehicles in Motion - J&J Driver failed to give right of way (failed to yield)",
  "Vehicles in Motion - Other driver failed to give right of way (failed to yield)",
  "Vehicles in Motion - J&J Driver hit rear of other vehicle",
  "Vehicles in Motion - Other driver hit rear of J&J vehicle",
  'Vehicles in Motion - J&J Driver parking/”unparking”* (while Other Driver was in motion or stopped, but not parked) *J&J Driver motion may be moving forward or backing out',
  'Vehicles in Motion - Other Driver parking/”unparking”* (while J&J Driver was in motion or stopped, but not parked)  *Other Driver motion may be moving forward or backing out',
  "Vehicles in Motion - J&J Driver Hit and Run (Hit Other Driver)",
  "Vehicles in Motion - Other Driver Hit and Run (Hit J&J Driver)",
  "Vehicles in Motion - Our Driver Lost Control and Hit Other Vehicle (causing death, injury or material damage)",
  "Vehicles in Motion - Other Driver Lost Control and Hit Our Vehicle (causing death, injury or material damage)",
  "Vehicles in Motion - Other collision between vehicles in motion",
  "Collision with Stationary Object - J&J Driver parking/”unparking” (J&J Driver motion may be moving forward or backing out)",
  "Collision with Stationary Object - J&J Driver Failed to Observe Clearance (e.g., driver misjudges space between stationary objects such as poles or barriers)",
  "Collision with Stationary Object - J&J Driver Skidded or Slid into a stationary object",
  "Collision with Stationary Object - Other",
  "Collision with Stationary Object",
  "Non-Collision Crashes - J&J Driver lost control of vehicle (e.g., rollover of the vehicle causing death, injury or material damage)",
  "Non-Collision Crashes - Other",
  "Non-Collision Crashes",
  "Contact with Pedestrians or Bystanders - Death or injury caused by impact with vehicle, an object carried on the vehicle or set in motion by the vehicle",
  "Acts of Nature - Damages resulting from acts of nature such as ice, rain, lightning, earthquakes, severe storm, etc.",
  "Properly Parked Vehicle - Occurrences resulting in damage when vehicle is properly parked",
  "Contact with (or avoidance of) Animals, Rocks, Gravel, Tar or Debris - Damage resulting from contact with these items (include damage to windshield)",
  "Objects Falling on Motor Vehicle - Damage caused solely by object(s) falling on the vehicle (e.g., falling tree, rocks, items falling off or out of another vehicle and hitting our vehicle, etc.)",
  "Fire, Theft or Vandalism - Damage resulting from fire, vandalism or theft (i.e., breaking into vehicle)",
  "Vehicle or Equipment Failure - Damage resulting from vehicle or equipment failure (e.g., electrical fire, tire blow-out)",
  "Other Incident",
];

const INJURED_PARTIES = [
  "Our driver",
  "Our passenger(s)",
  "Other driver",
  "Other passenger(s)",
  "Cyclist",
  "Pedestrian",
  "Animal",
  "None",
  "Other (specify)",
];

const ROAD_TYPES = [
  "Public Access Road",
  "Private Access Road",
  "J&J property",
  "Bus Stop",
  "Parking lot/deck",
  "Personal Driveway/Garage",
  "Train track/Rail",
  "Other private property",
];

const ROAD_CONDITIONS = [
  "Dry",
  "Flooded",
  "Greasy",
  "Icy",
  "Muddy",
  "Potholes",
  "Rough terrain",
  "Snow covered",
  "Substance Deposited on Road",
  "Wet/damp",
  "Dirt",
];

const WEATHER_CONDITIONS = [
  "Dull/Overcast",
  "Fine/Sunny",
  "Fog/Mist",
  "Hail",
  "Rain",
  "Sandstorm",
  "Snow",
  "Strong Winds",
];

/* Default option lists for selects (these may have been updated by you) */
const DEFAULT_VISIBILITY_OPTIONS = ["Good", "Moderate", "Poor"];
const DEFAULT_LIGHT_CONDITION_OPTIONS = [
  "Daylight",
  "Dawn/Dusk",
  "Dark - Lighted",
  "Dark - Not Lighted",
];

/* Uniform two-column row for perfect alignment */
function Row({ label, required = false, children }) {
  return (
    <div className="grid grid-cols-1 items-start md:grid-cols-[22%_1fr]">
      <div className="px-16 py-2 text-xs font-semibold text-gray-600">
        {required ? `* ${label}` : label}
      </div>
      <div className="px-2 py-1">{children}</div>
    </div>
  );
}

/* Helper: two-column checkbox grid on larger screens (collapses to one on mobile) */
function CheckboxGrid({ options, selected, onToggle }) {
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {options.map((o) => (
        <label key={o} className="flex items-start gap-2 text-sm">
          <input
            type="checkbox"
            checked={selected.includes(o)}
            onChange={() => onToggle(o)}
          />
          <span>{o}</span>
        </label>
      ))}
    </div>
  );
}

/* Themed input styles to match property/spill modals */
const inputCls = "w-full rounded border border-jnj-line px-3 py-2 text-sm";
const selectNarrowCls =
  "w-[280px] rounded border border-jnj-line px-3 py-2 text-sm";

const norm = (s) => String(s || "").toLowerCase();
const toYesNo = (val) => {
  if (val === true || val === 1 || String(val).toLowerCase() === "yes")
    return "Yes";
  if (val === false || val === 0 || String(val).toLowerCase() === "no")
    return "No";
  return val == null ? "" : String(val);
};

export default function NewVehicleEventModal({
  onClose,
  onSave,
  // Preferred edit props
  incidentMasterNo, // master Incident RecordNo
  incidentRecordNo, // Vehicle sub-form RecordNo
  // Legacy fallback
  eventId,
  recordNo,
}) {
  const [form, setForm] = useState({
    masterRecord: "",
    isSafeFleetRelated: "",
    franchise: "",

    incidentCharacteristics: [],
    incidentCharacteristicsOther: "",

    injuredParties: [],
    injuredPartiesOther: "",

    damageToVehiclesOther: "",
    productOrSamplesInvolved: "",
    productHazardousYesNo: "",

    reportedToPolice: "",
    policeRecordNumber: "",
    policeNumberAssignedByPolice: "",
    policeDriverCitation: "",

    purposeOfJourney: "",
    driverDistracted: "",
    seatBeltWorn: "",
    numberOfPassengers: "",
    postedSpeedLimit: "",
    speedAtIncident: "",
    regulatoryReporting: "",
    escalationRequired: "No",
    sensitiveInformation: "No",

    roadTypes: [],
    roadConditions: [],
    weatherConditions: [],
    visibility: "",
    lightConditions: "",

    attachments: [],
  });

  const [loading, setLoading] = useState(false);
  const [involvedVehicleModalOpen, setInvolvedVehicleModalOpen] =
    useState(false);
  const [editingVehicleRecordNo, setEditingVehicleRecordNo] = useState(null);

  // Vehicle/Driver table rows (populated from VehicleObject endpoint OR InvolveVehicles)
  const [vehicleRows, setVehicleRows] = useState([]);

  // Make visibility/light options dynamic so we can inject API-returned values
  const [visibilityOptions, setVisibilityOptions] = useState(
    DEFAULT_VISIBILITY_OPTIONS
  );
  const [lightConditionOptions, setLightConditionOptions] = useState(
    DEFAULT_LIGHT_CONDITION_OPTIONS
  );

  const masterNo = incidentMasterNo ?? eventId;
  const detailNo = incidentRecordNo ?? recordNo;
  const isEdit =
    masterNo != null && masterNo !== "" && detailNo != null && detailNo !== "";

  const setField = (key, value) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const toggleArray = (key, value) =>
    setForm((prev) => {
      const exists = prev[key].includes(value);
      return {
        ...prev,
        [key]: exists
          ? prev[key].filter((v) => v !== value)
          : [...prev[key], value],
      };
    });

  // helper to safely extract Value arrays from expanded objects
  const extractArrayValues = (maybeArray) =>
    Array.isArray(maybeArray)
      ? maybeArray.map((x) => x?.Value).filter(Boolean)
      : [];

  // helper: case-insensitive contains
  const optionExists = (options, raw) =>
    options.some((o) => norm(o) === norm(raw));

  // Load core Vehicle Incident details
  useEffect(() => {
    let cancelled = false;

    if (!isEdit) {
      setForm((p) => ({
        ...p,
        masterRecord: "",
      }));
      setVehicleRows([]);
      setLoading(false);
      return;
    }

    const load = async () => {
      try {
        setLoading(true);
        const data = await getVehicleIncidentByIds(masterNo, detailNo);
        if (cancelled) return;

        if (data) {
          // Franchise
          const franchiseName =
            data?.Franchise?.DCP?.NameSafeFleet ||
            data?.Franchise?.Caption ||
            data?.Franchise?.Value ||
            "";

          // Characteristics
          const characteristicValues = extractArrayValues(data?.Characteristics);
          const helper = String(data?.HelperResult2 || "").toLowerCase();
          const fallbackFromHelper =
            characteristicValues.length === 0 && helper
              ? INCIDENT_CHARACTERISTICS.filter((opt) =>
                  helper.includes(norm(opt).slice(0, Math.min(20, opt.length)))
                )
              : [];

          const selectedCharacteristics =
            characteristicValues.length > 0
              ? INCIDENT_CHARACTERISTICS.filter((opt) =>
                  characteristicValues.some(
                    (cv) =>
                      norm(cv) === norm(opt) ||
                      norm(cv).includes(norm(opt).slice(0, 20)) ||
                      norm(opt).includes(norm(cv).slice(0, 20))
                  )
                )
              : fallbackFromHelper;

          const unknownCharacteristics =
            characteristicValues.length > 0
              ? characteristicValues.filter(
                  (cv) =>
                    !INCIDENT_CHARACTERISTICS.some((opt) => norm(opt) === norm(cv))
                )
              : [];

          // Injured parties
          const injuredValues = extractArrayValues(data?.InjuredParties);
          const selectedInjured = INJURED_PARTIES.filter((opt) =>
            injuredValues.some((iv) => norm(iv) === norm(opt))
          );
          const unknownInjured = injuredValues.filter(
            (iv) => !INJURED_PARTIES.some((opt) => norm(opt) === norm(iv))
          );

          // Road / weather / visibility / light
          const roadTypes = extractArrayValues(data?.RoadType);
          const selectedRoadTypes = ROAD_TYPES.filter((opt) =>
            roadTypes.some((rt) => norm(rt) === norm(opt))
          );

          const roadConditions = extractArrayValues(data?.RoadCondition);
          const selectedRoadConditions = ROAD_CONDITIONS.filter((opt) =>
            roadConditions.some((rc) => norm(rc) === norm(opt))
          );

          const weatherConditions = extractArrayValues(data?.WeatheCondition);
          const selectedWeatherConditions = WEATHER_CONDITIONS.filter((opt) =>
            weatherConditions.some((wc) => norm(wc) === norm(opt))
          );

          // Visibility and Light raw values from API
          const visibilityRaw = data?.Visibility?.Value || "";
          const lightConditionsRaw = data?.LightConditions?.Value || "";

          // Ensure visibilityRaw is present in options (case-insensitive). If not, inject it.
          if (visibilityRaw && !optionExists(visibilityOptions, visibilityRaw)) {
            setVisibilityOptions((prev) =>
              prev.includes(visibilityRaw) ? prev : [visibilityRaw, ...prev]
            );
          }

          // Ensure lightConditionsRaw is present in options (case-insensitive). If not, inject it.
          if (
            lightConditionsRaw &&
            !optionExists(lightConditionOptions, lightConditionsRaw)
          ) {
            setLightConditionOptions((prev) =>
              prev.includes(lightConditionsRaw) ? prev : [lightConditionsRaw, ...prev]
            );
          }

          // InvolveVehicles mapping
          const involveVehicles = Array.isArray(data?.InvolveVehicles)
            ? data.InvolveVehicles
            : [];
          const mappedInvolveVehicles =
            involveVehicles.length > 0
              ? involveVehicles.map((v) => {
                  const ownership =
                    v?.VehiclOwnership?.Caption || v?.VehiclOwnership?.Value || "";
                  const type = v?.VehicleType?.Caption || v?.VehicleType?.Value || "";
                  const driver =
                    v?.DriversName ||
                    v?.VehicAssignedTo?.Name ||
                    v?.VehicAssignedTo?.FullName ||
                    "";
                  return {
                    vehicleRecordNo: v?.RecordNo ?? null,
                    vehicleOwnership: ownership,
                    vehicleType: type,
                    vehicleDriver: driver,
                  };
                })
              : [];

          // Police / Other fields
          const policeRecordNumber = data?.PolrecordNumber || "";
          const rByEitherDriver = data?.RbyEitherDriver || "";
          const otherInjuredFreeText = data?.OInjuredParties || "";

          // Purpose of journey
          const purposeOfJourney = data?.PurposofJourney?.Value || data?.Description || "";

          // Update form fields
          setForm((prev) => ({
            ...prev,
            masterRecord: `Incident #${masterNo}`,
            isSafeFleetRelated: toYesNo(data?.SAFFleetrelated),
            franchise: franchiseName,

            incidentCharacteristics: selectedCharacteristics,
            incidentCharacteristicsOther: unknownCharacteristics.join("; "),

            injuredParties: selectedInjured,
            injuredPartiesOther: unknownInjured.join("; ") || otherInjuredFreeText,

            damageToVehiclesOther: toYesNo(data?.DamagetoVehicle),
            productOrSamplesInvolved: toYesNo(data?.WsProdctInvolvd),
            productHazardousYesNo: toYesNo(data?.mrequirecleanup),

            reportedToPolice: toYesNo(data?.ReportetoPolice),
            policeRecordNumber: policeRecordNumber,
            policeNumberAssignedByPolice: "",
            policeDriverCitation: rByEitherDriver,

            purposeOfJourney: purposeOfJourney,
            driverDistracted: toYesNo(data?.DriverDistract),
            seatBeltWorn: toYesNo(data?.wearingseatbelt ?? data?.wearinSeatbelts),
            numberOfPassengers:
              data?.NumofPassengers != null ? String(data.NumofPassengers) : "",
            postedSpeedLimit:
              data?.PosteSpeedLimitUoMDefaultValue != null
                ? String(data.PosteSpeedLimitUoMDefaultValue)
                : "",
            speedAtIncident:
              data?.aTimeofIncidentUoMDefaultValue != null
                ? String(data.aTimeofIncidentUoMDefaultValue)
                : "",
            regulatoryReporting: toYesNo(data?.RegRptRequired),
            escalationRequired: toYesNo(data?.Escalation) || "No",
            sensitiveInformation: toYesNo(data?.Sensitive) || "No",

            roadTypes: selectedRoadTypes,
            roadConditions: selectedRoadConditions,
            weatherConditions: selectedWeatherConditions,
            // Set visibility and light to raw API values (the select will show them since we injected them if needed)
            visibility: visibilityRaw,
            lightConditions: lightConditionsRaw,

            attachments: prev.attachments ?? [],
          }));

          // Populate vehicleRows if InvolveVehicles provided inline
          if (mappedInvolveVehicles.length > 0) {
            setVehicleRows(mappedInvolveVehicles);
          }
        } else {
          setForm((p) => ({
            ...p,
            masterRecord: `Incident #${masterNo}`,
          }));
        }
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error("Error loading Vehicle Incident:", e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    load();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isEdit, masterNo, detailNo]); // visibilityOptions/lightConditionOptions not added to deps to avoid loops

  // Load Vehicle/Driver info list for this incident (preferred source)
  useEffect(() => {
    let cancelled = false;

    if (!isEdit) {
      setVehicleRows([]);
      return;
    }

    const loadVehicles = async () => {
      try {
        const list = await getVehicleDriversForIncident(masterNo, detailNo);
        if (cancelled) return;

        const rows = list.map((v) => {
          const ownership =
            v?.VehiclOwnership?.Caption || v?.VehiclOwnership?.Value || "";
          const type = v?.VehicleType?.Caption || v?.VehicleType?.Value || "";
          const driver =
            v?.DriversName ||
            v?.VehicAssignedTo?.Name ||
            v?.VehicAssignedTo?.FullName ||
            "";

          return {
            vehicleRecordNo: v?.RecordNo ?? null, // keep record id for editing
            vehicleOwnership: ownership,
            vehicleType: type,
            vehicleDriver: driver,
          };
        });

        setVehicleRows(rows);
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error("Error loading Vehicle/Driver list:", e);
        setVehicleRows([]);
      }
    };

    loadVehicles();
    return () => {
      cancelled = true;
    };
  }, [isEdit, masterNo, detailNo]);

  const toolbarBtn = "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";

  const handleSave = () => onSave?.(form);

  const handleOpenInvolvedVehicleModal = () => {
    setEditingVehicleRecordNo(null); // add mode
    setInvolvedVehicleModalOpen(true);
  };

  const handleCloseInvolvedVehicleModal = () => {
    setInvolvedVehicleModalOpen(false);
    setEditingVehicleRecordNo(null);
  };

  const handleEditInvolvedVehicle = (row) => {
    setEditingVehicleRecordNo(row?.vehicleRecordNo ?? null);
    setInvolvedVehicleModalOpen(true);
  };

  const handleSaveInvolvedVehicle = (vehicleData) => {
    // Add or update the vehicle in the table
    const incomingRecordNo =
      vehicleData?.recordNo ?? editingVehicleRecordNo ?? null;

    const newRow = {
      vehicleRecordNo: incomingRecordNo,
      vehicleOwnership: vehicleData.vehicleOwnership,
      vehicleType: vehicleData.vehicleType,
      vehicleDriver: vehicleData.driverName,
    };

    setVehicleRows((prev) => {
      if (incomingRecordNo != null) {
        const idx = prev.findIndex((r) => r.vehicleRecordNo === incomingRecordNo);
        if (idx >= 0) {
          const copy = [...prev];
          copy[idx] = newRow;
          return copy;
        }
      }
      return [...prev, newRow];
    });

    setInvolvedVehicleModalOpen(false);
    setEditingVehicleRecordNo(null);
  };

  // Convenience flags for conditional UI
  const isSafeFleetYes = String(form.isSafeFleetRelated) === "Yes";
  const injuredPartiesHasOther = form.injuredParties.includes("Other (specify)");
  const productInvolvedYes = String(form.productOrSamplesInvolved) === "Yes";
  const reportedToPoliceYes = String(form.reportedToPolice) === "Yes";

  // Create rows with a leading pencil icon for edit
  const vehicleRowsWithEdit = vehicleRows.map((row, index) => ({
    ...row,
    edit: (
      <button
        type="button"
        onClick={() => handleEditInvolvedVehicle(row)}
        className="inline-flex items-center text-jnj-slate hover:text-jnj-red"
        title="Edit Vehicle/Driver"
      >
        <Pencil className="h-4 w-4" />
      </button>
    ),
    _rowKey:
      row.vehicleRecordNo ?? `${row.vehicleOwnership}-${row.vehicleType}-${index}`,
  }));

  return (
    <>
      <ModalShell
        title={isEdit ? `Vehicle Event (${detailNo})` : "Add Entry"}
        onClose={onClose}
        maxWidth="max-w-6xl"
      >
        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
          <button
            onClick={handleSave}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red"
          >
            <Save className="h-4 w-4" />
            Save
          </button>

          <button
            onClick={() => {
              handleSave();
              onClose?.();
            }}
            className={toolbarBtn}
          >
            Save & Exit
          </button>

          <button onClick={onClose} className={toolbarBtn}>
            Cancel
          </button>
        </div>

        {/* Body */}
        <div className="max-h-[80vh] overflow-y-auto px-5 py-5">
          <h2 className="mb-2 text-2xl font-bold text-jnj-ink">
            {isEdit ? "Vehicle Event Detail" : "New Vehicle Event"}
          </h2>

          {/* Master Event Information */}
          <div className="overflow-hidden rounded-xl border border-jnj-line">
            <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
              <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                <Info className="h-3.5 w-3.5" />
              </span>
              <h4 className="text-sm font-bold text-jnj-ink">Master Event Information</h4>
            </div>

            <div className="p-4">
              <Row label="Master Record No.">
                <div className="text-sky-600">{form.masterRecord || "Incident # -"}</div>
              </Row>
            </div>
          </div>

          {/* Loading indicator */}
          {loading ? (
            <div className="py-8 text-center text-sm text-slate-500">
              Loading Vehicle Event details...
            </div>
          ) : (
            <>
              {/* Incident Details */}
              <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
                <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                  <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                    <Info className="h-3.5 w-3.5" />
                  </span>
                  <h4 className="text-sm font-bold text-jnj-ink">Incident Details</h4>
                </div>

                <div className="space-y-4 p-4">
                  <Row label="Is this SAFE FLEET related?">
                    <select
                      className={selectNarrowCls}
                      value={form.isSafeFleetRelated}
                      onChange={(e) => setField("isSafeFleetRelated", e.target.value)}
                    >
                      <option value=""></option>
                      {YES_NO_OPTIONS.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </Row>

                  {/* If SAFE FLEET related = Yes → Franchise dropdown (required) */}
                  {isSafeFleetYes && (
                    <Row label="Franchise" required>
                      <select
                        className={selectNarrowCls}
                        value={form.franchise}
                        onChange={(e) => setField("franchise", e.target.value)}
                      >
                        <option value=""></option>
                        {FRANCHISE_OPTIONS.map((o) => (
                          <option key={o} value={o}>
                            {o}
                          </option>
                        ))}
                      </select>
                    </Row>
                  )}

                  {/* Incident Characteristics (two-column checkboxes) */}
                  <Row label="Incident Characteristics" required>
                    <CheckboxGrid
                      options={INCIDENT_CHARACTERISTICS}
                      selected={form.incidentCharacteristics}
                      onToggle={(v) => toggleArray("incidentCharacteristics", v)}
                    />
                    {form.incidentCharacteristicsOther && (
                      <div className="mt-2 text-xs text-slate-600">
                        Other characteristics: {form.incidentCharacteristicsOther}
                      </div>
                    )}
                  </Row>

                  {/* Injured Parties */}
                  <Row label="Injured Parties?" required>
                    <CheckboxGrid
                      options={INJURED_PARTIES}
                      selected={form.injuredParties}
                      onToggle={(v) => toggleArray("injuredParties", v)}
                    />
                    {form.injuredPartiesOther && (
                      <div className="mt-2 text-xs text-slate-600">
                        Other injured parties: {form.injuredPartiesOther}
                      </div>
                    )}
                  </Row>

                  {/* If Injured Parties includes Other (specify) → required text box */}
                  {injuredPartiesHasOther && (
                    <Row label="Please Specify Other Injured Parties" required>
                      <input
                        type="text"
                        className={inputCls}
                        value={form.injuredPartiesOther}
                        onChange={(e) => setField("injuredPartiesOther", e.target.value)}
                        placeholder="Enter other injured parties"
                      />
                    </Row>
                  )}

                  {/* Damage / Product / Police */}
                  <Row label="Damage to Vehicle(s), Other?" required>
                    <select
                      className={selectNarrowCls}
                      value={form.damageToVehiclesOther}
                      onChange={(e) => setField("damageToVehiclesOther", e.target.value)}
                    >
                      <option value=""></option>
                      {YES_NO_OPTIONS.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </Row>

                  <Row label="Was Product or Samples Involved?" required>
                    <select
                      className={selectNarrowCls}
                      value={form.productOrSamplesInvolved}
                      onChange={(e) => setField("productOrSamplesInvolved", e.target.value)}
                    >
                      <option value=""></option>
                      {YES_NO_OPTIONS.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </Row>

                  {/* If Product/Samples involved = Yes → dropdown Yes/No */}
                  {productInvolvedYes && (
                    <Row label="Did product or Hazardous">
                      <select
                        className={selectNarrowCls}
                        value={form.productHazardousYesNo}
                        onChange={(e) => setField("productHazardousYesNo", e.target.value)}
                      >
                        <option value=""></option>
                        {YES_NO_OPTIONS.map((o) => (
                          <option key={o} value={o}>
                            {o}
                          </option>
                        ))}
                      </select>
                    </Row>
                  )}

                  <Row label="Was Event Reported to Police?" required>
                    <select
                      className={selectNarrowCls}
                      value={form.reportedToPolice}
                      onChange={(e) => setField("reportedToPolice", e.target.value)}
                    >
                      <option value=""></option>
                      {YES_NO_OPTIONS.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </Row>

                  {/* If Reported to Police = Yes → show additional fields */}
                  {reportedToPoliceYes && (
                    <>
                      <Row label="Police Record Number">
                        <input
                          type="text"
                          className={inputCls}
                          value={form.policeRecordNumber}
                          onChange={(e) => setField("policeRecordNumber", e.target.value)}
                          placeholder="Enter police record number"
                        />
                      </Row>

                      <Row label="This number is assigned by the police.">
                        <input
                          type="text"
                          className={inputCls}
                          value={form.policeNumberAssignedByPolice}
                          onChange={(e) => setField("policeNumberAssignedByPolice", e.target.value)}
                          placeholder="Enter number assigned by police"
                        />
                      </Row>

                      <Row label="Did our Driver Receive a Citation?">
                        <select
                          className={selectNarrowCls}
                          value={form.policeDriverCitation}
                          onChange={(e) => setField("policeDriverCitation", e.target.value)}
                        >
                          <option value=""></option>
                          {YES_NO_OPTIONS.map((o) => (
                            <option key={o} value={o}>
                              {o}
                            </option>
                          ))}
                        </select>
                      </Row>
                    </>
                  )}

                  <Row label="Purpose of Journey" required>
                    <input
                      type="text"
                      className={inputCls}
                      value={form.purposeOfJourney}
                      onChange={(e) => setField("purposeOfJourney", e.target.value)}
                    />
                  </Row>

                  <Row
                    label="Was Driver Distracted (Using Mobile Device, Fatigued, Reaching for object, vehicle adjustment, etc.)?"
                    required
                  >
                    <select
                      className={selectNarrowCls}
                      value={form.driverDistracted}
                      onChange={(e) => setField("driverDistracted", e.target.value)}
                    >
                      <option value=""></option>
                      {YES_NO_OPTIONS.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </Row>

                  <Row label="Was Driver wearing seat belt?">
                    <select
                      className={selectNarrowCls}
                      value={form.seatBeltWorn}
                      onChange={(e) => setField("seatBeltWorn", e.target.value)}
                    >
                      <option value=""></option>
                      {YES_NO_OPTIONS.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </Row>

                  {/* Passenger / Speed fields */}
                  <Row label="Number of Passengers" required>
                    <input
                      type="number"
                      min="0"
                      className={selectNarrowCls}
                      value={form.numberOfPassengers}
                      onChange={(e) => setField("numberOfPassengers", e.target.value)}
                    />
                  </Row>

                  <Row label="Posted Speed Limit" required>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="0"
                        className={selectNarrowCls}
                        value={form.postedSpeedLimit}
                        onChange={(e) => setField("postedSpeedLimit", e.target.value)}
                      />
                      <span className="text-sm text-slate-600">mph</span>
                    </div>
                  </Row>

                  <Row label="Speed at Time of Incident" required>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="0"
                        className={selectNarrowCls}
                        value={form.speedAtIncident}
                        onChange={(e) => setField("speedAtIncident", e.target.value)}
                      />
                      <span className="text-sm text-slate-600">mph</span>
                    </div>
                  </Row>
                </div>
              </div>

              {/* Regulatory Information */}
              <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
                <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                  <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                    <Info className="h-3.5 w-3.5" />
                  </span>
                  <h4 className="text-sm font-bold text-jnj-ink">Regulatory Information</h4>
                </div>

                <div className="space-y-4 p-4">
                  <Row label="Does this require regulatory reporting in your region?" required>
                    <select
                      className={selectNarrowCls}
                      value={form.regulatoryReporting}
                      onChange={(e) => setField("regulatoryReporting", e.target.value)}
                    >
                      <option value=""></option>
                      {YES_NO_OPTIONS.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </Row>

                  <div className="px-16 text-sm">
                    To view the Incident Reporting Guidelines click here -
                    <a href="#" className="ml-1 text-sky-600 hover:underline">
                      LINK
                    </a>
                  </div>

                  <Row label="J&J Escalation required beyond site management (Vehicle - Escalation Guideline)">
                    <select
                      className={selectNarrowCls}
                      value={form.escalationRequired}
                      onChange={(e) => setField("escalationRequired", e.target.value)}
                    >
                      {YES_NO_OPTIONS.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </Row>

                  <div className="rounded border border-sky-300 bg-sky-100 px-3 py-2 text-sm text-sky-900">
                    If the field "J&J Escalation required beyond site management (Escalation
                    Guideline)" is YES, and you wish to change this, please review the fields
                    in this subform which are triggering this escalation. If you wish to
                    override the escalation guideline for a specific circumstance, you can do
                    that in the master event. A justification is required.
                  </div>
                </div>
              </div>

              {/* External Conditions */}
              <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
                <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                  <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                    <Info className="h-3.5 w-3.5" />
                  </span>
                  <h4 className="text-sm font-bold text-jnj-ink">External Conditions</h4>
                </div>

                <div className="space-y-4 p-4">
                  <Row label="Road Type" required>
                    <CheckboxGrid
                      options={ROAD_TYPES}
                      selected={form.roadTypes}
                      onToggle={(v) => toggleArray("roadTypes", v)}
                    />
                  </Row>

                  <Row label="Road Condition" required>
                    <CheckboxGrid
                      options={ROAD_CONDITIONS}
                      selected={form.roadConditions}
                      onToggle={(v) => toggleArray("roadConditions", v)}
                    />
                  </Row>

                  <Row label="Weather Condition" required>
                    <CheckboxGrid
                      options={WEATHER_CONDITIONS}
                      selected={form.weatherConditions}
                      onToggle={(v) => toggleArray("weatherConditions", v)}
                    />
                  </Row>

                  <Row label="Visibility" required>
                    <select
                      className={selectNarrowCls}
                      value={form.visibility}
                      onChange={(e) => setField("visibility", e.target.value)}
                    >
                      <option value=""></option>
                      {visibilityOptions.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </Row>

                  <Row label="Light Conditions" required>
                    <select
                      className={selectNarrowCls}
                      value={form.lightConditions}
                      onChange={(e) => setField("lightConditions", e.target.value)}
                    >
                      <option value=""></option>
                      {lightConditionOptions.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </Row>
                </div>
              </div>

              {/* Sensitive Information */}
              <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
                <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                  <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                    <Info className="h-3.5 w-3.5" />
                  </span>
                  <h4 className="text-sm font-bold text-jnj-ink">Sensitive Information</h4>
                </div>

                <div className="p-4">
                  <Row label="Sensitive Information Included in this form?">
                    <select
                      className={selectNarrowCls}
                      value={form.sensitiveInformation}
                      onChange={(e) => setField("sensitiveInformation", e.target.value)}
                    >
                      {YES_NO_OPTIONS.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  </Row>
                </div>
              </div>

              {/* Vehicle/Driver Information (now prefilled from API) */}
              <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
                <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                  <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                    <Info className="h-3.5 w-3.5" />
                  </span>
                  <h4 className="text-sm font-bold text-jnj-ink">Vehicle/Driver Information</h4>
                </div>

                <div className="p-4">
                  <div className="px-2 py-1 text-sm text-slate-600">
                    To add vehicle/driver info, please click save first. If you don't see the
                    vehicle/driver information that you've added, please click "List All".
                  </div>

                  <SubformTable
                    addLabel="Add Vehicle/Driver"
                    actions={["List All"]}
                    columns={[
                      { key: "edit", label: "" }, // edit pencil
                      { key: "vehicleOwnership", label: "Vehicle Ownership" },
                      { key: "vehicleType", label: "Vehicle Type" },
                      { key: "vehicleDriver", label: "Vehicle Driver" },
                    ]}
                    rows={vehicleRowsWithEdit}
                    emptyText="No records to display."
                    onAdd={handleOpenInvolvedVehicleModal}
                  />
                </div>
              </div>

              {/* Pictures and Attachments */}
              <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
                <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                  <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                    <Paperclip className="h-3.5 w-3.5" />
                  </span>
                  <h4 className="text-sm font-bold text-jnj-ink">Pictures and Attachments</h4>
                </div>

                <div className="p-4">
                  <SubformTable
                    addLabel="Attach Document"
                    actions={["Detach Document", "List All"]}
                    columns={[
                      { key: "attachmentName", label: "Attachment Name" },
                      { key: "url", label: "URL" },
                    ]}
                    rows={[]}
                    emptyText="No records to display."
                    onAdd={() => {}}
                  />

                  <div className="mt-3 text-xs text-slate-600">10 Items Displayed</div>

                  <div className="mt-3 rounded border border-sky-200 bg-sky-50 px-3 py-2 text-sm text-sky-900">
                    Pictures and Attachments: Do not publish or think carefully before
                    disclosing pictures with personal information or recognizable persons on it.
                  </div>
                </div>
              </div>

              {/* Downloadable Documents */}
              <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
                <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                  <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                    <Info className="h-3.5 w-3.5" />
                  </span>
                  <h4 className="text-sm font-bold text-jnj-ink">Downloadable Documents</h4>
                </div>

                <div className="p-4">
                  <SubformTable
                    actions={["List All"]}
                    columns={[{ key: "templateName", label: "Template Name" }]}
                    rows={[]}
                    emptyText="No records to display."
                    onAdd={() => {}}
                  />

                  <div className="mt-3 text-xs text-slate-600">Default Items Displayed</div>
                </div>
              </div>
            </>
          )}
        </div>
      </ModalShell>

      {/* Involved Vehicle Modal */}
      {involvedVehicleModalOpen && (
        <InvolvedVehicleModal
          onClose={handleCloseInvolvedVehicleModal}
          onSave={handleSaveInvolvedVehicle}
          incidentMasterNo={masterNo}
          incidentRecordNo={detailNo}
          vehicleRecordNo={editingVehicleRecordNo}
        />
      )}
    </>
  );
}
