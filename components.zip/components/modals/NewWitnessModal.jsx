// components/modals/NewWitnessModal.jsx
"use client";

import { useEffect, useState } from "react";
import { Info, Paperclip } from "lucide-react";

import { ModalShell } from "./ModalShell";
import SubformModalToolbar from "./SubformModalToolbar";
import FieldInput from "@/components/FieldInput";
import OnBehalfOfDropdown from "@/components/EmployeeSearchDropdown";
import SubformTable from "@/components/SubformTable";
import { WITNESS_TYPE_OPTIONS } from "@/app/constants/initialReport";
import { getWitnessDetails } from "@/lib/witnessApi";
import { useTranslation } from "@/lib/i18n";
import { SAVE_MODES } from "@/lib/subformRecords";
import { YES, NO } from "@/lib/businessRules";

export const EMPTY_WITNESS_FORM = Object.freeze({
  witnessName: "",
  witnessType: "",
  contactInfo: "",
  dateOfInterview: "",
  witnessStatement: "",
  selectFromJJEDS: "", // "Yes" | "No" for JJEDS types
});

// Canonical witness-type values (language independent).
const JJEDS_TYPES = [
  "Agency worker supervised by J&J (Non-J&J Employee)",
  "Contractor (Construction)",
  "Contractor (Embedded)",
  "Contractor (other)",
];
const PLAIN_NAME_TYPES = ["Visitor/other", "Visitor", "Other"];

function isNameRequired(form) {
  if (!form.witnessType) return false;
  if (PLAIN_NAME_TYPES.includes(form.witnessType)) return true;
  if (JJEDS_TYPES.includes(form.witnessType)) return form.selectFromJJEDS === NO;
  return true;
}

export function validateWitnessForm(form) {
  const errors = {};
  if (!form.witnessType) errors.witnessType = "validation.required";
  if (isNameRequired(form) && !String(form.witnessName ?? "").trim()) errors.witnessName = "validation.required";
  return errors;
}

export default function NewWitnessModal({
  eventId,
  serverRecordNo, // when editing a server row without local edits, details are fetched
  recordLabel,
  initialForm,
  restoredDraft = false,
  onSave,
  onClose,
  onDiscardDraft,
}) {
  const { t, toOptions } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState(() => ({ ...EMPTY_WITNESS_FORM, ...(initialForm || {}) }));
  const [attempted, setAttempted] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState(null);
  const [showRestored, setShowRestored] = useState(restoredDraft);

  const set = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  // Load details for an existing server record (only if we have no local copy).
  useEffect(() => {
    if (!serverRecordNo || initialForm) return;
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);
        const witness = await getWitnessDetails(eventId, serverRecordNo);
        if (!witness || cancelled) return;
        setForm({
          ...EMPTY_WITNESS_FORM,
          witnessName: witness?.EmployeeName || witness?.HelpWitnessName || "",
          witnessType: witness?.JJWitnessType?.EmployeeType || witness?.JJWitnessType?.Value || "",
          contactInfo: witness?.WitContactNum ?? "",
          dateOfInterview: witness?.DateofInterview
            ? new Date(witness.DateofInterview).toISOString().split("T")[0]
            : "",
          witnessStatement: witness?.WitnesStatement ?? "",
        });
      } catch (error) {
        console.error("Witness Detail Load Error:", error);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [eventId, serverRecordNo, initialForm]);

  // Default "Select from JJEDS?" to Yes for JJEDS types; clear it otherwise.
  useEffect(() => {
    setForm((prev) => {
      if (JJEDS_TYPES.includes(prev.witnessType)) {
        return prev.selectFromJJEDS ? prev : { ...prev, selectFromJJEDS: YES };
      }
      return prev.selectFromJJEDS ? { ...prev, selectFromJJEDS: "" } : prev;
    });
  }, [form.witnessType]);

  const errors = validateWitnessForm(form);
  const errorFor = (key) => (attempted && errors[key] ? t(errors[key]) : undefined);

  const handleSave = (mode) => {
    setAttempted(true);
    if (Object.keys(errors).length > 0) return;
    onSave(form, mode);
    if (mode === SAVE_MODES.SAVE) setLastSavedAt(new Date().toISOString());
  };

  const showNameField = Boolean(form.witnessType);
  const nameRequired = isNameRequired(form);
  const useTextName =
    PLAIN_NAME_TYPES.includes(form.witnessType) ||
    (JJEDS_TYPES.includes(form.witnessType) && form.selectFromJJEDS === NO);

  return (
    <ModalShell
      title={recordLabel ? t("witness.modal.titleEdit", { recordNo: recordLabel }) : t("witness.modal.titleNew")}
      onClose={onClose}
      maxWidth="max-w-4xl"
    >
      <SubformModalToolbar onSave={handleSave} onCancel={onClose} busy={loading} lastSavedAt={lastSavedAt} />

      <div className="max-h-[70vh] overflow-y-auto px-5 py-5">
        {loading && <div className="mb-4 text-sm text-slate-500">{t("witness.modal.loading")}</div>}

        {showRestored && (
          <div className="mb-4 flex flex-wrap items-center gap-3 rounded-lg bg-amber-50 px-3.5 py-2.5 text-xs text-amber-800 ring-1 ring-inset ring-amber-200">
            <span>{t("subform.restoredDraft")}</span>
            <button
              type="button"
              onClick={() => {
                onDiscardDraft?.();
                setForm({ ...EMPTY_WITNESS_FORM });
                setShowRestored(false);
                setAttempted(false);
              }}
              className="font-semibold underline hover:text-amber-900"
            >
              {t("subform.discardDraft")}
            </button>
          </div>
        )}

        {attempted && Object.keys(errors).length > 0 && (
          <div role="alert" className="mb-4 rounded-lg bg-red-50 px-3.5 py-2.5 text-xs text-red-700 ring-1 ring-inset ring-red-200">
            {t("validation.fixHighlightedFields")}
          </div>
        )}

        <h3 className="text-lg font-bold tracking-tight text-jnj-ink">
          {recordLabel ? t("witness.modal.titleEdit", { recordNo: recordLabel }) : t("witness.modal.headingNew")}
        </h3>

        {/* Witness Details */}
        <div className="mt-4 overflow-hidden rounded-xl border border-jnj-line">
          <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
            <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
              <Info className="h-3.5 w-3.5" />
            </span>
            <h4 className="text-sm font-bold text-jnj-ink">{t("witness.modal.sectionDetails")}</h4>
          </div>

          <div className="space-y-4 px-4 py-4">
            <FieldInput
              field={{
                key: "witnessType",
                label: t("witness.fields.witnessType"),
                type: "select",
                required: true,
                options: toOptions("witnessType", WITNESS_TYPE_OPTIONS),
                error: errorFor("witnessType"),
              }}
              value={form.witnessType}
              onChange={set}
            />

            {JJEDS_TYPES.includes(form.witnessType) && (
              <FieldInput
                field={{
                  key: "selectFromJJEDS",
                  label: t("witness.fields.selectFromJJEDS"),
                  type: "select",
                  options: toOptions("yesNo", [YES, NO]),
                }}
                value={form.selectFromJJEDS}
                onChange={set}
              />
            )}

            {showNameField &&
              (useTextName ? (
                <FieldInput
                  field={{
                    key: "witnessName",
                    label: t("witness.fields.witnessName"),
                    type: "text",
                    required: nameRequired,
                    error: errorFor("witnessName"),
                  }}
                  value={form.witnessName}
                  onChange={set}
                />
              ) : (
                <div className="grid grid-cols-1 items-start md:grid-cols-[22%_1fr]">
                  <label className="px-3 py-2 text-left text-xs font-semibold leading-snug text-gray-600 break-words md:text-right">
                    {t("witness.fields.witnessName")}
                    {nameRequired && <span className="ml-1 text-red-500">*</span>}
                  </label>
                  <div className="w-full min-w-0 px-2 py-1">
                    <OnBehalfOfDropdown
                      value={form.witnessName}
                      onSelect={(name) => set("witnessName", name)}
                      className="w-full"
                    />
                    {errorFor("witnessName") && (
                      <p role="alert" className="mt-1 text-xs font-medium text-red-600">
                        {errorFor("witnessName")}
                      </p>
                    )}
                  </div>
                </div>
              ))}

            <FieldInput
              field={{ key: "contactInfo", label: t("witness.fields.contactInfo"), type: "textarea", rows: 2 }}
              value={form.contactInfo}
              onChange={set}
            />

            <FieldInput
              field={{ key: "dateOfInterview", label: t("witness.fields.dateOfInterview"), type: "date" }}
              value={form.dateOfInterview}
              onChange={set}
            />

            <FieldInput
              field={{ key: "witnessStatement", label: t("witness.fields.witnessStatement"), type: "textarea", rows: 3 }}
              value={form.witnessStatement}
              onChange={set}
            />

            <div className="flex items-start gap-2.5 rounded-lg bg-sky-50/70 px-3.5 py-2.5 text-xs leading-relaxed text-sky-900 ring-1 ring-inset ring-sky-100">
              <Info className="mt-0.5 h-4 w-4 flex-shrink-0 text-sky-500" />
              <span>{t("witness.modal.statementPrivacy")}</span>
            </div>
          </div>
        </div>

        {/* Pictures and Attachments */}
        <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
          <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
            <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
              <Paperclip className="h-3.5 w-3.5" />
            </span>
            <h4 className="text-sm font-bold text-jnj-ink">{t("attachments.title")}</h4>
          </div>

          <div className="px-4 py-4">
            <SubformTable
              addLabel={t("attachments.attach")}
              addId="attach"
              actions={[
                { id: "detach", label: t("attachments.detach") },
                { id: "listAll", label: t("subform.listAll") },
              ]}
              columns={[
                { key: "attachmentName", label: t("attachments.columns.name") },
                { key: "url", label: t("attachments.columns.url") },
              ]}
              rows={[]}
              onAdd={() => {}}
            />

            <div className="mt-4 flex items-start gap-2.5 rounded-lg bg-sky-50/70 px-3.5 py-2.5 text-xs leading-relaxed text-sky-900 ring-1 ring-inset ring-sky-100">
              <Info className="mt-0.5 h-4 w-4 flex-shrink-0 text-sky-500" />
              <span>{t("attachments.privacy")}</span>
            </div>
          </div>
        </div>
      </div>
    </ModalShell>
  );
}
