// components/modals/CapaModal.jsx

import { useState, useEffect } from "react";
import { Save, CheckCircle2 } from "lucide-react";
import { ModalShell, ModalSubsection, PrivacyNote } from "./ModalShell";
import FieldInput from "@/components/FieldInput";
import OnBehalfOfDropdown from "@/components/EmployeeSearchDropdown";
import CauseCheckGroup from "@/components/CauseCheckGroup";
import SubformTable from "@/components/SubformTable";
import { getCapaActionDetail } from "@/lib/capaModalApi";
import { getIncidentData } from "@/lib/intelApi";
import {
  PARENT_EVENT,
  CAPA_PRIORITY,
  CAPA_CONTROL_TYPE,
  EXTENSION_APPROVAL,
  PROGRAM_CATEGORY_GROUPS,
} from "@/app/constants/capa";

// Local storage helpers to mirror ProgramCategorySection selections (fallback)
const storageKey = (eventId) => `program_categories:${eventId || "new"}`;
const loadSelected = (eventId) => {
  try {
    const raw = window.localStorage.getItem(storageKey(eventId));
    if (!raw) return new Set();
    const arr = JSON.parse(raw);
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
};
const saveSelected = (eventId, set) => {
  try {
    const arr = Array.from(set);
    window.localStorage.setItem(storageKey(eventId), JSON.stringify(arr));
  } catch {
    // ignore
  }
};

export default function CapaModal({
  onClose,
  onSave,
  actionId = null,
  eventId = null,
}) {
  const [form, setForm] = useState({
    // Report Details
    jnjSite: "",
    company: "",
    ehsSubdivId: "",
    sector: "",
    ehsBusinessUnit: "",
    ehsSubBusinessUnit: "",
    siteLocation: "",
    subSiteLocation: "",
    department: "",
    subDepartment: "",
    specificLocation: "",
    capaSource: "",
    capaSourceDetail: "",
    comments: "",

    // CAPA Details
    capaAssigned: "No",
    actionNo: "",
    actionRequired: "",
    actionOwner: "",
    createdBy: "",
    capaInitiator: "",
    priority: "",
    extensionApproval: "",
    originalDueDate: "",
    controlType: "",
    closureVerificationNeeded: "",
    capaClosureVerificationResponsible: "",
    additionalComments: "",
  });

  const [categories, setCategories] = useState(() => new Set());
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [workflowRows, setWorkflowRows] = useState([]);
  const [relatedEventLabel, setRelatedEventLabel] = useState(PARENT_EVENT);

  const hasRecord = Boolean(actionId && eventId);
  const isEditMode = hasRecord;
  const showMinimal = !hasRecord;

  // Build a reliable YYYY-MM-DD for min date (no timezone issues)
  const today = new Date();
  const yyyy = today.getFullYear();
  const mm = String(today.getMonth() + 1).padStart(2, "0");
  const dd = String(today.getDate()).padStart(2, "0");
  const todayStr = `${yyyy}-${mm}-${dd}`;

  // Fetch existing CAPA detail (Edit mode)
  useEffect(() => {
    if (hasRecord) {
      loadCapaDetail();
    }
  }, [hasRecord]);

  // In Add Entry (minimal mode), pre-populate from Incident API and mirror ProgramCategorySection
  useEffect(() => {
    if (!showMinimal || !eventId) return;

    // Pre-hydrate from storage to avoid UI flicker
    const stored = loadSelected(eventId);
    if (stored.size) {
      setCategories(stored);
    }

    loadEventDefaults();
  }, [showMinimal, eventId]);

  const mapCategoryToGroupFromCapaRecord = (record) => {
    const cats = new Set();
    const fields = [
      "CapaBioChemPhy",
      "CapaEnvironment",
      "CapaErgo",
      "OccupatioSafety",
      "ManagemenSystem",
      "CapaSFclMngmnt",
    ];
    fields.forEach((field) => {
      if (Array.isArray(record[field])) {
        record[field].forEach((item) => {
          if (item.Caption) {
            cats.add(item.Caption);
          }
        });
      }
    });
    return cats;
  };

  // Load defaults for Add Entry (prepopulate J&J Site, Related Event, Program Category)
  const loadEventDefaults = async () => {
    try {
      setLoading(true);
      setError(null);

      const incident = await getIncidentData(
        eventId,
        ["Name", "RecordNo"],
        [
          "Location($select=Name)",
          "Macandequipment($select=Value)",
          "General($select=Value)",
          "CPhysicalagents($select=Value)",
          "Environment($select=Value)",
          "Ergonomics($select=Value)",
          "MstrFaclMngmnt($select=Value)",
        ]
      );

      const jnjSite = incident?.Location?.Name || "";

      const selectedValues = [
        ...(incident?.Macandequipment?.map((x) => x.Value) || []),
        ...(incident?.General?.map((x) => x.Value) || []),
        ...(incident?.CPhysicalagents?.map((x) => x.Value) || []),
        ...(incident?.Environment?.map((x) => x.Value) || []),
        ...(incident?.Ergonomics?.map((x) => x.Value) || []),
        ...(incident?.MstrFaclMngmnt?.map((x) => x.Value) || []),
      ];

      const recNo = incident?.RecordNo;
      const name = incident?.Name;
      const label =
        recNo && name
          ? `Incident #${recNo} - ${name}`
          : name
          ? `${name}`
          : recNo
          ? `Incident #${recNo}`
          : PARENT_EVENT;
      setRelatedEventLabel(label);

      setForm((prev) => ({
        ...prev,
        jnjSite,
        capaAssigned: "No",
      }));

      const next = new Set(selectedValues);
      setCategories(next);
      saveSelected(eventId, next);
    } catch (err) {
      setError(`Failed to load defaults: ${err?.message || "Unknown error"}`);
    } finally {
      setLoading(false);
    }
  };

  const loadCapaDetail = async () => {
    try {
      setLoading(true);
      setError(null);

      const detailedRecord = await getCapaActionDetail(eventId, actionId);

      const mappedCategories = mapCategoryToGroupFromCapaRecord(detailedRecord);

      const companyData =
        detailedRecord.CompanyKeys && detailedRecord.CompanyKeys.length > 0
          ? detailedRecord.CompanyKeys[0]
          : {};

      setForm({
        // Report Details
        jnjSite: detailedRecord.Location?.Name || "",
        company: companyData.KeyName || "",
        ehsSubdivId: companyData.SubdivID || "",
        sector: companyData.Sector || "",
        ehsBusinessUnit: companyData.BU || "",
        ehsSubBusinessUnit: companyData.Sub0BU || "",
        siteLocation: detailedRecord.SiteLocation0?.Name || "",
        subSiteLocation: detailedRecord.SubSiteLocation?.SiteLocLocalN || "",
        department: detailedRecord.Department0?.DepartmentName || "",
        subDepartment: detailedRecord.SubDepartment?.LocalDeptName || "",
        specificLocation: detailedRecord.SpecifiLoc0 || "",
        capaSource: detailedRecord.CAPASource0?.Name || "",
        capaSourceDetail: detailedRecord.CAPSourceDet0 || "",
        comments: detailedRecord.Comments || "",

        // CAPA Details
        capaAssigned: detailedRecord.ActionValid0 ? "Yes" : "No",
        actionNo: detailedRecord.ActionNo || "",
        actionRequired: detailedRecord.CPARActionReq || "",
        actionOwner: detailedRecord.PersonResp0?.Name || "",
        createdBy: detailedRecord.CreatedBy?.Name || "",
        capaInitiator: detailedRecord.CAPACreator?.Name || "",
        priority: detailedRecord.Priority0?.Value || "",
        extensionApproval: detailedRecord.RqrsExtnsnAprvl?.Value || "",
        originalDueDate: detailedRecord.OTargetDate
          ? new Date(detailedRecord.OTargetDate).toISOString().split("T")[0]
          : "",
        controlType: detailedRecord.CAPAControlType?.Name || "",
        closureVerificationNeeded: detailedRecord.DueDateG12month ? "Yes" : "No",
        capaClosureVerificationResponsible: detailedRecord.ReqEHSsiteleadA ? "Yes" : "No",
        additionalComments: detailedRecord.Additiocomments || "",
      });

      setCategories(mappedCategories);

      const recNo = detailedRecord?.RelatedEvent?.RecordNo;
      const name = detailedRecord?.RelatedEvent?.Name;
      const label =
        recNo && name
          ? `Incident #${recNo} - ${name}`
          : name
          ? `${name}`
          : recNo
          ? `Incident #${recNo}`
          : PARENT_EVENT;
      setRelatedEventLabel(label);
    } catch (err) {
      setError(`Failed to load CAPA details: ${err.message || "Unknown error"}`);
    } finally {
      setLoading(false);
    }
  };

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const toggleCat = (item) => {
    setCategories((p) => {
      const n = new Set(p);
      if (n.has(item)) {
        n.delete(item);
      } else {
        n.add(item);
      }
      if (showMinimal) {
        saveSelected(eventId, n);
      }
      return n;
    });
  };

  const toolbarBtn = "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";

  const handleSave = async (assignNow, addAnother) => {
    try {
      setSaving(true);
      setError(null);

      // Validate Original Due Date >= today
      if (form.originalDueDate && form.originalDueDate < todayStr) {
        setError("Original Due Date cannot be in the past.");
        setSaving(false);
        return;
      }

      onSave();
    } catch (err) {
      setError(`Failed to save CAPA: ${err.message || "Unknown error"}`);
    } finally {
      setSaving(false);
    }
  };

  const workflowColumns = [
    { key: "stage", label: "Stage" },
    { key: "dateSubmitted", label: "Date Submitted" },
    { key: "action", label: "Action" },
    { key: "message", label: "Message" },
    { key: "submittedBy", label: "Submitted By" },
  ];

  const renderField = (field) => {
    return <FieldInput key={field.key} field={field} value={form[field.key] ?? ""} onChange={set} />;
  };

  return (
    <ModalShell title={isEditMode ? "Edit CAPA Entry" : "Add Entry"} onClose={onClose} maxWidth="max-w-5xl">
      <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
        {!isEditMode && (
          <button
            onClick={() => handleSave(true, false)}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red transition hover:text-jnj-red-dark disabled:opacity-50"
            disabled={saving || loading}
          >
            <CheckCircle2 className="h-4 w-4" /> Save &amp; Assign CAPA Now
          </button>
        )}
        <button
          onClick={() => handleSave(false, false)}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red transition hover:text-jnj-red-dark disabled:opacity-50"
          disabled={saving || loading}
        >
          <Save className="h-4 w-4" /> {isEditMode ? "Update" : "Save"}
        </button>
        <button
          onClick={() => handleSave(false, false)}
          className={`${toolbarBtn} disabled:opacity-50`}
          disabled={saving || loading}
        >
          {isEditMode ? "Update and Exit" : "Save and Exit"}
        </button>
        <button onClick={onClose} className={`${toolbarBtn} disabled:opacity-50`} disabled={saving || loading}>
          Cancel
        </button>
      </div>

      <div className="max-h-[72vh] overflow-y-auto px-5 py-5">
        <h3 className="text-lg font-bold tracking-tight text-jnj-ink">{isEditMode ? "Edit CAPA" : "New CAPA"}</h3>

        {error && (
          <div className="mb-4 rounded-md bg-red-50 p-4 text-sm text-red-700 border border-red-200">
            <p className="font-semibold">Error:</p>
            <p>{error}</p>
          </div>
        )}

        {loading ? (
          <div className="py-8 text-center text-sm text-slate-500">Loading CAPA details...</div>
        ) : (
          <>
            {/* Minimal mode: show J&J Site */}
            {showMinimal && (
              <ModalSubsection title="CAPAs Report Details">
                {renderField({ key: "jnjSite", label: "J&J Site", type: "readonly" })}
              </ModalSubsection>
            )}

            {/* Full Report Details only when we have a record */}
            {!showMinimal && (
              <ModalSubsection title="CAPAs Report Details">
                {renderField({ key: "jnjSite", label: "J&J Site", type: "readonly" })}
                {renderField({
                  key: "company",
                  label: "At what Company did this occur or what J&J Company is responsible?",
                  type: "readonly",
                })}
                {renderField({ key: "ehsSubdivId", label: "EH&S Subdiv ID", type: "readonly" })}
                {renderField({ key: "sector", label: "Sector", type: "readonly" })}
                {renderField({ key: "ehsBusinessUnit", label: "EH&S Business Unit", type: "readonly" })}
                {renderField({ key: "ehsSubBusinessUnit", label: "EH&S Sub-Business Unit", type: "readonly" })}
                {renderField({ key: "siteLocation", label: "Site Location", type: "readonly" })}
                {renderField({ key: "subSiteLocation", label: "Sub Site Location", type: "readonly" })}
                {renderField({ key: "department", label: "Department", type: "readonly" })}
                {renderField({ key: "subDepartment", label: "Sub Department", type: "readonly" })}
                {renderField({ key: "specificLocation", label: "Specific Location", type: "readonly" })}
                {renderField({ key: "capaSource", label: "CAPA Source", type: "readonly" })}
                {renderField({ key: "capaSourceDetail", label: "CAPA Source Detail", type: "readonly" })}
                {renderField({ key: "comments", label: "Comments", type: "textarea", rows: 2 })}
              </ModalSubsection>
            )}

            {/* CAPA Details */}
            <ModalSubsection title="CAPAs Details">
              {/* Show "Assign CAPA now?" even in minimal, default No (readonly) */}
              {renderField({ key: "capaAssigned", label: "CAPA Assigned", type: "readonly" })}

              {eventId && (
                <div className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start">
                  <label className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
                    Related Event
                  </label>
                  <div className="px-2 py-1 min-w-0">
                    <a
                      href="#"
                      onClick={(e) => e.preventDefault()}
                      className="text-sm text-gray-700 hover:text-jnj-red hover:underline"
                    >
                      {relatedEventLabel}
                    </a>
                  </div>
                </div>
              )}

              {!showMinimal && renderField({ key: "actionNo", label: "Action No.", type: "readonly" })}

              {renderField({
                key: "actionRequired",
                label: "Action Required",
                type: "textarea",
                required: true,
                rows: 3,
              })}

              <div className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start">
                <label className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
                  Action Owner<span className="ml-1 text-red-500">*</span>
                </label>
                <div className="px-2 py-1 min-w-0">
                  <OnBehalfOfDropdown value={form.actionOwner} onSelect={(actionOwner) => set("actionOwner", actionOwner)} />
                </div>
              </div>

              {!showMinimal && renderField({ key: "createdBy", label: "Created By", type: "readonly" })}

              {!showMinimal && (
                <div className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start">
                  <label className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
                    CAPA Initiator
                  </label>
                  <div className="px-2 py-1 min-w-0">
                    <OnBehalfOfDropdown value={form.capaInitiator} onSelect={(capaInitiator) => set("capaInitiator", capaInitiator)} />
                  </div>
                </div>
              )}

              <p className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start">
                <span></span>
                <span className="px-2 py-1 text-xs text-gray-600">
                  To determine priority click here for finding classifications (LINK) or risk matrix (LINK) to calculate priority.
                </span>
              </p>

              {renderField({
                key: "priority",
                label: "Priority",
                type: "select",
                required: true,
                options: ["", ...CAPA_PRIORITY],
              })}

              {renderField({
                key: "extensionApproval",
                label: "Requires Extension Approval?",
                type: "select",
                required: true,
                options: ["", ...EXTENSION_APPROVAL],
              })}

              {renderField({
                key: "originalDueDate",
                label: "Original Due Date",
                type: "date",
                required: true,
                min: todayStr, // disable past dates
              })}

              {renderField({
                key: "controlType",
                label: "CAPA Control Type",
                type: "select",
                required: true,
                options: ["", ...CAPA_CONTROL_TYPE],
              })}

              <p className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start">
                <span></span>
                <span className="px-2 py-1 text-xs text-gray-600">
                  If CAPA is not Critical, you can also select "No" for "Closure Verification Needed"
                </span>
              </p>

              {renderField({
                key: "closureVerificationNeeded",
                label: "Closure Verification Needed",
                type: "select",
                options: ["", "Yes", "No"],
              })}

              {!showMinimal &&
                renderField({
                  key: "capaClosureVerificationResponsible",
                  label: "CAPA Closure Verification Responsible",
                  type: "select",
                  options: ["", "Yes", "No"],
                })}

              {renderField({
                key: "additionalComments",
                label: "Additional comments",
                type: "textarea",
                rows: 2,
              })}
            </ModalSubsection>

            {/* Program Category */}
            <ModalSubsection title="Program Category">
              <div className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start">
                <span></span>
                <span className="px-2 py-1 text-xs text-gray-600">
                  Please indicate the correct program category to which this CAPA is related. You can assign more than 1 category, but please use the most obvious one and try to include no more than 3 per CAPA.
                </span>
              </div>
              <div className="space-y-6 mt-4">
                {PROGRAM_CATEGORY_GROUPS.map((g) => (
                  <div key={g.group} className="grid grid-cols-1 gap-x-6 gap-y-3 md:grid-cols-[22%_1fr]">
                    <label className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
                      {g.group}
                    </label>
                    <div className="px-2 py-1 min-w-0">
                      <CauseCheckGroup items={g.items} selected={categories} onToggle={toggleCat} />
                    </div>
                  </div>
                ))}
              </div>
            </ModalSubsection>

            {/* Pictures and Attachments */}
            <ModalSubsection title="Pictures and Attachments">
              <SubformTable
                addLabel="Attach Document"
                actions={["Detach Document", "List All"]}
                columns={[
                  { key: "attachmentName", label: "Attachment Name" },
                  { key: "url", label: "URL" },
                ]}
                rows={[]}
                emptyText="No records to display."
                onAdd={() => {}}
              />
              <PrivacyNote>
                Pictures and Attachments: Do not publish or think carefully before publishing or disclosing pictures with personal information or recognizable persons on it, or any other private information.
              </PrivacyNote>
            </ModalSubsection>

            {/* Workflow Tracking */}
            {isEditMode && (
              <ModalSubsection title="Workflow Tracking">
                <SubformTable
                  addLabel=""
                  actions={["List All"]}
                  columns={workflowColumns}
                  rows={workflowRows}
                  emptyText="No records to display."
                  onAdd={() => {}}
                />
              </ModalSubsection>
            )}
          </>
        )}
      </div>
    </ModalShell>
  );
}
