// components/modals/SpillReleaseModal.jsx
"use client";

import { useEffect, useState } from "react";
import { Save, Info, Paperclip } from "lucide-react";

import { ModalShell } from "./ModalShell";
import SubformTable from "@/components/SubformTable";
import { getSpillReleaseByIds } from "@/lib/spillApi";

/* Options: exact text and order to match your reference UI */
const CLEANUP_COMPLETED_BY = [
  "Internal response team",
  "External vendor",
  "External government team",
  "Other (specify)",
];

const SPILL_RELEASE_TYPES = [
  "Refrigerant spill",
  "Release within Containment",
  "Release to Air - Indoor",
  "Release to Air - Outdoor",
  "Release to Soil",
  "Release to water (e.g., river, pond)",
  "Release to waste water sewer/drain",
  "Release to storm water sewer/drain",
  "Noise",
  "Light",
  "Other (specify)",
  "SPM (Microplastics)",
];

const SPILL_RELEASE_SEVERITY = [
  "Critical - a regulatory non-compliance leading to a potential of a fine (>$10K USD)",
  "Major - Risk score on the EHS&S Risk Prioritization Matrix ≥ 36",
  "Major - Involved ODS (CFC or HCFC) refrigerant emission of >200 lbs/90 kg and/or other refrigerant emission with CO2 equivalent emission (emissions amount in kg * global warming potential) >200,000",
  "Major - Off site in-transit materials that required transportation to be suspended or redirected for cleanup.",
  "Minor - Required more than one person to clean up",
  "Minor - Use of personal protective equipment different than from normal activities",
  "Minor - Any evacuation of nearby people or employees",
  "Minor - A spill or release not covered above",
];

const YES_NO_OPTIONS = ["Yes", "No"];
const JJSIF_OPTIONS = ["Yes", "No", "Potential"];
const UNIT_OPTIONS = [
  "Cubic Meter",
  "Cubic yards",
  "Liters",
  "US Gallons",
  "Gram",
  "KiloGram",
  "Metric tons",
  "Pounds (US)",
];

/* Uniform two-column row for perfect alignment */
function Row({ label, required = false, children }) {
  return (
    <div className="grid grid-cols-1 items-start md:grid-cols-[22%_1fr]">
      <div className="px-16 py-2 text-xs font-semibold text-gray-600">
        {required ? `* ${label}` : label}
      </div>
      <div className="px-2 py-1">{children}</div>
    </div>
  );
}

/* Themed input styles to match property modal */
const inputCls = "w-full rounded border border-jnj-line px-3 py-2 text-sm";
const selectNarrowCls = "w-[280px] rounded border border-jnj-line px-3 py-2 text-sm";
const textAreaCls = "w-full rounded border border-jnj-line p-2 text-sm";

/* Helpers */
const isProvided = (v) => v !== undefined && v !== null && String(v).trim() !== "";

const toYesNo = (val) => {
  if (val === true || val === 1 || String(val).toLowerCase() === "yes") return "Yes";
  if (val === false || val === 0 || String(val).toLowerCase() === "no") return "No";
  return val == null ? "" : String(val);
};

const toYesNoPotential = (val) => {
  const s = String(val ?? "").toLowerCase();
  if (s.includes("potential")) return "Potential";
  if (s === "yes" || s === "true" || s === "1") return "Yes";
  if (s === "no" || s === "false" || s === "0") return "No";
  return val == null ? "" : String(val);
};

const norm = (s) => String(s || "").trim().toLowerCase();

const mapValuesToOptions = (src, options) => {
  const arr = Array.isArray(src) ? src : src ? [src] : [];
  return arr
    .map((x) => {
      const v = x?.Value ?? x;
      const n = norm(v);
      return (
        options.find((o) => norm(o) === n) ||
        options.find((o) => norm(o).includes(n) || n.includes(norm(o)))
      );
    })
    .filter(Boolean);
};

// Date helpers for input fields (local dates/times)
const toDateInput = (d) => {
  if (!d) return "";
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return "";
  const yyyy = dt.getFullYear();
  const mm = String(dt.getMonth() + 1).padStart(2, "0");
  const dd = String(dt.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
};

const toTimeInput = (d) => {
  if (!d) return "";
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return "";
  const hh = String(dt.getHours()).padStart(2, "0");
  const mi = String(dt.getMinutes()).padStart(2, "0");
  return `${hh}:${mi}`;
};

export default function SpillReleaseModal({
  onClose,
  onSave,
  // Preferred edit props
  incidentMasterNo, // master Incident RecordNo
  incidentRecordNo, // Spill/Release sub-form RecordNo
  // Legacy fallback
  eventId,
  recordNo,
}) {
  const [form, setForm] = useState({
    cleanupDate: "",
    cleanupTime: "",
    cleanupBy: [],
    cleanupByOther: "",

    spillTypes: [],
    spillTypeOther: "",

    spillSeverity: [],

    // Refrigerant specific
    refrigerantODP: "",
    refrigerantGWP: "",
    refrigerantCircuitOver50lbs: "", // Yes/No

    jjsif: "",
    materialName: "",
    amount: "",
    unit: "",
    comments: "",

    regulatoryNonCompliance: "No",
    regulatoryReportingRequired: "", // Yes/No when shown

    escalationRequired: "No",
    sensitiveInformation: "No",
    attachments: [],
  });

  const [loading, setLoading] = useState(false);

  // compute today's date string (YYYY-MM-DD) to use as max for date input
  const today = new Date();
  const maxDateStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(
    2,
    "0"
  )}-${String(today.getDate()).padStart(2, "0")}`;

  const masterNo = isProvided(incidentMasterNo) ? incidentMasterNo : eventId;
  const detailNo = isProvided(incidentRecordNo) ? incidentRecordNo : recordNo;
  const isEdit = isProvided(masterNo) && isProvided(detailNo);

  const setField = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const toggleArray = (key, value) =>
    setForm((prev) => {
      const exists = prev[key].includes(value);
      return {
        ...prev,
        [key]: exists ? prev[key].filter((v) => v !== value) : [...prev[key], value],
      };
    });

  useEffect(() => {
    let cancelled = false;

    if (!isEdit) {
      setLoading(false);
      return;
    }

    const load = async () => {
      try {
        setLoading(true);
        const data = await getSpillReleaseByIds(masterNo, detailNo);
        if (cancelled) return;

        if (data) {
          // Map multi-selects from expands
          const cleanupBy = mapValuesToOptions(data?.completedbytype, CLEANUP_COMPLETED_BY);
          const spillTypes = mapValuesToOptions(data?.SpillReleasType, SPILL_RELEASE_TYPES);
          const spillSeverity = mapValuesToOptions(data?.SpillReSeverity, SPILL_RELEASE_SEVERITY);

          // Map single selects and booleans
          const jjsif = toYesNoPotential(data?.JJSIFSseverity);
          const unit =
            mapValuesToOptions([data?.Unit?.Value], UNIT_OPTIONS)[0] || (data?.Unit?.Value || "");

          // Date/time - clamp date to today so no future date appears in UI
          const rawDate = toDateInput(data?.DateTimeClean);
          const rawTime = toTimeInput(data?.DateTimeClean);
          const cleanupDate = rawDate && rawDate > maxDateStr ? maxDateStr : rawDate;
          const cleanupTime = rawTime;

          setForm((prev) => ({
            ...prev,
            cleanupDate,
            cleanupTime,
            cleanupBy,
            spillTypes,
            spillSeverity,
            jjsif,
            materialName: data?.MaterialName || "",
            amount: data?.Amount != null ? String(data.Amount) : "",
            unit,
            comments: data?.Comments || data?.Description || "",
            regulatoryNonCompliance: toYesNo(data?.Renoncompliance),
            escalationRequired: toYesNo(data?.Escalation) || "No",
            sensitiveInformation: toYesNo(data?.Sensitive) || "No",
            // The new fields remain default unless a backend mapping is added
          }));
        }
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error("Error loading Spill/Release record:", e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [isEdit, masterNo, detailNo, maxDateStr]);

  const toolbarBtn = "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";

  const handleSave = () => onSave?.(form);

  // Convenience flags for conditional UI
  const hasCleanupOther = form.cleanupBy.includes("Other (specify)");
  const hasRefrigerantSpill = form.spillTypes.includes("Refrigerant spill");
  const hasReleaseToSoil = form.spillTypes.includes("Release to Soil");
  const hasSpillTypeOther = form.spillTypes.includes("Other (specify)");
  const hasMajorRiskScoreSeverity = form.spillSeverity.includes(
    "Major - Risk score on the EHS&S Risk Prioritization Matrix ≥ 36"
  );
  const regulatoryIsYes = String(form.regulatoryNonCompliance) === "Yes";

  return (
    <ModalShell
      title={isEdit ? `Spill/Release (${detailNo})` : "Add Entry"}
      onClose={onClose}
      maxWidth="max-w-6xl"
    >
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-5 py-3">
        <button
          onClick={handleSave}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red"
        >
          <Save className="h-4 w-4" />
          Save
        </button>

        <button
          onClick={() => {
            handleSave();
            onClose?.();
          }}
          className={toolbarBtn}
        >
          Save & Exit
        </button>

        <button onClick={onClose} className={toolbarBtn}>
          Cancel
        </button>
      </div>

      {/* Body */}
      <div className="max-h-[80vh] overflow-y-auto px-5 py-5">
        {/* Title */}
        <h2 className="mb-2 text-2xl font-bold text-jnj-ink">
          {isEdit ? "Spill/Release Detail" : "New Spill/Release event"}
        </h2>

        {/* Master Event Information */}
        <div className="overflow-hidden rounded-xl border border-jnj-line">
          <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
            <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
              <Info className="h-3.5 w-3.5" />
            </span>
            <h4 className="text-sm font-bold text-jnj-ink">Master Event Information</h4>
          </div>

          <div className="p-4">
            <Row label="Master Record No.">
              <div className="text-sky-600">
                {isEdit ? `Incident #${masterNo}` : "Incident # -"}
              </div>
            </Row>
          </div>
        </div>

        {/* Loading indicator */}
        {loading ? (
          <div className="py-8 text-center text-sm text-slate-500">
            Loading Spill/Release details...
          </div>
        ) : (
          <>
            {/* Spill/Release Details */}
            <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
              <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                  <Info className="h-3.5 w-3.5" />
                </span>
                <h4 className="text-sm font-bold text-jnj-ink">Spill/Release Details</h4>
              </div>

              <div className="space-y-4 p-4">
                {/* Info callout */}
                <div className="rounded border border-sky-200 bg-sky-50 px-3 py-2 text-sm text-sky-800">
                  Spill/Release = an uncontrolled or undesired escape of a hazardous chemical
                  or waste (including wastewater & air emissions)
                </div>

                {/* Date and Time */}
                <Row label="Date and Time of Clean Up">
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <input
                      type="date"
                      className={inputCls}
                      value={form.cleanupDate}
                      onChange={(e) => setField("cleanupDate", e.target.value)}
                      max={maxDateStr} // <- prevent selecting future dates
                    />
                    <input
                      type="time"
                      className={inputCls}
                      value={form.cleanupTime}
                      onChange={(e) => setField("cleanupTime", e.target.value)}
                    />
                  </div>
                </Row>

                {/* Clean Up Completed By */}
                <Row label="Clean Up Completed By">
                  <div className="space-y-1">
                    {CLEANUP_COMPLETED_BY.map((item) => (
                      <label key={item} className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={form.cleanupBy.includes(item)}
                          onChange={() => toggleArray("cleanupBy", item)}
                        />
                        {item}
                      </label>
                    ))}
                  </div>
                </Row>

                {/* If Clean Up Completed By includes Other (specify) */}
                {hasCleanupOther && (
                  <Row label="Please specify Other Clean Up Completed By" required>
                    <input
                      type="text"
                      className={inputCls}
                      value={form.cleanupByOther}
                      onChange={(e) => setField("cleanupByOther", e.target.value)}
                      placeholder="Enter other clean up party"
                    />
                  </Row>
                )}

                {/* Spill/Release Type */}
                <Row label="Spill/Release Type" required>
                  <div>
                    <div className="space-y-1">
                      {SPILL_RELEASE_TYPES.map((item) => (
                        <label key={item} className="flex items-center gap-2 text-sm">
                          <input
                            type="checkbox"
                            checked={form.spillTypes.includes(item)}
                            onChange={() => toggleArray("spillTypes", item)}
                          />
                          {item}
                        </label>
                      ))}
                    </div>
                    <div className="mt-2 text-xs text-slate-600">
                      (&lt;5 mm in any dimension, synthetic polymer particles, that are organic,
                      insoluble, and resistant to degradation)
                    </div>
                  </div>
                </Row>

                {/* If Spill/Release Type is Refrigerant spill */}
                {hasRefrigerantSpill && (
                  <>
                    <Row label="ODP (Ozone Depletion Potential)">
                      <input
                        type="number"
                        step="any"
                        className={selectNarrowCls}
                        value={form.refrigerantODP}
                        onChange={(e) => setField("refrigerantODP", e.target.value)}
                        placeholder="Enter ODP (number)"
                      />
                    </Row>
                    <Row label="GWP (Global Warming Potential)">
                      <input
                        type="number"
                        step="any"
                        className={selectNarrowCls}
                        value={form.refrigerantGWP}
                        onChange={(e) => setField("refrigerantGWP", e.target.value)}
                        placeholder="Enter GWP (number)"
                      />
                    </Row>
                    <Row label="Refrigerant Circuit capacity is >50lbs/23 Kg" required>
                      <select
                        className={selectNarrowCls}
                        value={form.refrigerantCircuitOver50lbs}
                        onChange={(e) => setField("refrigerantCircuitOver50lbs", e.target.value)}
                      >
                        <option value=""></option>
                        {YES_NO_OPTIONS.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                    </Row>
                  </>
                )}

                {/* If Spill/Release Type is Release to Soil */}
                {hasReleaseToSoil && (
                  <div className="rounded border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
                    NOTE: “As there is release to soil, please review/update the site’s soil and/or groundwater contamination/remediation record in the CURVE application – EHS Soil & Groundwater Contamination”. If no access to this application, reach out to your EH&S site lead.
                  </div>
                )}

                {/* If Spill/Release Type is Other (specify) */}
                {hasSpillTypeOther && (
                  <Row label="Please Specify Other Spill/Release Type" required>
                    <input
                      type="text"
                      className={inputCls}
                      value={form.spillTypeOther}
                      onChange={(e) => setField("spillTypeOther", e.target.value)}
                      placeholder="Enter other spill/release type"
                    />
                  </Row>
                )}

                {/* Spill/Release Severity */}
                <Row label="Spill/Release Severity" required>
                  <div className="space-y-1">
                    {SPILL_RELEASE_SEVERITY.map((item) => (
                      <label key={item} className="flex items-start gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={form.spillSeverity.includes(item)}
                          onChange={() => toggleArray("spillSeverity", item)}
                        />
                        <span>{item}</span>
                      </label>
                    ))}
                  </div>
                </Row>

                {/* If Spill/Release Severity includes the Major Risk Score item */}
                {hasMajorRiskScoreSeverity && (
                  <div className="rounded border border-sky-200 bg-sky-50 px-3 py-2 text-sm text-sky-800">
                    According to the guidance, this spill/release could be classified as an environmental J&J SIF. Please review and indicate the J&J SIF field below as needed
                  </div>
                )}

                {/* Program link */}
                <div className="px-16 text-sm">
                  To view the Severe Impact or Fatality Prevention Program click here -
                  <a href="#" className="ml-1 text-sky-600 hover:underline">
                    LINK
                  </a>
                </div>

                {/* J&J SIF */}
                <Row label="J&J SIF" required>
                  <select
                    className={selectNarrowCls}
                    value={form.jjsif}
                    onChange={(e) => setField("jjsif", e.target.value)}
                  >
                    <option value=""></option>
                    {JJSIF_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </Row>
              </div>
            </div>

            {/* Spilled Release Materials */}
            <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
              <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                  <Info className="h-3.5 w-3.5" />
                </span>
                <h4 className="text-sm font-bold text-jnj-ink">Spilled Release Materials</h4>
              </div>

              <div className="space-y-4 p-4">
                <Row label="Material Name">
                  <textarea
                    rows={3}
                    className={textAreaCls}
                    value={form.materialName}
                    onChange={(e) => setField("materialName", e.target.value)}
                  />
                </Row>

                <Row label="Amount">
                  <input
                    type="text"
                    className={selectNarrowCls}
                    value={form.amount}
                    onChange={(e) => setField("amount", e.target.value)}
                  />
                </Row>

                <Row label="Unit">
                  <select
                    className={selectNarrowCls}
                    value={form.unit}
                    onChange={(e) => setField("unit", e.target.value)}
                  >
                    <option value=""></option>
                    {UNIT_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </Row>

                <Row label="Comments">
                  <textarea
                    rows={3}
                    className={textAreaCls}
                    value={form.comments}
                    onChange={(e) => setField("comments", e.target.value)}
                  />
                </Row>
              </div>
            </div>

            {/* Regulatory Information */}
            <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
              <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                  <Info className="h-3.5 w-3.5" />
                </span>
                <h4 className="text-sm font-bold text-jnj-ink">Regulatory Information</h4>
              </div>

              <div className="space-y-4 p-4">
                <Row label="Regulatory non-compliance?" required>
                  <select
                    className={selectNarrowCls}
                    value={form.regulatoryNonCompliance}
                    onChange={(e) => setField("regulatoryNonCompliance", e.target.value)}
                  >
                    {YES_NO_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </Row>

                {/* If Regulatory non-compliance is Yes */}
                {regulatoryIsYes && (
                  <Row label="Does this require regulatory reporting in your region?" required>
                    <select
                      className={selectNarrowCls}
                      value={form.regulatoryReportingRequired}
                      onChange={(e) => setField("regulatoryReportingRequired", e.target.value)}
                    >
                      <option value=""></option>
                      {YES_NO_OPTIONS.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  </Row>
                )}

                <div className="px-16 text-sm">
                  To view the Incident Reporting Guidelines click here -
                  <a href="#" className="ml-1 text-sky-600 hover:underline">
                    LINK
                  </a>
                </div>

                <Row label="J&J Escalation required beyond site management (Spill/Release - Escalation Guideline)">
                  <select
                    className={selectNarrowCls}
                    value={form.escalationRequired}
                    onChange={(e) => setField("escalationRequired", e.target.value)}
                  >
                    {YES_NO_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </Row>

                <div className="rounded border border-sky-300 bg-sky-100 px-3 py-2 text-sm text-sky-900">
                  If the field "J&J Escalation required beyond site management (Escalation
                  Guideline)" is YES, and you wish to change this, please review the fields
                  in this subform which are triggering this escalation. If you wish to
                  override the escalation guideline for a specific circumstance, you can do
                  that in the master event. A justification is required.
                </div>
              </div>
            </div>

            {/* Sensitive Information */}
            <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
              <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                  <Info className="h-3.5 w-3.5" />
                </span>
                <h4 className="text-sm font-bold text-jnj-ink">Sensitive Information</h4>
              </div>

              <div className="p-4">
                <Row label="Sensitive Information Included in this form?">
                  <select
                    className={selectNarrowCls}
                    value={form.sensitiveInformation}
                    onChange={(e) => setField("sensitiveInformation", e.target.value)}
                  >
                    {YES_NO_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </Row>
              </div>
            </div>

            {/* Pictures and Attachments */}
            <div className="mt-5 overflow-hidden rounded-xl border border-jnj-line">
              <div className="flex items-center gap-2 border-b border-jnj-line bg-jnj-mist/60 px-4 py-2.5">
                <span className="grid h-6 w-6 place-items-center rounded bg-red-50 text-jnj-red">
                  <Paperclip className="h-3.5 w-3.5" />
                </span>
                <h4 className="text-sm font-bold text-jnj-ink">Pictures and Attachments</h4>
              </div>

              <div className="p-4">
                <SubformTable
                  addLabel="Attach Document"
                  actions={["Detach Document", "List All"]}
                  columns={[
                    { key: "attachmentName", label: "Attachment Name" },
                    { key: "url", label: "URL" },
                  ]}
                  rows={[]}
                  emptyText="No records to display."
                  onAdd={() => {}}
                />
              </div>
            </div>
          </>
        )}
      </div>
    </ModalShell>
  );
}
