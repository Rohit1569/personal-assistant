// components/modals/CapaSelectionModal.jsx

"use client";

import { useEffect, useState } from "react";
import { Check, X } from "lucide-react";
import { ModalShell } from "./ModalShell";

export default function CapaSelectionModal({
  capas,
  selectedCapas,
  onClose,
  onSave,
}) {
  const [checkedCapas, setCheckedCapas] = useState(
    new Set(selectedCapas.map((c) => c.ActionNo))
  );
  const [searchTerm, setSearchTerm] = useState("");

  const filteredCapas = capas.filter((capa) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      capa.ActionNo.toString().includes(searchLower) ||
      capa.CPARActionReq.toLowerCase().includes(searchLower) ||
      capa.CurrentStageACA.toLowerCase().includes(searchLower)
    );
  });

  const handleCheckboxChange = (actionNo) => {
    const newChecked = new Set(checkedCapas);
    if (newChecked.has(actionNo)) {
      newChecked.delete(actionNo);
    } else {
      newChecked.add(actionNo);
    }
    setCheckedCapas(newChecked);
  };

  const handleSelectAll = () => {
    if (checkedCapas.size === filteredCapas.length) {
      setCheckedCapas(new Set());
    } else {
      setCheckedCapas(
        new Set(filteredCapas.map((c) => c.ActionNo))
      );
    }
  };

  const handleSave = () => {
    const selectedCapasData = capas.filter((c) =>
      checkedCapas.has(c.ActionNo)
    );
    onSave(selectedCapasData);
  };

  return (
    <ModalShell
      title="Select CAPAs"
      onClose={onClose}
      maxWidth="max-w-2xl"
    >
      <div className="flex flex-col h-full">
        {/* Header with search */}
        <div className="border-b border-jnj-line px-5 py-4">
          <input
            type="text"
            placeholder="Search by Action No, Description, or Status..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-3 py-2 border border-jnj-line rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-jnj-red"
          />
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-5 py-4">
          {/* Select All Checkbox */}
          <div className="mb-4 pb-4 border-b border-jnj-line">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={
                  filteredCapas.length > 0 &&
                  checkedCapas.size === filteredCapas.length
                }
                onChange={handleSelectAll}
                className="w-4 h-4 text-jnj-red border-jnj-line rounded focus:ring-2 focus:ring-jnj-red cursor-pointer"
              />
              <span className="text-sm font-semibold text-jnj-ink">
                Select All ({filteredCapas.length})
              </span>
            </label>
          </div>

          {/* CAPA List */}
          {filteredCapas.length === 0 ? (
            <div className="py-8 text-center text-sm text-slate-500">
              No CAPAs found matching your search.
            </div>
          ) : (
            <div className="space-y-2">
              {filteredCapas.map((capa) => (
                <label
                  key={capa.ActionNo}
                  className="flex items-start gap-3 p-3 rounded-lg border border-jnj-line hover:bg-jnj-mist transition cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={checkedCapas.has(capa.ActionNo)}
                    onChange={() =>
                      handleCheckboxChange(capa.ActionNo)
                    }
                    className="w-4 h-4 mt-0.5 text-jnj-red border-jnj-line rounded focus:ring-2 focus:ring-jnj-red cursor-pointer"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-sm text-jnj-ink">
                        Action {capa.ActionNo}
                      </span>
                      <span className="inline-flex px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                        {capa.CurrentStageACA}
                      </span>
                    </div>
                    <p className="text-xs text-gray-600 mb-1">
                      {capa.CPARActionReq}
                    </p>
                    <div className="flex flex-wrap gap-2 text-xs text-gray-500">
                      <span>
                        Priority:{" "}
                        <span className="font-medium">
                          {capa.Priority0?.Caption || "N/A"}
                        </span>
                      </span>
                      <span>•</span>
                      <span>
                        Assigned to:{" "}
                        <span className="font-medium">
                          {capa.PersonResp0?.Name || "N/A"}
                        </span>
                      </span>
                    </div>
                  </div>
                </label>
              ))}
            </div>
          )}
        </div>

        {/* Footer with action buttons */}
        <div className="border-t border-jnj-line px-5 py-4 flex items-center justify-end gap-3 bg-gray-50">
          <span className="text-sm text-gray-600">
            {checkedCapas.size} selected
          </span>
          <button
            onClick={onClose}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-jnj-line text-sm font-medium text-jnj-ink hover:bg-gray-100 transition"
          >
            <X className="h-4 w-4" />
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={checkedCapas.size === 0}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-jnj-red text-white text-sm font-medium hover:bg-jnj-red-dark transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Check className="h-4 w-4" />
            Add Selected ({checkedCapas.size})
          </button>
        </div>
      </div>
    </ModalShell>
  );
}
