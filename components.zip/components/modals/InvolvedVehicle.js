// components/modals/InvolvedVehicleModal.jsx

"use client";

import { useEffect, useState } from "react";
import { Save, X } from "lucide-react";
import { ModalShell, ModalSubsection } from "./ModalShell";
import { getVehicleDriversForIncident } from "@/lib/vehicleApi";
import OnBehalfOfDropdown from "@/components/EmployeeSearchDropdown";

/*
  This modal supports edit mode:
  - If vehicleRecordNo is provided (with incidentMasterNo and incidentRecordNo),
    it fetches the vehicle record and pre-fills the form.
  - On save, it returns the same shape as before plus recordNo for parent to identify/update.
*/

function toYesNoLower(val) {
  if (val === true) return "yes";
  if (val === false) return "no";
  const s = String(val || "").toLowerCase();
  if (s === "yes" || s === "y" || s === "true" || s === "1") return "yes";
  if (s === "no" || s === "n" || s === "false" || s === "0") return "no";
  return "";
}

const VEHICLE_OWNERSHIP_OPTIONS = [
  "J&J owned",
  "J&J leased",
  "Public",
  "Personal",
  "Personal used >10% for business",
  "Contractor",
  "Other",
];

const VEHICLE_TYPE_OPTIONS = [
  "Artic",
  "Boat",
  "Bus/Coach/Minibus",
  "Car",
  "Car Transporter",
  "Draw bar",
  "Car, Rental",
  "Motorbike",
  "Forklift truck",
  "Repair vehicle",
  "Tanker",
  "Tipper",
  "Tractor",
  "Van",
  "Planes/ Helicopter",
  "Powered Industrical Vehicle/Forklift",
  "Segway",
  "Tanker/ Box Truck",
  "Train",
  "Other (specify)",
];

const DRIVER_TYPE_OPTIONS = [
  "J&J Employee",
  "Visitor",
  "Contractor (supervised by J&J)",
  "Contractor (Construction)",
  "Contractor (Embedded)",
  "Contractor (Service)",
  "Spouse/Domestic Partner",
  "Dependent Family Member",
  "Other",
];

const DRIVER_FUNCTION_OPTIONS = [
  "Business",
  "Delivery and Collection",
  "Personal/Private",
  "Trunking",
  "Other",
];

function normalize(s) {
  return String(s || "").trim().toLowerCase();
}

function mapOwnershipCaptionToLabel(caption) {
  const c = normalize(caption);
  if (c.includes("j&j") && c.includes("own")) return "J&J owned";
  if (c.includes("j&j") && (c.includes("lease") || c.includes("leased"))) return "J&J leased";
  if (c.includes("public")) return "Public";
  if (c.includes(">10")) return "Personal used >10% for business";
  if (c.includes("personal")) return "Personal";
  if (c.includes("contract")) return "Contractor";
  return "Other";
}

// Map any incoming caption or legacy value to one of the VEHICLE_TYPE_OPTIONS
function mapVehicleTypeCaptionToOption(caption) {
  const c = normalize(caption);
  if (!c) return "";
  if (c.includes("artic")) return "Artic";
  if (c.includes("boat")) return "Boat";
  if (c.includes("coach") || c.includes("minibus") || (c.includes("bus") && !c.includes("box"))) return "Bus/Coach/Minibus";
  if (c === "car" || c.includes("car ") || c === "car") return "Car";
  if (c.includes("transporter")) return "Car Transporter";
  if (c.includes("draw")) return "Draw bar";
  if (c.includes("rental")) return "Car, Rental";
  if (c.includes("motorbike") || c.includes("motorcycle") || c.includes("bike")) return "Motorbike";
  if (c.includes("powered") || c.includes("industrial")) return "Powered Industrical Vehicle/Forklift";
  if (c.includes("forklift")) return "Forklift truck";
  if (c.includes("repair")) return "Repair vehicle";
  if (c.includes("tanker") && c.includes("box")) return "Tanker/ Box Truck";
  if (c.includes("tanker")) return "Tanker";
  if (c.includes("tipper")) return "Tipper";
  if (c.includes("tractor")) return "Tractor";
  if (c.includes("van")) return "Van";
  if (c.includes("plane") || c.includes("helicopter")) return "Planes/ Helicopter";
  if (c.includes("segway")) return "Segway";
  if (c.includes("train")) return "Train";
  // Legacy short codes mapping
  if (c === "truck" || c.includes("lorry")) return "Tanker/ Box Truck";
  if (c === "bus") return "Bus/Coach/Minibus";
  if (c === "van") return "Van";
  if (c === "car") return "Car";
  return "Other (specify)";
}

function mapDriverTypeCaptionToOption(caption) {
  const c = normalize(caption);
  if (!c) return "";
  if (c.includes("employee")) return "J&J Employee";
  if (c.includes("visitor")) return "Visitor";
  if (c.includes("supervised") && c.includes("contractor")) return "Contractor (supervised by J&J)";
  if (c.includes("construction")) return "Contractor (Construction)";
  if (c.includes("embedded")) return "Contractor (Embedded)";
  if (c.includes("service")) return "Contractor (Service)";
  if (c.includes("spouse") || c.includes("partner")) return "Spouse/Domestic Partner";
  if (c.includes("dependent") || c.includes("family")) return "Dependent Family Member";
  return "Other";
}

function mapPurposeToFunctionOption(caption) {
  const c = normalize(caption);
  if (!c) return "";
  if (c.includes("business")) return "Business";
  if (c.includes("delivery") || c.includes("collection")) return "Delivery and Collection";
  if (c.includes("personal") || c.includes("private")) return "Personal/Private";
  if (c.includes("trunk")) return "Trunking";
  return "Other";
}

export default function InvolvedVehicleModal({
  onClose,
  onSave,
  initialData = null,

  // Props for edit/prefill
  incidentMasterNo,
  incidentRecordNo,
  vehicleRecordNo, // when present, modal loads and pre-fills
}) {
  const [loading, setLoading] = useState(false); // used for prefill AND save states
  const [recordNo, setRecordNo] = useState(null);

  const [formData, setFormData] = useState({
    // Vehicle
    vehicleOwnership: initialData?.vehicleOwnership || "",
    vehicleMake: initialData?.vehicleMake || "",
    vehicleMode: initialData?.vehicleMode || "",
    vehicleAssignedTo: initialData?.vehicleAssignedTo || "",
    vehicleAssignedToId: initialData?.vehicleAssignedToId || "",
    otherVehicleOwnerType: initialData?.otherVehicleOwnerType || "",

    vehicleType:
      (initialData?.vehicleType &&
        mapVehicleTypeCaptionToOption(initialData.vehicleType)) ||
      "",

    vehicleTypeOther: initialData?.vehicleTypeOther || "",

    // Driver
    driverName: initialData?.driverName || "",
    driverType:
      (initialData?.driverType &&
        mapDriverTypeCaptionToOption(initialData.driverType)) ||
      "",
    driverFunction:
      (initialData?.driverFunction &&
        mapPurposeToFunctionOption(initialData.driverFunction)) ||
      "",
    driverCurrentlyLicensed: initialData?.driverCurrentlyLicensed || "",
    driverLicenseAuthority: initialData?.driverLicenseAuthority || "",
  });

  const [errors, setErrors] = useState({});

  const isEdit = !!vehicleRecordNo;

  // Prefill on edit
  useEffect(() => {
    let cancelled = false;

    const prefill = async () => {
      if (!incidentMasterNo || !incidentRecordNo || !vehicleRecordNo) return;

      try {
        setLoading(true);
        const list = await getVehicleDriversForIncident(
          incidentMasterNo,
          incidentRecordNo,
          vehicleRecordNo
        );

        if (cancelled) return;

        const v = Array.isArray(list) && list.length > 0 ? list[0] : null;
        if (!v) return;

        const ownershipCaption =
          v?.VehiclOwnership?.Caption || v?.VehiclOwnership?.Value || "";
        const vehicleTypeCaption =
          v?.VehicleType?.Caption || v?.VehicleType?.Value || "";
        const driverTypeCaption =
          v?.DriverType?.Caption || v?.DriverType?.Value || "";
        const purposeCaption =
          v?.VehiclePurpose?.Caption || v?.VehiclePurpose?.Value || "";

        setRecordNo(v?.RecordNo ?? null);
        setFormData((prev) => ({
          ...prev,
          vehicleOwnership: mapOwnershipCaptionToLabel(ownershipCaption),
          vehicleType: mapVehicleTypeCaptionToOption(
            prev.vehicleType || vehicleTypeCaption
          ),
          // Optional fields if API provides them; else keep previous/defaults
          vehicleMake: prev.vehicleMake || v?.VehicleMake || "",
          vehicleMode: prev.vehicleMode || v?.VehicleModel || "",
          vehicleAssignedTo:
            prev.vehicleAssignedTo ||
            v?.VehicAssignedTo?.Name ||
            v?.VehicAssignedTo?.FullName ||
            v?.DriversName ||
            "",
          driverName:
            v?.DriversName ||
            v?.VehicAssignedTo?.Name ||
            v?.VehicAssignedTo?.FullName ||
            "",
          driverType: mapDriverTypeCaptionToOption(
            prev.driverType || driverTypeCaption
          ),
          driverFunction: mapPurposeToFunctionOption(
            prev.driverFunction || purposeCaption
          ),
          driverCurrentlyLicensed: toYesNoLower(v?.CurrentLicensed),
          // keep license authority as provided or blank
        }));
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error("Failed to prefill vehicle record:", e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    prefill();
    return () => {
      cancelled = true;
    };
  }, [incidentMasterNo, incidentRecordNo, vehicleRecordNo]);

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
    if (errors[field]) {
      setErrors((prev) => ({
        ...prev,
        [field]: "",
      }));
    }
  };

  const handleAssigneeSelect = (employee) => {
    const label =
      employee?.displayName ||
      employee?.fullName ||
      employee?.name ||
      employee?.label ||
      "";
    const id = employee?.id || employee?.employeeId || "";
    setFormData((prev) => ({
      ...prev,
      vehicleAssignedTo: label,
      vehicleAssignedToId: id,
    }));
    if (errors.vehicleAssignedTo) {
      setErrors((prev) => ({ ...prev, vehicleAssignedTo: "" }));
    }
  };

  // Conditional flags per business rules
  const isJnjOwned = formData.vehicleOwnership === "J&J owned";
  const isJnjLeased = formData.vehicleOwnership === "J&J leased";
  const isOwnershipOther = formData.vehicleOwnership === "Other";
  const isVehicleTypeOther = formData.vehicleType === "Other (specify)";
  const isDriverLicensedYes = formData.driverCurrentlyLicensed === "yes";

  const validateForm = () => {
    const newErrors = {};

    // Always required
    if (!formData.vehicleOwnership.trim()) {
      newErrors.vehicleOwnership = "Vehicle Ownership is required";
    }
    if (!formData.vehicleType.trim()) {
      newErrors.vehicleType = "Vehicle Type is required";
    }
    if (!formData.driverName.trim()) {
      newErrors.driverName = "Driver Name is required";
    }
    if (!formData.driverType.trim()) {
      newErrors.driverType = "Driver Type is required";
    }
    if (!formData.driverFunction.trim()) {
      newErrors.driverFunction = "Driver Function is required";
    }
    if (!formData.driverCurrentlyLicensed.trim()) {
      newErrors.driverCurrentlyLicensed = "Driver Currently Licensed is required";
    }

    // Conditional required fields
    if ((isJnjOwned || isJnjLeased) && !formData.vehicleAssignedTo.trim()) {
      newErrors.vehicleAssignedTo = "Vehicle Assigned To is required";
    }
    if (isDriverLicensedYes && !formData.driverLicenseAuthority.trim()) {
      newErrors.driverLicenseAuthority = "Authority issuing license is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) return;

    setLoading(true);
    try {
      // Simulate save or call your create/update API here as needed
      await new Promise((resolve) => setTimeout(resolve, 300));

      onSave({
        ...formData,
        recordNo: recordNo ?? vehicleRecordNo ?? null,
      });
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error("Error saving vehicle information:", error);
    } finally {
      setLoading(false);
    }
  };

  const toolbarBtn =
    "text-sm font-medium text-jnj-slate transition hover:text-jnj-red";

  return (
    <ModalShell
      title={isEdit ? "Edit Involved Vehicle" : "New Involved Vehicle"}
      onClose={onClose}
      maxWidth="max-w-2xl"
    >
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-5 border-b border-jnj-line px-6 py-3">
        <button
          onClick={handleSave}
          disabled={loading}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-jnj-red transition hover:text-jnj-red-dark disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Save className="h-4 w-4" />
          {loading ? "Saving..." : "Save"}
        </button>

        <button onClick={onClose} className={toolbarBtn}>
          Cancel
        </button>
      </div>

      {/* Body */}
      <div className="max-h-[75vh] overflow-y-auto px-6 py-5">
        <ModalSubsection title="Vehicle Information">
          {/* Vehicle Ownership (required) */}
          <div className="mb-5">
            <label className="block text-sm font-medium text-jnj-ink mb-2">
              <span className="text-jnj-red">*</span> Vehicle Ownership
            </label>
            <select
              value={formData.vehicleOwnership}
              onChange={(e) => handleInputChange("vehicleOwnership", e.target.value)}
              disabled={loading}
              className={`w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-jnj-red transition ${
                errors.vehicleOwnership ? "border-red-500 bg-red-50" : "border-jnj-line bg-white"
              }`}
            >
              <option value="">Select Vehicle Ownership</option>
              {VEHICLE_OWNERSHIP_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
            {errors.vehicleOwnership && (
              <p className="text-red-500 text-xs mt-1">{errors.vehicleOwnership}</p>
            )}
          </div>

          {/* If "J&J owned" → Vehicle Make, Vehicle Mode, and required Vehicle Assigned To (employee search) */}
          {isJnjOwned && (
            <>
              <div className="mb-5">
                <label className="block text-sm font-medium text-jnj-ink mb-2">
                  Vehicle Make
                </label>
                <input
                  type="text"
                  value={formData.vehicleMake}
                  onChange={(e) => handleInputChange("vehicleMake", e.target.value)}
                  placeholder="Enter vehicle make"
                  disabled={loading}
                  className="w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-jnj-red border-jnj-line bg-white"
                />
              </div>

              <div className="mb-5">
                <label className="block text-sm font-medium text-jnj-ink mb-2">
                  Vehicle Mode
                </label>
                <input
                  type="text"
                  value={formData.vehicleMode}
                  onChange={(e) => handleInputChange("vehicleMode", e.target.value)}
                  placeholder="Enter vehicle mode"
                  disabled={loading}
                  className="w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-jnj-red border-jnj-line bg-white"
                />
              </div>

              <div className="mb-5">
                <label className="block text-sm font-medium text-jnj-ink mb-2">
                  <span className="text-jnj-red">*</span> Vehicle Assigned To
                </label>
                <OnBehalfOfDropdown
                  value={formData.vehicleAssignedTo ?? ""}
                    // EmployeeSearchDropdown returns an employee object on select
                  onSelect={handleAssigneeSelect}
                />
                {errors.vehicleAssignedTo && (
                  <p className="text-red-500 text-xs mt-1">{errors.vehicleAssignedTo}</p>
                )}
              </div>
            </>
          )}

          {/* If "J&J leased" → required Vehicle Assigned To (employee search) */}
          {isJnjLeased && (
            <div className="mb-5">
              <label className="block text-sm font-medium text-jnj-ink mb-2">
                <span className="text-jnj-red">*</span> Vehicle Assigned To
              </label>
              <OnBehalfOfDropdown
                value={formData.vehicleAssignedTo ?? ""}
                onSelect={handleAssigneeSelect}
              />
              {errors.vehicleAssignedTo && (
                <p className="text-red-500 text-xs mt-1">{errors.vehicleAssignedTo}</p>
              )}
            </div>
          )}

          {/* If ownership is Other → show text field (not explicitly required) */}
          {isOwnershipOther && (
            <div className="mb-5">
              <label className="block text-sm font-medium text-jnj-ink mb-2">
                Other Vehicle Owner Type
              </label>
              <input
                type="text"
                value={formData.otherVehicleOwnerType}
                onChange={(e) => handleInputChange("otherVehicleOwnerType", e.target.value)}
                placeholder="Please specify other owner type"
                disabled={loading}
                className="w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-jnj-red border-jnj-line bg-white"
              />
            </div>
          )}

          {/* Vehicle Type (required) */}
          <div className="mb-5">
            <label className="block text-sm font-medium text-jnj-ink mb-2">
              <span className="text-jnj-red">*</span> Vehicle Type
            </label>
            <select
              value={formData.vehicleType}
              onChange={(e) => handleInputChange("vehicleType", e.target.value)}
              disabled={loading}
              className={`w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-jnj-red transition ${
                errors.vehicleType ? "border-red-500 bg-red-50" : "border-jnj-line bg-white"
              }`}
            >
              <option value="">Select Vehicle Type</option>
              {VEHICLE_TYPE_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
            {errors.vehicleType && <p className="text-red-500 text-xs mt-1">{errors.vehicleType}</p>}
          </div>

          {/* If Vehicle Type is Other (specify) → show text box */}
          {isVehicleTypeOther && (
            <div className="mb-5">
              <label className="block text-sm font-medium text-jnj-ink mb-2">
                Please Specify Other Vehicle Type
              </label>
              <input
                type="text"
                value={formData.vehicleTypeOther}
                onChange={(e) => handleInputChange("vehicleTypeOther", e.target.value)}
                placeholder="Enter other vehicle type"
                disabled={loading}
                className="w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-jnj-red border-jnj-line bg-white"
              />
            </div>
          )}
        </ModalSubsection>

        <ModalSubsection title="Driver Information">
          {/* Driver Name (required) */}
          <div className="mb-5">
            <label className="block text-sm font-medium text-jnj-ink mb-2">
              <span className="text-jnj-red">*</span> Driver Name
            </label>
            <input
              type="text"
              value={formData.driverName}
              onChange={(e) => handleInputChange("driverName", e.target.value)}
              placeholder="Enter driver name"
              disabled={loading}
              className={`w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-jnj-red transition ${
                errors.driverName ? "border-red-500 bg-red-50" : "border-jnj-line bg-white"
              }`}
            />
            {errors.driverName && <p className="text-red-500 text-xs mt-1">{errors.driverName}</p>}
          </div>

          {/* Driver Type (required) */}
          <div className="mb-5">
            <label className="block text-sm font-medium text-jnj-ink mb-2">
              <span className="text-jnj-red">*</span> Driver Type
            </label>
            <select
              value={formData.driverType}
              onChange={(e) => handleInputChange("driverType", e.target.value)}
              disabled={loading}
              className={`w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-jnj-red transition ${
                errors.driverType ? "border-red-500 bg-red-50" : "border-jnj-line bg-white"
              }`}
            >
              <option value="">Select Driver Type</option>
              {DRIVER_TYPE_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
            {errors.driverType && <p className="text-red-500 text-xs mt-1">{errors.driverType}</p>}
          </div>

          {/* Driver Function (required) */}
          <div className="mb-5">
            <label className="block text-sm font-medium text-jnj-ink mb-2">
              <span className="text-jnj-red">*</span> Driver Function
            </label>
            <select
              value={formData.driverFunction}
              onChange={(e) => handleInputChange("driverFunction", e.target.value)}
              disabled={loading}
              className={`w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-jnj-red transition ${
                errors.driverFunction ? "border-red-500 bg-red-50" : "border-jnj-line bg-white"
              }`}
            >
              <option value="">Select Driver Function</option>
              {DRIVER_FUNCTION_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
            {errors.driverFunction && (
              <p className="text-red-500 text-xs mt-1">{errors.driverFunction}</p>
            )}
          </div>

          {/* Driver Currently Licensed? (required) */}
          <div className="mb-5">
            <label className="block text-sm font-medium text-jnj-ink mb-2">
              <span className="text-jnj-red">*</span> Driver Currently Licensed?
            </label>
            <div className="flex gap-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="driverCurrentlyLicensed"
                  value="yes"
                  checked={formData.driverCurrentlyLicensed === "yes"}
                  onChange={(e) => handleInputChange("driverCurrentlyLicensed", e.target.value)}
                  disabled={loading}
                  className="w-4 h-4 text-jnj-red cursor-pointer accent-jnj-red"
                />
                <span className="text-sm text-jnj-ink">Yes</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="driverCurrentlyLicensed"
                  value="no"
                  checked={formData.driverCurrentlyLicensed === "no"}
                  onChange={(e) => handleInputChange("driverCurrentlyLicensed", e.target.value)}
                  disabled={loading}
                  className="w-4 h-4 text-jnj-red cursor-pointer accent-jnj-red"
                />
                <span className="text-sm text-jnj-ink">No</span>
              </label>
            </div>
            {errors.driverCurrentlyLicensed && (
              <p className="text-red-500 text-xs mt-1">{errors.driverCurrentlyLicensed}</p>
            )}
          </div>

          {/* If Licensed = Yes → required Authority issuing license */}
          {isDriverLicensedYes && (
            <div className="mb-5">
              <label className="block text-sm font-medium text-jnj-ink mb-2">
                <span className="text-jnj-red">*</span> Authority issuing license
              </label>
              <input
                type="text"
                value={formData.driverLicenseAuthority}
                onChange={(e) => handleInputChange("driverLicenseAuthority", e.target.value)}
                placeholder="Enter licensing authority"
                disabled={loading}
                className={`w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-jnj-red transition ${
                  errors.driverLicenseAuthority ? "border-red-500 bg-red-50" : "border-jnj-line bg-white"
                }`}
              />
              {errors.driverLicenseAuthority && (
                <p className="text-red-500 text-xs mt-1">{errors.driverLicenseAuthority}</p>
              )}
            </div>
          )}
        </ModalSubsection>
      </div>

      {/* Footer */}
      <div className="border-t border-jnj-line px-6 py-3 bg-gray-50 flex items-center justify-end gap-3">
        <button
          onClick={onClose}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-jnj-line text-sm font-medium text-jnj-ink hover:bg-gray-100 transition"
        >
          <X className="h-4 w-4" />
          Cancel
        </button>
        <button
          onClick={handleSave}
          disabled={loading}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-jnj-red text-white text-sm font-medium hover:bg-jnj-red-dark transition disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Save className="h-4 w-4" />
          {loading ? "Saving..." : "Save"}
        </button>
      </div>
    </ModalShell>
  );
}
