"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

import { ModalShell } from "./ModalShell";
import NewPropertyDamageModal from "./Property";
import NewInjuryIllnessModal from "./Injury";
import NewRegulatoryEventModal from "./Regulatory";
import SpillReleaseModal from "./SpillReleaseModal";
import NewVehicleEventModal from "./VehicleEventModal";

import { controlBase } from "@/lib/status";

export default function CreateEventDialog({
  onClose,
  onConfirm,
}) {
  const CREATE_EVENT_OPTIONS = [
    "Injury/Illness event",
    "Spill/Release event",
    "Property Damage event",
    "New Vehicle event",
    "Regulatory event",
  ];

  const [evt, setEvt] = useState(
    CREATE_EVENT_OPTIONS[0]
  );

  const [
    showPropertyDamageModal,
    setShowPropertyDamageModal,
  ] = useState(false);

  const [
    showInjuryIllnessModal,
    setShowInjuryIllnessModal,
  ] = useState(false);

    const [
    showVehicleEventModal,
    setShowVehicleEventModal,
  ] = useState(false);

  const [
    showRegulatoryModal,
    setShowRegulatoryModal,
  ] = useState(false);

  const [
    showSpillReleaseModal,
    setShowSpillReleaseModal,
  ] = useState(false);

  const handleOk = () => {
    console.log("Selected Event:", evt);

    switch (evt) {
      case "Injury/Illness event":
        setShowInjuryIllnessModal(
          true
        );
        return;

      case "Spill/Release event":
        setShowSpillReleaseModal(
          true
        );
        return;

      case "Property Damage event":
        setShowPropertyDamageModal(
          true
        );
        return;

      case "Regulatory event":
        setShowRegulatoryModal(
          true
        );
        return;

       case "New Vehicle event":
        setShowVehicleEventModal(
          true
        );
        return;

      default:
        if (onConfirm) {
          onConfirm(evt);
        }
    }
  };

  if (showInjuryIllnessModal) {
    return (
      <NewInjuryIllnessModal
        onClose={() => {
          setShowInjuryIllnessModal(
            false
          );

          if (onClose) {
            onClose();
          }
        }}
      />
    );
  }

  if (showSpillReleaseModal) {
    return (
      <SpillReleaseModal
        onClose={() => {
          setShowSpillReleaseModal(
            false
          );

          if (onClose) {
            onClose();
          }
        }}
      />
    );
  }

  if (showPropertyDamageModal) {
    return (
      <NewPropertyDamageModal
        onClose={() => {
          setShowPropertyDamageModal(
            false
          );

          if (onClose) {
            onClose();
          }
        }}
      />
    );
  }

  if (showRegulatoryModal) {
    return (
      <NewRegulatoryEventModal
        onClose={() => {
          setShowRegulatoryModal(
            false
          );

          if (onClose) {
            onClose();
          }
        }}
      />
    );
  }

   if (showVehicleEventModal) {
    return (
      <NewVehicleEventModal
        onClose={() => {
          setShowVehicleEventModal(
            false
          );

          if (onClose) {
            onClose();
          }
        }}
      />
    );
  }

  return (
    <ModalShell
      title="Confirmation"
      onClose={onClose}
      maxWidth="max-w-sm"
    >
      <div className="px-5 py-5">
        <p className="text-sm font-medium text-jnj-ink">
          Select Event to create:
        </p>

        <div className="relative mt-2">
          <select
            value={evt}
            onChange={(e) =>
              setEvt(e.target.value)
            }
            className={`${controlBase} appearance-none cursor-pointer pr-9`}
          >
            {CREATE_EVENT_OPTIONS.map(
              (option) => (
                <option
                  key={option}
                  value={option}
                >
                  {option}
                </option>
              )
            )}
          </select>

          <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <button
            type="button"
            onClick={handleOk}
            className="rounded-lg bg-jnj-red px-5 py-2 text-sm font-semibold text-white transition hover:bg-jnj-red-dark active:scale-[0.98]"
          >
            Ok
          </button>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-jnj-line px-5 py-2 text-sm font-medium text-jnj-slate transition hover:bg-jnj-mist"
          >
            Cancel
          </button>
        </div>
      </div>
    </ModalShell>
  );
}