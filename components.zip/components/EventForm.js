'use client'
 
import React, { useState, useCallback, useEffect, useRef } from 'react'
import { BotAvatar } from './Avatars'
import { ClipboardList, CheckCircle2, AlertCircle } from 'lucide-react'
import { fetchEmployees } from '@/lib/employeeApi'
import { enhanceText } from '@/lib/enhanceApi'
import { detectPii } from '@/lib/piiApi'
import fieldInfoTranslations from "./fieldInfoTranslations.json";
import FileUploadModal from './FileUploadModal'

export const getFieldInfo = (language, key) => {
  return (
    fieldInfoTranslations?.[language]?.[key] ||
    fieldInfoTranslations?.English?.[key] ||
    ''
  )
}

function isReportIntro(introHtml = '', fields = []) {
  if (introHtml.includes('FINAL EHS&S REPORT')) return true
  if (introHtml.includes('FINAL EHS\\&S REPORT')) return true
  const lc = introHtml.toLowerCase()
  if (lc.includes('here is the report')) return true
  if (lc.includes('please review all the details')) return true
  if (lc.includes('would you like to make any changes or submit')) return true
  if (lc.includes('voici le rapport')) return true
  if (lc.includes('hier ist der bericht')) return true
  if (lc.includes('aquí está el informe')) return true
  if (lc.includes('hier is het rapport')) return true
  if (lc.includes('ecco il rapporto')) return true
  if (lc.includes('aqui está o relatório')) return true
  const kvLines = introHtml.split('\n').filter(line => {
    const idx = line.indexOf(':')
    return idx > 0 && idx < 60
  })
  if (kvLines.length >= 5) return true
  const REPORT_FIELD_LABELS = new Set([
    'Event Type', 'Site Location', 'Department', 'Responsible Department',
    'What Happened', 'Report in Confidence?', 'Select Different Reviewer?',
    'Default Incident Reviewer', 'Default Good Save Reviewer',
  ])
  const matchCount = fields.filter(f =>
    REPORT_FIELD_LABELS.has(f.label) || REPORT_FIELD_LABELS.has(f.englishLabel)
  ).length
  return matchCount >= 3
}
 
function extractTrailingQuestion(intro = '') {
  const trimmed = intro.trimEnd()
  const lastDoubleNewline = trimmed.lastIndexOf('\n\n')
  if (lastDoubleNewline === -1) return { cleanIntro: trimmed, trailingQuestion: '' }
  const tail = trimmed.slice(lastDoubleNewline + 2).trim()
  if (!tail.includes(':')) {
    return {
      cleanIntro: trimmed.slice(0, lastDoubleNewline).trimEnd(),
      trailingQuestion: tail,
    }
  }
  return { cleanIntro: trimmed, trailingQuestion: '' }
}
 
function parseIntroRows(intro = '') {
  const rows = []
  const seen = new Set()
  for (const line of intro.split('\n')) {
    const colonIdx = line.indexOf(':')
    if (colonIdx === -1) continue
    const key = line.slice(0, colonIdx).trim().replace(/^[\*•\-\s]+/, '').trim()
    const val = line.slice(colonIdx + 1).trim()
    if (!key || seen.has(key)) continue
    if (/^[A-Z0-9\s&!.,;:'"()\-]+$/.test(key) && key.replace(/[\s&]/g, '').length > 4) continue
    if (/^(here is|thank you|since the|please (review|select|fill|note)|i need|based on)/i.test(key)) continue
    seen.add(key)
    rows.push({ key, value: val })
  }
  return rows
}

// ─── Field IDs ────────────────────────────────────────────────────────────────
const FID = {
  EVENT_TYPE:           'EVENT_TYPE',
  LOCATION:             'LOCATION',
  COMPANY:              'COMPANY',
  SITE_LOCATION:        'SITE_LOCATION',
  SUB_SITE_LOCATION:    'SUB_SITE_LOCATION',
  DEPARTMENT:           'DEPARTMENT',
  SUB_DEPARTMENT:       'SUB_DEPARTMENT',
  RESPONSIBLE_DEPT:     'RESPONSIBLE_DEPT',
  DESCRIBE_OTHER:       'DESCRIBE_OTHER',
  CONSTRUCTION_PROJECT: 'CONSTRUCTION_PROJECT',
  PHASE_CONSTRUCTION:   'PHASE_CONSTRUCTION',
  HRA:                  'HRA',
  SECONDARY_HRA:        'SECONDARY_HRA',
  EQUIPMENT:            'EQUIPMENT',
  CONSTRUCTION_DETAILS: 'CONSTRUCTION_DETAILS',
  SPECIFIC_LOCATION:    'SPECIFIC_LOCATION',
  SELECT_REVIEWER:      'SELECT_REVIEWER',
  DATE_TIME_EVENT:      'DATE_TIME_EVENT',
  WHAT_HAPPENED:        'WHAT_HAPPENED',
  CAUSE:                'CAUSE',
  ACTION_TAKEN:         'ACTION_TAKEN',
  ACTION_SUGGEST:       'ACTION_SUGGEST',
  COMMENTS:             'COMMENTS',
  ON_BEHALF_OF:         'ON_BEHALF_OF',
  SUPERVISOR:           'SUPERVISOR',
  DATE_TIME_REPORTED:   'DATE_TIME_REPORTED',
  CONFIDENCE:           'CONFIDENCE',
  DEFAULT_GS_REVIEWER:  'DEFAULT_GS_REVIEWER',
  DEFAULT_INC_REVIEWER: 'DEFAULT_INC_REVIEWER',
  SITE_LIST_QUESTION:   'SITE_LIST_QUESTION',
  SITE_LIST_SELECT:     'SITE_LIST_SELECT',
  SELECT_DIFF_REVIEWER: 'SELECT_DIFF_REVIEWER',
  SELECT_NEW_REVIEWER:  'SELECT_NEW_REVIEWER',
}

// ─── FIELD_GROUPS ─────────────────────────────────────────────────────────────
// [0]Arabic [1]Chinese [2]Czech [3]Dutch(BE) [4]Dutch [5]English
// [6]French [7]German [8]Indonesian [9]Italian [10]Japanese [11]Korean
// [12]Malay [13]Polish [14]Portuguese(Brazil) [15]Russian [16]Spanish(Mexico)
// [17]Swedish [18]Thai

const FIELD_GROUPS = {
  [FID.EVENT_TYPE]: [
    'نوع الحدث','事件类型','Typ události','Gebeurtenistype','Gebeurtenistype','Event Type',
    "Type d'événement",'Ereignistyp','Jenis Peristiwa','Tipo di evento','イベントタイプ','이벤트 유형',
    'Jenis Peristiwa','Rodzaj zdarzenia','Tipo de evento','Тип события','Tipo de evento',
    'Typ av rapport','ประเภทเหตุการณ์',
  ],
  [FID.LOCATION]: [
    'الموقع','位置','Umístění','Locatie','Locatie','Location','Emplacement','Firmenstandort',
    'Lokasi','Posizione','場所','위치','Lokasi','Lokalizacja','Localização',
    'Местоположение','Ubicación','Plats','สถานที่',
  ],
  [FID.COMPANY]: [
    'الشركة','公司','Společnost','Bedrijf','Bedrijf','Company','Entreprise','Unternehmen',
    'Perusahaan','Azienda','会社','회사','Syarikat','Firma','Empresa',
    'Компания','Empresa','Företag','บริษัท',
  ],
  [FID.SITE_LOCATION]: [
    'موقع الموقع','现场位置','Umístění areálu','Sitelocatie','Sitelocatie','Site Location',
    'Emplacement du site','Standort','Lokasi Situs','Posizione del sito','サイトロケーション',
    '사이트 위치','Lokasi Tapak','Lokalizacja obiektu','Localização da companhia',
    'Местоположение объекта','Ubicación del sitio','Plats på företaget','ที่ตั้งไซต์',
  ],
  [FID.SUB_SITE_LOCATION]: [
    'موقع الموقع الفرعي','子现场位置','Dílčí umístění areálu','Sub-sitelocatie','Sub-sitelocatie',
    'Sub Site Location','Sub emplacement du site','Teilbereich eines Standortes','Sub Lokasi Situs',
    'Posizione del sito secondario','サイトロケーション(サブ)','하위 사이트 위치',
    'Sub Lokasi Tapak','Podlokalizacja obiektu','Localização do subsite',
    'Дополнительное местоположение объекта','Sub Ubicación del sitio','Plats för underort','พื้นที่ย่อย',
  ],
  [FID.DEPARTMENT]: [
    'القسم','部门','Oddělení','Afdeling','Afdeling','Department','Département','Abteilung',
    'Departemen','Dipartimento','所属','부서','Jabatan','Dział','Departamento',
    'Отдел','Departamento','Avdelning','แผนก',
  ],
  [FID.SUB_DEPARTMENT]: [
    'القسم الفرعي','子部门','Pododdělení','Sub-afdeling','Sub-afdeling','Sub Department',
    'Sub service','Untergeordnete Abteilung eines Standorts','Sub Departemen',
    'Sotto-dipartimento','部署(サブ)','하위 부서','Sub Jabatan','Podział','Sub Departamento',
    'Подотдел','Sub Departamento','Underavdelning','แผนกย่อย',
  ],
  [FID.RESPONSIBLE_DEPT]: [
    'الإدارة المسؤولة','负责部门','Odpovědné oddělení',
    'Verantwoordelijke afdeling','Verantwoordelijke afdeling','Responsible Department',
    'Service responsable','Zuständige Abteilung','Departemen Penanggung Jawab',
    'Dipartimento responsabile','担当部署','담당 부서',
    'Jabatan Bertanggungjawab','Odpowiedzialny dział','Departamento responsável',
    'Ответственный отдел','Departamento responsable','Ansvarig avdelning','แผนกที่รับผิดชอบ',
  ],
  [FID.DESCRIBE_OTHER]: [
    "وصف 'أخرى' القسم المسؤول",
    "描述'其他'责任部门",
    "Popište 'Jiný' odpovědný útvar",
    "Beschrijf 'Andere' verantwoordelijke afdeling",
    "Beschrijf 'Andere' verantwoordelijke afdeling",
    "Describe 'Other' Responsible Department",
    "Décrire 'Autre' département responsable",
    "Anderes verantwortliches Abteilung beschreiben",
    "Deskripsikan 'Lainnya' Departemen",
    "Descrivere 'Altro' dipartimento responsabile",
    "「その他」の担当部門を説明する",
    "'기타' 담당 부서 설명",
    "Huraikan 'Lain' Jabatan",
    "Opisz 'Inne' odpowiedzialne działy",
    "Descrever 'Outro' departamento responsável",
    "Опишите 'Другой' ответственный отдел",
    "Describir 'Otro' departamento responsable",
    "Beskriv 'Annan' ansvarig avdelning",
    "อธิบาย 'อื่นๆ' แผนก",
  ],
  [FID.DATE_TIME_EVENT]: [
    'تاريخ ووقت الحدث','事件日期和时间','Datum a čas události',
    'Datum en tijdstip van het incident','Datum en tijdstip van het incident','Date and Time of Event',
    "Date et heure de l'événement",'Datum und Uhrzeit des Ereignisses','Tanggal dan Waktu Peristiwa',
    "Data e ora dell'evento",'イベント発生日時','이벤트 날짜 및 시간',
    'Tarikh dan Masa Peristiwa','Data i godzina zdarzenia','Data e horário do evento',
    'Дата и время события','Fecha y hora del evento','Datum och tidpunkt för risk/händelse',
    'วันที่และเวลาที่เกิดเหตุการณ์',
  ],
  [FID.WHAT_HAPPENED]: [
    'ماذا حدث؟','发生了什么?','Co se stalo?','Wat is er gebeurd?','Wat is er gebeurd?','What Happened',
    "Que s'est-il passé?",'Was ist los?','Apa yang Terjadi?','Cosa è successo?','どうしましたか？',
    '무슨 일이 있었나요?','Apa yang Berlaku?','Co się stało?','O que aconteceu?',
    'Что произошло?','¿Qué pasó?','Vad hände?','เกิดอะไรขึ้น',
  ],
  [FID.CAUSE]: [
    'برأيك ما الذي تسبب في هذا الحادث؟',
    '您认为是什么导致了这起事故?',
    'Co si myslíte, že způsobilo tento incident?',
    'Wat denkt u dat dit incident heeft veroorzaakt?',
    'Wat denkt u dat dit incident heeft veroorzaakt?',
    'What do you think caused this Incident?',
    'Selon vous, quelle est la cause de cet incident?',
    'Was hat diesen Vorfall Ihrer Meinung nach verursacht?',
    'Apa yang Anda Pikir Menyebabkan Insiden Ini?',
    'Cosa pensa abbia causato questo incidente?',
    'このインシデントの原因は何だと思いますか？',
    '이 사건의 원인이 무엇이라고 생각하십니까?',
    'Apa yang anda fikir menyebabkan insiden ini?',
    'Co według Ciebie spowodowało to zdarzenie?',
    'O que você acha que causou este incidente?',
    'Что, по вашему мнению, вызвало этот инцидент?',
    '¿Cuál cree que fue la causa de este incidente?',
    'Vad tror du orsakade den här incidenten?',
    'คุณคิดว่าอะไรเป็นสาเหตุของเหตุการณ์นี้',
  ],
  [FID.ACTION_TAKEN]: [
    'ما الإجراءات (الإجراءات) الذي اتخذته؟',
    '您采取了什么行动？',
    'Jaká opatření jste přijali?',
    'Welke actie(s) heeft u ondernomen?',
    'Welke actie(s) heeft u ondernomen?',
    'What action(s) did you take?',
    'Quelle(s) action(s) avez-vous effectuées?',
    'Welche Maßnahme(n) haben Sie getroffen?',
    'Tindakan apa yang Anda ambil?',
    'Quali azioni ha intrapreso?',
    'どのようなアクションを取りましたか',
    '어떤 조치를 취하셨습니까?',
    'Apakah tindakan yang anda ambil?',
    'Jakie działanie(-a) zostało(-y) przez Ciebie podjęte?',
    'Qual(is) medida(s) você tomou?',
    'Какие действия вы предприняли?',
    '¿Qué acciones tomó?',
    'Vilken/vilka åtgärd/er vidtog du?',
    'คุณดำเนินการอย่างไร?',
  ],
  [FID.ACTION_SUGGEST]: [
    'ما الإجراءات (الإجراءات) الذي تقترحه؟',
    '您建议采取什么行动？',
    'Jaká opatření doporučujete?',
    'Welke actie(s) stelt u voor?',
    'Welke actie(s) stelt u voor?',
    'What action(s) do you suggest?',
    'Quelle(s) action(s) suggérez-vous?',
    'Welche Maßnahme(n) schlagen Sie vor?',
    'Tindakan apa yang Anda sarankan?',
    'Quali azioni suggerisce?',
    '今後どのようなアクションを提案しますか',
    '어떤 조치를 권고하십니까?',
    'Apakah tindakan yang anda cadangkan?',
    'Jakie działanie(-a) zostało(-y) przez Ciebie zasugerowane?',
    'Qual(is) medida(s) você sugere?',
    'Какие действия вы предлагаете?',
    '¿Qué acciones sugiere?',
    'Vilken/vilka åtgärd/er föreslår du?',
    'คุณแนะนำให้ดำเนินการอย่างไร?',
  ],
  [FID.COMMENTS]: [
    'التعليقات','备注','Komentáře','Opmerkingen','Opmerkingen','Comments',
    'Commentaires','Kommentare','Komentar','Commenti','コメント','댓글',
    'Komen','Komentarze','Comentários','Комментарии','Comentarios','Kommentarer','ข้อคิดเห็น',
  ],
  [FID.ON_BEHALF_OF]: [
    'تم الإبلاغ بنيابة عن','代表报告人','Hlášeno jménem',
    'Gerapporteerd namens','Gerapporteerd namens','Reported On Behalf Of',
    'Rapporté pour le compte de','Gemeldet im Namen von','Dilaporkan Atas Nama',
    'Segnalato per conto di','下記の者の代理で報告','대리 보고자',
    'Dilaporkan Bagi Pihak','Zdarzenie zgłoszone w imieniu','Relatado em nome de',
    'Сообщено от имени','Reportado en nombre de','Rapporteras på uppdrag av','รายงานในนามของ',
  ],
  [FID.SUPERVISOR]: [
    'تم الإبلاغ بالنيابة عن - المشرف',
    '代表报告-主管',
    'Nadřízený pro hlášení jménem',
    'Supervisor voor rapportage namens',
    'Supervisor voor rapportage namens',
    'Reported On Behalf Of - Supervisor',
    'Signalé au nom de - superviseur',
    'Gemeldet Im Namen Von - Vorgesetzter',
    'Supervisor Dilaporkan Atas Nama',
    'Supervisore per segnalazione per conto di',
    '代理報告-スーパーバイザ',
    '대리 보고자 - 상사',
    'Penyelia Dilaporkan Bagi Pihak',
    'Zgłoszono w imieniu - przełożony',
    'Comunicado em nome de - Supervisor',
    'Руководитель для сообщения от имени',
    'Supervisor reportado en nombre de',
    'Anmäld på uppdrag av - Supervisor',
    'รายงานในนามของ - หัวหน้างาน',
  ],
  [FID.DATE_TIME_REPORTED]: [
    'التاريخ والوقت المبلغ عنه','报告日期和时间','Datum a čas hlášení',
    'Datum en tijdstip van rapportage','Datum en tijdstip van rapportage','Date and Time Reported',
    'Date et heure du signalement','Datum und Uhrzeit der Meldung','Tanggal dan Waktu Dilaporkan',
    'Data e ora della segnalazione','日付と時刻が報告されました','보고 날짜 및 시간',
    'Tarikh dan Masa Dilaporkan','Raportowana data i godzina','Data e horas apontadas',
    'Дата и время сообщения','Fecha y hora del reporte','Datum och tid som rapporteras',
    'วันที่และเวลาที่รายงาน',
  ],
  [FID.CONFIDENCE]: [
    'الإبلاغ بثقة؟','机密报告?','Důvěrná zpráva?',
    'Vertrouwelijk rapport?','Vertrouwelijk rapport?','Report in Confidence?',
    'Rapport confidentiel?','Vertraulich...','Laporan Rahasia?',
    'Rapporto riservato?','機密性のある報告ですか','기밀 보고서?',
    'Laporan Sulit?','Zgłoszenie zdarzenia w sposób poufny?','Relatar confidencialmente?',
    'Конфиденциальный отчёт?','¿Informe confidencial?','Vill du rapportera konfidentiellt?',
    'รายงานโดยปิดตัวตนของคุณหรือไม่?',
  ],
  [FID.DEFAULT_GS_REVIEWER]: [
    'مراجع الحفظ الجيد الافتراضي','默认Good Save审核人','Výchozí recenzent Good Save',
    'Standaard good save reviewer','Standaard good save reviewer','Default Good Save Reviewer',
    'Réviseur de sauvegarde par défaut','Standard-Good-Save-Prüfer','Peninjau Good Save Default',
    'Revisore predefinito Good Save','デフォルトのグッドセーブ・レビュアー','기본 Good Save 검토자',
    'Pengulas Good Save Lalai','Domyślny recenzent zapobieżenia','Analista padrão do Good Save',
    'Рецензент Good Save по умолчанию','Revisor predeterminado de Good Save',
    'Standard Risk-granskare','ผู้ตรวจสอบเหตุการณ์ที่ป้องกันได้หันเริ่มต้น',
  ],
  [FID.DEFAULT_INC_REVIEWER]: [
    'مراجع الحوادث الافتراضي','默认事件审核人','Výchozí recenzent incidentu',
    'Standaard incidentreviewer','Standaard incidentreviewer','Default Incident Reviewer',
    "Vérificateur d'incident par défaut",'Standard-Vorfalls-Reviewer','Peninjau Insiden Default',
    'Revisore predefinito degli incidenti','デフォルトのインシデント・レビュアー','기본 인시던트 검토자',
    'Pengulas Insiden Lalai','Domyślny recenzent incydentów','Analista padrão de incidentes',
    'Рецензент инцидента по умолчанию','Revisor predeterminado de incidentes',
    'Standard incidentgranskare','ผู้ตรวจสอบเหตุการณ์เริ่มต้น',
  ],
  [FID.SELECT_DIFF_REVIEWER]: [
    'حدد مراجع مختلف','选择不同的审核人？','Vybrat jiného recenzenta?',
    'Een andere reviewer selecteren?','Een andere reviewer selecteren?','Select Different Reviewer?',
    'Sélectionner un autre vérificateur?','Anderen Reviewer auswählen','Pilih Peninjau Berbeda?',
    'Selezionare un revisore diverso?','他のレビュアーを選択しますか？','다른 검토자 선택?',
    'Pilih Pengulas Berbeza?','Wybrać innego recenzenta?','Selecionar um analista diferente?',
    'Выбрать другого рецензента?','¿Seleccionar un revisor diferente?','Markera en annan granskare?',
    'เลือกผู้ตรวจสอบรายอื่นหรือไม่?',
  ],
  [FID.SELECT_NEW_REVIEWER]: [
    'حدد مراجع جديد','选择新审核人','Vybrat nového recenzenta',
    'Nieuwe reviewer selecteren','Nieuwe reviewer selecteren','Select New Reviewer',
    'Sélectionner un nouveau vérificateur','Wählen Sie Neuer Prüfer.','Pilih Peninjau Baru',
    'Seleziona nuovo revisore','新しいレビュアーを選択','새 검토자 선택',
    'Pilih Pengulas Baru','Wybierz nowego recenzenta','Selecionar um novo analista',
    'Выбрать нового рецензента','Seleccionar nuevo revisor','Välj ny granskare','เลือกผู้ตรวจสอบใหม่',
  ],
  [FID.SITE_LIST_QUESTION]: [
    'هل تريد أن تتم مراجعة Good Save من قبل قائمة الموقع الكاملة؟',
    '您是否希望由完整的站点维护列表审核Good Save？',
    'Chcete, aby byl Good Save přezkoumán úplným seznamem lokality?',
    'Wilt u dat de Good Save wordt beoordeeld door de volledige sitelijst?',
    'Wilt u dat de Good Save wordt beoordeeld door de volledige sitelijst?',
    'Do you want the Good Save to be reviewed by the complete Site Maintained List?',
    'Voulez-vous que le Good Save soit envoyé automatiquement à toutes les personnes désignées pour la revue ?',
    'Soll der Good Save von der vollständigen Site-Liste geprüft werden?',
    'Apakah Anda ingin Good Save ditinjau oleh Daftar Situs lengkap?',
    "Vuoi che il Good Save sia esaminato dall'elenco completo del sito?",
    'Good Saveをサイト維持リスト全体でレビューしますか？',
    'Good Save를 전체 사이트 목록으로 검토하시겠습니까?',
    'Adakah anda mahu Good Save disemak oleh Senarai Tapak yang lengkap?',
    'Czy chcesz, aby Good Save był sprawdzony przez pełną listę serwisowaną?',
    'Você quer que o Good Save seja revisado pela lista completa do site?',
    'Хотите, чтобы Good Save был проверен полным списком сайта?',
    '¿Desea que el Good Save sea revisado por la lista completa del sitio?',
    'Vill du att den risks ska granskas av hela den listan som upprätthålls av platsen?',
    'คุณต้องการให้ Good Save ตรวจสอบโดยรายการไซต์ทั้งหมด?',
  ],
  [FID.SITE_LIST_SELECT]: [
    'الاختيار من قائمة الموقع','从站点维护列表中选择','Vybrat ze seznamu lokality',
    'Selecteer uit de sitelijst','Selecteer uit de sitelijst','Select from Site Maintained List',
    'Sélectionner dans la liste des personnes désignées',
    'Aus vom Standort verwalteter Liste auswählen','Pilih dari Daftar Situs',
    "Seleziona dall'elenco del sito",'サイト維持リストから選択','사이트 목록에서 선택',
    'Pilih dari Senarai Tapak','Wybierz z listy serwisowanej','Selecionar da lista do site',
    'Выбрать из списка сайта','Seleccionar de la lista del sitio',
    'Välj från platsens lista','เลือกจากรายการไซต์',
  ],
  [FID.SELECT_REVIEWER]: [
    'اختر المراجع','选择审核人','Vybrat recenzenta',
    'Reviewer selecteren','Reviewer selecteren','Select Reviewer',
    'Sélectionner le vérificateur','Wählen Sie Prüfer','Pilih Peninjau',
    'Seleziona revisore','レビュアーを選択','검토자 선택',
    'Pilih Pengulas','Wybierz recenzenta','Selecionar analista',
    'Выбрать рецензента','Seleccionar revisor','Välj granskare','เลือกผู้ตรวจสอบ',
  ],
  [FID.CONSTRUCTION_PROJECT]: [
    'مشروع البناء ذو الصلة','相关建设项目','Sovisející stavební projekt',
    'Gerelateerd bouwproject','Gerelateerd bouwproject','Related Construction Project',
    'Projet de construction connexe','Verwandtes Bauprojekt','Proyek Konstruksi Terkait',
    'Progetto di costruzione correlato','関連建設プロジェクト','관련 건설 프로젝트',
    'Projek Pembinaan Berkaitan','Powiązany projekt budowlany','Projeto de construção relacionado',
    'Связанный строительный проект','Proyecto de construcción relacionado',
    'Relaterat byggprojekt','โครงการก่อสร้างที่เกี่ยวข้อง',
  ],
  [FID.PHASE_CONSTRUCTION]: [
    'مرحلة البناء','建设阶段','Fáze výstavby','Bouwfase','Bouwfase','Phase of Construction',
    'Phase de construction','Bauphase','Fase Konstruksi','Fase di costruzione','建設フェーズ',
    '건설 단계','Fasa Pembinaan','Faza budowy','Fase de construção',
    'Этап строительства','Fase de construcción','Byggfas','ระยะก่อสร้าง',
  ],
  [FID.HRA]: [
    'نشاط عالي الخطورة (HRA)','高风险活动 (HRA)','Vysoce riziková aktivita (HRA)',
    'Hoogrisico activiteit (HRA)','Hoogrisico activiteit (HRA)','High Risk Activity (HRA)',
    'Activité à haut risque (HRA)','Hochrisikoaktivität (HRA)','Aktivitas Berisiko Tinggi (HRA)',
    'Attività ad alto rischio (HRA)','高リスク活動 (HRA)','고위험 활동 (HRA)',
    'Aktiviti Berisiko Tinggi (HRA)','Działalność wysokiego ryzyka (HRA)',
    'Atividade de Alto Risco (HRA)','Деятельность высокого риска (HRA)',
    'Actividad de Alto Riesgo (HRA)','Högriskaktivitet (HRA)','กิจกรรมความเสี่ยงสูง (HRA)',
  ],
  [FID.SECONDARY_HRA]: [
    'نشاط ثانوي عالي الخطورة (HRA)','次要高风险活动 (HRA)','Sekundární vysoce riziková aktivita (HRA)',
    'Secundaire hoogrisico activiteit (HRA)','Secundaire hoogrisico activiteit (HRA)',
    'Secondary High Risk Activity (HRA)','Activité secondaire à haut risque (HRA)',
    'Sekundäre Hochrisikoaktivität (HRA)','Aktivitas Berisiko Tinggi Sekunder (HRA)',
    'Attività secondaria ad alto rischio (HRA)','副次的高リスク活動 (HRA)','이차 고위험 활동 (HRA)',
    'Aktiviti Berisiko Tinggi Sekunder (HRA)','Wtórna działalność wysokiego ryzyka (HRA)',
    'Atividade Secundária de Alto Risco (HRA)','Вторичная деятельность высокого риска (HRA)',
    'Actividad Secundaria de Alto Riesgo (HRA)','Sekundär högriskaktivitet (HRA)',
    'กิจกรรมความเสี่ยงสูงรอง (HRA)',
  ],
  [FID.EQUIPMENT]: [
    'المعدات المعنية','涉及的设备','Zapojené vybavení',
    'Betrokken apparatuur','Betrokken apparatuur','Equipment Involved',
    'Équipement impliqué','Beteiligtes Equipment','Peralatan yang Terlibat',
    'Attrezzatura coinvolta','関連機器','관련 장비',
    'Peralatan yang Terlibat','Zaangażowany sprzęt','Equipamento envolvido',
    'Задействованное оборудование','Equipo involucrado','Involverad utrustning','อุปกรณ์ที่เกี่ยวข้อง',
  ],
  [FID.CONSTRUCTION_DETAILS]: [
    'تفاصيل موقع البناء','建设地点详情','Podrobnosti o místě stavby',
    'Bouwlocatiedetails','Bouwlocatiedetails','Construction Location Details',
    "Détails de l'emplacement de construction",'Standortdetails Bau','Detail Lokasi Konstruksi',
    'Dettagli posizione costruzione','建設場所の詳細','건설 위치 세부 사항',
    'Butiran Lokasi Pembinaan','Szczegóły lokalizacji budowy','Detalhes do local de construção',
    'Детали места строительства','Detalles de la ubicación de construcción',
    'Byggplatsdetaljer','รายละเอียดสถานที่ก่อสร้าง',
  ],
  [FID.SPECIFIC_LOCATION]: [
    'موقع محدد','具体位置','Konkrétní umístění',
    'Specifieke locatie','Specifieke locatie','Specific Location',
    'Emplacement spécifique','Spezifischer Standort','Lokasi Spesifik',
    'Posizione specifica','特定の場所','특정 위치',
    'Lokasi Tertentu','Konkretna lokalizacja','Localização específica',
    'Конкретное местоположение','Ubicación específica','Specifik plats','ตำแหน่งที่ระบุ',
  ],
}

// ─── Auto-build reverse lookup ───────────────────────────────────────────────
const LABEL_TO_FID = {}
Object.entries(FIELD_GROUPS).forEach(([fid, labels]) => {
  labels.forEach(label => { if (label) LABEL_TO_FID[label] = fid })
})
const LABEL_TO_FID_LOWER = {}
Object.entries(LABEL_TO_FID).forEach(([k, v]) => { LABEL_TO_FID_LOWER[k.toLowerCase()] = v })
function labelLookup(label) {
  return LABEL_TO_FID[label] || LABEL_TO_FID_LOWER[label.toLowerCase()] || null
}

function resolveFieldsByContent(fields) {
  const claimed = new Set()
  const result  = new Map()
  fields.forEach((f, i) => {
    const id = getFieldIdByLabel(f)
    if (id && !claimed.has(id)) { result.set(i, id); claimed.add(id) }
  })
  fields.forEach((f, i) => {
    if (result.has(i)) return
    const opts = Array.isArray(f.options) ? f.options : []
    const n    = opts.length
    if (typeof f.options === 'string') {
      if (!claimed.has(FID.ON_BEHALF_OF)) { result.set(i, FID.ON_BEHALF_OF); claimed.add(FID.ON_BEHALF_OF) }
      return
    }
    if (f.input_type === 'checkbox') {
      if (!claimed.has(FID.EQUIPMENT)) { result.set(i, FID.EQUIPMENT); claimed.add(FID.EQUIPMENT) }
      return
    }
    if (n > 50) {
      if (!claimed.has(FID.CONSTRUCTION_PROJECT)) { result.set(i, FID.CONSTRUCTION_PROJECT); claimed.add(FID.CONSTRUCTION_PROJECT) }
      return
    }
    if (n >= 20 && n <= 25) {
      if (!claimed.has(FID.PHASE_CONSTRUCTION)) { result.set(i, FID.PHASE_CONSTRUCTION); claimed.add(FID.PHASE_CONSTRUCTION) }
      return
    }
    if (n === 14 && !f.optional) {
      if (!claimed.has(FID.HRA)) { result.set(i, FID.HRA); claimed.add(FID.HRA) }
      return
    }
    if (n === 5 && !f.optional) {
      if (!claimed.has(FID.CONSTRUCTION_DETAILS)) { result.set(i, FID.CONSTRUCTION_DETAILS); claimed.add(FID.CONSTRUCTION_DETAILS) }
      return
    }
    if (n === 14 && f.optional) {
      if (!claimed.has(FID.SECONDARY_HRA)) { result.set(i, FID.SECONDARY_HRA); claimed.add(FID.SECONDARY_HRA) }
      return
    }
    if (n === 1) {
      const opt = opts[0]
      if (opt === '--no options available--') {
        const target = !claimed.has(FID.SITE_LIST_SELECT) ? FID.SITE_LIST_SELECT : FID.SELECT_NEW_REVIEWER
        if (!claimed.has(target)) { result.set(i, target); claimed.add(target) }
        return
      }
      if (/\(\d{4,}\)/.test(opt)) {
        if (!claimed.has(FID.SELECT_REVIEWER)) { result.set(i, FID.SELECT_REVIEWER); claimed.add(FID.SELECT_REVIEWER) }
        return
      }
      if (/,\s/.test(opt)) {
        if (!claimed.has(FID.LOCATION)) { result.set(i, FID.LOCATION); claimed.add(FID.LOCATION) }
        return
      }
      if (opt.includes(' - ')) {
        if (!claimed.has(FID.COMPANY)) { result.set(i, FID.COMPANY); claimed.add(FID.COMPANY) }
        return
      }
      const target = !claimed.has(FID.DEFAULT_GS_REVIEWER) ? FID.DEFAULT_GS_REVIEWER : FID.DEFAULT_INC_REVIEWER
      if (!claimed.has(target)) { result.set(i, target); claimed.add(target) }
      return
    }
    if (n === 2) {
      const firstOptLen = opts[0].trim().length
      if (firstOptLen >= 4) {
        if (!claimed.has(FID.EVENT_TYPE)) { result.set(i, FID.EVENT_TYPE); claimed.add(FID.EVENT_TYPE) }
        return
      }
      const yesNoOrder = [FID.CONFIDENCE, FID.SITE_LIST_QUESTION, FID.SELECT_DIFF_REVIEWER]
      const target = yesNoOrder.find(id => !claimed.has(id))
      if (target) { result.set(i, target); claimed.add(target) }
      return
    }
    if (n > 5 && n < 20) {
      if (!claimed.has(FID.RESPONSIBLE_DEPT)) { result.set(i, FID.RESPONSIBLE_DEPT); claimed.add(FID.RESPONSIBLE_DEPT) }
    }
  })
  return result
}

function getFieldIdByLabel(field) {
  if (field.englishLabel) {
    const id = labelLookup(field.englishLabel)
    if (id) return id
  }
  const id = labelLookup(field.label)
  if (id) return id
  const hybrid = field.label.match(/^([^(]+)\s*\(/)
  if (hybrid) {
    const id2 = labelLookup(hybrid[1].trim())
    if (id2) return id2
  }
  const stripped = field.label.replace(/[.…?!]+$/, '').trim()
  if (stripped !== field.label) {
    const id3 = labelLookup(stripped)
    if (id3) return id3
  }
  return null
}

function getFieldId(field) {
  const byLabel = getFieldIdByLabel(field)
  if (byLabel) return byLabel
  const opts = Array.isArray(field.options) ? field.options : []
  const n    = opts.length
  if (typeof field.options === 'string')    return FID.ON_BEHALF_OF
  if (field.input_type === 'checkbox')      return FID.EQUIPMENT
  if (n > 50)                               return FID.CONSTRUCTION_PROJECT
  if (n >= 20 && n <= 25)                   return FID.PHASE_CONSTRUCTION
  if (n === 14 && !field.optional)          return FID.HRA
  if (n === 5 && !field.optional)           return FID.CONSTRUCTION_DETAILS
  if (n === 14 && field.optional)           return FID.SECONDARY_HRA
  return null
}

const FIELD_ORDER = [
  FID.EVENT_TYPE, FID.LOCATION, FID.COMPANY,
  FID.SITE_LOCATION, FID.SUB_SITE_LOCATION,
  FID.DEPARTMENT, FID.SUB_DEPARTMENT, FID.RESPONSIBLE_DEPT, FID.DESCRIBE_OTHER,
  FID.CONSTRUCTION_PROJECT, FID.PHASE_CONSTRUCTION,
  FID.HRA, FID.SECONDARY_HRA, FID.EQUIPMENT,
  FID.CONSTRUCTION_DETAILS, FID.SPECIFIC_LOCATION,
  FID.DATE_TIME_EVENT, FID.WHAT_HAPPENED,
  FID.CAUSE, FID.ACTION_TAKEN, FID.ACTION_SUGGEST, FID.COMMENTS,
  FID.ON_BEHALF_OF, FID.SUPERVISOR, FID.DATE_TIME_REPORTED,
  FID.CONFIDENCE, FID.DEFAULT_GS_REVIEWER, FID.DEFAULT_INC_REVIEWER,
  FID.SITE_LIST_QUESTION, FID.SITE_LIST_SELECT,
  FID.SELECT_DIFF_REVIEWER, FID.SELECT_NEW_REVIEWER, FID.SELECT_REVIEWER,
]

// ─── J&J Site / Company labels for all 19 languages ──────────────────────────
// Language index matches FIELD_GROUPS order exactly:
// [0]Arabic [1]Chinese [2]Czech [3]Dutch(BE) [4]Dutch [5]English
// [6]French [7]German [8]Indonesian [9]Italian [10]Japanese [11]Korean
// [12]Malay [13]Polish [14]Portuguese(Brazil) [15]Russian [16]Spanish(Mexico)
// [17]Swedish [18]Thai

const LANG_TO_IDX = {
  'Arabic': 0, 'Chinese': 1, 'Czech (Czechia)': 2,
  'Dutch (Belgium)': 3, 'Dutch': 4, 'English': 5,
  'French (France)': 6, 'German (Germany)': 7, 'Indonesian (Indonesia)': 8,
  'Italian (Italy)': 9, 'Japanese (Japan)': 10, 'Korean (Korea)': 11,
  'Malay': 12, 'Polish (Poland)': 13, 'Portuguese (Brazil)': 14,
  'Russian (Russia)': 15, 'Spanish (Mexico)': 16, 'Swedish (Sweden)': 17, 'Thai (Thailand)': 18,
}

const JNJ_SITE_LABELS = [
  'موقع J&J',       'J&J 地点',        'Lokalita J&J',
  'J&J locatie',    'J&J locatie',    'J&J Site',
  'Site J&J',       'J&J-Standort',   'Lokasi J&J',
  'Sede J&J',       'J&Jサイト',       'J&J 사이트',
  'Tapak J&J',      'Obiekt J&J',     'Site J&J',
  'Объект J&J',     'Sitio J&J',      'J&J Plats',      'J&J ไซต์',
]

const JNJ_COMPANY_LABELS = [
  'شركة J&J',       'J&J 公司',        'J&J společnost',
  'J&J bedrijf',    'J&J bedrijf',    'J&J Company',
  'Entreprise J&J', 'J&J Unternehmen','Perusahaan J&J',
  'Azienda J&J',    'J&J会社',         'J&J 회사',
  'Syarikat J&J',   'Firma J&J',      'Empresa J&J',
  'Компания J&J',   'Empresa J&J',    'J&J Företag',    'J&J บริษัท',
]

const WHAT_HAPPENED_LABELS = [
  'ماذا حدث؟','发生了什么?','Co se stalo?',
  'Wat is er gebeurd?','Wat is er gebeurd?','What happened?',
  "Que s'est-il passé?",'Was ist passiert?','Apa yang Terjadi?',
  'Cosa è successo?','どうしましたか？','무슨 일이 있었나요?',
  'Apa yang Berlaku?','Co się stało?','O que aconteceu?',
  'Что произошло?','¿Qué pasó?','Vad hände?','เกิดอะไรขึ้น?',
]

const DESCRIBE_OTHER_LABELS = [
  'وصف أخرى','描述其他','Popište jiný',
  'Beschrijf andere','Beschrijf andere','Describe Other',
  'Décrire autre','Andere beschreiben','Jelaskan lainnya',
  'Descrivi altro','その他を説明する','기타 설명',
  'Huraikan lain','Opisz inne','Descrever outro',
  'Описать другое','Describir otro','Beskriv annat','อธิบายอื่นๆ',
]

function getLangIdx(lang = '') { return LANG_TO_IDX[lang] ?? 5 }
function getJnjSiteLabel(lang)    { return JNJ_SITE_LABELS[getLangIdx(lang)] }
function getJnjCompanyLabel(lang) { return JNJ_COMPANY_LABELS[getLangIdx(lang)] }
function getWhatHappenedLabel(lang)  { return WHAT_HAPPENED_LABELS[getLangIdx(lang)] }
function getDescribeOtherLabel(lang) { return DESCRIBE_OTHER_LABELS[getLangIdx(lang)] }


const ENHANCEABLE = new Set([FID.WHAT_HAPPENED, FID.ACTION_TAKEN, FID.ACTION_SUGGEST, FID.CAUSE, FID.COMMENTS])

const REQUIRED_IDS_BASE = new Set([
  FID.EVENT_TYPE, FID.LOCATION, FID.COMPANY, FID.SITE_LOCATION, FID.DEPARTMENT,
  FID.RESPONSIBLE_DEPT, FID.DATE_TIME_EVENT, FID.WHAT_HAPPENED, FID.ON_BEHALF_OF,
  FID.CONFIDENCE, FID.DATE_TIME_REPORTED, FID.DEFAULT_GS_REVIEWER, FID.DEFAULT_INC_REVIEWER,
  FID.SELECT_DIFF_REVIEWER, FID.DESCRIBE_OTHER, FID.SELECT_NEW_REVIEWER,
  FID.CONSTRUCTION_PROJECT, FID.PHASE_CONSTRUCTION, FID.HRA, FID.EQUIPMENT,
  FID.CONSTRUCTION_DETAILS, FID.SPECIFIC_LOCATION, FID.SELECT_REVIEWER,
  FID.SITE_LIST_QUESTION, FID.SITE_LIST_SELECT,
])
const REQUIRED_IDS_ENPS = new Set([
  FID.CONSTRUCTION_PROJECT, FID.HRA, FID.EQUIPMENT, FID.CONSTRUCTION_DETAILS, FID.SELECT_REVIEWER,
])
const READONLY_FIELDS = new Set([FID.DEFAULT_INC_REVIEWER, FID.SUPERVISOR, FID.DEFAULT_GS_REVIEWER, FID.LOCATION])
const DATETIME_FIELDS = new Set([FID.DATE_TIME_EVENT, FID.DATE_TIME_REPORTED])
const FIELD_LABELS = {}

function parseBackendUtc(raw) {
  const m = raw.trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})\s*(AM|PM)$/i)
  if (!m) return null
  let [, month, day, year, hour, min, sec, meridiem] = m
  hour = parseInt(hour, 10)
  if (/pm/i.test(meridiem) && hour !== 12) hour += 12
  if (/am/i.test(meridiem) && hour === 12) hour = 0
  return new Date(Date.UTC(+year, +month - 1, +day, hour, +min, +sec))
}

function formatUtcToLocal(rawValue) {
  if (!rawValue || typeof rawValue !== 'string') return rawValue
  let date = parseBackendUtc(rawValue)
  if (!date || isNaN(date.getTime())) {
    let iso = rawValue.trim().replace(' ', 'T')
    if (!/[Zz]$/.test(iso) && !/[+-]\d{2}:\d{2}$/.test(iso)) iso += 'Z'
    date = new Date(iso)
  }
  if (!date || isNaN(date.getTime())) return rawValue
  try {
    const d = date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
    const t = date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true })
    return `${d}, ${t}`
  } catch { return rawValue }
}

const IconSparkles = ({ className = 'w-3 h-3' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
    <path d="M5 3v4" /><path d="M19 17v4" /><path d="M3 5h4" /><path d="M17 19h4" />
  </svg>
)
const IconRotate = ({ className = 'w-3 h-3' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" />
  </svg>
)
const IconCheck = ({ className = 'w-3 h-3' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12" />
  </svg>
)
const IconX = ({ className = 'w-2.5 h-2.5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
  </svg>
)
const IconLock = ({ className = 'w-2.5 h-2.5' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
  </svg>
)
const IconSend = ({ className = 'w-3 h-3' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 2L11 13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
  </svg>
)
const IconSearch = ({ className = 'w-3 h-3' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
  </svg>
)
const IconUser = ({ className = 'w-3 h-3' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
  </svg>
)

const FIELD_INFO = {
  [FID.LOCATION]: "If the incident/good save happened at a J&J property, you need to indicate this J&J property (also if you are linked to another J&J property). If the incident/good save happened at a non J&J location, you need to indicate which J&J location is responsible / accountable for this incident/good save.",
  [FID.SITE_LOCATION]: "You can indicate the specific on-site location where the incident/good save happened. If the incident/good save did not happen on site, you can indicate at what type of off-site location it occurred (like 3PL warehouse, high priority supplier, WWE construction project site, etc.).",
  [FID.SUB_SITE_LOCATION]: "This list is specific to this site only. It is rolled up as part of the Site Location category.",
  [FID.DEPARTMENT]: "Please select the department where the good save/incident occurred.",
  [FID.SUB_DEPARTMENT]: "This list is specific to this site only. It is rolled up as part of the Department category.",
  [FID.RESPONSIBLE_DEPT]: "Department managing the activity related to the event (incidents/good saves).",
  [FID.SPECIFIC_LOCATION]: "Please add here all extra information, next to the other location-related fields, that can help clarify where the incident/good save actually happened (room number, etc.).",
  [FID.EVENT_TYPE]: "Good save: An accident that almost happened or an environmental mishap that almost occurred. Includes near misses, unsafe conditions identified and unsafe behaviors observed that could have resulted in an injury/illness, environmental impact or property damage.\n\nIncident: An unplanned, undesired occurrence that interrupts normal operations.",
  [FID.WHAT_HAPPENED]: "Enter a brief description about the incident/good save, including how it occurred, conditions that caused it (such as leading events or basis, immediate or system causes, etc.), and the result(s).",
  [FID.CAUSE]: "Used to capture an initial suspected cause of the event.",
  [FID.ACTION_TAKEN]: "If an action was already taken, please describe it in this field.",
  [FID.ACTION_SUGGEST]: "If additional actions are necessary, describe here which actions you would suggest be taken.",
  [FID.SUPERVISOR]: "Click 'Save as Draft' if you updated the 'Reported On Behalf Of' field.",
  [FID.DATE_TIME_REPORTED]: "Date the event was reported.",
  [FID.CONFIDENCE]: "You can indicate 'in confidence' if you don't want your supervisor to see your name in the system. If your supervisor is mentioned as the reviewer, you can also change this to someone else.",
  [FID.CONSTRUCTION_PROJECT]: "If you can't find the necessary project, please contact the Project Manager.",
}

function InfoTooltip({ text }) {
  const [visible, setVisible] = useState(false)
  return (
    <span className="relative" style={{ display: 'inline-block', verticalAlign: 'super', lineHeight: 0, marginLeft: 2 }}>
      <button type="button"
        onMouseEnter={() => setVisible(true)} onMouseLeave={() => setVisible(false)}
        onFocus={() => setVisible(true)} onBlur={() => setVisible(false)}
        className="flex items-center justify-center rounded-full border-none cursor-pointer outline-none"
        style={{ width: 11, height: 11, background: '#3B82F6', flexShrink: 0, padding: 0 }}
        tabIndex={-1} aria-label="More info">
        <span style={{ color: '#fff', fontSize: 7, fontWeight: 400, lineHeight: 1, userSelect: 'none' }}>i</span>
      </button>
      {visible && (
        <div className="absolute z-50 rounded-xl bg-white text-black-500 text-xs leading-relaxed"
          style={{ width: 700, padding: '10px 12px', border: '1px solid #E5E7EB',
            boxShadow: '0 8px 24px rgba(0,0,0,0.15)', top: 'calc(100% + 6px)', left: 0,
            whiteSpace: 'pre-wrap', textAlign: 'left', lineHeight: '1.6', pointerEvents: 'none' }}>
          <span style={{ position: 'absolute', top: -6, left: 2, width: 0, height: 0,
            borderLeft: '6px solid transparent', borderRight: '6px solid transparent', borderBottom: '6px solid #E5E7EB' }} />
          <span style={{ position: 'absolute', top: -5, left: 2, width: 0, height: 0,
            borderLeft: '6px solid transparent', borderRight: '6px solid transparent', borderBottom: '6px solid #fff' }} />
          {text}
        </div>
      )}
    </span>
  )
}

function HighlightMatch({ text, query }) {
  if (!query) return <span>{text}</span>
  const idx = text.toLowerCase().indexOf(query.toLowerCase())
  if (idx === -1) return <span>{text}</span>
  return (
    <span>
      {text.slice(0, idx)}
      <mark className="bg-yellow-100 text-yellow-800 font-semibold rounded-sm px-0">{text.slice(idx, idx + query.length)}</mark>
      {text.slice(idx + query.length)}
    </span>
  )
}

function CircularSpinner({ size = 22 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 22 22" fill="none" className="animate-spin" style={{ animationDuration: '0.7s' }}>
      <circle cx="11" cy="11" r="9" stroke="#E5E7EB" strokeWidth="2.5" />
      <path d="M11 2a9 9 0 0 1 9 9" stroke="#B91C1C" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  )
}

function OnBehalfOfDropdown({ value, onSelect, disabled = false, dropUp = false }) {
  const [query,   setQuery]   = useState(value || '')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [open,    setOpen]    = useState(false)
  const [error,   setError]   = useState('')
  const [hovered, setHovered] = useState(false)
  const [focused, setFocused] = useState(false)
  const debounceRef  = useRef(null)
  const containerRef = useRef(null)
  const listRef      = useRef(null)
  const abortRef     = useRef(null)

  useEffect(() => { if (!focused) setQuery(value || '') }, [value, focused])
  useEffect(() => {
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false); setFocused(false); setQuery(value || '')
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [value])

  const doSearch = useCallback((text) => {
    if (!text || text.trim().length < 1) { setResults([]); setOpen(false); setLoading(false); return }
    if (abortRef.current) abortRef.current.abort()
    abortRef.current = new AbortController()
    setLoading(true); setError('')
    fetchEmployees(text.trim(), { signal: abortRef.current.signal })
      .then(data => { setResults(data); setOpen(true); setLoading(false) })
      .catch(err => {
        if (err.name !== 'AbortError') { setError('Could not load employees. Check connection.'); setLoading(false); setOpen(true) }
      })
  }, [])

  const handleChange = (e) => {
    const val = e.target.value; setQuery(val)
    clearTimeout(debounceRef.current)
    if (!val.trim()) { setResults([]); setOpen(false); setLoading(false); return }
    setLoading(true)
    debounceRef.current = setTimeout(() => doSearch(val), 350)
  }
  const handleSelect = (emp) => { setQuery(emp.name); setOpen(false); setFocused(false); onSelect(emp.name, emp.supervisor) }
  const borderColor = disabled ? '#E5E7EB' : focused ? '#B91C1C' : hovered ? '#B91C1C' : '#D1D5DB'
  const boxShadow   = disabled ? 'none' : focused ? '0 0 0 3px rgba(185,28,28,0.1)' : hovered ? '0 0 0 2px rgba(185,28,28,0.06)' : 'none'

  return (
    <div ref={containerRef} className="relative w-full">
      <div className="flex items-center gap-2 rounded-lg px-2.5 py-1.5 transition-all duration-150"
        style={{ background: disabled ? '#F3F4F6' : focused || hovered ? '#ffffff' : '#F7F8FA',
          border: `${focused ? '2px' : '1.5px'} ${focused ? 'solid' : 'dashed'} ${borderColor}`, boxShadow }}
        onMouseEnter={() => !disabled && setHovered(true)} onMouseLeave={() => setHovered(false)}>
        <IconSearch className="w-3 h-3 text-gray-400 shrink-0" />
        <input type="text" value={query} onChange={handleChange}
          onFocus={() => { if (!disabled) { setFocused(true); if (query.trim()) doSearch(query) } }}
          disabled={disabled} placeholder="Type a name to search…"
          className="flex-1 text-xs text-gray-900 bg-transparent outline-none placeholder-gray-400 disabled:cursor-not-allowed"
          autoComplete="off" />
        {query && !disabled && (
          <button onMouseDown={e => { e.preventDefault(); setQuery(''); setResults([]); setOpen(false); onSelect('', '') }}
            className="text-gray-400 hover:text-gray-600 bg-transparent border-none cursor-pointer p-0 leading-none" title="Clear">
            <IconX className="w-2.5 h-2.5" />
          </button>
        )}
      </div>
      {(open || loading) && focused && (
        <div className="absolute z-50 left-0 right-0 rounded-2xl bg-white overflow-hidden"
          style={{ boxShadow: '0 8px 32px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.08)', border: '1px solid #F1F1F1',
            ...(dropUp ? { bottom: 'calc(100% + 8px)' } : { top: 'calc(100% + 8px)' }) }}>
          <div className="flex items-center justify-between px-3 py-2 border-b border-gray-100">
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-widest">
              {loading ? 'Searching…' : `${results.length} employee${results.length !== 1 ? 's' : ''} found`}
            </span>
            {loading && <CircularSpinner size={12} />}
          </div>
          {loading ? (
            <div className="px-3 py-2 flex flex-col gap-2">
              {[90, 70, 80].map((w, i) => (
                <div key={i} className="flex items-center gap-2.5 py-1">
                  <div className="w-7 h-7 rounded-full bg-gray-100 animate-pulse shrink-0" />
                  <div className="flex flex-col gap-1 flex-1">
                    <div className="h-2.5 rounded-full bg-gray-100 animate-pulse" style={{ width: `${w}%` }} />
                    <div className="h-2 rounded-full bg-gray-50 animate-pulse" style={{ width: `${w - 20}%` }} />
                  </div>
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="flex items-center gap-2 px-4 py-3 text-xs text-red-500">
              <AlertCircle size={13} className="shrink-0" /> {error}
            </div>
          ) : results.length === 0 ? (
            <div className="flex flex-col items-center gap-1.5 px-4 py-5">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#D1D5DB" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
              </svg>
              <span className="text-xs text-gray-400">No employees found for <strong className="text-gray-500">&ldquo;{query}&rdquo;</strong></span>
            </div>
          ) : (
            <ul ref={listRef} className="overflow-y-auto" style={{ maxHeight: 260 }}>
              {results.map((emp, i) => (
                <li key={`${emp.raw}-${i}`}>
                  <button onMouseDown={e => { e.preventDefault(); handleSelect(emp) }}
                    className="w-full flex items-center gap-3 px-3 py-2.5 text-left border-none bg-transparent cursor-pointer group transition-all duration-100"
                    style={{ background: 'transparent' }}
                    onMouseEnter={e => e.currentTarget.style.background = '#FEF2F2'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                    <div className="w-7 h-7 shrink-0 rounded-full flex items-center justify-center text-[10px] font-bold"
                      style={{ background: `hsl(${(emp.name.charCodeAt(0) * 37) % 360}, 55%, 92%)`, color: `hsl(${(emp.name.charCodeAt(0) * 37) % 360}, 55%, 35%)` }}>
                      {emp.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()}
                    </div>
                    <div className="flex flex-col min-w-0 flex-1">
                      <span className="text-xs font-semibold text-gray-800 truncate leading-snug">
                        <HighlightMatch text={emp.name} query={query} />
                      </span>
                      {emp.supervisor ? (
                        <span className="text-[10px] text-gray-400 truncate leading-snug flex items-center gap-1">
                          <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
                            <path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                          </svg>
                          {emp.supervisor}
                        </span>
                      ) : (
                        <span className="text-[10px] text-gray-300 truncate leading-snug">No supervisor</span>
                      )}
                    </div>
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#B91C1C" strokeWidth="3"
                      strokeLinecap="round" strokeLinejoin="round" className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  )
}

function EnhancePopover({ originalText, selectedLanguage, onAccept, onClose }) {
  const [status, setStatus] = useState('loading')
  const [text, setText] = useState('')
  const run = async () => {
    setStatus('loading'); setText('')
    try {
      const enhanced = await enhanceText(originalText, selectedLanguage)
      setText(enhanced)
    } catch { setText('Failed to enhance text. Please try again.') }
    finally { setStatus('done') }
  }
  useEffect(() => { run() }, [selectedLanguage, originalText])
  return (
    <div className="absolute z-50 left-0 right-0 rounded-xl overflow-hidden border border-purple-200 bg-white shadow-xl"
      style={{ top: 'calc(100% + 6px)' }}>
      <div className="flex items-center justify-between px-3 py-2 bg-gradient-to-r from-violet-600 to-purple-700">
        <span className="flex items-center gap-1.5 text-white text-xs font-bold tracking-wide">
          <IconSparkles className="w-2.5 h-2.5" /> AI SUGGESTION
        </span>
        <button onClick={onClose} className="text-white/60 hover:text-white text-sm leading-none bg-transparent border-none cursor-pointer">✕</button>
      </div>
      <div className="p-3">
        {status === 'loading' ? (
          <div className="flex flex-col gap-2">
            {[100, 80, 62].map((w, i) => (
              <div key={i} className="h-2 rounded bg-gray-200 animate-pulse" style={{ width: `${w}%` }} />
            ))}
            <p className="text-xs text-gray-400 text-center mt-1">Enhancing…</p>
          </div>
        ) : (
          <textarea value={text} onChange={e => setText(e.target.value)} rows={4}
            className="w-full border border-purple-200 rounded-lg px-2.5 py-2 text-xs text-gray-800 leading-relaxed resize-none outline-none bg-violet-50/30" />
        )}
      </div>
      <div className="flex justify-between items-center px-3 pb-3 pt-2 border-t border-gray-100">
        <button onClick={run} className="flex items-center gap-1 text-xs text-violet-600 font-semibold bg-transparent border-none cursor-pointer">
          <IconRotate /> Regenerate
        </button>
        <button onClick={() => onAccept(text)} className="px-4 py-1 text-xs font-bold text-white rounded-full cursor-pointer border-none bg-violet-600 hover:bg-violet-700">
          Insert
        </button>
      </div>
    </div>
  )
}

const ACCENT = '#B91C1C'

function DateTimePicker({ rowKey, value, onSave, disabled }) {
  const pad = n => String(n).padStart(2, '0')
  const getNowParts = () => {
    const n = new Date()
    return { dateStr: `${n.getFullYear()}-${pad(n.getMonth()+1)}-${pad(n.getDate())}`, timeStr: `${pad(n.getHours())}:${pad(n.getMinutes())}` }
  }
  const parseToLocalParts = (raw) => {
    if (!raw) return { date: '', time: '' }
    let d = parseBackendUtc(raw)
    if (!d || isNaN(d.getTime())) {
      let iso = String(raw).trim().replace(' ', 'T')
      if (!/[Zz]$/.test(iso) && !/[+-]\d{2}:\d{2}$/.test(iso)) iso += 'Z'
      d = new Date(iso)
    }
    if (!d || isNaN(d.getTime())) return { date: '', time: '' }
    if (d > new Date()) d = new Date()
    return { date: `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`, time: `${pad(d.getHours())}:${pad(d.getMinutes())}` }
  }
  const toBackendFormat = (dateStr, timeStr) => {
    if (!dateStr || !timeStr) return ''
    const d = new Date(`${dateStr}T${timeStr}`)
    if (isNaN(d.getTime())) return ''
    const m = d.getUTCMonth() + 1, day = d.getUTCDate(), y = d.getUTCFullYear()
    let h = d.getUTCHours()
    const min = String(d.getUTCMinutes()).padStart(2, '0')
    const ampm = h >= 12 ? 'PM' : 'AM'
    h = h % 12 || 12
    return `${m}/${day}/${y}  ${h}:${min}:00 ${ampm}`
  }
  const init = parseToLocalParts(value)
  const [dateVal, setDateVal] = useState(init.date)
  const [timeVal, setTimeVal] = useState(init.time)
  useEffect(() => {
    const p = parseToLocalParts(value)
    setDateVal(p.date); setTimeVal(p.time)
    const raw = value || ''
    let original = parseBackendUtc(raw)
    if (!original) { const iso = raw.trim().replace(' ', 'T'); original = new Date(/[Zz]$|[+-]\d{2}:\d{2}$/.test(iso) ? iso : iso + 'Z') }
    if (original && !isNaN(original.getTime()) && original > new Date()) onSave(rowKey, toBackendFormat(p.date, p.time))
  }, [value])
  const fieldCls = (focused, hovered) => ({
    background: disabled ? '#F3F4F6' : focused || hovered ? '#fff' : '#F7F8FA',
    border: disabled ? '1.5px solid #E5E7EB' : focused ? `2px solid ${ACCENT}` : hovered ? `1.5px solid ${ACCENT}` : '1.5px dashed #D1D5DB',
    boxShadow: disabled ? 'none' : focused ? `0 0 0 3px ${ACCENT}18` : hovered ? `0 0 0 2px ${ACCENT}0D` : 'none',
    colorScheme: 'light',
  })
  const [df, setDf] = useState(false), [dh, setDh] = useState(false)
  const [tf, setTf] = useState(false), [th, setTh] = useState(false)
  const { dateStr: todayStr, timeStr: nowTimeStr } = getNowParts()
  const isToday = dateVal === todayStr
  return (
    <div className="flex gap-2">
      <input type="date" value={dateVal} disabled={disabled} max={todayStr}
        onChange={e => {
          const val = e.target.value > todayStr ? todayStr : e.target.value
          let clampedTime = timeVal
          if (val === todayStr && timeVal > nowTimeStr) { clampedTime = nowTimeStr; setTimeVal(clampedTime) }
          setDateVal(val); onSave(rowKey, toBackendFormat(val, clampedTime))
        }}
        onFocus={() => setDf(true)} onBlur={() => setDf(false)}
        onMouseEnter={() => setDh(true)} onMouseLeave={() => setDh(false)}
        className="w-1/2 text-xs text-gray-900 rounded-lg outline-none transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        style={{ padding: '6px 8px', ...fieldCls(df, dh) }} />
      <input type="time" value={timeVal} disabled={disabled} max={isToday ? nowTimeStr : undefined}
        onChange={e => {
          const val = (isToday && e.target.value > nowTimeStr) ? nowTimeStr : e.target.value
          setTimeVal(val); onSave(rowKey, toBackendFormat(dateVal, val))
        }}
        onFocus={() => setTf(true)} onBlur={() => setTf(false)}
        onMouseEnter={() => setTh(true)} onMouseLeave={() => setTh(false)}
        className="w-1/2 text-xs text-gray-900 rounded-lg outline-none transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        style={{ padding: '6px 8px', ...fieldCls(tf, th) }} />
    </div>
  )
}

function RowCell({ rowKey, value, options, onSave, disabled = false, fieldType = null, placeholder = '— Select —', selectedLanguage, setIsPiiDetected }) {
  const isReadonly   = READONLY_FIELDS.has(rowKey)
  const isDatetime   = DATETIME_FIELDS.has(rowKey)
  const canEnhance   = ENHANCEABLE.has(rowKey) && !isReadonly
  const displayValue = isDatetime ? formatUtcToLocal(value) : value
  const hasOptions   = Array.isArray(options) && options.length > 0 && !(options.length === 1 && options[0] === '--no options available--')
  const [draft,       setDraft]       = useState(displayValue)
  const [editing,     setEditing]     = useState(false)
  const [hovered,     setHovered]     = useState(false)
  const [showAI,      setShowAI]      = useState(false)
  const [piiWarning,  setPiiWarning]  = useState(null)
  const [piiChecking, setPiiChecking] = useState(false)
  const taRef = useRef(null)



  useEffect(() => { if (!editing) setDraft(displayValue) }, [value, editing])
  useEffect(() => {
    const el = taRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = el.scrollHeight + 'px'
  }, [draft])

  // Parses "glass broken by [PII:Deepak] via [PII:deepak@x.com]"
  // into normal text + red highlighted <mark> spans
  const renderPiiHighlight = (text) => {
    if (!text) return null
    const parts = []
    const regex = /\[PII:([^\]]+)\]/g
    let last = 0; let m; let k = 0
    while ((m = regex.exec(text)) !== null) {
      if (m.index > last) parts.push(<span key={k++}>{text.slice(last, m.index)}</span>)
      parts.push(
        <mark key={k++} style={{
          background: '#FEE2E2', color: '#B91C1C',
          fontWeight: 700, borderRadius: 3, padding: '0 3px',
        }}>
          {m[1]}
        </mark>
      )
      last = m.index + m[0].length
    }
    if (last < text.length) parts.push(<span key={k++}>{text.slice(last)}</span>)
    return parts
  }

const commit = async () => {
  if (!draft.trim()) { onSave(rowKey, draft); setEditing(false); return }
  setPiiChecking(true)
  try {
    const data = await detectPii(draft, selectedLanguage)

    if (data && data.pii_detected) {
      // If backend provided a sanitized_text, apply it directly and save
      const sanitized = data.sanitized_text ?? (data.result && data.result.sanitized_text) ?? null
      if (sanitized) {
        // show sanitized locally immediately (optional but recommended)
        setDraft(sanitized)

        // persist sanitized value
        onSave(rowKey, sanitized)

        // clear inline edit-warning state and close editor
        setPiiWarning(null)
        setPiiChecking(false)
        setIsPiiDetected(false)
        setEditing(false)
        return
      }

      // No sanitized_text available: preserve prior behavior (show inline PII warning and keep editing)
      setPiiWarning(data)
      setIsPiiDetected(true)
      setPiiChecking(false)
      return
    }
  } catch {
    // network / server error — don't block the user
  }

  // no PII or detect call failed: clear PII state and save normally
  setPiiWarning(null)
  setPiiChecking(false)
  setIsPiiDetected(false)
  onSave(rowKey, draft)
  setEditing(false)
}


const cancel = () => {
  setDraft(displayValue)
  setEditing(false)
  setIsPiiDetected(false)
  setPiiWarning(null)
  setPiiChecking(false)
}



  // ── Read-only ──────────────────────────────────────────────────────────────
  if (isReadonly) return (
    <div className="flex items-center gap-2 px-2.5 py-1.5 bg-gray-100 rounded-lg border border-gray-200 cursor-not-allowed select-none">
      <IconLock className="w-2.5 h-2.5 text-gray-400 shrink-0" />
      <span className="text-xs text-gray-500 font-medium flex-1">{displayValue || '—'}</span>
    </div>
  )

  // ── Date-time ──────────────────────────────────────────────────────────────
  if (isDatetime) return <DateTimePicker rowKey={rowKey} value={value} onSave={onSave} disabled={disabled} />

  // ── Checkbox ───────────────────────────────────────────────────────────────
  if (hasOptions && fieldType === 'checkbox') {
    const checked = value ? value.split(',').map(v => v.trim()).filter(Boolean) : []
    const toggle  = (opt) => {
      if (disabled) return
      const next = checked.includes(opt) ? checked.filter(v => v !== opt) : [...checked, opt]
      onSave(rowKey, next.join(', '))
    }
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-3 gap-y-1.5 py-1">
        {options.map(opt => {
          const isChecked = checked.includes(opt)
          return (
            <label key={opt} className="flex items-center gap-2 cursor-pointer select-none group" style={{ opacity: disabled ? 0.6 : 1 }}>
              <span onClick={() => toggle(opt)}
                className="shrink-0 w-4 h-4 rounded flex items-center justify-center border transition-all duration-150"
                style={{ background: isChecked ? '#B91C1C' : '#fff', borderColor: isChecked ? '#B91C1C' : '#D1D5DB',
                  boxShadow: isChecked ? '0 0 0 2px rgba(185,28,28,0.15)' : 'none',
                  cursor: disabled ? 'not-allowed' : 'pointer' }}>
                {isChecked && (
                  <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"/>
                  </svg>
                )}
              </span>
              <span onClick={() => toggle(opt)} className="text-xs leading-snug transition-colors"
                style={{ color: isChecked ? '#B91C1C' : '#374151', fontWeight: isChecked ? 600 : 400 }}>
                {opt}
              </span>
            </label>
          )
        })}
      </div>
    )
  }

  // ── Dropdown / dependent ───────────────────────────────────────────────────
  if (hasOptions || fieldType === 'dependent') {
    const validatedValue = options.includes(draft) ? draft : ''
    return (
      <CustomDropdown
        options={options} value={validatedValue}
        onChange={v => { setDraft(v); onSave(rowKey, v) }}
        disabled={disabled} placeholder={placeholder} />
    )
  }

  // ── Free-text (with PII check) ─────────────────────────────────────────────
  return (
    <div className="relative w-full">

      {/* AI enhance button */}
      {canEnhance && value && !disabled && (
        <button onClick={() => setShowAI(v => !v)} title="Enhance with AI"
          className="absolute left-1.5 top-1.5 w-5 h-5 rounded-full flex items-center justify-center cursor-pointer border-none z-10 transition-all duration-200"
          style={{
            background: showAI
              ? 'linear-gradient(135deg,#7C3AED,#6D28D9)'
              : 'linear-gradient(135deg,#C4B5FD,#818CF8)',
            boxShadow: showAI
              ? '0 0 8px rgba(124,58,237,0.5)'
              : '0 1px 4px rgba(124,58,237,0.22)',
          }}>
          <IconSparkles className="w-2.5 h-2.5 text-white" />
        </button>
      )}

      {/* Textarea */}
      <textarea ref={taRef} rows={1} value={draft}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onFocus={() => { if (!disabled) setEditing(true) }}
      onChange={e => {
  if (disabled) return
  setDraft(e.target.value)
  setEditing(true)
  if (piiWarning) setPiiWarning(null) // clear warning on edit
}}


        disabled={disabled} placeholder="Enter value…"
        className="w-full text-xs font-normal text-gray-900 rounded-lg outline-none transition-all duration-200 cursor-text disabled:opacity-50 disabled:cursor-not-allowed"
        style={{
          padding: `6px 10px 6px ${canEnhance ? '30px' : '10px'}`,
          background: disabled ? '#F3F4F6' : editing || hovered ? '#ffffff' : '#F7F8FA',
          border: disabled    ? '1.5px solid #E5E7EB'
                : piiWarning  ? '1.5px solid #FCA5A5'
                : editing     ? `2px solid ${ACCENT}`
                : hovered     ? `1.5px solid ${ACCENT}`
                :               '1.5px dashed #D1D5DB',
          boxShadow: disabled ? 'none'
                   : editing  ? `0 0 0 3px ${ACCENT}18`
                   : hovered  ? `0 0 0 2px ${ACCENT}0D`
                   :            'none',
          resize: 'none', overflow: 'hidden', minHeight: '30px', lineHeight: '1.5',
        }} />
 
{piiWarning && (
  <div className="text-xs text-red-600 font-medium mt-2">
    <span className="text-xs text-red-600 font-medium">{piiWarning.pii_warning_en} </span>
    <span>{renderPiiHighlight(piiWarning.highlighted_text)}</span>
  </div>
)}

      {/* Confirm / Cancel buttons */}
      {editing && (
        <div className="flex gap-1.5 mt-1">
          <button onClick={commit} disabled={piiChecking}
            className="flex items-center gap-1 px-2.5 py-1 text-white text-xs font-bold rounded-md cursor-pointer border-none bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 disabled:cursor-not-allowed">
            {piiChecking
              ? <><CircularSpinner size={11} /> Checking…</>
              : <><IconCheck /> Confirm</>}
          </button>
          <button onClick={cancel}
            className="flex items-center gap-1 px-2.5 py-1 text-gray-600 text-xs font-semibold rounded-md cursor-pointer bg-white border border-gray-200 hover:bg-gray-50">
            <IconX /> Cancel
          </button>
        </div>
      )}

      {/* PII warning */}
   

      {/* AI enhance popover */}
      {showAI && (
        <EnhancePopover
          originalText={value} selectedLanguage={selectedLanguage}
          onAccept={v => { setDraft(v); onSave(rowKey, v); setShowAI(false) }}
          onClose={() => setShowAI(false)} />
      )}

    </div>
  )
}

// ─── Language-agnostic value helpers ─────────────────────────────────────────
const isGoodSaveValue = (val, fieldOpts) => {
  if (Array.isArray(fieldOpts) && fieldOpts.length >= 1) return val === fieldOpts[0]
  return /good.?save|bon.?gest|buen.?gesto|goed.?redden|buon.?salva/i.test(val)
}
const isIncidentValue = (val, fieldOpts) => {
  if (Array.isArray(fieldOpts) && fieldOpts.length >= 2) return val === fieldOpts[1]
  return /incident/i.test(val)
}
const isYesValue = (val, fieldOpts) => {
  if (Array.isArray(fieldOpts) && fieldOpts.length >= 1) return val === fieldOpts[0]
  return /^(yes|oui|ja|sí|si|sim|はい|是|예|tak|ano|evet|да|نعم|igen|da)$/i.test(val)
}
const isNoValue = (val, fieldOpts) => {
  if (Array.isArray(fieldOpts) && fieldOpts.length >= 2) return val === fieldOpts[1]
  return /^(no|non|nein|não|いいえ|否|아니오|nie|hayır|нет|لا|nem)$/i.test(val)
}
const isEPSSiteValue    = (val) => /E&PS/i.test(val || '')
const isSupervisValue   = (val) => { if (!val || val === '--no options available--') return false; return !/\(\d{4,}\)/.test(val) }
const isDescribeOtherValue = (val, rdOptions) => {
  if (!val) return false
  const opts = Array.isArray(rdOptions) ? rdOptions : []
  if (opts.length > 0 && val === opts[opts.length - 1]) return true
  return /beschreib|beschrijf|décri|descri|deskrip|huraik|beskriv|popsat|opisz|описат|صف|説明|설명|อธิบาย|描述/i.test(val)
}




function ReportStyleForm({ 
  fields, 
  introHtml, 
  onSubmit, 
  onSave, 
  locked = false, 
  selectedLanguage, 
  piiCheck = null,
  onFileUpload,
  session 
}) {
  const rawIntro   = introHtml || ''
  const firstBreak = rawIntro.indexOf('\n\n')
  const fieldsOnly = firstBreak !== -1 ? rawIntro.slice(firstBreak + 2).trim() : rawIntro
  const { cleanIntro, trailingQuestion } = extractTrailingQuestion(fieldsOnly)
  const introRows = parseIntroRows(cleanIntro)
  
  // File upload states
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [isPiiDetected, setIsPiiDetected] = useState(false);
const [isFileUploadModalOpen, setIsFileUploadModalOpen] = useState(false);

  const fieldMap = {}
  for (const f of fields) {
    if (f.label) fieldMap[f.label] = f
    if (f.englishLabel) fieldMap[f.englishLabel] = f
    const engKey = getFieldId(f)
    if (engKey && engKey !== f.label) fieldMap[engKey] = f
  }

  const contentResolution = resolveFieldsByContent(fields)
  const fieldById = {}
  const localLabelById = {}
  fields.forEach((f, i) => {
    const id = contentResolution.get(i)
    if (id) { fieldById[id] = f; localLabelById[id] = f.label }
  })

  const localLabelToFid = {}
  Object.entries(localLabelById).forEach(([id, lbl]) => {
    if (lbl) {
      localLabelToFid[lbl] = id; localLabelToFid[lbl.toLowerCase()] = id
      const stripped = lbl.replace(/[.…?!:]+$/, '').trim()
      if (stripped !== lbl) { localLabelToFid[stripped] = id; localLabelToFid[stripped.toLowerCase()] = id }
    }
  })

  const resolveIntroKey = (key) => {
    const id1 = labelLookup(key); if (id1) return id1
    const id2 = localLabelToFid[key] || localLabelToFid[key.toLowerCase()]; if (id2) return id2
    const hybrid = key.match(/^([^(]+)\s*\(/)
    if (hybrid) {
      const base = hybrid[1].trim()
      const id3 = labelLookup(base) || localLabelToFid[base] || localLabelToFid[base.toLowerCase()]
      if (id3) return id3
    }
    const stripped = key.replace(/[.…?!:]+$/, '').trim()
    if (stripped !== key) {
      const id4 = labelLookup(stripped) || localLabelToFid[stripped] || localLabelToFid[stripped.toLowerCase()]
      if (id4) return id4
    }
    return null
  }

  const INTRO_SEQUENCE = [
    FID.EVENT_TYPE, FID.LOCATION, FID.COMPANY, FID.SITE_LOCATION, FID.SUB_SITE_LOCATION,
    FID.DEPARTMENT, FID.SUB_DEPARTMENT, FID.RESPONSIBLE_DEPT,
    FID.DATE_TIME_EVENT, FID.WHAT_HAPPENED, FID.CAUSE, FID.ACTION_TAKEN, FID.ACTION_SUGGEST, FID.COMMENTS,
    FID.ON_BEHALF_OF, FID.SUPERVISOR, FID.DATE_TIME_REPORTED,
    FID.CONFIDENCE, FID.DEFAULT_GS_REVIEWER, FID.DEFAULT_INC_REVIEWER,
    FID.SITE_LIST_QUESTION, FID.SITE_LIST_SELECT, FID.SELECT_DIFF_REVIEWER, FID.SELECT_NEW_REVIEWER,
  ]

  const introRowsResolved = introRows.map(row => ({ ...row, id: resolveIntroKey(row.key) || null }))
  const introById = {}; const introKeyById = {}; let seqPtr = 0
  introRowsResolved.forEach(({ key, value, id }) => {
    if (id) {
      const pos = INTRO_SEQUENCE.indexOf(id, seqPtr)
      if (pos >= 0) seqPtr = pos + 1
      if (!introById[id]) { introById[id] = value; introKeyById[id] = key }
    } else {
      while (seqPtr < INTRO_SEQUENCE.length) {
        const candidate = INTRO_SEQUENCE[seqPtr++]
        if (!introById[candidate]) { introById[candidate] = value; introKeyById[candidate] = key; break }
      }
    }
  })

  const augmentedIntroRows = FIELD_ORDER.map(id => {
    const f       = fieldById[id]
    const value   = introById[id] ?? ''
    const inIntro = introKeyById[id] !== undefined
    if (!f && !inIntro) {
      if (id === FID.DESCRIBE_OTHER && (fieldById[FID.RESPONSIBLE_DEPT] || introById[FID.RESPONSIBLE_DEPT] !== undefined)) { 
        const langIdx = getLangIdx(CACHED_LANGUAGE) 
        return { id, value: '', localLabel: FIELD_GROUPS[id]?.[langIdx] || FIELD_GROUPS[id]?.[5] || "Describe Other" } 
      }

      if (id === FID.SPECIFIC_LOCATION && fieldById[FID.CONSTRUCTION_DETAILS]) {
        const langIdx = getLangIdx(CACHED_LANGUAGE)
        return { id, value: '', localLabel: FIELD_GROUPS[id]?.[langIdx] || FIELD_GROUPS[id]?.[5] || 'Specific Location' } 
      }
      return null
    }
    let seedValue = value
    if (!seedValue && f && (id === FID.DEFAULT_GS_REVIEWER || id === FID.DEFAULT_INC_REVIEWER)) {
      const opts = Array.isArray(f.options) ? f.options : []
      seedValue = opts.length > 0 && opts[0] !== '--no options available--' ? opts[0] : ''
    }
    const localLabel = f ? f.label : (introKeyById[id] || FIELD_GROUPS[id]?.[5] || id)
    return { id, value: seedValue, localLabel }
  }).filter(Boolean)

  const initAnswers = () => {
    const a = {}
    augmentedIntroRows.forEach(({ id, value }) => { a[id] = value || '' })
    if (!a[FID.SELECT_REVIEWER]) {
      const onBehalf = a[FID.ON_BEHALF_OF]
      const opts     = fieldById[FID.ON_BEHALF_OF]?.options
      a[FID.SELECT_REVIEWER] = introById[FID.SELECT_REVIEWER] || onBehalf || (typeof opts === 'string' ? opts : '') || ''
    }
    const sdrOpts = fieldById[FID.SELECT_DIFF_REVIEWER]?.options || []
    if (!a[FID.SELECT_DIFF_REVIEWER]) a[FID.SELECT_DIFF_REVIEWER] = sdrOpts[1] || 'No'
    const slOpts  = fieldById[FID.SITE_LIST_QUESTION]?.options || []
    if (!a[FID.SITE_LIST_QUESTION]) a[FID.SITE_LIST_QUESTION] = slOpts[0] || 'Yes'
    const reviewerDefault = fieldById[FID.DEFAULT_GS_REVIEWER]?.options?.[0] || fieldById[FID.DEFAULT_INC_REVIEWER]?.options?.[0] || ''
    if (!a[FID.DEFAULT_GS_REVIEWER])  a[FID.DEFAULT_GS_REVIEWER]  = reviewerDefault
    if (!a[FID.DEFAULT_INC_REVIEWER]) a[FID.DEFAULT_INC_REVIEWER] = reviewerDefault
    if (a[FID.EQUIPMENT]) {
      const raw = String(a[FID.EQUIPMENT]).trim()
      if (raw.startsWith('[')) {
        try {
          const parsed = JSON.parse(raw.replace(/'/g, '"'))
          if (Array.isArray(parsed)) a[FID.EQUIPMENT] = parsed.map(s => String(s).trim()).join(', ')
        } catch {
          const items = raw.replace(/[\[\]'"]/g, '').split(',').map(s => s.trim()).filter(Boolean)
          if (items.length) a[FID.EQUIPMENT] = items.join(', ')
        }
      }
    }
    return a
  }

  const [answers,   setAnswers]   = useState(initAnswers)
  const [submitted, setSubmitted] = useState(false)
  const [saved,     setSaved]     = useState(false)
  const isLocked = submitted || locked
  const [footerMode, setFooterMode] = useState('idle')
  const [changeMsg,  setChangeMsg]  = useState('')
  const answersRef        = useRef(initAnswers())
  const initialAnswersRef = useRef(initAnswers())

  const ENPS_ONLY_CLEAR      = [FID.CONSTRUCTION_PROJECT, FID.PHASE_CONSTRUCTION, FID.HRA, FID.SECONDARY_HRA, FID.EQUIPMENT, FID.CONSTRUCTION_DETAILS, FID.SPECIFIC_LOCATION]
  const REVIEWER_CLEAR       = [FID.SELECT_NEW_REVIEWER, FID.SITE_LIST_QUESTION, FID.SITE_LIST_SELECT]
  const GOOD_SAVE_ONLY_CLEAR = [FID.SITE_LIST_QUESTION, FID.SITE_LIST_SELECT, FID.SELECT_NEW_REVIEWER]
  const INCIDENT_ONLY_CLEAR  = [FID.SELECT_NEW_REVIEWER]

  // ── File Upload Handlers ──



  const handleSave = useCallback((id, val) => {
    setSaved(false); let extra = {}
    if (id === FID.SITE_LOCATION)  extra[FID.SUB_SITE_LOCATION] = ''
    if (id === FID.DEPARTMENT)     extra[FID.SUB_DEPARTMENT]    = ''
    if (id === FID.SITE_LOCATION) {
      const toEPS = isEPSSiteValue(val); const wasEPS = isEPSSiteValue(answersRef.current[FID.SITE_LOCATION])
      if (toEPS && !wasEPS) {
        REVIEWER_CLEAR.forEach(k => { extra[k] = '' })
        const onBehalf = answersRef.current[FID.ON_BEHALF_OF]
        const opts = fieldById[FID.ON_BEHALF_OF]?.options
        const fallback = onBehalf || (typeof opts === 'string' ? opts : '')
        if (fallback && (!answersRef.current[FID.SELECT_REVIEWER] || answersRef.current[FID.SELECT_REVIEWER] === answersRef.current[FID.ON_BEHALF_OF])) extra[FID.SELECT_REVIEWER] = fallback
      }
      if (!toEPS && wasEPS) ENPS_ONLY_CLEAR.forEach(k => { extra[k] = '' })
    }
    if (id === FID.EVENT_TYPE) {
      const evOpts = fieldById[FID.EVENT_TYPE]?.options
      const wasGoodSave = isGoodSaveValue(answersRef.current[FID.EVENT_TYPE] || '', evOpts)
      const wasIncident = isIncidentValue(answersRef.current[FID.EVENT_TYPE] || '', evOpts)
      if (isGoodSaveValue(val, evOpts) && wasIncident) INCIDENT_ONLY_CLEAR.forEach(k => { extra[k] = '' })
      if (isIncidentValue(val, evOpts) && wasGoodSave) GOOD_SAVE_ONLY_CLEAR.forEach(k => { extra[k] = '' })
      ;[FID.DEFAULT_GS_REVIEWER, FID.DEFAULT_INC_REVIEWER].forEach(rid => {
        if (!answersRef.current[rid]) {
          const opts = fieldById[rid]?.options
          const first = Array.isArray(opts) && opts.length > 0 && opts[0] !== '--no options available--' ? opts[0] : ''
          if (first) { extra[rid] = first; initialAnswersRef.current = { ...initialAnswersRef.current, [rid]: first } }
        }
      })
    }
    answersRef.current = { ...answersRef.current, [id]: val, ...extra }
    setAnswers(prev => ({ ...prev, [id]: val, ...extra }))
  }, [fieldById])

  const handleOnBehalfSelect = useCallback((employeeName, supervisorName) => {
    setSaved(false)
    const updates = { [FID.ON_BEHALF_OF]: employeeName, [FID.SUPERVISOR]: supervisorName }
    const isEPS = isEPSSiteValue(answersRef.current[FID.SITE_LOCATION])
    if (isEPS && (!answersRef.current[FID.SELECT_REVIEWER] || answersRef.current[FID.SELECT_REVIEWER] === answersRef.current[FID.ON_BEHALF_OF])) updates[FID.SELECT_REVIEWER] = employeeName
    answersRef.current = { ...answersRef.current, ...updates }
    setAnswers(prev => ({ ...prev, ...updates }))
  }, [])

  const handleSaveWithReviewerClear = useCallback((id, val) => {
    setSaved(false); answersRef.current = { ...answersRef.current, [id]: val }
    if (id === FID.SELECT_DIFF_REVIEWER && !isYesValue(val, fieldById[FID.SELECT_DIFF_REVIEWER]?.options)) {
      answersRef.current[FID.SELECT_NEW_REVIEWER] = ''
      setAnswers(prev => ({ ...prev, [id]: val, [FID.SELECT_NEW_REVIEWER]: '' }))
    } else { setAnswers(prev => ({ ...prev, [id]: val })) }
  }, [fieldById])

  const handleSaveWithSiteListClear = useCallback((id, val) => {
    setSaved(false); answersRef.current = { ...answersRef.current, [id]: val }
    if (id === FID.SITE_LIST_QUESTION && !isNoValue(val, fieldById[FID.SITE_LIST_QUESTION]?.options)) {
      answersRef.current[FID.SITE_LIST_SELECT] = ''
      setAnswers(prev => ({ ...prev, [id]: val, [FID.SITE_LIST_SELECT]: '' }))
    } else { setAnswers(prev => ({ ...prev, [id]: val })) }
  }, [fieldById])

  const siteLocation  = answers[FID.SITE_LOCATION] || ''
  const eventTypeOpts = fieldById[FID.EVENT_TYPE]?.options
  const isGoodSave    = isGoodSaveValue(answers[FID.EVENT_TYPE] || '', eventTypeOpts)
  const isIncident    = isIncidentValue(answers[FID.EVENT_TYPE] || '', eventTypeOpts)
  const isEPSSite     = isEPSSiteValue(siteLocation)
  const siteListSelectHasRealOpts = (fieldById[FID.SITE_LIST_SELECT]?.options || []) .some(o => o !== '--no options available--') 
  const isSupervisorReviewer = !siteListSelectHasRealOpts && ( isSupervisValue(answers[FID.DEFAULT_GS_REVIEWER] || '') || isSupervisValue(answers[FID.DEFAULT_INC_REVIEWER] || '') || isSupervisValue(fieldById[FID.DEFAULT_INC_REVIEWER]?.options?.[0] || '') || isSupervisValue(fieldById[FID.DEFAULT_GS_REVIEWER]?.options?.[0] || '') )
  const responsibleDept      = answers[FID.RESPONSIBLE_DEPT] || ''
  const showDescribeOther    = isDescribeOtherValue(responsibleDept, fieldById[FID.RESPONSIBLE_DEPT]?.options)
  const constructionOpts     = fieldById[FID.CONSTRUCTION_DETAILS]?.options || []
  const isOtherConstruction  = constructionOpts.length > 0 && answers[FID.CONSTRUCTION_DETAILS] === constructionOpts[constructionOpts.length - 1]

  const ENPS_ONLY   = new Set([FID.CONSTRUCTION_PROJECT, FID.EQUIPMENT, FID.PHASE_CONSTRUCTION, FID.HRA, FID.CONSTRUCTION_DETAILS, FID.SPECIFIC_LOCATION, FID.SELECT_REVIEWER])
  const ENPS_HIDDEN = new Set([FID.DEFAULT_GS_REVIEWER, FID.DEFAULT_INC_REVIEWER, FID.SELECT_DIFF_REVIEWER, FID.SITE_LIST_QUESTION])

  const shouldShowRow = (id) => {
    if (id === FID.SECONDARY_HRA) return isEPSSite
    if (isEPSSite) {
      if (ENPS_HIDDEN.has(id)) return false
      if (id === FID.DESCRIBE_OTHER)      return showDescribeOther
      if (id === FID.SPECIFIC_LOCATION)   return isOtherConstruction
      if (id === FID.SELECT_NEW_REVIEWER) return false
      if (id === FID.SITE_LIST_SELECT)    return false
      return true
    }
    if (ENPS_ONLY.has(id)) return false
    if (id === FID.DESCRIBE_OTHER) return showDescribeOther
    if (id === FID.SELECT_NEW_REVIEWER) return isSupervisorReviewer && isYesValue(answers[FID.SELECT_DIFF_REVIEWER] || '', fieldById[FID.SELECT_DIFF_REVIEWER]?.options)
    if (id === FID.SITE_LIST_SELECT) return !isSupervisorReviewer && isGoodSave && isNoValue(answers[FID.SITE_LIST_QUESTION] || '', fieldById[FID.SITE_LIST_QUESTION]?.options)
    if (id === FID.SELECT_DIFF_REVIEWER) return isSupervisorReviewer
    if (isSupervisorReviewer) {
      if (id === FID.DEFAULT_GS_REVIEWER)  return isGoodSave
      if (id === FID.DEFAULT_INC_REVIEWER) return isIncident
      if (id === FID.SITE_LIST_QUESTION)   return false
    } else {
      if (isIncident) { if (id === FID.DEFAULT_GS_REVIEWER || id === FID.SITE_LIST_QUESTION) return false }
      if (isGoodSave) { if (id === FID.DEFAULT_INC_REVIEWER) return false }
      if (id === FID.SELECT_DIFF_REVIEWER) return false
    }
    return true
  }

  const handleSubmit = () => { if (submitted) return; setSubmitted(true); onSubmit({ message: '', fields: { ...answersRef.current } }) }
  const shouldShowRowRef = useRef(shouldShowRow); shouldShowRowRef.current = shouldShowRow

  const handleSaveReport = (action = 'save') => {
    const current = answersRef.current
    const initial = initialAnswersRef.current
    const evOpts = fieldById[FID.EVENT_TYPE]?.options
 
    const currIsGoodSave = isGoodSaveValue(current[FID.EVENT_TYPE] || '', evOpts)
    const currIsIncident = isIncidentValue(current[FID.EVENT_TYPE] || '', evOpts)
    const currIsEPS      = isEPSSiteValue(current[FID.SITE_LOCATION])
    const initIsGoodSave = isGoodSaveValue(initial[FID.EVENT_TYPE] || '', evOpts)
    const initIsIncident = isIncidentValue(initial[FID.EVENT_TYPE] || '', evOpts)
    const initIsEPS      = isEPSSiteValue(initial[FID.SITE_LOCATION])
 
    const isNewlyVisible = (id) => {
      if (!shouldShowRowRef.current(id)) return false
      const nowVal = String(current[id] ?? '').trim()
      if (!nowVal) return false
      if (currIsGoodSave && !initIsGoodSave) {
        if ([FID.SITE_LIST_QUESTION, FID.DEFAULT_GS_REVIEWER,
             FID.SELECT_DIFF_REVIEWER, FID.SITE_LIST_SELECT].includes(id)) return true
      }
      if (currIsIncident && !initIsIncident) {
        if ([FID.DEFAULT_INC_REVIEWER, FID.SELECT_DIFF_REVIEWER].includes(id)) return true
      }
      if (currIsEPS && !initIsEPS) {
        if ([FID.CONSTRUCTION_PROJECT, FID.PHASE_CONSTRUCTION, FID.HRA,
             FID.SECONDARY_HRA, FID.EQUIPMENT, FID.CONSTRUCTION_DETAILS,
             FID.SELECT_REVIEWER].includes(id)) return true
      }
      if (!currIsEPS && initIsEPS) {
        if ([FID.DEFAULT_GS_REVIEWER, FID.DEFAULT_INC_REVIEWER,
             FID.SITE_LIST_QUESTION, FID.SELECT_DIFF_REVIEWER].includes(id)) return true
      }
      return false
    }
 
    let changedEntries = Object.entries(current).filter(([id, val]) => {
      if (!shouldShowRowRef.current(id)) return false
      if (isNewlyVisible(id)) return true

      const orig = initial[id] ?? ''
      return String(val ?? '').trim() !== String(orig ?? '').trim()
    })

    const backendOnlyEntries = []
    const isEPS = isEPSSiteValue(current[FID.SITE_LOCATION])

    if (isEPS && fieldById[FID.SECONDARY_HRA]) {
      const currentVal = (current[FID.SECONDARY_HRA] || '').trim()
      const initialVal = (initial[FID.SECONDARY_HRA] || '').trim()

      const secondaryHraChanged = changedEntries.some(
        ([id]) => id === FID.SECONDARY_HRA
      )

      changedEntries = changedEntries.filter(
        ([id]) => id !== FID.SECONDARY_HRA
      )

      if (!currentVal) {
        if (action === 'save') {
          backendOnlyEntries.push([FID.SECONDARY_HRA, 'skip'])
        }

        if (initialVal && secondaryHraChanged) {
          changedEntries.push([FID.SECONDARY_HRA, '(Cleared)'])
        }
      } else if (secondaryHraChanged) {
        changedEntries.push([FID.SECONDARY_HRA, currentVal])
      }
    }

    const langIdx = getLangIdx(selectedLanguage)

    const buildMessage = (entries, useLocal) =>
      entries.length > 0
        ? entries.map(([id, val]) => {
            const label =
              localLabelById[id]
              || FIELD_GROUPS[id]?.[langIdx]
              || FIELD_GROUPS[id]?.[5]
              || id

            const display =
              (useLocal &&
                (id === FID.DATE_TIME_EVENT ||
                 id === FID.DATE_TIME_REPORTED))
                ? (formatUtcToLocal(val) || val || '(cleared)')
                : (val || '(cleared)')

            return `change ${label} to ${display}`
          }).join(', ')
        : 'submit'

    const backendEntries = [
      ...changedEntries.filter(
        ([id, value]) =>
          !(id === FID.SECONDARY_HRA && value === '(Cleared)')
      ),
      ...backendOnlyEntries
    ]

    if (onSave) {
      onSave({
        message: buildMessage(backendEntries, false),
        displayMessage: buildMessage(changedEntries, true),
        fields: {},
      })
    }

    setSaved(true)
  }

  const hasChanges = Object.entries(answers).some(([id, val]) => {
    if (!shouldShowRow(id)) return false
    const orig = initialAnswersRef.current[id] ?? ''
    return String(val ?? '').trim() !== String(orig ?? '').trim()
  })

  const REQUIRED_IDS = new Set([...REQUIRED_IDS_BASE, ...(isEPSSite ? REQUIRED_IDS_ENPS : [])])
  const allRequiredFilled = augmentedIntroRows.filter(({ id }) => shouldShowRow(id)).every(({ id }) => {
    const isRequired = REQUIRED_IDS.has(id) || (id === FID.DESCRIBE_OTHER && showDescribeOther)
    if (!isRequired) return true
    const val = answers[id]
    return val && String(val).trim() !== ''
  })

  const parseDateAnswer = (id) => { 
    const raw = answers[id] || ''; if (!raw) return null 
    const d = parseBackendUtc(raw) 
    if (d && !isNaN(d.getTime())) return d 
    const iso = raw.trim().replace(' ', 'T') 
    const d2 = new Date(/[Zz]$|[+-]\d{2}:\d{2}$/.test(iso) ? iso : iso + 'Z') 
    return isNaN(d2.getTime()) ? null : d2 
  } 
    
  const toMinute = (d) => d ? new Date(Math.floor(d.getTime() / 60000) * 60000) : null 
  const eventDate = toMinute(parseDateAnswer(FID.DATE_TIME_EVENT)) 
  const reportedDate = toMinute(parseDateAnswer(FID.DATE_TIME_REPORTED))
  const dateTimeValid = !(eventDate && reportedDate && eventDate > reportedDate)
  const handleIndividualFileUpload = useCallback((fileData) => {
  console.log('Individual file uploaded:', fileData);
  setUploadedFiles(prev => [...prev, fileData]);
  
  if (onFileUpload) {
    onFileUpload(fileData);
  }
}, [onFileUpload]);

const handleAllFilesUploadComplete = useCallback((files) => {
  console.log('All files uploaded:', files);
  setUploadedFiles(files);
  
  if (onFileUpload) {
    onFileUpload(files);
  }
}, [onFileUpload]);
console.log(session,"Session>>>>>>>>>>>>>>>>>>>>>>>");

  return (
    <div className="flex items-start gap-2 w-full">
      <style>{`
        .ehss-form-row { display: grid; grid-template-columns: 20% 1fr; align-items: start; border-bottom: 1px solid #F9FAFB; }
        .ehss-form-label { padding: 8px 12px 4px; text-align: right; word-break: break-word; overflow-wrap: break-word; }
        .ehss-form-field { padding: 4px 8px 8px; min-width: 0; }
        @media (max-width: 640px) { .ehss-form-row { grid-template-columns: 1fr; } .ehss-form-label { text-align: left; padding-bottom: 2px; } }
      `}</style>
      <BotAvatar />
      <div className="flex-1 min-w-0">
        <div className="w-full rounded-xl border border-gray-200 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-red-500 rounded-t-xl">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 shrink-0 rounded-lg flex items-center justify-center bg-white/20">
                <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>
                  <rect x="8" y="2" width="8" height="4" rx="1"/>
                </svg>
              </div>
              <div>
                <p className="text-white/70 text-xs font-medium leading-none mb-0.5">Incident Management System</p>
                <h2 className="text-white text-sm font-semibold leading-tight">Review &amp; Confirm Report</h2>
              </div>
            </div>
            <div className="flex flex-wrap gap-3 items-center">
              {[
                { icon: <span className="text-red-200 font-bold text-xs">*</span>, label: 'Required' },
                { icon: <IconSparkles className="w-2.5 h-2.5 text-white/70" />, label: 'AI-enhanceable' },
                { icon: <IconLock className="w-2.5 h-2.5 text-white/70" />, label: 'Read-only' },
              ].map((item, i) => (
                <span key={i} className="flex items-center gap-1 text-white/70 text-xs">{item.icon} {item.label}</span>
              ))}
            </div>
          </div>



{/* Add Modal */}
<FileUploadModal
  isOpen={isFileUploadModalOpen}
  onClose={() => setIsFileUploadModalOpen(false)}
  session={session}
  onFileUpload={handleIndividualFileUpload}
  onComplete={handleAllFilesUploadComplete}
  isLocked={false}
/>

          <div>
            {augmentedIntroRows.map(({ id, localLabel }) => {
              if (!shouldShowRow(id)) return null
              const fieldDef   = fieldById[id]
              const label = id === FID.LOCATION  ? getJnjSiteLabel(selectedLanguage)
                          : id === FID.COMPANY   ? getJnjCompanyLabel(selectedLanguage)
                          : id === FID.WHAT_HAPPENED  ? getWhatHappenedLabel(selectedLanguage)
                          : id === FID.DESCRIBE_OTHER ? getDescribeOtherLabel(selectedLanguage)
                          : id === FID.SPECIFIC_LOCATION? (FIELD_GROUPS[FID.SPECIFIC_LOCATION]?.[getLangIdx(selectedLanguage)] || 'Specific Location')
                          : (localLabel || id)
              const isRequired = REQUIRED_IDS.has(id) || (id === FID.DESCRIBE_OTHER && showDescribeOther)
              const isOnBehalf = id === FID.ON_BEHALF_OF || id === FID.SELECT_REVIEWER || id === FID.SELECT_NEW_REVIEWER
              const isDiffReviewer  = id === FID.SELECT_DIFF_REVIEWER
              const isSiteListField = id === FID.SITE_LIST_QUESTION

              const isKnownChild = id === FID.SUB_SITE_LOCATION || id === FID.SUB_DEPARTMENT
              const parentId     = id === FID.SUB_SITE_LOCATION ? FID.SITE_LOCATION : id === FID.SUB_DEPARTMENT ? FID.DEPARTMENT : null
              const fieldType    = fieldDef ? resolveFieldType(fieldDef) : (isKnownChild ? 'dependent' : null)
              const isDependent  = isKnownChild || (fieldDef && !Array.isArray(fieldDef.options) && fieldDef.options !== null && typeof fieldDef.options === 'object')
              const parentValue  = parentId ? (answers[parentId] || '') : ''
              const options      = (isDependent && fieldDef && !Array.isArray(fieldDef.options) && typeof fieldDef.options === 'object')
                ? ((fieldDef.options || {})[parentValue] || [])
                : (fieldDef && Array.isArray(fieldDef.options) ? fieldDef.options : [])
              const knownParentVal   = isKnownChild ? (answers[parentId] || '') : ''
              const hasNoRealOptions = options.length === 0 || (options.length === 1 && options[0] === '--no options available--')
              const noSubOptions     = isKnownChild && (!knownParentVal || hasNoRealOptions)
              const dependentPlaceholder = isDependent && !knownParentVal && !parentValue
                ? '— Select parent field first —' : isDependent && hasNoRealOptions ? '--no options available--' : '— Select —'

              const showConfidenceNote = id === FID.CONFIDENCE && isYesValue(answers[FID.CONFIDENCE] || '', fieldById[FID.CONFIDENCE]?.options)
              const isDepartmentField = id === FID.DEPARTMENT

              const isLocation = id === FID.LOCATION;
              const isCommentsField    = id === FID.COMMENTS
              const showFutureDateWarning = id === FID.DATE_TIME_EVENT && (() => {
                const orig = introById[FID.DATE_TIME_EVENT] || ''; if (!orig) return false
                const d = parseBackendUtc(orig)
                return d && !isNaN(d.getTime()) && d > new Date()
              })()

              const whatHappenedPiiNote = id === FID.WHAT_HAPPENED
                && piiCheck?.result?.pii_detected
                && piiCheck.text
                && (introById[FID.WHAT_HAPPENED] || '').trim() !== piiCheck.text.trim()
                ? piiCheck.result
                : null

              const FIELD_INFO_KEYS = {
                [FID.EVENT_TYPE]: 'Event Type',
                [FID.LOCATION]: 'At what site did this occur or what J&J site is responsible?',
                [FID.SITE_LOCATION]: 'Site Location',
                [FID.SUB_SITE_LOCATION]: 'Sub Site Location',
                [FID.DEPARTMENT]: 'Department',
                [FID.SUB_DEPARTMENT]: 'Sub Department',
                [FID.RESPONSIBLE_DEPT]: 'Responsible Department',
                [FID.CONSTRUCTION_PROJECT]: 'Related Construction Project',
                [FID.SPECIFIC_LOCATION]: 'Specific Location',
                [FID.WHAT_HAPPENED]: 'What happened?',
                [FID.CAUSE]: 'What do you think caused this Incident?',
                [FID.ACTION_TAKEN]: 'What action(s) did you take?',
                [FID.SUPERVISOR]: 'Reported On Behalf Of - Supervisor',
                [FID.DATE_TIME_REPORTED]: 'Date and Time Reported',
                [FID.CONFIDENCE]: 'Report in Confidence?',
              };

              const infoKey = FIELD_INFO_KEYS[id];

              const infoText =
                fieldInfoTranslations?.[selectedLanguage]?.[infoKey] ||
                fieldInfoTranslations?.English?.[infoKey] ||
                '';

              const confidenceText =
                fieldInfoTranslations?.[selectedLanguage]?.[
                  'For all people reviewing this event: Please note, the reporter is requesting this to be managed in confidence. For the reporter: You selected to "Report in Confidence". When you "Report in Confidence" this means you want to remain anonymous for the Good Save/Incident that you submitted. When you make this selection, you may not get credit for the Good Save. When you want to keep the report in Confidence = Yes, please make sure your supervisor is not defined as the reviewer.'
                ] ||
                fieldInfoTranslations?.English?.[
                  'For all people reviewing this event: Please note, the reporter is requesting this to be managed in confidence. For the reporter: You selected to "Report in Confidence". When you "Report in Confidence" this means you want to remain anonymous for the Good Save/Incident that you submitted. When you make this selection, you may not get credit for the Good Save. When you want to keep the report in Confidence = Yes, please make sure your supervisor is not defined as the reviewer.'
                ] ||
                '';

              const commentsText =
                fieldInfoTranslations?.[selectedLanguage]?.[
                  "Comments: Do not publish or think carefully before publishing or disclosing personal information, such as full names (use only first names) or any other private information in the free text fields 'What happened?', 'What do you think caused this Incident?', 'What action(s) did you take?', 'What action(s) do you suggest?', 'Comments'."
                ] ||
                fieldInfoTranslations?.English?.[
                  "Comments: Do not publish or think carefully before publishing or disclosing personal information, such as full names (use only first names) or any other private information in the free text fields 'What happened?', 'What do you think caused this Incident?', 'What action(s) did you take?', 'What action(s) do you suggest?', 'Comments'."
                ] ||
                '';

              const departmentNoteText =
                fieldInfoTranslations?.[selectedLanguage]?.[
                  'Department where the incident/good save occurred.'
                ] ||
                fieldInfoTranslations?.English?.[
                  'Department where the incident/good save occurred.'
                ] ||
                '';

              const jnjSiteNoteText =
                fieldInfoTranslations?.[selectedLanguage]?.[
                  'If you need to change the J&J site, please type it into the chat. The J&J site can only be changed by asking the question, as it may recalculate other fields afterwards.'
                ] ||
                fieldInfoTranslations?.English?.[
                  'If you need to change the J&J site, please type it into the chat. The J&J site can only be changed by asking the question, as it may recalculate other fields afterwards.'
                ] ||
                '';

              return (
                <React.Fragment key={id}>
                  {isDepartmentField && (
                    <div className="ehss-form-row" style={{ borderBottom: 'none' }}>
                      <div className="ehss-form-label" />
                      <div className="ehss-form-field" style={{ paddingBottom: 2 }}>
                        <span className="text-xs italic text-gray-500" style={{ whiteSpace: 'normal', wordBreak: 'break-word' }}>
                          {localLabelById[FID.DEPARTMENT] ? `${localLabelById[FID.DEPARTMENT]} — ` : ''}
                          {departmentNoteText}
                        </span>
                      </div>
                    </div>
                  )}

                  {isLocation && (
                    <div className="ehss-form-row" style={{ borderBottom: 'none' }}>
                      <div className="ehss-form-label" />
                      <div className="ehss-form-field" style={{ paddingBottom: 2 }}>
                        <span className="text-xs italic text-gray-500" style={{ whiteSpace: 'normal', wordBreak: 'break-word' }}>
                          {label ? `${label} — ` : ''}
                          {jnjSiteNoteText}.
                        </span>
                      </div>
                    </div>
                  )}
                  
                  <div className="ehss-form-row">
                    <div className="ehss-form-label">
                      <span className="text-xs font-semibold text-gray-600 leading-snug">
                        {label}
                        {isRequired && <span className="text-red-500 ml-0.5 font-bold">*</span>}
                        {infoText && <InfoTooltip text={infoText} />}
                      </span>
                    </div>
                    <div className="ehss-form-field">
                      {isOnBehalf ? (
                        <OnBehalfOfDropdown 
                          value={answers[id]}
                          onSelect={id === FID.SELECT_REVIEWER || id === FID.SELECT_NEW_REVIEWER
                            ? (name) => { setSaved(false); handleSave(id, name) } 
                            : handleOnBehalfSelect}
                          disabled={isLocked} 
                          dropUp={id === FID.SELECT_NEW_REVIEWER} 
                        />
                      ) : (
                        <RowCell 
                          selectedLanguage={selectedLanguage} 
                          rowKey={id} 
                          value={answers[id]} 
                          options={options}
                          onSave={isDiffReviewer ? handleSaveWithReviewerClear : isSiteListField ? handleSaveWithSiteListClear : handleSave}
                          disabled={isLocked || (isDependent && (!parentValue || hasNoRealOptions)) || noSubOptions}
                          fieldType={fieldType}
                          placeholder={isDependent ? dependentPlaceholder : (isKnownChild ? dependentPlaceholder : undefined)} 
                          setIsPiiDetected={setIsPiiDetected}
                        />
                      )}
                    </div>
                  </div>

                  {whatHappenedPiiNote && (
                    <div className="ehss-form-row" style={{ borderBottom: 'none' }}>
                      <div className="ehss-form-label" />
                      <div className="ehss-form-field" style={{ paddingTop: 2, paddingBottom: 6 }}>
                        <p className="text-xs font-semibold text-red-600 mb-0.5">{whatHappenedPiiNote.pii_warning_en}</p>
                        <p className="text-xs text-red-500 leading-relaxed">
                          Removed: {whatHappenedPiiNote.pii_items?.map(item => item.text).join(', ') || '—'}
                        </p>
                      </div>
                    </div>
                  )}

                  {showFutureDateWarning && (
                    <div className="ehss-form-row" style={{ borderBottom: 'none' }}>
                      <div className="ehss-form-label" />
                      <div className="ehss-form-field" style={{ paddingTop: 2, paddingBottom: 4 }}>
                        <div className="flex items-center gap-1.5">
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#DC2626" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                            <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
                          </svg>
                          <span className="text-xs text-red-600 font-medium">Future dates are not allowed. Date has been updated to current date and time.</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {!dateTimeValid && (id === FID.DATE_TIME_EVENT || id === FID.DATE_TIME_REPORTED) && (
                    <div className="ehss-form-row" style={{ borderBottom: 'none' }}>
                      <div className="ehss-form-label" />
                      <div className="ehss-form-field" style={{ paddingTop: 2, paddingBottom: 4 }}>
                        <div className="flex items-center gap-1.5">
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#DC2626" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                            <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
                          </svg>
                          <span className="text-xs text-red-600 font-medium">
                            {id === FID.DATE_TIME_EVENT ? 'Event date cannot be later than the reported date.' : 'Reported date cannot be earlier than the event date.'}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                  {showConfidenceNote && (
                    <div className="px-4 py-3 border-b border-gray-50">
                      <p className="text-xs text-gray-800 leading-relaxed">{confidenceText}</p>
                    </div>
                  )}

                  {isCommentsField && (
                    <div className="px-4 py-2 border-b border-gray-50">
                      <div className="rounded-lg px-3 py-2.5 flex items-start gap-2" style={{ background: '#EFF6FF', border: '1px solid #BFDBFE' }}>
                        <svg className="shrink-0 mt-0.5" width="14" height="14" viewBox="0 0 24 24" fill="#1D4ED8">
                          <circle cx="12" cy="12" r="10"/>
                          <path d="M12 8v1M12 11v5" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                        </svg>
                        <p className="text-xs text-black-900 leading-relaxed">{commentsText}</p>
                      </div>
                    </div>
                  )}
                </React.Fragment>
              )
            })}
          </div>

        <div className="px-4 py-3 bg-white rounded-b-xl">
  {hasChanges ? (
    <div className="flex flex-col gap-3 items-start">
      <span className="text-[10px] text-gray-400 italic">
        {isLocked ? 'Form submitted — no further changes allowed'
          : saved ? 'Saved — changes sent'
          : !dateTimeValid ? 'Event date cannot be later than reported date'
          : !allRequiredFilled ? 'Fill all required fields (*) to continue'
          : 'Save your changes to proceed'}
      </span>
      
      <div className='flex gap-2 flex-wrap'>
        <button 
          onClick={() => handleSaveReport('save')}
          className="flex items-center gap-1.5 px-5 py-1.5 text-xs font-bold rounded-full border-none cursor-pointer transition-all disabled:opacity-40 disabled:cursor-not-allowed"
          style={{ 
            background: saved ? '#059669' : '#B91C1C', 
            boxShadow: saved ? '0 2px 8px rgba(5,150,105,0.3)' : '0 2px 8px rgba(185,28,28,0.3)', 
            color: '#fff' 
          }}
          disabled={isLocked || saved || !allRequiredFilled || !dateTimeValid || isPiiDetected}
          title={!allRequiredFilled ? 'Please fill all required fields before saving' : !dateTimeValid ? 'Fix date/time error before saving' : ''}
          onMouseEnter={e => { if (!submitted && allRequiredFilled && dateTimeValid) e.currentTarget.style.background = saved ? '#047857' : '#991b1b' }}
          onMouseLeave={e => { e.currentTarget.style.background = saved ? '#059669' : '#B91C1C' }}
        >
          {saved ? <><CheckCircle2 size={13} /> Saved</> : <><IconCheck className="w-3 h-3" /> Save</>}
        </button>

        <button
          onClick={() => setIsFileUploadModalOpen(true)}
          disabled={isLocked || !allRequiredFilled || !dateTimeValid || isPiiDetected}
          title={
            !allRequiredFilled
              ? 'Please fill all required fields before uploading files'
              : !dateTimeValid
              ? 'Fix date/time error before uploading'
              : ''
          }
          className="flex items-center gap-1.5 px-5 py-1.5 text-xs font-bold rounded-full border-none cursor-pointer transition-all disabled:opacity-40 disabled:cursor-not-allowed"
          style={{ 
            background: '#B91C1C', 
            boxShadow: '0 2px 8px rgba(185,28,28,0.3)', 
            color: '#fff' 
          }}
          onMouseEnter={e => { if (!submitted && allRequiredFilled && dateTimeValid) e.currentTarget.style.background = '#991b1b' }}
          onMouseLeave={e => { e.currentTarget.style.background = '#B91C1C' }}
        >
          <svg className="w-3 h-3" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="17 8 12 3 7 8" />
            <line x1="12" y1="3" x2="12" y2="15" />
          </svg>
          Attach Documents
        </button>
      </div>
    </div>
  ) : (
    <div className="flex flex-col gap-3 items-start">
      <span className="text-[10px] text-gray-400 italic">
        {isLocked ? 'Form submitted — no further changes allowed'
          : !dateTimeValid ? 'Event date cannot be later than reported date'
          : !allRequiredFilled ? 'Fill all required fields (*) to continue'
          : 'Would you like to make any changes or submit this report?'}
      </span>
      
      <div className='flex gap-2 flex-wrap'>
        <button
          onClick={() => handleSaveReport('submit')}
          disabled={isLocked || !allRequiredFilled || !dateTimeValid || isPiiDetected}
          title={
            !allRequiredFilled
              ? 'Please fill all required fields before submitting'
              : !dateTimeValid
              ? 'Fix date/time error before submitting'
              : ''
          }
          className="flex items-center gap-1.5 px-5 py-1.5 text-xs font-bold rounded-full border-none cursor-pointer transition-all disabled:opacity-40 disabled:cursor-not-allowed"
          style={{ 
            background: '#B91C1C', 
            boxShadow: '0 2px 8px rgba(185,28,28,0.3)', 
            color: '#fff' 
          }}
          onMouseEnter={e => { if (!submitted && allRequiredFilled && dateTimeValid) e.currentTarget.style.background = '#991b1b' }}
          onMouseLeave={e => { e.currentTarget.style.background = '#B91C1C' }}
        >
          <IconSend className="w-3 h-3" /> Submit
        </button>

        <button
          onClick={() => setIsFileUploadModalOpen(true)}
          disabled={isLocked || !allRequiredFilled || !dateTimeValid || isPiiDetected}
          title={
            !allRequiredFilled
              ? 'Please fill all required fields before uploading files'
              : !dateTimeValid
              ? 'Fix date/time error before uploading'
              : ''
          }
          className="flex items-center gap-1.5 px-5 py-1.5 text-xs font-bold rounded-full border-none cursor-pointer transition-all disabled:opacity-40 disabled:cursor-not-allowed"
          style={{ 
            background: '#B91C1C', 
            boxShadow: '0 2px 8px rgba(185,28,28,0.3)', 
            color: '#fff' 
          }}
          onMouseEnter={e => { if (!submitted && allRequiredFilled && dateTimeValid) e.currentTarget.style.background = '#991b1b' }}
          onMouseLeave={e => { e.currentTarget.style.background = '#B91C1C' }}
        >
          <svg className="w-3 h-3" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="17 8 12 3 7 8" />
            <line x1="12" y1="3" x2="12" y2="15" />
          </svg>
          Attach Documents
        </button>
      </div>
    </div>
  )}
</div>

        </div>
      </div>
    </div>
  )
}


function resolveFieldType(field) {
  const DEPENDENT = { 'Sub Site Location': 'Site Location', 'Sub Department': 'Department' }
  const { input_type, options, englishLabel } = field
  if (DEPENDENT[englishLabel]) return 'dependent'
  if (input_type === 'text')     return 'text'
  if (input_type === 'checkbox') return 'checkbox'
  const opts = Array.isArray(options) ? options : []
  if (input_type === 'dropdown' || opts.length > 6) return 'dropdown'
  return 'buttons'
}

function CustomDropdown({ options = [], value = '', onChange, disabled = false, placeholder = '— Select —', emptyMsg = 'No options available', dropUp = false }) {
  const [open,    setOpen]    = useState(false)
  const [search,  setSearch]  = useState('')
  const [focused, setFocused] = useState(false)
  const containerRef = useRef(null)
  const searchRef    = useRef(null)

  useEffect(() => {
    const handler = e => { if (containerRef.current && !containerRef.current.contains(e.target)) { setOpen(false); setSearch('') } }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])
  useEffect(() => { if (open && searchRef.current) searchRef.current.focus() }, [open])

  const filtered     = search.trim() ? options.filter(o => o.toLowerCase().includes(search.toLowerCase())) : options
  const handleSelect = (opt) => { onChange(opt); setOpen(false); setSearch('') }
  const handleClear  = (e) => { e.stopPropagation(); onChange('') }

  return (
    <div ref={containerRef} className="relative w-full">
      <button type="button" disabled={disabled}
        onClick={() => { if (!disabled) { setOpen(v => !v); setSearch('') } }}
        onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
        className="w-full flex items-center gap-2 text-left outline-none transition-all duration-150 rounded-lg disabled:cursor-not-allowed"
        style={{ padding: '6px 10px', background: disabled ? '#F3F4F6' : open || focused ? '#ffffff' : '#F7F8FA',
          border: disabled ? '1.5px solid #E5E7EB' : open || focused ? '2px solid #B91C1C' : '1.5px dashed #D1D5DB',
          boxShadow: open || focused ? '0 0 0 3px rgba(185,28,28,0.1)' : 'none', opacity: disabled ? 0.6 : 1 }}>
        <span className={`flex-1 text-xs truncate ${value ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>{value || placeholder}</span>
        {value && !disabled && (
          <span onMouseDown={handleClear} className="shrink-0 w-4 h-4 rounded-full bg-gray-100 hover:bg-red-100 flex items-center justify-center transition-colors cursor-pointer">
            <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth="3" strokeLinecap="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </span>
        )}
        <span className="shrink-0 w-5 h-5 rounded-md flex items-center justify-center transition-colors" style={{ background: open ? 'rgba(185,28,28,0.08)' : '#F3F4F6' }}>
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke={open ? '#B91C1C' : '#6B7280'} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
            style={{ transform: open ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.15s' }}>
            <path d="M6 9l6 6 6-6"/>
          </svg>
        </span>
      </button>
      {open && (
        <div className="absolute z-50 left-0 right-0 bg-white rounded-2xl overflow-hidden"
          style={{ ...(dropUp ? { bottom: 'calc(100% + 6px)' } : { top: 'calc(100% + 6px)' }),
            boxShadow: '0 8px 32px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.06)', border: '1px solid #F1F1F1' }}>
          {options.length > 5 && (
            <div className="px-2.5 pt-2.5 pb-1.5">
              <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-2.5 py-1.5 border border-gray-100">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                  <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
                </svg>
                <input ref={searchRef} type="text" value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Search…" className="flex-1 text-xs text-gray-800 bg-transparent outline-none placeholder-gray-400" />
                {search && (
                  <button onMouseDown={() => setSearch('')} className="bg-transparent border-none cursor-pointer p-0">
                    <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="3" strokeLinecap="round">
                      <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                  </button>
                )}
              </div>
            </div>
          )}
          <ul className="overflow-y-auto py-1" style={{ maxHeight: 220 }}>
            {filtered.length === 0 ? (
              <li className="px-3 py-3 text-xs text-gray-400 text-center">{search ? `No results for "${search}"` : emptyMsg}</li>
            ) : filtered.map((opt, i) => {
              const isSelected = opt === value
              return (
                <li key={i}>
                  <button type="button" onMouseDown={e => { e.preventDefault(); handleSelect(opt) }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-xs border-none cursor-pointer transition-colors duration-100 outline-none"
                    style={{ background: isSelected ? 'rgba(185,28,28,0.06)' : 'transparent', color: isSelected ? '#B91C1C' : '#111827', fontWeight: isSelected ? 600 : 400 }}
                    onMouseEnter={e => { if (!isSelected) e.currentTarget.style.background = '#FEF2F2' }}
                    onMouseLeave={e => { if (!isSelected) e.currentTarget.style.background = isSelected ? 'rgba(185,28,28,0.06)' : 'transparent' }}>
                    <span className="shrink-0 w-1.5 h-1.5 rounded-full" style={{ background: isSelected ? '#B91C1C' : 'transparent' }} />
                    <span className="flex-1 truncate leading-snug">{search.trim() ? <HighlightMatch text={opt} query={search} /> : opt}</span>
                    {isSelected && <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#B91C1C" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="shrink-0"><polyline points="20 6 9 17 4 12"/></svg>}
                  </button>
                </li>
              )
            })}
          </ul>
          {filtered.length > 0 && (
            <div className="px-3 py-1.5 border-t border-gray-50 text-[10px] text-gray-300 text-right select-none">
              {filtered.length}{search && options.length !== filtered.length ? ` of ${options.length}` : ''} option{filtered.length !== 1 ? 's' : ''}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

const EMPLOYEE_SEARCH_FIELDS = new Set(['Select Reviewer', 'Select New Reviewer'])

function FieldEditor({ field, answers, setAnswers, allFields, disabled }) {
  const type = resolveFieldType(field)
  const val  = answers[field.label]
  const set  = useCallback(v => setAnswers(prev => ({ ...prev, [field.label]: v })), [field.label, setAnswers])

  if (EMPLOYEE_SEARCH_FIELDS.has(field.label)) {
    return <OnBehalfOfDropdown value={val || ''} onSelect={(name) => set(name)} disabled={disabled} />
  }
  if (type === 'text') return (
    <input type="text" className="w-full rounded-lg border border-gray-200 bg-white text-xs text-gray-800 font-medium outline-none transition-all duration-200 disabled:opacity-60 disabled:bg-gray-50 disabled:cursor-not-allowed focus:border-red-400 focus:ring-2 focus:ring-red-50 hover:border-red-300 hover:shadow-sm px-3 py-1.5"
      value={val || ''} onChange={e => set(e.target.value)} disabled={disabled} />
  )
  if (type === 'dropdown') {
    const opts = Array.isArray(field.options) ? field.options : []
    return <CustomDropdown options={opts} value={val || ''} onChange={set} disabled={disabled} />
  }
  if (type === 'dependent') {
    const DEPENDENT = { 'Sub Site Location': 'Site Location', 'Sub Department': 'Department' }
    const ctrlField = allFields.find(f => f.englishLabel === DEPENDENT[field.englishLabel])
    const ctrlVal   = ctrlField ? answers[ctrlField.label] : ''
    const opts      = ctrlVal ? ((field.options || {})[ctrlVal] || []) : []
    return <CustomDropdown options={opts} value={val || ''} onChange={set} disabled={disabled || !opts.length}
      placeholder={!opts.length ? '— Select parent first —' : '— Select —'} emptyMsg="Select parent field first" />
  }
  if (type === 'checkbox') {
    const checked = Array.isArray(val) ? val : []
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-1 gap-x-2 bg-gray-50 rounded-md px-2.5 py-2 border border-gray-200">
        {(field.options || []).map(opt => (
          <label key={opt} className="flex items-center gap-1.5 text-[12px] cursor-pointer select-none">
            <input type="checkbox" checked={checked.includes(opt)} disabled={disabled}
              onChange={() => set(checked.includes(opt) ? checked.filter(v => v !== opt) : [...checked, opt])}
              className="accent-red-500 w-3 h-3 flex-shrink-0" />
            <span className="text-gray-700">{opt}</span>
          </label>
        ))}
      </div>
    )
  }
  const opts = Array.isArray(field.options) ? field.options : []
  if (opts.length <= 2) return <CustomDropdown options={opts} value={val || ''} onChange={set} disabled={disabled} />
  return (
    <div className="flex flex-wrap gap-1">
      {opts.map(opt => (
        <button key={opt} type="button" onClick={() => !disabled && set(opt)}
          className={['px-3 py-1 rounded-full border text-[12px] font-medium transition-all',
            val === opt ? 'bg-red-50 text-red-600 border-red-400' : 'bg-gray-50 text-gray-700 border-gray-200 hover:border-red-300 hover:text-red-500',
            disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'].join(' ')}>{opt}</button>
      ))}
    </div>
  )
}

// function SimpleForm({ fields, introHtml, onSubmit }) {
//   const initAnswers = () => {
//     const a = {}
//     fields.forEach(f => { a[f.label] = f.input_type === 'checkbox' ? (Array.isArray(f.prediction) ? [...f.prediction] : []) : (f.prediction ?? '') })
//     return a
//   }
//   const [answers, setAnswers] = useState(initAnswers)
//   const [submitted, setSubmitted] = useState(false)
//   const [errors, setErrors] = useState([])
//   const handleSubmit = () => {
//     const missing = fields.filter(f => { if (f.optional) return false; const v = answers[f.label]; return Array.isArray(v) ? !v.length : (!v || v === '') })
//     if (missing.length) { setErrors(missing.map(f => f.label)); return }
//     setErrors([]); setSubmitted(true)
//     const result = {}
//     fields.forEach(f => { const v = answers[f.label]; result[f.label] = Array.isArray(v) ? (v.length ? v : (f.optional ? 'skip' : '')) : ((v && v !== '') ? v : (f.optional ? 'skip' : '')) })
//     const messageText = fields.filter(f => f.label !== 'Timezone').map(f => result[f.label]).filter(v => v && v !== 'skip').join(', ')
//     onSubmit({ message: messageText, fields: result })
//   }
//   return (
//     <div className="flex items-start gap-2 w-full">
//       <BotAvatar />
//       <div className="flex-1 min-w-0">
//         <div className="w-full rounded-xl border border-gray-200 shadow-sm">
//           <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-red-500 rounded-t-xl">
//             <div className="flex items-center gap-2.5">
//               <div className="w-8 h-8 shrink-0 rounded-lg flex items-center justify-center bg-white/20">
//                 <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//                   <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>
//                   <rect x="8" y="2" width="8" height="4" rx="1"/>
//                 </svg>
//               </div>
//               <div>
//                 <p className="text-white/70 text-xs font-medium leading-none mb-0.5">Incident Management System</p>
//                 <h2 className="text-white text-sm font-semibold leading-tight">Update Fields</h2>
//               </div>
//             </div>
//             {fields.some(f => !f.optional) && <span className="text-white/70 text-xs flex items-center gap-1"><span className="text-red-200 font-bold">*</span> Required</span>}
//           </div>
//           {introHtml && <div className="px-4 py-2.5 bg-red-50 border-b border-red-100"><p className="text-xs text-red-700 leading-relaxed">{introHtml}</p></div>}
//           {errors.length > 0 && (
//             <div className="mx-3 mt-3 flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
//               <AlertCircle size={13} className="text-red-500 mt-0.5 flex-shrink-0" />
//               <p className="text-xs text-red-700 font-medium">{errors.join(' · ')}</p>
//             </div>
//           )}
//           <div>
//             {fields.map((field, i) => (
//               <div key={i} className="ehss-form-row">
//                 <div className="ehss-form-label">
//                   <span className="text-xs font-semibold text-gray-600 leading-snug">
//                     {field.label}{!field.optional && <span className="text-red-500 ml-0.5 font-bold">*</span>}
//                   </span>
//                 </div>
//                 <div className="ehss-form-field">
//                   <FieldEditor field={field} answers={answers} setAnswers={setAnswers} allFields={fields} disabled={submitted} />
//                 </div>
//               </div>
//             ))}
//           </div>
//           <div className="px-4 py-3 bg-gray-50 flex justify-end">
//             {submitted ? (
//               <div className="flex items-center gap-1.5 text-green-600 text-xs font-semibold"><CheckCircle2 size={13} /> Submitted</div>
//             ) : (
//               <button onClick={handleSubmit}
//                 className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-white rounded-full border-none cursor-pointer transition-all"
//                 style={{ background: '#B91C1C', boxShadow: '0 2px 8px rgba(185,28,28,0.3)' }}
//                 onMouseEnter={e => e.currentTarget.style.background = '#991b1b'}
//                 onMouseLeave={e => e.currentTarget.style.background = '#B91C1C'}>
//                 <IconSend className="w-3 h-3" /> Submit
//               </button>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   )
// }


// ─── WwidForm ─────────────────────────────────────────────────────────────────
// Two modes:
//   isWwidStep (has WWID or Language field) → narrow card, simple inputs
//   !isWwidStep (partial field update)      → full-width grid, sorted by FIELD_ORDER,
//                                             ENPS conditional logic, J&J labels

function WwidForm({ fields, introHtml, onSubmit, selectedLanguage, setSelectedLanguage, locked = false ,wwid, session}) {
  const initAnswers = () => {
    const a = {}
    fields.forEach(f => { a[f.label] = f.prediction ?? '' })
    return a
  }
  const [answers,   setAnswers]   = useState(initAnswers)
  const [submitted, setSubmitted] = useState(false)
  const [errors,    setErrors]    = useState([])

  // Detect which mode we're in
  const isWwidStep = fields.some(f => f.label === 'WWID' || f.label === 'Language')

  // ── Conditional field visibility (ENPS + dependent) ─────────────────────────
  // Uses FID-based logic — works for all 19 languages
  const shouldShowField = (field) => {
    const fid = getFieldId(field)
    if (!fid) return true

    // SPECIFIC_LOCATION: only when Construction Details = last option ("Other")
    if (fid === FID.SPECIFIC_LOCATION) {
      const df = fields.find(f => getFieldId(f) === FID.CONSTRUCTION_DETAILS)
      if (!df) return false
      const opts = Array.isArray(df.options) ? df.options : []
      return opts.length > 0 && answers[df.label] === opts[opts.length - 1]
    }
    // DESCRIBE_OTHER: only when Responsible Dept = last option
    if (fid === FID.DESCRIBE_OTHER) {
      const rf = fields.find(f => getFieldId(f) === FID.RESPONSIBLE_DEPT)
      if (!rf) return false
      return isDescribeOtherValue(answers[rf.label], rf.options)
    }
    // SUB_SITE_LOCATION: only when Site Location has value
    if (fid === FID.SUB_SITE_LOCATION) {
      const pf = fields.find(f => getFieldId(f) === FID.SITE_LOCATION)
      return !pf || !!answers[pf.label]
    }
    // SUB_DEPARTMENT: only when Department has value
    if (fid === FID.SUB_DEPARTMENT) {
      const pf = fields.find(f => getFieldId(f) === FID.DEPARTMENT)
      return !pf || !!answers[pf.label]
    }
    return true
  }

  


  // ── Sort fields by master FIELD_ORDER ────────────────────────────────────────
  const sortedFields = [...fields].sort((a, b) => {
    const idA = getFieldId(a); const idB = getFieldId(b)
    const posA = idA ? FIELD_ORDER.indexOf(idA) : Infinity
    const posB = idB ? FIELD_ORDER.indexOf(idB) : Infinity
    return (posA === -1 ? Infinity : posA) - (posB === -1 ? Infinity : posB)
  })

  useEffect(() => {
  console.log(
    "WWID FORM RECEIVED WWID:",
    wwid
  );
}, [wwid]);

  const handleSubmit = () => {
    if (locked) return
    const activeFields = isWwidStep ? fields : sortedFields.filter(f => shouldShowField(f) && !isHeadingField(f))
    const missing = activeFields.filter(f => {
      if (f.optional) return false
      const v = answers[f.label]
      if (f.input_type === 'checkbox') return !v || v === ''
      return !v || v === ''
    })
    if (missing.length) { setErrors(missing.map(f => f.label)); return }
    setErrors([]); setSubmitted(true)

    if (isWwidStep) {
      // ── WWID / Language step: flat object with WWID, Language, Timezone ──────
      const result = {}
      fields
  .filter(f => f.label === 'Language')
  .forEach(f => {
    result[f.label] = answers[f.label] || '';
  });
      try {
        const off  = new Date().getTimezoneOffset()
        const sign = off <= 0 ? '+' : '-'
        const abs  = Math.abs(off)
        const h    = String(Math.floor(abs / 60)).padStart(2, '0')
        const m    = String(abs % 60).padStart(2, '0')
        result['Timezone'] = `GMT${sign}${h}:${m}`
        console.log(
  "SUBMITTING WWID:",
  wwid
);

result["WWID"] = "702441187";
result['Session_Id']=session;
      } catch {}
      console.log("Submitting:", result);
      onSubmit(result)

      if (result['Language']) setSelectedLanguage(result['Language'])
    } else {
      // ── Partial field update: { message, fields } — exclude heading fields ───
      const submitFields = activeFields.filter(f => !isHeadingField(f))
      const fieldValues  = {}
      const messageParts = []
      submitFields.forEach(f => {
        const fid = getFieldId(f)
        let val = answers[f.label] || ''
        if (fid === FID.SECONDARY_HRA && !val.trim()) val = 'skip'
        fieldValues[f.label] = val
        messageParts.push(`change ${f.label} to ${val || '(cleared)'}`)
      })
      onSubmit({ message: messageParts.join(', '), fields: fieldValues })
    }
  }


  // ─────────────────────────────────────────────────────────────────────────────
  // MODE A: WWID / Language step — narrow card (unchanged design)
  // ─────────────────────────────────────────────────────────────────────────────
  if (isWwidStep) {
    return (
      <div className="flex items-start gap-2 w-full">
        <BotAvatar />
        <div className="flex-1 min-w-0 max-w-sm">
          <div className="bg-white border border-gray-200 rounded-2xl rounded-tl-none shadow-sm">
            <div className="px-4 py-2.5 bg-red-500 rounded-t-2xl rounded-tl-none">
              <p className="text-white text-xs font-semibold">{introHtml || 'Please fill in the details'}</p>
            </div>
            {errors.length > 0 && (
              <div className="mx-3 mt-2 flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-1.5">
                <AlertCircle size={12} className="text-red-500 mt-0.5 shrink-0" />
                <p className="text-[11px] text-red-700 font-medium">{errors.join(', ')}</p>
              </div>
            )}
            <div className="px-4 py-3 flex flex-col gap-3">
              {fields
  .filter(field => field.label === 'Language')
  .map((field, i) => {

                const opts = Array.isArray(field.options) ? field.options : []
                const isDropdown = field.input_type === 'dropdown' || opts.length > 1
                return (
                  <div key={i} className="flex flex-col gap-1">
                    <label className="text-xs font-semibold text-gray-600">
                      {field.label}{!field.optional && <span className="text-red-500 ml-0.5">*</span>}
                    </label>
                    {isDropdown ? (
                      <CustomDropdown options={opts} value={answers[field.label] || ''}
                        onChange={v => setAnswers(prev => ({ ...prev, [field.label]: v }))} disabled={submitted || locked} />
                    ) : (
                      <input type="text" value={answers[field.label] || ''}
                        onChange={e => setAnswers(prev => ({ ...prev, [field.label]: e.target.value }))}
                        onKeyDown={e => { if (e.key === 'Enter') handleSubmit() }}
                        disabled={submitted || locked} placeholder={`Enter ${field.label}…`}
                        className="w-full text-xs text-gray-900 border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-red-400 focus:ring-1 focus:ring-red-100 transition-all disabled:opacity-50" />
                    )}
                  </div>
                )
              })}
            </div>
            <div className="px-4 pb-3 flex justify-end">
              {submitted ? (
                <div className="flex items-center gap-1.5 text-green-600 text-xs font-semibold"><CheckCircle2 size={13} /> Submitted</div>
              ) : (
                <button onClick={handleSubmit} disabled={locked}
                  className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-white rounded-full border-none cursor-pointer transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                  style={{ background: '#B91C1C' }}
                  onMouseEnter={e => { if (!locked) e.currentTarget.style.background = '#991b1b' }}
                  onMouseLeave={e => e.currentTarget.style.background = '#B91C1C'}>
                  <IconSend className="w-3 h-3" /> Submit
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    )
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // MODE B: Partial field update — full-width grid with master ordering & logic
  // Same visual language as ReportStyleForm (ehss-form-row grid, red header, etc.)
  // ─────────────────────────────────────────────────────────────────────────────
  const visibleFields = sortedFields.filter(f => shouldShowField(f))

  // ── Separate heading fields from actual input fields ─────────────────────────
  // A "heading" is a backend field with no known FID and no options.
  // All real data fields either resolve to a FID (via FIELD_GROUPS label lookup)
  // or are fingerprinted by their options structure.
  // A field with null FID AND no options is instructional text, not a data entry field.
  const isHeadingField = (f) => {
    const opts = Array.isArray(f.options) ? f.options : []
    return !getFieldId(f) && opts.length === 0
  }
  const headingText  = visibleFields.filter(isHeadingField).map(f => f.label).join(' ')
  const inputFields  = visibleFields.filter(f => !isHeadingField(f))

  return (
    <div className="flex items-start gap-2 w-full">
      <style>{`
        .ehss-form-row { display: grid; grid-template-columns: 20% 1fr; align-items: start; border-bottom: 1px solid #F9FAFB; }
        .ehss-form-label { padding: 8px 12px 4px; text-align: right; word-break: break-word; overflow-wrap: break-word; }
        .ehss-form-field { padding: 4px 8px 8px; min-width: 0; }
        @media (max-width: 640px) { .ehss-form-row { grid-template-columns: 1fr; } .ehss-form-label { text-align: left; padding-bottom: 2px; } }
      `}</style>
      <BotAvatar />
      <div className="flex-1 min-w-0">
        <div className="w-full rounded-xl border border-gray-200 shadow-sm">
          {/* Header */}
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-red-500 rounded-t-xl">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 shrink-0 rounded-lg flex items-center justify-center bg-white/20">
                <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>
                  <rect x="8" y="2" width="8" height="4" rx="1"/>
                </svg>
              </div>
              <div>
                <p className="text-white/70 text-xs font-medium leading-none mb-0.5">Incident Management System</p>
                {/* Show heading field label as the form title, fall back to "Update Fields" */}
                <h2 className="text-white text-sm font-semibold leading-tight">
                  {headingText || 'Update Fields'}
                </h2>
              </div>
            </div>
            {inputFields.some(f => !f.optional) && (
              <span className="text-white/70 text-xs flex items-center gap-1">
                <span className="text-red-200 font-bold">*</span> Required
              </span>
            )}
          </div>

          {/* Intro text */}
          {introHtml && (
            <div className="px-4 py-2.5 bg-red-50 border-b border-red-100">
              <p className="text-xs text-red-700 leading-relaxed">{introHtml}</p>
            </div>
          )}

          {/* Errors */}
          {errors.length > 0 && (
            <div className="mx-3 mt-3 flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
              <AlertCircle size={13} className="text-red-500 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-red-700 font-medium">{errors.join(' · ')}</p>
            </div>
          )}

          {/* Fields in master-ordered grid layout */}
          <div>
          {inputFields.map((field, i) => {
            const fid        = getFieldId(field)
            const isCheckbox = field.input_type === 'checkbox'
            // Dependent field resolution (Sub Site Location → Site Location, Sub Department → Department)
            const isDependent = field.options !== null && typeof field.options === 'object' && !Array.isArray(field.options)
            const parentFid   = fid === FID.SUB_SITE_LOCATION ? FID.SITE_LOCATION
                              : fid === FID.SUB_DEPARTMENT    ? FID.DEPARTMENT
                              : null
            const parentField = parentFid ? fields.find(f => getFieldId(f) === parentFid) : null
            const parentVal   = parentField ? (answers[parentField.label] || '') : ''
            const opts = isDependent
              ? (field.options[parentVal] || [])
              : Array.isArray(field.options) ? field.options : []
            const isDropdown       = !isCheckbox && (isDependent || field.input_type === 'dropdown' || opts.length > 1)
            const dependentDisabled = isDependent && !parentVal
            const depPlaceholder    = isDependent && !parentVal   ? '— Select —'
                                    : isDependent && !opts.length ? '--no options available--'
                                    : '— Select —'
 
              // J&J label override for Location/Company — use correct language
              const displayLabel = fid === FID.LOCATION  ? getJnjSiteLabel(selectedLanguage)
                                 : fid === FID.COMPANY   ? getJnjCompanyLabel(selectedLanguage)
                                 : fid === FID.WHAT_HAPPENED  ? getWhatHappenedLabel(selectedLanguage)
                                 : fid === FID.DESCRIBE_OTHER ? getDescribeOtherLabel(selectedLanguage)
                                 : fid === FID.SPECIFIC_LOCATION? (FIELD_GROUPS[FID.SPECIFIC_LOCATION]?.[getLangIdx(selectedLanguage)] || 'Specific Location')
                                 : field.label

              // Checkbox value as comma-separated string
              const rawVal = answers[field.label] ?? ''
              const checkedItems = isCheckbox
                ? (Array.isArray(rawVal) ? rawVal : (rawVal?.split?.(',') ?? []).map(v => v.trim()).filter(Boolean))
                : []
               

              return (
                <div key={i} className="ehss-form-row">
                  <div className="ehss-form-label">
                    <span className="text-xs font-semibold text-gray-600 leading-snug">
                      {displayLabel}
                      {!field.optional && <span className="text-red-500 ml-0.5 font-bold">*</span>}
                     {FIELD_INFO[fid] && <InfoTooltip text={FIELD_INFO[fid]} />}
                    </span>
                  </div>
                  <div className="ehss-form-field">
                    {isCheckbox ? (
                      /* Checkbox grid — same style as ReportStyleForm RowCell */
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-3 gap-y-1.5 py-1">
                        {opts.map(opt => {
                          const isChecked = checkedItems.includes(opt)
                          return (
                            <label key={opt} className="flex items-center gap-2 cursor-pointer select-none" style={{ opacity: (submitted || locked) ? 0.6 : 1 }}>
                              <span onClick={() => {
                                if (submitted || locked) return
                                const next = isChecked ? checkedItems.filter(v => v !== opt) : [...checkedItems, opt]
                                setAnswers(prev => ({ ...prev, [field.label]: next.join(', ') }))
                              }} className="shrink-0 w-4 h-4 rounded flex items-center justify-center border transition-all duration-150"
                                style={{ background: isChecked ? '#B91C1C' : '#fff', borderColor: isChecked ? '#B91C1C' : '#D1D5DB',
                                  boxShadow: isChecked ? '0 0 0 2px rgba(185,28,28,0.15)' : 'none', cursor: (submitted || locked) ? 'not-allowed' : 'pointer' }}>
                                {isChecked && <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>}
                              </span>
                              <span className="text-xs leading-snug" style={{ color: isChecked ? '#B91C1C' : '#374151', fontWeight: isChecked ? 600 : 400 }}>{opt}</span>
                            </label>
                          )
                        })}
                      </div>
                    ) : isDropdown ? (
                    <CustomDropdown options={opts} value={rawVal}
                      onChange={v => setAnswers(prev => ({ ...prev, [field.label]: v }))}
                      disabled={submitted || locked || dependentDisabled}
                      placeholder={isDependent ? depPlaceholder : '— Select —'} /> 
                    ) : (
                      <input type="text" value={rawVal}
                        onChange={e => setAnswers(prev => ({ ...prev, [field.label]: e.target.value }))}
                        onKeyDown={e => { if (e.key === 'Enter') handleSubmit() }}
                        disabled={submitted || locked} placeholder={`Enter ${field.label}…`}
                        className="w-full text-xs text-gray-900 border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-red-400 focus:ring-1 focus:ring-red-100 transition-all disabled:opacity-50" />
                    )}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Footer */}
          <div className="px-4 py-3 bg-gray-50 rounded-b-xl flex justify-end">
            {submitted ? (
              <div className="flex items-center gap-1.5 text-green-600 text-xs font-semibold"><CheckCircle2 size={13} /> Submitted</div>
            ) : (
              <button onClick={handleSubmit} disabled={locked}
                className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-white rounded-full border-none cursor-pointer transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ background: '#B91C1C', boxShadow: '0 2px 8px rgba(185,28,28,0.3)' }}
                onMouseEnter={e => { if (!locked) e.currentTarget.style.background = '#991b1b' }}
                onMouseLeave={e => e.currentTarget.style.background = '#B91C1C'}>
                <IconSend className="w-3 h-3" /> Submit
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Module-level language cache — bridges WwidForm → ReportStyleForm ─────────
let CACHED_LANGUAGE = 'english'

// ─── Auto-lock: every new EventForm mount locks all previously rendered forms ─
const _lockRegistry = new Set()

// ─── Main form detection ──────────────────────────────────────────────────────
// Full ReportStyleForm: has report-style intro OR specific full-form-only field
// labels OR 10+ fields with englishLabel (partial updates have 1-5 fields max).
const MAIN_FORM_LABELS = new Set([
  'Event Type', 'What Happened', 'Report in Confidence?',
  'Select Different Reviewer?', 'Default Incident Reviewer', 'Default Good Save Reviewer',
])

function isMainForm(fields = [], introHtml = '') {

  if (fields.length === 0) return false

  // Layer 1: report-style intro

  if (isReportIntro(introHtml, fields)) return true

  // Layer 2: 10+ fields with englishLabel = full form

  if (fields.filter(f => f.englishLabel).length >= 10) return true

  // Layer 3: full form always has 15+ total fields; partial updates have 1–6

  if (fields.length >= 15) return true

  return false
}
 

export default function EventForm({ fields = [], introHtml, onSubmit, onSave, locked = false, piiCheck = null, onLanguageChange ,wwid,session,onFileUpload})  {
  const [selectedLanguage, setSelectedLanguage] = useState(CACHED_LANGUAGE)
  const [_autoLocked, _setAutoLocked] = useState(false)

  useEffect(() => {
    const lockMe = () => _setAutoLocked(true)
    _lockRegistry.add(lockMe)
    _lockRegistry.forEach(fn => { if (fn !== lockMe) fn() })
    return () => _lockRegistry.delete(lockMe)
  }, [])


 useEffect(() => {
  console.log(
    "EVENT FORM RECEIVED WWID:",
    wwid
  );
}, [wwid]);
const handleSetLanguage = (lang) => {
  CACHED_LANGUAGE = lang;
  setSelectedLanguage(lang);

  // Send updated language to parent
  onLanguageChange?.(lang);
};
  const effectiveLocked = locked || _autoLocked

  // Full main form → ReportStyleForm
  // Everything else (WWID step, partial updates) → WwidForm
  // WwidForm internally detects isWwidStep and renders narrow or full-width layout
  if (isMainForm(fields, introHtml)) {
    return <ReportStyleForm fields={fields} introHtml={introHtml} onSubmit={onSubmit}
                             onSave={onSave} locked={effectiveLocked} selectedLanguage={CACHED_LANGUAGE}
                             piiCheck={piiCheck} session={session} onFileUpload={onFileUpload} />
  }
  return <WwidForm fields={fields} introHtml={introHtml} onSubmit={onSubmit}
                   selectedLanguage={selectedLanguage} setSelectedLanguage={handleSetLanguage}
                   locked={effectiveLocked} wwid={wwid} session={session}/>
}