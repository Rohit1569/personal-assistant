"use client";

import { Archive, Trash2, List, Paperclip, FileText, Plus, Info, AlertTriangle } from "lucide-react";
import { useTranslation } from "@/lib/i18n";

// Icons are chosen by action *id* (language independent). Legacy string actions
// are still supported: the string is used as both id and label.
const ICONS_BY_ID = {
  archive: Archive,
  delete: Trash2,
  listAll: List,
  showActive: List,
  attach: Paperclip,
  detach: Paperclip,
  template: FileText,
};

function legacyIconFor(label = "") {
  const l = String(label).toLowerCase();
  if (l.includes("archive")) return Archive;
  if (l.includes("delete")) return Trash2;
  if (l.includes("list")) return List;
  if (l.includes("attach") || l.includes("detach")) return Paperclip;
  if (l.includes("template")) return FileText;
  return null;
}

const normalizeAction = (action) =>
  typeof action === "string" ? { id: action, label: action } : { ...action, label: action.label ?? action.id };

function ActionIcon({ action, className }) {
  const Icon = ICONS_BY_ID[action.icon || action.id] || legacyIconFor(action.label);
  return Icon ? <Icon className={className} /> : null;
}

function AddIcon({ id }) {
  const l = String(id ?? "").toLowerCase();
  if (l.includes("attach")) return <Paperclip className="h-4 w-4" strokeWidth={2.4} />;
  if (l.includes("template")) return <FileText className="h-4 w-4" strokeWidth={2.4} />;
  if (l.includes("list")) return <List className="h-4 w-4" strokeWidth={2.4} />;
  return <Plus className="h-4 w-4" strokeWidth={2.6} />;
}

const LINK_COLUMNS = new Set(["recordNo", "actionNo", "incidentNo"]);

export default function SubformTable({
  addLabel,
  addId,
  addDisabled = false,
  addDisabledReason,
  actions = [],
  columns = [],
  rows = [],
  emptyText,
  onAdd,
  onRowClick,

  // Selection / archive
  selectable = false,
  selectedKeys,
  onToggleRow,
  onToggleAll,
  notice,

  showFilters = false,
  filters = {},
  onFilterChange,
  onFilterEnter,
}) {
  const { t } = useTranslation();
  const normalizedActions = actions.map(normalizeAction);
  const rowKey = (row, index) => row?._key ?? index;
  const isSelected = (row, index) => Boolean(selectedKeys?.has?.(rowKey(row, index)));

  const selectableRows = rows.filter((r) => !r?._archived);
  const allSelected =
    selectable && selectableRows.length > 0 && selectableRows.every((r, i) => selectedKeys?.has?.(rowKey(r, i)));
  const totalColumns = columns.length + (selectable ? 1 : 0);

  const handleRowClick = (row, e) => {
    e.stopPropagation();
    if (row?._archived) return; // archived rows are read-only
    onRowClick?.(row);
  };

  const addActionId = addId ?? addLabel;

  return (
    <div>
      {(addLabel || normalizedActions.length > 0) && (
        <div className="mb-3 flex flex-wrap items-center gap-2">
          {addLabel && (
            <button
              type="button"
              onClick={() => !addDisabled && onAdd?.(addActionId)}
              disabled={addDisabled}
              title={addDisabled ? addDisabledReason : undefined}
              className="inline-flex items-center gap-1.5 rounded-lg bg-jnj-red px-3 py-1.5 text-xs font-semibold text-white shadow-sm transition hover:bg-jnj-red-dark active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
            >
              <AddIcon id={addActionId} />
              {addLabel}
            </button>
          )}

          {normalizedActions.map((action) => (
            <button
              type="button"
              key={action.id}
              onClick={() => !action.disabled && onAdd?.(action.id)}
              disabled={action.disabled}
              title={action.title}
              aria-pressed={action.pressed}
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition disabled:cursor-not-allowed disabled:opacity-50 ${
                action.pressed
                  ? "border-jnj-red bg-red-50 text-jnj-red"
                  : "border-jnj-line bg-white text-jnj-slate hover:border-slate-300 hover:text-jnj-ink"
              }`}
            >
              <ActionIcon action={action} className="h-3.5 w-3.5" />
              {action.label}
            </button>
          ))}
        </div>
      )}

      {addDisabled && addDisabledReason && (
        <p className="mb-3 flex items-start gap-2 text-xs text-jnj-slate">
          <Info className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-sky-500" />
          {addDisabledReason}
        </p>
      )}

      {notice?.text && (
        <div
          role="status"
          className={`mb-3 flex items-start gap-2 rounded-lg px-3 py-2 text-xs ring-1 ring-inset ${
            notice.type === "error"
              ? "bg-red-50 text-red-700 ring-red-200"
              : "bg-sky-50/70 text-sky-900 ring-sky-100"
          }`}
        >
          {notice.type === "error" ? (
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 flex-shrink-0" />
          ) : (
            <Info className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-sky-500" />
          )}
          <span>{notice.text}</span>
        </div>
      )}

      <div className="overflow-x-auto rounded-lg border border-jnj-line">
        <table className="w-full border-collapse text-left text-sm">
          <thead>
            <tr className="bg-jnj-mist">
              {selectable && (
                <th className="w-10 border-b border-jnj-line px-3 py-2.5">
                  <input
                    type="checkbox"
                    aria-label={t("subform.selectAll")}
                    checked={allSelected}
                    disabled={selectableRows.length === 0}
                    onChange={() => onToggleAll?.()}
                    className="h-4 w-4 accent-red-600"
                  />
                </th>
              )}
              {columns.map((column) => (
                <th
                  key={column.key}
                  className="whitespace-nowrap border-b border-jnj-line px-3 py-2.5 text-xs font-semibold uppercase tracking-wide text-jnj-slate"
                >
                  {column.label}
                </th>
              ))}
            </tr>

            {showFilters && (
              <tr className="bg-white">
                {selectable && <th className="border-b border-jnj-line" />}
                {columns.map((column) => (
                  <th key={`filter-${column.key}`} className="border-b border-jnj-line px-2 py-2">
                    <input
                      type="text"
                      aria-label={t("subform.filterColumn", { column: column.label })}
                      value={filters?.[column.key] ?? ""}
                      onChange={(e) => onFilterChange?.({ ...filters, [column.key]: e.target.value })}
                      onKeyDown={(e) => onFilterEnter?.(e)}
                      className="w-full rounded border border-slate-300 px-2 py-1 text-xs focus:border-red-500 focus:outline-none"
                    />
                  </th>
                ))}
              </tr>
            )}
          </thead>

          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={totalColumns} className="px-3 py-6 text-center text-sm text-slate-400">
                  {emptyText ?? t("subform.noRecords")}
                </td>
              </tr>
            ) : (
              rows.map((row, index) => {
                const archived = Boolean(row?._archived);
                const clickable = Boolean(onRowClick) && !archived;
                return (
                  <tr
                    key={rowKey(row, index)}
                    onClick={clickable ? (e) => handleRowClick(row, e) : undefined}
                    className={`transition-colors ${
                      archived
                        ? "bg-slate-50 text-slate-400"
                        : clickable
                        ? "cursor-pointer hover:bg-red-50/60"
                        : "hover:bg-red-50/40"
                    } ${isSelected(row, index) ? "bg-red-50/70" : ""}`}
                  >
                    {selectable && (
                      <td className="border-b border-jnj-line px-3 py-2.5" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          aria-label={t("subform.selectRow")}
                          checked={isSelected(row, index)}
                          disabled={archived}
                          onChange={() => onToggleRow?.(rowKey(row, index))}
                          className="h-4 w-4 accent-red-600"
                        />
                      </td>
                    )}
                    {columns.map((column, columnIndex) => {
                      const cell = row[column.key];
                      const content =
                        clickable && LINK_COLUMNS.has(column.key) ? (
                          <button
                            type="button"
                            onClick={(e) => handleRowClick(row, e)}
                            className="font-semibold text-jnj-red hover:underline"
                          >
                            {cell}
                          </button>
                        ) : (
                          cell ?? <span className="text-slate-300">—</span>
                        );

                      return (
                        <td key={column.key} className="border-b border-jnj-line px-3 py-2.5 text-jnj-ink/90">
                          {content}
                          {columnIndex === 0 && archived && (
                            <span className="ml-2 inline-flex rounded-full bg-slate-200 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-slate-600">
                              {t("subform.archivedBadge")}
                            </span>
                          )}
                          {columnIndex === 0 && !archived && row?._source === "local" && (
                            <span className="ml-2 inline-flex rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-amber-700">
                              {t("subform.draftBadge")}
                            </span>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
