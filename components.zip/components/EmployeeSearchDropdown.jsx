// "use client";

// import { useEffect, useCallback, useRef, useState } from "react";

// import { fetchEmployees } from "@/lib/employeeApi"

// function HighlightMatch({ text, query }) {
//   if (!query) return <span>{text}</span>
//   const idx = text.toLowerCase().indexOf(query.toLowerCase())
//   if (idx === -1) return <span>{text}</span>
//   return (
//     <span>
//       {text.slice(0, idx)}
//       <mark className="bg-yellow-100 text-yellow-800 font-semibold rounded-sm px-0">{text.slice(idx, idx + query.length)}</mark>
//       {text.slice(idx + query.length)}
//     </span>
//   )
// }

// function CircularSpinner({ size = 22 }) {
//   return (
//     <svg width={size} height={size} viewBox="0 0 22 22" fill="none" className="animate-spin" style={{ animationDuration: '0.7s' }}>
//       <circle cx="11" cy="11" r="9" stroke="#E5E7EB" strokeWidth="2.5" />
//       <path d="M11 2a9 9 0 0 1 9 9" stroke="#B91C1C" strokeWidth="2.5" strokeLinecap="round" />
//     </svg>
//   )
// }

// export default function OnBehalfOfDropdown({ value, onSelect, disabled = false, dropUp = false }) {
//   const [query,   setQuery]   = useState(value || '')
//   const [results, setResults] = useState([])
//   const [loading, setLoading] = useState(false)
//   const [open,    setOpen]    = useState(false)
//   const [error,   setError]   = useState('')
//   const [hovered, setHovered] = useState(false)
//   const [focused, setFocused] = useState(false)
//   const debounceRef  = useRef(null)
//   const containerRef = useRef(null)
//   const listRef      = useRef(null)
//   const abortRef     = useRef(null)
//   const IconSearch = ({ className = 'w-3 h-3' }) => (
//   <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
//     <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
//   </svg>
// )

// const IconX = ({ className = 'w-2.5 h-2.5' }) => (
//   <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
//     <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
//   </svg>
// )

//   useEffect(() => { if (!focused) setQuery(value || '') }, [value, focused])
//   useEffect(() => {
//     const handler = (e) => {
//       if (containerRef.current && !containerRef.current.contains(e.target)) {
//         setOpen(false); setFocused(false); setQuery(value || '')
//       }
//     }
//     document.addEventListener('mousedown', handler)
//     return () => document.removeEventListener('mousedown', handler)
//   }, [value])

//   const doSearch = useCallback((text) => {
//     if (!text || text.trim().length < 1) { setResults([]); setOpen(false); setLoading(false); return }
//     if (abortRef.current) abortRef.current.abort()
//     abortRef.current = new AbortController()
//     setLoading(true); setError('')
//     fetchEmployees(text.trim(), { signal: abortRef.current.signal })
//       .then(data => { setResults(data); setOpen(true); setLoading(false) })
//       .catch(err => {
//         if (err.name !== 'AbortError') { setError('Could not load employees. Check connection.'); setLoading(false); setOpen(true) }
//       })
//   }, [])

//   const handleChange = (e) => {
//     const val = e.target.value; setQuery(val)
//     clearTimeout(debounceRef.current)
//     if (!val.trim()) { setResults([]); setOpen(false); setLoading(false); return }
//     setLoading(true)
//     debounceRef.current = setTimeout(() => doSearch(val), 350)
//   }
//   const handleSelect = (emp) => { setQuery(emp.name); setOpen(false); setFocused(false); onSelect(emp.name, emp.supervisor) }
//   const borderColor = disabled ? '#E5E7EB' : focused ? '#B91C1C' : hovered ? '#B91C1C' : '#D1D5DB'
//   const boxShadow   = disabled ? 'none' : focused ? '0 0 0 3px rgba(185,28,28,0.1)' : hovered ? '0 0 0 2px rgba(185,28,28,0.06)' : 'none'

//   return (
//     <div ref={containerRef} className="relative w-full">
//       <div className="flex items-center gap-2 rounded-lg px-2.5 py-1.5 transition-all duration-150"
//         style={{ background: disabled ? '#F3F4F6' : focused || hovered ? '#ffffff' : '#F7F8FA',
//           border: `${focused ? '2px' : '1.5px'} ${focused ? 'solid' : 'dashed'} ${borderColor}`, boxShadow }}
//         onMouseEnter={() => !disabled && setHovered(true)} onMouseLeave={() => setHovered(false)}>
//         <IconSearch className="w-3 h-3 text-gray-400 shrink-0" />
//         <input type="text" value={query} onChange={handleChange}
//           onFocus={() => { if (!disabled) { setFocused(true); if (query.trim()) doSearch(query) } }}
//           disabled={disabled} placeholder="Type a name to search…"
//           className="flex-1 text-xs text-gray-900 bg-transparent outline-none placeholder-gray-400 disabled:cursor-not-allowed"
//           autoComplete="off" />
//         {query && !disabled && (
//           <button onMouseDown={e => { e.preventDefault(); setQuery(''); setResults([]); setOpen(false); onSelect('', '') }}
//             className="text-gray-400 hover:text-gray-600 bg-transparent border-none cursor-pointer p-0 leading-none" title="Clear">
//             <IconX className="w-2.5 h-2.5" />
//           </button>
//         )}
//       </div>
//       {(open || loading) && focused && (
//         <div className="absolute z-50 left-0 right-0 rounded-2xl bg-white overflow-hidden"
//           style={{ boxShadow: '0 8px 32px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.08)', border: '1px solid #F1F1F1',
//             ...(dropUp ? { bottom: 'calc(100% + 8px)' } : { top: 'calc(100% + 8px)' }) }}>
//           <div className="flex items-center justify-between px-3 py-2 border-b border-gray-100">
//             <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-widest">
//               {loading ? 'Searching…' : `${results.length} employee${results.length !== 1 ? 's' : ''} found`}
//             </span>
//             {loading && <CircularSpinner size={12} />}
//           </div>
//           {loading ? (
//             <div className="px-3 py-2 flex flex-col gap-2">
//               {[90, 70, 80].map((w, i) => (
//                 <div key={i} className="flex items-center gap-2.5 py-1">
//                   <div className="w-7 h-7 rounded-full bg-gray-100 animate-pulse shrink-0" />
//                   <div className="flex flex-col gap-1 flex-1">
//                     <div className="h-2.5 rounded-full bg-gray-100 animate-pulse" style={{ width: `${w}%` }} />
//                     <div className="h-2 rounded-full bg-gray-50 animate-pulse" style={{ width: `${w - 20}%` }} />
//                   </div>
//                 </div>
//               ))}
//             </div>
//           ) : error ? (
//             <div className="flex items-center gap-2 px-4 py-3 text-xs text-red-500">
//               <AlertCircle size={13} className="shrink-0" /> {error}
//             </div>
//           ) : results.length === 0 ? (
//             <div className="flex flex-col items-center gap-1.5 px-4 py-5">
//               <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#D1D5DB" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
//                 <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
//               </svg>
//               <span className="text-xs text-gray-400">No employees found for <strong className="text-gray-500">&ldquo;{query}&rdquo;</strong></span>
//             </div>
//           ) : (
//             <ul ref={listRef} className="overflow-y-auto" style={{ maxHeight: 260 }}>
//               {results.map((emp, i) => (
//                 <li key={`${emp.raw}-${i}`}>
//                   <button onMouseDown={e => { e.preventDefault(); handleSelect(emp) }}
//                     className="w-full flex items-center gap-3 px-3 py-2.5 text-left border-none bg-transparent cursor-pointer group transition-all duration-100"
//                     style={{ background: 'transparent' }}
//                     onMouseEnter={e => e.currentTarget.style.background = '#FEF2F2'}
//                     onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
//                     <div className="w-7 h-7 shrink-0 rounded-full flex items-center justify-center text-[10px] font-bold"
//                       style={{ background: `hsl(${(emp.name.charCodeAt(0) * 37) % 360}, 55%, 92%)`, color: `hsl(${(emp.name.charCodeAt(0) * 37) % 360}, 55%, 35%)` }}>
//                       {emp.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()}
//                     </div>
//                     <div className="flex flex-col min-w-0 flex-1">
//                       <span className="text-xs font-semibold text-gray-800 truncate leading-snug">
//                         <HighlightMatch text={emp.name} query={query} />
//                       </span>
//                       {emp.supervisor ? (
//                         <span className="text-[10px] text-gray-400 truncate leading-snug flex items-center gap-1">
//                           <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
//                             <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
//                             <path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
//                           </svg>
//                           {emp.supervisor}
//                         </span>
//                       ) : (
//                         <span className="text-[10px] text-gray-300 truncate leading-snug">No supervisor</span>
//                       )}
//                     </div>
//                     <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#B91C1C" strokeWidth="3"
//                       strokeLinecap="round" strokeLinejoin="round" className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
//                       <polyline points="20 6 9 17 4 12"/>
//                     </svg>
//                   </button>
//                 </li>
//               ))}
//             </ul>
//           )}
//         </div>
//       )}
//     </div>
//   )
// }

// components/EmployeeSearchDropdown.jsx

"use client";

import { useEffect, useCallback, useRef, useState } from "react";
import { AlertCircle } from "lucide-react";
import { fetchEmployees } from "@/lib/employeeApi";

function HighlightMatch({ text, query }) {
  if (!query) return <span>{text}</span>;
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return <span>{text}</span>;
  return (
    <span>
      {text.slice(0, idx)}
      <mark className="bg-yellow-100 text-yellow-800 font-semibold rounded-sm px-0">
        {text.slice(idx, idx + query.length)}
      </mark>
      {text.slice(idx + query.length)}
    </span>
  );
}

function CircularSpinner({ size = 18 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 22 22"
      fill="none"
      className="animate-spin"
      style={{ animationDuration: "0.7s" }}
    >
      <circle cx="11" cy="11" r="9" stroke="#E5E7EB" strokeWidth="2.5" />
      <path d="M11 2a9 9 0 0 1 9 9" stroke="#B91C1C" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

/**
 * OnBehalfOfDropdown (styled to match other FieldInput controls)
 * Props:
 *  - value: current text value (string)
 *  - onSelect: function(name, supervisor) called when user selects an employee
 *  - disabled: boolean
 *  - dropUp: boolean (if true, dropdown opens upward)
 *  - className: optional extra class applied to outer wrapper
 */
export default function OnBehalfOfDropdown({
  value,
  onSelect,
  disabled = false,
  dropUp = false,
  className = "",
}) {
  const [query, setQuery] = useState(value || "");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const [hovered, setHovered] = useState(false);
  const [focused, setFocused] = useState(false);

  const debounceRef = useRef(null);
  const containerRef = useRef(null);
  const listRef = useRef(null);
  const abortRef = useRef(null);

  useEffect(() => {
    if (!focused) setQuery(value || "");
  }, [value, focused]);

  useEffect(() => {
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
        setFocused(false);
        setQuery(value || "");
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [value]);

  const doSearch = useCallback((text) => {
    if (!text || text.trim().length < 1) {
      setResults([]);
      setOpen(false);
      setLoading(false);
      return;
    }

    if (abortRef.current) abortRef.current.abort();
    abortRef.current = new AbortController();

    setLoading(true);
    setError("");

    fetchEmployees(text.trim(), { signal: abortRef.current.signal })
      .then((data) => {
        setResults(data || []);
        setOpen(true);
        setLoading(false);
      })
      .catch((err) => {
        if (err.name !== "AbortError") {
          setError("Could not load employees. Check connection.");
          setLoading(false);
          setOpen(true);
        }
      });
  }, []);

  const handleChange = (e) => {
    const val = e.target.value;
    setQuery(val);

    clearTimeout(debounceRef.current);

    if (!val.trim()) {
      setResults([]);
      setOpen(false);
      setLoading(false);
      return;
    }

    setLoading(true);
    setOpen(true);

    debounceRef.current = setTimeout(() => doSearch(val), 350);
  };

  const handleSelect = (emp) => {
    setQuery(emp.name);
    setOpen(false);
    setFocused(false);
    onSelect?.(emp.name, emp.supervisor);
  };

  const handleClear = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setQuery("");
    setResults([]);
    setOpen(false);
    onSelect?.("", "");
  };

  // Styling to closely match FieldInput controls used in the rest of the form
  const wrapperBg = disabled ? "bg-gray-50" : hovered || focused ? "bg-white" : "bg-[#F7F8FA]";
  const borderColor = disabled ? "border-gray-200" : focused ? "border-jnj-red" : "border-gray-300";
  const shadow = focused ? "ring-4 ring-jnj-red/10" : hovered ? "ring-2 ring-jnj-red/6" : "";

  return (
    <div ref={containerRef} className={`relative w-full ${className}`}>
      {/* Input area styled like other fields */}
      <div
        className={`flex items-center gap-2 rounded-md border ${borderColor} px-3 py-2 ${wrapperBg} ${shadow}`}
        onMouseEnter={() => !disabled && setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        role="combobox"
        aria-expanded={open}
      >
        {/* Search icon */}
        <svg
          className="w-4 h-4 text-gray-400 shrink-0"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden
        >
          <circle cx="11" cy="11" r="8" />
          <path d="m21 21-4.35-4.35" />
        </svg>

        <input
          type="text"
          value={query}
          onChange={handleChange}
          onFocus={() => {
            if (!disabled) {
              setFocused(true);
              if (query.trim()) doSearch(query);
            }
          }}
          disabled={disabled}
          placeholder="Type a name to search…"
          className="flex-1 text-sm text-gray-900 bg-transparent outline-none placeholder-gray-400 disabled:cursor-not-allowed"
          autoComplete="off"
        />

        {/* Clear button */}
        {query && !disabled && (
          <button
            onMouseDown={handleClear}
            className="text-gray-400 hover:text-gray-600 bg-transparent border-none cursor-pointer p-1 leading-none"
            title="Clear"
          >
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        )}
      </div>

      {/* Dropdown panel */}
      {(open || loading) && focused && (
        <div
          className={`absolute z-50 left-0 right-0 rounded-lg bg-white overflow-hidden mt-2`}
          style={{
            boxShadow: "0 8px 32px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.08)",
            border: "1px solid #F1F1F1",
            ...(dropUp ? { bottom: "calc(100% + 8px)" } : { top: "calc(100% + 8px)" }),
          }}
        >
          <div className="flex items-center justify-between px-3 py-2 border-b border-gray-100">
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-widest">
              {loading ? "Searching…" : `${results.length} employee${results.length !== 1 ? "s" : ""} found`}
            </span>
            {loading && <CircularSpinner size={12} />}
          </div>

          {loading ? (
            <div className="px-3 py-2 flex flex-col gap-2">
              {[90, 70, 80].map((w, i) => (
                <div key={i} className="flex items-center gap-2.5 py-1">
                  <div className="w-7 h-7 rounded-full bg-gray-100 animate-pulse shrink-0" />
                  <div className="flex flex-col gap-1 flex-1">
                    <div className="h-2.5 rounded-full bg-gray-100 animate-pulse" style={{ width: `${w}%` }} />
                    <div className="h-2 rounded-full bg-gray-50 animate-pulse" style={{ width: `${w - 20}%` }} />
                  </div>
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="flex items-center gap-2 px-4 py-3 text-xs text-red-500">
              <AlertCircle size={13} className="shrink-0" /> {error}
            </div>
          ) : results.length === 0 ? (
            <div className="flex flex-col items-center gap-1.5 px-4 py-5">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#D1D5DB" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.35-4.35" />
              </svg>
              <span className="text-xs text-gray-400">
                No employees found for{" "}
                <strong className="text-gray-500">&ldquo;{query}&rdquo;</strong>
              </span>
            </div>
          ) : (
            <ul ref={listRef} className="overflow-y-auto" style={{ maxHeight: 260 }}>
              {results.map((emp, i) => (
                <li key={`${emp.raw ?? emp.id ?? emp.name}-${i}`}>
                  <button
                    onMouseDown={(e) => {
                      e.preventDefault(); // prevent input blur before selection
                      handleSelect(emp);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2.5 text-left bg-transparent cursor-pointer group transition-all duration-100"
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#FEF2F2")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                  >
                    <div
                      className="w-7 h-7 shrink-0 rounded-full flex items-center justify-center text-[10px] font-bold"
                      style={{
                        background: `hsl(${(emp.name.charCodeAt(0) * 37) % 360}, 55%, 92%)`,
                        color: `hsl(${(emp.name.charCodeAt(0) * 37) % 360}, 55%, 35%)`,
                      }}
                    >
                      {emp.name
                        .split(" ")
                        .map((w) => w[0])
                        .slice(0, 2)
                        .join("")
                        .toUpperCase()}
                    </div>

                    <div className="flex flex-col min-w-0 flex-1">
                      <span className="text-xs font-semibold text-gray-800 truncate leading-snug">
                        <HighlightMatch text={emp.name} query={query} />
                      </span>
                      {emp.supervisor ? (
                        <span className="text-[10px] text-gray-400 truncate leading-snug flex items-center gap-1">
                          <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                            <circle cx="9" cy="7" r="4" />
                            <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                          </svg>
                          {emp.supervisor}
                        </span>
                      ) : (
                        <span className="text-[10px] text-gray-300 truncate leading-snug">No supervisor</span>
                      )}
                    </div>

                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#B91C1C" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

