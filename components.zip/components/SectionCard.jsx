import { useState } from "react";
import { ChevronUp, Info } from "lucide-react";
import { STATUS_DOT } from "@/lib/status";

export default function SectionCard({ index, title, note, anchorId, children, status }) {
  const [open, setOpen] = useState(true);
  return (
    <section id={anchorId} className="scroll-mt-24 overflow-hidden rounded-2xl border border-jnj-line bg-white shadow-card">
      <button onClick={() => setOpen((o) => !o)} className="flex w-full items-center justify-between gap-3 bg-white px-5 py-4 text-left transition hover:bg-jnj-mist/50">
        <div className="flex items-center gap-3">
          <span className="grid h-7 w-7 flex-shrink-0 place-items-center rounded-lg bg-red-50 text-xs font-bold text-jnj-red">{String(index).padStart(2, "0")}</span>
          <h2 className="text-base font-bold tracking-tight text-jnj-ink">{title}</h2>
          {status && status.status !== "none" && (
            <span
              className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-semibold"
              style={{ background: STATUS_DOT[status.status] + "18", color: STATUS_DOT[status.status] }}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: STATUS_DOT[status.status] }} />
              {status.filled}/{status.total} required
            </span>
          )}
        </div>
        <ChevronUp className={`h-5 w-5 flex-shrink-0 text-jnj-slate transition-transform ${open ? "" : "rotate-180"}`} />
      </button>
      {open && (
        <div className="animate-section border-t border-jnj-line px-5 py-5">
          {note && (
            <div className="mb-5 flex items-start gap-2.5 rounded-lg bg-sky-50/70 px-3.5 py-2.5 text-xs leading-relaxed text-sky-900 ring-1 ring-inset ring-sky-100">
              <Info className="mt-0.5 h-4 w-4 flex-shrink-0 text-sky-500" />
              <span>{note}</span>
            </div>
          )}
          {children}
        </div>
      )}
    </section>
  );
}
