'use client'
// ── BackendForm — exact port of showMultiSelectionFields + createSelectOrButtons
// from curve_event_reporting_chatbot_v5_5.html
// Receives: fields[] from backend { label, options, input_type, prediction, optional, englishLabel }

import { useState, useRef, useEffect } from 'react'
import { BotAvatar } from './Avatars'
import { AlertCircle, CheckCircle2 } from 'lucide-react'

// ── Dependent dropdown mapping — mirrors HTML dependentMapping ────────────────
const DEPENDENT_MAPPING = {
  'Sub Site Location': 'Site Location',
  'Sub Department':    'Department',
}

// ── Single field renderer — mirrors createSelectOrButtons exactly ─────────────
function FieldInput({ field, fields, answers, onAnswerChange, disabled }) {
  const { label, options, input_type, prediction, optional, englishLabel } = field

  const inputCls = [
    'w-full px-3 py-2 rounded-lg border border-warm-300 bg-white',
    'text-[13.5px] font-medium text-blue-900 outline-none transition-all',
    'focus:border-red-400 focus:ring-2 focus:ring-red-100',
    'disabled:opacity-50 disabled:cursor-not-allowed appearance-none',
  ].join(' ')

  // ── Dependent dropdown (Sub Site Location / Sub Department) ──────────────
  const isDependent = Object.keys(DEPENDENT_MAPPING).includes(englishLabel) &&
    typeof options === 'object' && !Array.isArray(options)

  const [depOptions, setDepOptions] = useState([])
  const [depDisabled, setDepDisabled] = useState(true)

  useEffect(() => {
    if (!isDependent) return

    const controllerEnglish = DEPENDENT_MAPPING[englishLabel]
    const controllerField   = fields.find(f => f.englishLabel === controllerEnglish)
    if (!controllerField) return

    // Watch controller answer
    const controllerVal = answers[controllerField.label]
    const newOpts = (controllerVal && options[controllerVal]) ? options[controllerVal] : []
    setDepOptions(newOpts)
    setDepDisabled(newOpts.length === 0)

    // Prefill if prediction valid
    if (prediction && newOpts.includes(prediction)) {
      onAnswerChange(label, prediction)
    } else {
      onAnswerChange(label, '')
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [answers[fields.find(f => f.englishLabel === DEPENDENT_MAPPING[englishLabel])?.label]])

  if (isDependent) {
    return (
      <div className="relative">
        <select
          className={`${inputCls} pr-9 cursor-pointer`}
          value={answers[label] || ''}
          onChange={e => onAnswerChange(label, e.target.value)}
          disabled={disabled || depDisabled}
        >
          <option value="">{depDisabled ? '— Select parent first —' : '-- Select an option --'}</option>
          {depOptions.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
        <svg className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-warm-400" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    )
  }

  // ── Text input ────────────────────────────────────────────────────────────
  if (input_type === 'text') {
    return (
      <input
        type="text"
        className={inputCls}
        value={answers[label] || ''}
        onChange={e => onAnswerChange(label, e.target.value)}
        disabled={disabled}
        placeholder=""
      />
    )
  }

  // ── Checkbox ──────────────────────────────────────────────────────────────
  if (input_type === 'checkbox') {
    const checked = Array.isArray(answers[label]) ? answers[label] : []
    const toggle  = (opt) => {
      if (disabled) return
      onAnswerChange(label,
        checked.includes(opt) ? checked.filter(v => v !== opt) : [...checked, opt]
      )
    }
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-2 gap-x-3 bg-warm-50 rounded-lg px-3 py-2.5 border border-warm-200">
        {(Array.isArray(options) ? options : []).map(opt => (
          <label key={opt} className="flex items-center gap-2 text-[12.5px] cursor-pointer">
            <input
              type="checkbox"
              checked={checked.includes(opt)}
              onChange={() => toggle(opt)}
              disabled={disabled}
              className="accent-red-500 w-3.5 h-3.5"
            />
            <span className="text-warm-800 font-medium">{opt}</span>
          </label>
        ))}
      </div>
    )
  }

  const opts = Array.isArray(options) ? options : []

  // ── Dropdown (explicit or >6 options) ────────────────────────────────────
  if (input_type === 'dropdown' || opts.length > 6) {
    return (
      <div className="relative">
        <select
          className={`${inputCls} pr-9 cursor-pointer`}
          value={answers[label] || ''}
          onChange={e => onAnswerChange(label, e.target.value)}
          disabled={disabled}
        >
          <option value="">-- Select an option --</option>
          {opts.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
        <svg className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-warm-400" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    )
  }

  // ── Buttons (≤6 options) ──────────────────────────────────────────────────
  return (
    <div className="flex flex-wrap gap-2 mt-1">
      {opts.map(opt => (
        <button
          key={opt}
          type="button"
          disabled={disabled}
          onClick={() => !disabled && onAnswerChange(label, opt)}
          className={[
            'px-4 py-1.5 rounded-full border text-[12.5px] font-semibold transition-all',
            answers[label] === opt
              ? 'bg-red-50 text-red-600 border-red-400 shadow-sm'
              : 'bg-warm-50 text-warm-700 border-warm-300 hover:border-red-300 hover:text-red-500',
            disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',
          ].join(' ')}
        >
          {opt}
        </button>
      ))}
    </div>
  )
}

// ── Section divider ───────────────────────────────────────────────────────────
function SectionDivider({ title }) {
  return (
    <div className="flex items-center gap-3 mt-5 mb-1">
      <div className="h-px flex-1 bg-warm-200" />
      <span className="text-[10px] font-bold text-warm-400 uppercase tracking-widest whitespace-nowrap">{title}</span>
      <div className="h-px flex-1 bg-warm-200" />
    </div>
  )
}

// ── Main BackendForm component ────────────────────────────────────────────────
export default function BackendForm({ message, fields, onSubmit }) {
  // Init answers with predictions exactly like HTML
  const initAnswers = () => {
    const a = {}
    fields.forEach(f => {
      if (f.input_type === 'checkbox') {
        a[f.label] = Array.isArray(f.prediction) ? [...f.prediction] : []
      } else {
        // Prefill controller for dependent fields too (HTML line 764-767)
        a[f.label] = f.prediction ?? ''
      }
    })
    return a
  }

  const [answers,   setAnswers]   = useState(initAnswers)
  const [submitted, setSubmitted] = useState(false)
  const [errors,    setErrors]    = useState([])

  const onAnswerChange = (label, val) => {
    setAnswers(prev => ({ ...prev, [label]: val }))
  }

  const handleSubmit = () => {
    // Validate required fields — mirrors HTML missingRequired check
    const missing = fields.filter(f => {
      if (f.optional === true) return false
      const val = answers[f.label]
      if (Array.isArray(val)) return val.length === 0
      return !val || val === ''
    })

    if (missing.length > 0) {
      setErrors(missing.map(f => f.label))
      return
    }

    setErrors([])
    setSubmitted(true)

    // Build result — optional empty → "skip", mirrors HTML resultObj logic exactly
    const result = {}
    fields.forEach(f => {
      const val = answers[f.label]
      if (Array.isArray(val)) {
        result[f.label] = val.length > 0 ? val : (f.optional ? 'skip' : '')
      } else {
        result[f.label] = (val && val !== '') ? val : (f.optional ? 'skip' : '')
      }
    })

    onSubmit(result)
  }

  // Group into sections for visual clarity
  const grouped = []
  let currentGroup = null
  fields.forEach(f => {
    const section = f.section || 'Details'
    if (!currentGroup || currentGroup.title !== section) {
      currentGroup = { title: section, fields: [] }
      grouped.push(currentGroup)
    }
    currentGroup.fields.push(f)
  })

  return (
    <div className="flex items-start gap-3 animate-fade-up w-full">
      <BotAvatar />
      <div style={{ flex: '1 1 0', minWidth: 0 }}>
        <div className="bg-white border border-warm-200 rounded-2xl rounded-tl-none shadow-md overflow-hidden">

          {/* Header */}
          <div className="bg-gradient-to-r from-red-500 to-red-600 px-5 py-3">
            <p className="text-white text-[13px] font-bold tracking-wide">📋 Event Details</p>
            <p className="text-white/70 text-[10.5px] mt-0.5">Fields marked <span className="text-white font-bold">*</span> are required · Pre-filled from your records</p>
          </div>

          {/* Intro message from backend */}
          {message && (
            <div className="px-5 pt-4 pb-1 text-[13.5px] text-warm-800 leading-relaxed font-medium">
              {message}
            </div>
          )}

          {/* Error banner */}
          {errors.length > 0 && (
            <div className="mx-5 mt-3 flex items-start gap-2.5 bg-red-50 border border-red-200 rounded-xl px-4 py-3">
              <AlertCircle size={14} className="text-red-500 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-[12.5px] font-bold text-red-700">Please complete required fields:</p>
                <p className="text-[11.5px] text-red-600 mt-0.5">{errors.join(' · ')}</p>
              </div>
            </div>
          )}

          {/* Fields */}
          <div className="px-5 pb-2">
            {fields.map((f) => (
              <div key={f.label}>
                <label className="flex items-center gap-1 text-[13px] font-bold text-warm-900 mt-4 mb-1.5">
                  {!f.optional && <span className="text-red-500">*</span>}
                  {f.label}
                </label>
                <FieldInput
                  field={f}
                  fields={fields}
                  answers={answers}
                  onAnswerChange={onAnswerChange}
                  disabled={submitted}
                />
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="px-5 py-4 border-t border-warm-100 flex items-center justify-between mt-2">
            {submitted ? (
              <div className="flex items-center gap-2 text-green-600">
                <CheckCircle2 size={14} />
                <span className="text-[12.5px] font-semibold">Submitted</span>
              </div>
            ) : (
              <>
                <p className="text-[11px] text-warm-400">Pre-filled values are from your historical records</p>
                <button
                  onClick={handleSubmit}
                  className="flex items-center gap-2 bg-white text-red-500 border-2 border-red-500 text-[13px] font-bold px-6 py-2 rounded-full hover:bg-red-500 hover:text-white transition-all duration-200 shadow-sm"
                >
                  Submit
                </button>
              </>
            )}
          </div>

        </div>
      </div>
    </div>
  )
}
