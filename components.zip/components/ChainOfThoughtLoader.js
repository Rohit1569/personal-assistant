'use client'
import { useEffect, useState, useRef } from 'react'
import { BotAvatar } from './Avatars'

const MSGS = [
  'Analysing your report…',
  'Processing incident details…',
  'Fetching site information…',
  'Classifying event type…',
  'Matching department data…',
  'Preparing report fields…',
  'Almost there…',
]

export default function ChainOfThoughtLoader({ onDone }) {
  const [idx,  setIdx]  = useState(0)
  const [fade, setFade] = useState(true)
  const onDoneRef = useRef(onDone)
  useEffect(() => { onDoneRef.current = onDone }, [onDone])

  useEffect(() => {
    const t = setInterval(() => {
      setFade(false)
      setTimeout(() => { setIdx(i => (i + 1) % MSGS.length); setFade(true) }, 200)
    }, 1800)
    return () => clearInterval(t)
  }, [])

  return (
    <div className="flex items-center gap-2">
      <style>{`
        @keyframes gear-spin { to { transform: rotate(360deg); } }
        .cot-gear { animation: gear-spin 0.15s linear infinite; transform-origin: center; display: block; }
      `}</style>

      <BotAvatar />

      <div className="flex items-center gap-2.5 bg-white border border-red-200 rounded-2xl rounded-tl-none px-3.5 py-2.5 shadow-sm">
        <svg className="cot-gear" width="15" height="15" viewBox="0 0 24 24" fill="#B91C1C">
          <path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58C4.84 11.36 4.8 11.68 4.8 12s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.57 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>
        </svg>
        <span className="text-[11.5px] text-gray-500 font-medium select-none"
          style={{ opacity: fade ? 1 : 0, transition: 'opacity 0.2s ease' }}>
          {MSGS[idx]}
        </span>
      </div>
    </div>
  )
}