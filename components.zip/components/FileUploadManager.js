// components/FileUploadManager.jsx
'use client';

import { useState, useRef, useCallback } from 'react';
import { generateAndUploadFile } from '../lib/GenerateUploadUrl';

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB

export default function FileUploadManager({ 
  session, 
  onFileUpload, 
  onComplete,
  disabled = false,
  isLocked = false 
}) {
  const fileInputRef = useRef(null);
  const [selectedFiles, setSelectedFiles] = useState([]); // Files waiting to upload
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const [uploadProgress, setUploadProgress] = useState({}); // Progress for each file
  const [uploadedFiles, setUploadedFiles] = useState([]); // Successfully uploaded files
  const [currentUploadingFile, setCurrentUploadingFile] = useState(null);

  // Handle file selection (add to queue)
  const handleFileSelect = (e) => {
    const newFiles = e.target.files;
    if (!newFiles || newFiles.length === 0) return;
    
    e.target.value = ''; // Reset input

    // Convert FileList to Array and validate
    const filesArray = Array.from(newFiles);
    const validFiles = [];
    let hasError = false;

    for (const file of filesArray) {
      if (file.size > MAX_FILE_SIZE) {
        setUploadError(`File "${file.name}" exceeds 10 MB limit`);
        hasError = true;
        break;
      }
      validFiles.push({
        file,
        id: `${file.name}-${Date.now()}-${Math.random()}`,
        name: file.name,
        size: file.size,
        status: 'pending' // pending, uploading, completed, failed
      });
    }

    if (!hasError) {
      setUploadError(null);
      setSelectedFiles(prev => [...prev, ...validFiles]);
    }
  };

  // Start uploading all files one by one
  const handleStartUpload = useCallback(async () => {
    if (selectedFiles.length === 0) return;

    try {
      setUploading(true);
      setUploadError(null);
      setUploadProgress({});

      const uploadedFilesList = [];
      const totalFiles = selectedFiles.length;

      for (let i = 0; i < totalFiles; i++) {
        const fileItem = selectedFiles[i];
        const { file, id, name } = fileItem;

        try {
          // Update UI: show current uploading file
          setCurrentUploadingFile(`${i + 1}/${totalFiles}`);
          
          // Initialize progress
          setUploadProgress(prev => ({
            ...prev,
            [id]: { status: 'uploading', progress: 0, name }
          }));

          console.log(`[Uploading ${i + 1}/${totalFiles}] ${name}`);

          // Upload file
          const uploadResult = await generateAndUploadFile(file, session);

          console.log(`[Upload Success ${i + 1}/${totalFiles}]`, uploadResult);

          const fileData = {
            fileName: name,
            s3Key: uploadResult.s3_key,
            uploadUrl: uploadResult.upload_url,
            uploadedAt: new Date().toISOString(),
            size: file.size,
            type: file.type,
            id
          };

          uploadedFilesList.push(fileData);

          // Update progress to completed
          setUploadProgress(prev => ({
            ...prev,
            [id]: { status: 'completed', progress: 100, name }
          }));

          // Notify parent about individual file upload
          if (onFileUpload) {
            onFileUpload(fileData);
          }

          // Small delay between uploads for better UX
          await new Promise(resolve => setTimeout(resolve, 300));

        } catch (err) {
          console.error(`[Upload Error ${i + 1}/${totalFiles}]`, err);
          
          setUploadProgress(prev => ({
            ...prev,
            [id]: { status: 'failed', progress: 0, name, error: err.message }
          }));

          setUploadError(`Failed to upload "${name}": ${err.message || 'Unknown error'}`);
        }
      }

      // Store all uploaded files
      setUploadedFiles(uploadedFilesList);
      setSelectedFiles([]); // Clear selected files after upload
      setCurrentUploadingFile(null);

      // Notify completion
      if (onComplete) {
        onComplete(uploadedFilesList);
      }

    } catch (err) {
      console.error('[File Upload Manager Error]', err);
      setUploadError(err.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  }, [selectedFiles, session, onFileUpload, onComplete]);

  // Remove file from queue (before upload)
  const handleRemoveFromQueue = (id) => {
    setSelectedFiles(prev => prev.filter(f => f.id !== id));
  };

  // Remove uploaded file
  const handleRemoveUploadedFile = (id) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== id));
    setUploadProgress(prev => {
      const newProgress = { ...prev };
      delete newProgress[id];
      return newProgress;
    });
  };

  // Clear all
  const handleClearAll = () => {
    setSelectedFiles([]);
    setUploadedFiles([]);
    setUploadProgress({});
    setUploadError(null);
    setCurrentUploadingFile(null);
  };

  return (
    <div className="w-full space-y-3">
      <style jsx>{`
        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>

      {/* Upload Button */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading || disabled || isLocked}
          title="Select files to upload"
          className="bg-white text-gray-900 text-xs font-semibold px-4 py-1.5 rounded-full hover:bg-red-50 active:scale-95 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <path d="M12 5v14M5 12h14" />
          </svg>
          Select Files
        </button>

        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".csv,.pdf,.xlsx,.xls,.doc,.docx,.txt,.json,.jpg,.jpeg,.png,.gif"
          className="hidden"
          onChange={handleFileSelect}
          disabled={uploading || disabled || isLocked}
        />

        <span className="text-xs text-gray-500">
          Max 10 MB per file
        </span>
      </div>

      {/* Error Message */}
      {uploadError && (
        <div className="text-red-600 text-xs bg-red-50 px-3 py-2 rounded-lg border border-red-200 flex items-start gap-2">
          <svg className="w-4 h-4 shrink-0 mt-0.5" viewBox="0 0 24 24" fill="currentColor">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 8v4M12 16h.01" stroke="white" strokeWidth="2" strokeLinecap="round"/>
          </svg>
          <span>{uploadError}</span>
        </div>
      )}

      {/* Files Pending Upload */}
      {selectedFiles.length > 0 && !uploading && (
        <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-xs font-semibold text-blue-900">
              Ready to Upload ({selectedFiles.length} file{selectedFiles.length !== 1 ? 's' : ''})
            </h4>
            <button
              onClick={handleClearAll}
              className="text-xs text-blue-600 hover:text-blue-700 font-medium"
            >
              Clear
            </button>
          </div>

          <div className="space-y-1.5 mb-3">
            {selectedFiles.map((fileItem) => (
              <div
                key={fileItem.id}
                className="flex items-center justify-between p-2 bg-white rounded border border-blue-100"
              >
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <svg
                    className="w-4 h-4 text-blue-600 shrink-0"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z" />
                    <polyline points="13 2 13 9 20 9" />
                  </svg>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-gray-900 truncate">
                      {fileItem.name}
                    </p>
                    <p className="text-xs text-gray-500">
                      {(fileItem.size / 1024).toFixed(2)} KB
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => handleRemoveFromQueue(fileItem.id)}
                  disabled={uploading}
                  className="ml-2 text-gray-400 hover:text-red-600 disabled:opacity-50 transition-colors"
                  title="Remove from queue"
                >
                  <svg
                    className="w-4 h-4"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <line x1="18" y1="6" x2="6" y2="18" />
                    <line x1="6" y1="6" x2="18" y2="18" />
                  </svg>
                </button>
              </div>
            ))}
          </div>

          {/* Start Upload Button */}
          <button
            onClick={handleStartUpload}
            disabled={uploading || selectedFiles.length === 0}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white text-xs font-bold py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" y1="3" x2="12" y2="15" />
            </svg>
            Start Upload ({selectedFiles.length})
          </button>
        </div>
      )}

      {/* Uploading Progress */}
      {uploading && Object.keys(uploadProgress).length > 0 && (
        <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-semibold text-amber-900">
              Uploading Files {currentUploadingFile}
            </h4>
            <div className="flex items-center gap-1">
              <svg
                width="12"
                height="12"
                viewBox="0 0 24 24"
                style={{ animation: 'spin 0.8s linear infinite' }}
              >
                <circle
                  cx="12"
                  cy="12"
                  r="9"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeOpacity="0.2"
                />
                <path
                  d="M12 3 a9 9 0 0 1 9 9"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />
              </svg>
            </div>
          </div>

          <div className="space-y-2">
            {Object.entries(uploadProgress).map(([id, { status, progress, name, error }]) => (
              <div key={id} className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-gray-700 truncate flex-1">
                    {name}
                  </span>
                  <span className={`text-xs font-semibold ml-2 ${
                    status === 'completed' ? 'text-green-600' :
                    status === 'failed' ? 'text-red-600' :
                    'text-amber-600'
                  }`}>
                    {status === 'uploading' ? `${progress}%` :
                     status === 'completed' ? '✓' :
                     status === 'failed' ? '✗' :
                     ''}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-1.5 overflow-hidden">
                  <div
                    className={`h-1.5 rounded-full transition-all ${
                      status === 'completed' ? 'bg-green-500' :
                      status === 'failed' ? 'bg-red-500' :
                      'bg-amber-500'
                    }`}
                    style={{ width: `${progress}%` }}
                  />
                </div>
                {error && (
                  <p className="text-xs text-red-600">{error}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Successfully Uploaded Files */}
      {uploadedFiles.length > 0 && (
        <div className="p-3 bg-green-50 rounded-lg border border-green-200">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-xs font-semibold text-green-900">
              Uploaded Successfully ({uploadedFiles.length})
            </h4>
            {!uploading && (
              <button
                onClick={handleClearAll}
                className="text-xs text-green-600 hover:text-green-700 font-medium"
              >
                Clear All
              </button>
            )}
          </div>

          <div className="space-y-1.5">
            {uploadedFiles.map((file) => (
              <div
                key={file.id}
                className="flex items-center justify-between p-2 bg-white rounded border border-green-100 hover:bg-green-50 transition-colors"
              >
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <svg
                    className="w-4 h-4 text-green-600 shrink-0"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
                  </svg>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-gray-900 truncate">
                      {file.fileName}
                    </p>
                    <p className="text-xs text-gray-500">
                      {(file.size / 1024).toFixed(2)} KB • {new Date(file.uploadedAt).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => handleRemoveUploadedFile(file.id)}
                  disabled={uploading}
                  className="ml-2 text-gray-400 hover:text-red-600 disabled:opacity-50 transition-colors"
                  title="Remove file"
                >
                  <svg
                    className="w-4 h-4"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <line x1="18" y1="6" x2="6" y2="18" />
                    <line x1="6" y1="6" x2="18" y2="18" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
