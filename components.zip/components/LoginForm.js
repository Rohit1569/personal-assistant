// LoginForm is no longer used — the backend sends the WWID/Language form
// as a multi-selection message which EventForm renders automatically.
// This file is kept as an empty stub to avoid import errors.
export default function LoginForm() { return null }
