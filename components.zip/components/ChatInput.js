'use client'

import { useState, useRef } from 'react'
import { BACKEND_HOST } from '../lib/websocket'

const ANALYZE_URL = `${BACKEND_HOST}/curve-chatbot/analyze_image_base64`

const MAX_FILES = 3
const MAX_SIZE_BYTES = 10 * 1024 * 1024 // 10 MB

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload  = () => resolve(reader.result.split(',')[1])
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

export default function ChatInput({ onSend, onImageResult, disabled, allowImage, selectedLanguage }) {
  const [value, setValue] = useState('')
  // images: [{ file, preview, base64 }]
  const [images, setImages] = useState([])
  const [analyzing, setAnalyzing] = useState(false)
  const fileRef = useRef(null)

  const removeImageAt = (idx) => {
    setImages(prev => {
      const next = [...prev]
      const [removed] = next.splice(idx, 1)
      if (removed?.preview) URL.revokeObjectURL(removed.preview)
      return next
    })
  }

  const removeAllImages = () => {
    images.forEach(img => {
      if (img?.preview) URL.revokeObjectURL(img.preview)
    })
    setImages([])
  }

  const handleFileChange = async (e) => {
    const fileList = Array.from(e.target.files || [])
    if (!fileList.length) return
    e.target.value = ''

    const spaceLeft = Math.max(0, MAX_FILES - images.length)
    if (spaceLeft === 0) {
      alert(`You can upload at most ${MAX_FILES} images.`)
      return
    }

    // Enforce cap
    const selected = fileList.slice(0, spaceLeft)

    // Validate type and size
    const invalids = []
    const validFiles = selected.filter(f => {
      const isImage = f.type?.startsWith('image/')
      const okSize = f.size <= MAX_SIZE_BYTES
      if (!isImage || !okSize) invalids.push({ name: f.name, reason: !isImage ? 'not an image' : 'exceeds 10 MB' })
      return isImage && okSize
    })

    if (invalids.length) {
      const msg = invalids.map(i => `- ${i.name}: ${i.reason}`).join('\n')
      alert(`Some files were skipped:\n${msg}`)
    }
    if (!validFiles.length) return

    try {
      const prepared = await Promise.all(
        validFiles.map(async (file) => {
          const base64 = await fileToBase64(file)
          const preview = URL.createObjectURL(file)
          return { file, preview, base64 }
        })
      )
      setImages(prev => [...prev, ...prepared].slice(0, MAX_FILES))
    } catch (err) {
      console.error('[File->Base64]', err)
      alert('There was a problem reading one or more files.')
    }
  }

  const send = async () => {
    if (disabled || analyzing) return

    const t = value.trim()

    if (images.length) {
      // ── Image flow (multi-image) ────────────────────────────────────────────
      setAnalyzing(true)

      // Let chat show all images in the user bubble
      // Make sure your parent code supports imageUrls (array).
      onSend({ text: t || '', imageUrls: images.map(i => i.preview) })

      setValue('')

      try {
        // Preferred: backend supports multiple images as an array
        const payload = {
          Images_Base64: images.map(i => i.base64)
        }
        if (t) payload.What_Happened = t // optional text
        if (selectedLanguage) payload.language = selectedLanguage

        const res = await fetch(ANALYZE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })

        if (!res.ok) throw new Error(`HTTP ${res.status}`)

        const data = await res.json()
        // Handle both single or array-like responses
        let result =
          data.What_Happened || data.what_happened || data.result || ''

        if (Array.isArray(data) || Array.isArray(data.results)) {
          const arr = Array.isArray(data) ? data : data.results
          result = arr.map(x => x.What_Happened || x.what_happened || x.result || '').filter(Boolean).join('\n\n')
        }

        if (onImageResult) onImageResult(result, t)
      } catch (err) {
        console.error('[Analyze]', err)
        if (onImageResult) onImageResult(null, t, err.message)
      } finally {
        setAnalyzing(false)
        removeAllImages()
      }

      /* Alternative (if backend only supports a single image field):
         Uncomment and use this instead of the single call above.

      try {
        const results = []
        for (const img of images) {
          const payload = { Image_Base64: img.base64 }
          if (t) payload.What_Happened = t
          if (selectedLanguage) payload.language = selectedLanguage

          const res = await fetch(ANALYZE_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          })
          if (!res.ok) throw new Error(`HTTP ${res.status}`)
          const data = await res.json()
          const r = data.What_Happened || data.what_happened || data.result || ''
          results.push(r)
        }
        const combined = results.filter(Boolean).join('\n\n')
        if (onImageResult) onImageResult(combined, t)
      } catch (err) {
        console.error('[Analyze]', err)
        if (onImageResult) onImageResult(null, t, err.message)
      } finally {
        setAnalyzing(false)
        removeAllImages()
      }
      */

    } else {
      // ── Text-only flow ──────────────────────────────────────────────────────
      if (!t) return
      setValue('')
      onSend(t)
    }
  }

  const sendDisabled = disabled || analyzing || (!value.trim() && images.length === 0)

  return (
    <div className="flex-shrink-0 border-t border-gray-200 bg-white px-3 py-2.5">
      {/* Image preview chips */}
      {images.length > 0 && (
        <div className="flex items-start gap-2 mb-2 px-1">
          <div className="flex items-center gap-2 flex-wrap">
            {images.map((img, idx) => (
              <div key={idx} className="relative flex-shrink-0">
                <img
                  src={img.preview}
                  alt=""
                  className="w-10 h-10 rounded-lg object-cover border border-gray-200"
                />
                <button
                  onClick={() => removeImageAt(idx)}
                  className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-gray-600 text-white flex items-center justify-center hover:bg-gray-800"
                >
                  <svg width="7" height="7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5">
                    <path d="M18 6L6 18M6 6l12 12"/>
                  </svg>
                </button>
              </div>
            ))}
          </div>
          <p className="text-[11.5px] text-gray-500 leading-tight">
            <span className="font-medium text-gray-700 block">
              {images.length}/{MAX_FILES} image{images.length > 1 ? 's' : ''} selected
            </span>
            Optionally add context text, then press send
          </p>
        </div>
      )}

      <div className="flex items-center gap-2">
        {/* Image upload button — only shown when allowImage is true */}
        {allowImage && (
          <>
            <button
              onClick={() => !disabled && !analyzing && fileRef.current?.click()}
              disabled={disabled || analyzing}
              title="Upload images to describe the incident"
              className={
                'flex-shrink-0 w-9 h-9 rounded-full border flex items-center justify-center transition-all disabled:opacity-40 disabled:cursor-not-allowed ' +
                (images.length ? 'border-red-400 bg-red-50 text-red-500' : 'border-gray-300 bg-white text-gray-400 hover:border-red-300 hover:text-red-400')
              }
            >
              {analyzing ? (
                <svg width="14" height="14" viewBox="0 0 24 24" style={{ animation: 'spin 0.8s linear infinite' }}>
                  <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2.5" strokeOpacity="0.2" />
                  <path d="M12 3 a9 9 0 0 1 9 9" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
                </svg>
              ) : (
                /* Image icon */
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="3" width="18" height="18" rx="2" />
                  <circle cx="8.5" cy="8.5" r="1.5" />
                  <polyline points="21 15 16 10 5 21" />
                </svg>
              )}
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handleFileChange}
            />
          </>
        )}

        {/* Text input */}
        <input
          type="text"
          value={value}
          onChange={e => setValue(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
          placeholder={
            analyzing ? 'Analysing images…' :
            images.length ? 'Add context (optional) or press send…' :
            disabled ? 'Please complete the form above…' :
            'Type your message…'
          }
          disabled={disabled || analyzing}
          className="flex-1 px-4 py-2 rounded-full border border-gray-300 bg-white text-[13px] text-gray-900 placeholder:text-gray-400 outline-none focus:border-red-400 focus:ring-2 focus:ring-red-100 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
        />

        {/* Send */}
        <button
          onClick={send}
          disabled={sendDisabled}
          className="w-9 h-9 rounded-full bg-red-500 flex items-center justify-center text-white hover:bg-red-600 transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <line x1="22" y1="2" x2="11" y2="13"/>
            <polygon points="22 2 15 22 11 13 2 9 22 2"/>
          </svg>
        </button>
      </div>
    </div>
  )
}
