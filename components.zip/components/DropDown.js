function MuiLikeSelect({ value, onChange, options = [], disabled }) {
  const [hovered, setHovered] = useState(false)
  const [focused, setFocused] = useState(false)

  const ACCENT = '#B91C1C'

  const borderColor = disabled
    ? '#E5E7EB'
    : focused
    ? ACCENT
    : hovered
    ? ACCENT
    : '#D1D5DB'

  const boxShadow = disabled
    ? 'none'
    : focused
    ? `0 0 0 3px ${ACCENT}1A`
    : hovered
    ? `0 0 0 2px ${ACCENT}0D`
    : 'none'

  return (
    <div className="relative w-full">
      <select
        value={value || ''}
        onChange={onChange}
        disabled={disabled}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        onMouseEnter={() => !disabled && setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        className="w-full appearance-none text-xs text-gray-900 rounded-lg outline-none transition-all duration-150 cursor-pointer disabled:cursor-not-allowed"
        style={{
          padding: '6px 28px 6px 10px',
          background: disabled
            ? '#F3F4F6'
            : focused || hovered
            ? '#ffffff'
            : '#F7F8FA',
          border: disabled
            ? '1.5px solid #E5E7EB'
            : focused
            ? `2px solid ${ACCENT}`
            : hovered
            ? `1.5px solid ${ACCENT}`
            : '1.5px dashed #D1D5DB',
          boxShadow,
          color: value ? '#111827' : '#9CA3AF',
        }}
      >
        <option value="">— Select —</option>
        {options.map(o => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>

      {/* arrow */}
      <svg
        className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-gray-400"
        width="12"
        height="12"
        viewBox="0 0 24 24"
      >
        <path
          d="M6 9l6 6 6-6"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
        />
      </svg>
    </div>
  )
}
``