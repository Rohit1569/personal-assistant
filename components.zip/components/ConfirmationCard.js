import { BotAvatar } from './Avatars'
import { CheckCircle2, RefreshCw } from 'lucide-react'

export default function ConfirmationCard({ refId, rawText, onReset, time }) {
  return (
    <div className="flex items-start gap-2 animate-fade-up w-full">
      <BotAvatar />
      <div style={{ flex: '1 1 0', minWidth: 0, maxWidth: '70%' }}>
        <div className="bg-white border border-green-200 rounded-2xl rounded-tl-none shadow-sm overflow-hidden">
          <div className="bg-gradient-to-r from-green-600 to-green-700 px-4 py-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 size={13} className="text-white" />
              <span className="text-white text-[12.5px] font-semibold">Report Submitted</span>
            </div>
            {refId && <span className="bg-white/20 text-white text-[10.5px] font-bold px-2.5 py-0.5 rounded-full">{refId}</span>}
          </div>
          {rawText && (
            <div className="px-4 py-2.5 text-[12.5px] text-gray-700 leading-relaxed border-b border-gray-100">{rawText}</div>
          )}
          <div className="px-4 py-2.5">
            <button onClick={onReset} className="flex items-center gap-1.5 bg-red-500 text-white text-[12px] font-semibold px-3.5 py-1.5 rounded-full hover:bg-red-600 transition-colors">
              <RefreshCw size={11} /> Report Another Event
            </button>
          </div>
        </div>
        {time && <span className="text-[10px] text-gray-400 mt-1 block">{time}</span>}
      </div>
    </div>
  )
}
