// components/FileUploadModal.jsx
'use client';

import { useState, useRef, useCallback, useEffect } from 'react';
import { generateAndUploadFile } from '../lib/GenerateUploadUrl';

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB

// Comprehensive file type mapping
const FILE_TYPE_CONFIG = {
  // Documents
  'application/pdf': { icon: '📄', label: 'PDF', category: 'document' },
  'application/msword': { icon: '📝', label: 'Word', category: 'document' },
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': { icon: '📝', label: 'Word', category: 'document' },
  'application/vnd.ms-excel': { icon: '📊', label: 'Excel', category: 'spreadsheet' },
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': { icon: '📊', label: 'Excel', category: 'spreadsheet' },
  'text/plain': { icon: '📄', label: 'Text', category: 'document' },
  'text/csv': { icon: '📊', label: 'CSV', category: 'spreadsheet' },
  'application/json': { icon: '{}', label: 'JSON', category: 'data' },
  'application/vnd.ms-powerpoint': { icon: '🎯', label: 'PowerPoint', category: 'presentation' },
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': { icon: '🎯', label: 'PowerPoint', category: 'presentation' },
  
  // Images
  'image/jpeg': { icon: '🖼️', label: 'JPEG', category: 'image' },
  'image/png': { icon: '🖼️', label: 'PNG', category: 'image' },
  'image/gif': { icon: '🖼️', label: 'GIF', category: 'image' },
  'image/webp': { icon: '🖼️', label: 'WebP', category: 'image' },
  'image/svg+xml': { icon: '🖼️', label: 'SVG', category: 'image' },
  'image/tiff': { icon: '🖼️', label: 'TIFF', category: 'image' },
  
  // Archives
  'application/zip': { icon: '📦', label: 'ZIP', category: 'archive' },
  'application/x-rar-compressed': { icon: '📦', label: 'RAR', category: 'archive' },
  'application/x-7z-compressed': { icon: '📦', label: '7Z', category: 'archive' },
  'application/gzip': { icon: '📦', label: 'GZIP', category: 'archive' },
  
  // Audio/Video
  'audio/mpeg': { icon: '🎵', label: 'MP3', category: 'media' },
  'audio/wav': { icon: '🎵', label: 'WAV', category: 'media' },
  'video/mp4': { icon: '🎬', label: 'MP4', category: 'media' },
  'video/quicktime': { icon: '🎬', label: 'MOV', category: 'media' },
};

// Extension fallback mapping
const EXTENSION_CONFIG = {
  pdf: { icon: '📄', label: 'PDF', category: 'document' },
  doc: { icon: '📝', label: 'Word', category: 'document' },
  docx: { icon: '📝', label: 'Word', category: 'document' },
  xls: { icon: '📊', label: 'Excel', category: 'spreadsheet' },
  xlsx: { icon: '📊', label: 'Excel', category: 'spreadsheet' },
  csv: { icon: '📊', label: 'CSV', category: 'spreadsheet' },
  txt: { icon: '📄', label: 'Text', category: 'document' },
  json: { icon: '{}', label: 'JSON', category: 'data' },
  ppt: { icon: '🎯', label: 'PowerPoint', category: 'presentation' },
  pptx: { icon: '🎯', label: 'PowerPoint', category: 'presentation' },
  jpg: { icon: '🖼️', label: 'JPEG', category: 'image' },
  jpeg: { icon: '🖼️', label: 'JPEG', category: 'image' },
  png: { icon: '🖼️', label: 'PNG', category: 'image' },
  gif: { icon: '🖼️', label: 'GIF', category: 'image' },
  webp: { icon: '🖼️', label: 'WebP', category: 'image' },
  svg: { icon: '🖼️', label: 'SVG', category: 'image' },
  zip: { icon: '📦', label: 'ZIP', category: 'archive' },
  rar: { icon: '📦', label: 'RAR', category: 'archive' },
  '7z': { icon: '📦', label: '7Z', category: 'archive' },
  mp3: { icon: '🎵', label: 'MP3', category: 'media' },
  wav: { icon: '🎵', label: 'WAV', category: 'media' },
  mp4: { icon: '🎬', label: 'MP4', category: 'media' },
  mov: { icon: '🎬', label: 'MOV', category: 'media' },
  xml: { icon: '{}', label: 'XML', category: 'data' },
  sql: { icon: '🗄️', label: 'SQL', category: 'data' },
  rtf: { icon: '📝', label: 'RTF', category: 'document' },
  odt: { icon: '📝', label: 'ODT', category: 'document' },
  ods: { icon: '📊', label: 'ODS', category: 'spreadsheet' },
  odp: { icon: '🎯', label: 'ODP', category: 'presentation' },
};

const getFileTypeInfo = (file) => {
  // Try MIME type first
  if (file.type && FILE_TYPE_CONFIG[file.type]) {
    return FILE_TYPE_CONFIG[file.type];
  }

  // Fallback to extension
  const extension = file.name.split('.').pop().toLowerCase();
  if (EXTENSION_CONFIG[extension]) {
    return EXTENSION_CONFIG[extension];
  }

  // Default for unknown types
  return { icon: '📎', label: 'File', category: 'other' };
};

export default function FileUploadModal({ 
  isOpen, 
  onClose, 
  session, 
  onFileUpload, 
  onComplete,
  isLocked = false 
}) {
  const fileInputRef = useRef(null);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const [uploadProgress, setUploadProgress] = useState({});
  const [uploadedFilesList, setUploadedFilesList] = useState([]);
  const [dragActive, setDragActive] = useState(false);

  console.log('🎨 [FileUploadModal] Rendering. Session:', session, 'IsOpen:', isOpen);

  // Handle file selection (add to queue)
  const handleFileSelect = (e) => {
    console.log('📁 [FileUploadModal] handleFileSelect triggered');
    
    const newFiles = e.target.files;
    
    if (!newFiles || newFiles.length === 0) {
      console.log('⚠️ [FileUploadModal] No files selected');
      return;
    }

    processFiles(Array.from(newFiles));
    e.target.value = '';
  };

  // Process files (used by both file input and drag-drop)
  const processFiles = (filesArray) => {
    console.log('📁 [FileUploadModal] Files to process:', filesArray.map(f => f.name));
    
    const validFiles = [];
    let hasError = false;

    for (const file of filesArray) {
      // Validate file size
      if (file.size > MAX_FILE_SIZE) {
        setUploadError(`File "${file.name}" exceeds 10 MB limit`);
        hasError = true;
        break;
      }

      // Check if file already exists
      if (selectedFiles.some(f => f.name === file.name)) {
        setUploadError(`File "${file.name}" is already added`);
        hasError = true;
        break;
      }

      validFiles.push({
        file,
        id: `${file.name}-${Date.now()}-${Math.random()}`,
        name: file.name,
        size: file.size,
        status: 'pending',
        type: file.type
      });
    }

    if (!hasError) {
      setUploadError(null);
      setSelectedFiles(prev => [...prev, ...validFiles]);
      console.log('✅ [FileUploadModal] Files added. Total:', selectedFiles.length + validFiles.length);
    }
  };

  // Drag and drop handlers
  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (uploading || isLocked) return;

    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processFiles(Array.from(files));
    }
  };

  // Upload files one by one
  const handleUpload = useCallback(async () => {
    console.log('🚀 [FileUploadModal] handleUpload triggered');
    console.log('🚀 [FileUploadModal] Session:', session);
    console.log('🚀 [FileUploadModal] Files to upload:', selectedFiles.length);

    if (!session) {
      setUploadError('Session ID is missing');
      console.error('❌ [FileUploadModal] Session ID is missing');
      return;
    }

    if (selectedFiles.length === 0) {
      console.log('⚠️ [FileUploadModal] No files to upload');
      return;
    }

    try {
      setUploading(true);
      setUploadError(null);
      setUploadProgress({});
      setUploadedFilesList([]);

      const totalFiles = selectedFiles.length;
      const successfulUploads = [];

      for (let i = 0; i < totalFiles; i++) {
        const fileItem = selectedFiles[i];
        const { file, id, name } = fileItem;

        console.log(`📤 [FileUploadModal] Uploading ${i + 1}/${totalFiles}: ${name}`);

        try {
          // Update progress
          setUploadProgress(prev => ({
            ...prev,
            [id]: { status: 'uploading', progress: 0, name }
          }));

          // Upload file
          const uploadResult = await generateAndUploadFile(file, session);

          console.log(`✅ [FileUploadModal] Upload success:`, uploadResult);

          const fileData = {
            fileName: name,
            s3Key: uploadResult.s3_key,
            uploadUrl: uploadResult.upload_url,
            uploadedAt: new Date().toISOString(),
            size: file.size,
            type: file.type,
            id
          };

          successfulUploads.push(fileData);

          // Mark as completed
          setUploadProgress(prev => ({
            ...prev,
            [id]: { status: 'completed', progress: 100, name }
          }));

          // Notify parent about individual file
          if (onFileUpload) {
            onFileUpload(fileData);
          }

          // Delay between uploads
          await new Promise(resolve => setTimeout(resolve, 300));

        } catch (err) {
          console.error(`❌ [FileUploadModal] Upload failed for ${name}:`, err);
          
          setUploadProgress(prev => ({
            ...prev,
            [id]: { status: 'failed', progress: 0, name, error: err.message }
          }));

          setUploadError(`Failed to upload "${name}": ${err.message}`);
        }
      }

      // Store uploaded files
      setUploadedFilesList(successfulUploads);
      setSelectedFiles([]);

      // Notify completion
      if (onComplete) {
        console.log(`📢 [FileUploadModal] Calling onComplete with ${successfulUploads.length} files`);
        onComplete(successfulUploads);
      }

    } catch (err) {
      console.error('[FileUploadModal] Upload error:', err);
      setUploadError(err.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  }, [selectedFiles, session, onFileUpload, onComplete]);

  // Remove file from queue
  const handleRemoveFile = (id) => {
    setSelectedFiles(prev => prev.filter(f => f.id !== id));
  };

  // Clear all
  const handleClear = () => {
    setSelectedFiles([]);
    setUploadError(null);
    setUploadProgress({});
    setUploadedFilesList([]);
  };

  // Close modal
  const handleClose = () => {
    if (!uploading) {
      handleClear();
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-40 backdrop-blur-sm transition-opacity"
        onClick={handleClose}
      />

      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl overflow-hidden">
          
          {/* Header */}
          <div className="bg-gradient-to-r from-red-600 to-red-700 px-8 py-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z" />
              </svg>
              <h2 className="text-xl font-semibold text-white">Attach Document</h2>
            </div>
            <button
              onClick={handleClose}
              disabled={uploading}
              className="text-white hover:bg-red-700 p-2 rounded-lg transition-colors disabled:opacity-50"
            >
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z" />
              </svg>
            </button>
          </div>

          {/* Content */}
          <div className="p-8 space-y-6 min-h-80 max-h-96 overflow-y-auto">
            <style jsx>{`
              @keyframes spin {
                to {
                  transform: rotate(360deg);
                }
              }
              
              .scrollbar-hide::-webkit-scrollbar {
                display: none;
              }
              
              .scrollbar-hide {
                -ms-overflow-style: none;
                scrollbar-width: none;
              }
            `}</style>

            {/* Upload Area */}
            <div className="space-y-4">
              <label className="block">
                <div 
                  className={`relative transition-all duration-200 ${
                    dragActive 
                      ? 'bg-red-100 border-red-500' 
                      : 'bg-red-50 border-red-300 hover:border-red-500'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    className="hidden"
                    onChange={handleFileSelect}
                    disabled={uploading || isLocked}
                  />
                  
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                    className="w-full px-6 py-4 border-2 border-dashed border-inherit rounded-lg hover:bg-red-100 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <div className="flex flex-col items-center gap-2">
                      <svg className="w-8 h-8 text-red-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                        <polyline points="17 8 12 3 7 8" />
                        <line x1="12" y1="3" x2="12" y2="15" />
                      </svg>
                      <div>
                        <p className="text-sm font-semibold text-red-600">Click to upload or drag and drop</p>
                        <p className="text-xs text-gray-500">All file types supported (Max 10 MB)</p>
                      </div>
                    </div>
                  </button>
                </div>
              </label>
              
              {/* <div className="grid grid-cols-2 gap-2 text-xs text-gray-600 bg-gray-50 p-3 rounded-lg">
                <div>
                  <p className="font-semibold text-gray-700 mb-1">Documents:</p>
                  <p>PDF, DOC, DOCX, XLS, XLSX, CSV, TXT, JSON</p>
                </div>
                <div>
                  <p className="font-semibold text-gray-700 mb-1">Media & Other:</p>
                  <p>Images (JPG, PNG, GIF), Archives (ZIP, RAR), Audio/Video</p>
                </div>
              </div> */}
            </div>

            {/* Error Message */}
            {uploadError && (
              <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
                <svg className="w-5 h-5 text-red-600 shrink-0 mt-0.5" viewBox="0 0 24 24" fill="currentColor">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="8" x2="12" y2="12" stroke="white" strokeWidth="2" />
                  <line x1="12" y1="16" x2="12.01" y2="16" stroke="white" strokeWidth="2" />
                </svg>
                <p className="text-sm text-red-600">{uploadError}</p>
              </div>
            )}

            {/* Files List */}
            {selectedFiles.length > 0 || uploadedFilesList.length > 0 ? (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-gray-700">
                  {uploadedFilesList.length > 0 ? 'Uploaded Files' : 'Selected Files'}
                </h3>
                
                <div className="space-y-2 scrollbar-hide">
                  {/* Selected Files */}
                  {selectedFiles.map((fileItem) => {
                    const fileInfo = getFileTypeInfo(fileItem.file);
                    return (
                      <div
                        key={fileItem.id}
                        className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-gray-100 border border-gray-200 rounded-lg hover:shadow-md transition-all"
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className="p-2 bg-red-100 rounded-lg shrink-0 text-lg">
                            {fileInfo.icon}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">
                              {fileItem.name}
                            </p>
                            <div className="flex items-center gap-2 text-xs text-gray-500">
                              <span>{fileInfo.label}</span>
                              <span>•</span>
                              <span>{(fileItem.size / 1024).toFixed(2)} KB</span>
                            </div>
                          </div>
                        </div>

                        {/* Upload Progress or Remove Button */}
                        {uploading && uploadProgress[fileItem.id] ? (
                          <div className="flex items-center gap-3 ml-4 shrink-0">
                            {uploadProgress[fileItem.id].status === 'uploading' && (
                              <>
                                <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-gradient-to-r from-red-500 to-red-600 transition-all duration-300"
                                    style={{ width: `${uploadProgress[fileItem.id].progress}%` }}
                                  />
                                </div>
                                <span className="text-xs font-medium text-gray-600 w-10 text-right">
                                  {uploadProgress[fileItem.id].progress}%
                                </span>
                              </>
                            )}
                            {uploadProgress[fileItem.id].status === 'completed' && (
                              <div className="flex items-center gap-2">
                                <svg className="w-5 h-5 text-green-600" viewBox="0 0 24 24" fill="currentColor">
                                  <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
                                </svg>
                                <span className="text-xs text-green-600 font-medium">Done</span>
                              </div>
                            )}
                            {uploadProgress[fileItem.id].status === 'failed' && (
                              <div className="flex items-center gap-2">
                                <svg className="w-5 h-5 text-red-600" viewBox="0 0 24 24" fill="currentColor">
                                  <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z" />
                                </svg>
                                <span className="text-xs text-red-600 font-medium">Failed</span>
                              </div>
                            )}
                          </div>
                        ) : (
                          <button
                            onClick={() => handleRemoveFile(fileItem.id)}
                            disabled={uploading}
                            className="ml-4 p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50 shrink-0"
                            title="Remove file"
                          >
                            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z" />
                            </svg>
                          </button>
                        )}
                      </div>
                    );
                  })}

                  {/* Uploaded Files */}
                  {uploadedFilesList.map((fileItem) => {
                    const fileInfo = getFileTypeInfo({ name: fileItem.fileName, type: fileItem.type });
                    return (
                      <div
                        key={fileItem.id}
                        className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-green-100 border border-green-200 rounded-lg"
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className="p-2 bg-green-200 rounded-lg shrink-0 text-lg">
                            {fileInfo.icon}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">
                              {fileItem.fileName}
                            </p>
                            <div className="flex items-center gap-2 text-xs text-gray-500">
                              <span>{fileInfo.label}</span>
                              <span>•</span>
                              <span>{(fileItem.size / 1024).toFixed(2)} KB</span>
                            </div>
                          </div>
                        </div>
                        <span className="ml-4 text-xs font-semibold text-green-700 shrink-0">Uploaded</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z" />
                </svg>
                <p className="text-gray-500 text-sm font-medium">No files selected</p>
                <p className="text-gray-400 text-xs mt-1">Upload files to get started</p>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end gap-3 px-8 py-5 border-t border-gray-100 bg-gray-50">
            <button
              onClick={handleClear}
              disabled={uploading || (selectedFiles.length === 0 && uploadedFilesList.length === 0)}
              className="px-6 py-2.5 text-sm font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-200 rounded-lg transition-colors disabled:text-gray-400 disabled:cursor-not-allowed disabled:hover:bg-transparent"
            >
              Clear
            </button>
            <button
              onClick={handleClose}
              disabled={uploading}
              className="px-6 py-2.5 text-sm font-medium text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Cancel
            </button>
            <button
              onClick={handleUpload}
              disabled={uploading || selectedFiles.length === 0}
              className="px-8 py-2.5 text-sm font-semibold text-white bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 rounded-lg disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-200 flex items-center gap-2 shadow-lg hover:shadow-xl"
            >
              {uploading ? (
                <>
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    style={{ animation: 'spin 0.8s linear infinite' }}
                  >
                    <circle
                      cx="12"
                      cy="12"
                      r="9"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeOpacity="0.2"
                    />
                    <path
                      d="M12 3 a9 9 0 0 1 9 9"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                    />
                  </svg>
                  Uploading...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
                  </svg>
                  Upload
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
