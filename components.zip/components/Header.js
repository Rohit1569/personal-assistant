// components/Header.jsx
'use client';

import { useEffect, useState, useRef } from 'react';
import LanguageSelector from './LanguageSelector';

export default function Header({
  onReset,
  profile,
  open,
  setOpen,
  containerRef,
  onLogout,
  selectedLanguage,
  onLanguageChange,
  // hides Clear, Report New Event, and Language controls
  hideActions = false,
}) {
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false);
  const languageDropdownRef = useRef(null);

  // Support controlled or uncontrolled menu state
  const [internalOpen, setInternalOpen] = useState(false);
  const isControlled = typeof open === 'boolean' && typeof setOpen === 'function';
  const menuOpen = isControlled ? open : internalOpen;
  const setMenuOpen = isControlled ? setOpen : setInternalOpen;

  const containerElRef = containerRef ?? useRef(null);

  // Compute initials safely
  const initials = (() => {
    if (!profile) return '';
    const a = profile.firstName?.[0] ?? '';
    const b = profile.lastName?.[0] ?? '';
    if (a || b) return `${a}${b}`.toUpperCase();
    const parts = (profile?.displayName || '').split(/\s+/).filter(Boolean);
    if (parts.length) return parts.map((p) => p[0]).slice(0, 2).join('').toUpperCase();
    return 'U';
  })();

  useEffect(() => {
    function onKey(e) {
      if (e.key === 'Escape') {
        setMenuOpen(false);
        setShowLanguageDropdown(false);
      }
    }
    function onClickOutside(e) {
      if (languageDropdownRef.current && !languageDropdownRef.current.contains(e.target)) {
        setShowLanguageDropdown(false);
      }
    }
    window.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onClickOutside);
    return () => {
      window.removeEventListener('keydown', onKey);
      document.removeEventListener('mousedown', onClickOutside);
    };
  }, [setMenuOpen]);

  const handleLogin = () => {
    try {
      sessionStorage.removeItem('justLoggedOut');
    } catch {}
    window.location.reload();
  };

  // Show profile menu whenever profile is present
  const showProfile = !!profile;

  return (
    <header className="flex-shrink-0 h-12 bg-red-500 flex items-center justify-between px-4 shadow-sm z-20">
      <div className="bg-white rounded-md px-3 py-1 flex items-center h-8">
        <span className="text-red-500 font-bold text-sm leading-none tracking-tight select-none">
          Johnson & Johnson
        </span>
      </div>

      <div className="flex items-center gap-2">
        {!hideActions && (
          <>
            <button
              onClick={onReset}
              className="bg-white text-gray-900 text-xs font-semibold px-4 py-1.5 rounded-full hover:bg-red-50 active:scale-95 transition-all shadow-sm"
            >
              Clear
            </button>

            <button
              onClick={onReset}
              className="bg-white text-gray-900 text-xs font-semibold px-4 py-1.5 rounded-full hover:bg-red-50 active:scale-95 transition-all shadow-sm"
            >
              Report New Event
            </button>

            <div ref={languageDropdownRef} className="relative">
              <button
                onClick={() => setShowLanguageDropdown((s) => !s)}
                className="bg-white text-gray-900 text-xs font-semibold px-4 py-1.5 rounded-full hover:bg-red-50 active:scale-95 transition-all shadow-sm flex items-center gap-2"
                title="Change language"
              >
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <circle cx="12" cy="12" r="10" />
                  <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                  <path d="M2 12h20" />
                </svg>
                {selectedLanguage || 'English'}
              </button>

              {showLanguageDropdown && (
                <div className="absolute right-0 mt-2 w-56 bg-white border border-gray-200 rounded-lg shadow-lg z-50 max-h-96 overflow-y-auto">
                  <div className="p-3">
                    <LanguageSelector
                      onLanguageSelect={(lang) => {
                        onLanguageChange?.(lang);
                        setShowLanguageDropdown(false);
                      }}
                      isModal={false}
                    />
                  </div>
                </div>
              )}
            </div>
          </>
        )}

        {showProfile ? (
          <div ref={containerElRef} className="relative ml-2">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              aria-expanded={menuOpen}
              aria-haspopup="true"
              className="w-9 h-9 rounded-full bg-white flex items-center justify-center text-red-600 font-semibold select-none shadow-sm hover:brightness-95 transition"
              title={`${profile.firstName || ''} ${profile.lastName || ''}`.trim()}
            >
              {initials}
            </button>

            <div
              className={`origin-top-right absolute right-0 mt-2 w-56 rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 transform transition ease-out duration-150 ${
                menuOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'
              } z-30`}
              role="menu"
              aria-hidden={!menuOpen}
            >
              <div className="px-4 py-3">
                <p className="text-sm font-semibold text-gray-900 truncate">
                  {profile.firstName} {profile.lastName}
                </p>
                <p className="mt-1 text-xs text-gray-600 truncate">
                  {profile.email}
                </p>
                <div className="mt-3 border-t pt-3">
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onLogout?.();
                    }}
                    className="w-full text-left text-xs text-red-600 font-medium hover:bg-red-50 px-2 py-1.5 rounded transition-colors"
                  >
                    Logout
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <button
            onClick={handleLogin}
            className="bg-white text-red-600 text-xs font-semibold px-4 py-1.5 rounded-full hover:bg-red-50 active:scale-95 transition-all shadow-sm"
          >
            Login
          </button>
        )}
      </div>
    </header>
  );
}
