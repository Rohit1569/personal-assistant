export function BotAvatar() {
  return (
    <div className="w-7 h-7 rounded-full border border-red-300 bg-white flex items-center justify-center flex-shrink-0 shadow-sm">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#EB1700" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="8" width="18" height="13" rx="2"/>
        <path d="M8 8V6a4 4 0 0 1 8 0v2"/>
        <circle cx="9" cy="14" r="1" fill="#EB1700" stroke="none"/>
        <circle cx="15" cy="14" r="1" fill="#EB1700" stroke="none"/>
        <path d="M9.5 17.5h5"/>
      </svg>
    </div>
  )
}

export function UserAvatar() {
  return (
    <div className="w-7 h-7 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0 shadow-sm">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
        <circle cx="12" cy="7" r="4"/>
      </svg>
    </div>
  )
}
