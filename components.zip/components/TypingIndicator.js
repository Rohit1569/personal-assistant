'use client'
import { useEffect, useState } from 'react'
import { BotAvatar } from './Avatars'

const MSGS = [
  'Analysing your description…',
  'Checking historical records…',
  'Classifying event type…',
  'Fetching site data…',
  'Pre-filling from your reports…',
  'Generating report…',
  'Almost ready…',
  'Working on this…',
]

export default function TypingIndicator({ loaderText }) {
  const [i, setI] = useState(0)
  useEffect(() => {
    if (loaderText) return
    const t = setInterval(() => setI(n => (n + 1) % MSGS.length), 1800)
    return () => clearInterval(t)
  }, [loaderText])

  return (
    <div className="flex items-center gap-2 animate-fade-up">
      <BotAvatar />
      <div className="flex items-center gap-2.5 bg-white border border-red-200 rounded-2xl rounded-tl-none px-3.5 py-2 shadow-sm">
        <div className="flex gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-dot-1" />
          <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-dot-2" />
          <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-dot-3" />
        </div>
        <span key={loaderText || i} className="text-[11.5px] text-gray-500 font-medium animate-fade-up">
          {loaderText || MSGS[i]}
        </span>
      </div>
    </div>
  )
}
