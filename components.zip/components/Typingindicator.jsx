'use client'
 
import { useState, useEffect } from 'react'

import { BotAvatar } from './Avatars'
 
// Rotating messages shown while waiting for backend

const MESSAGES = [

  'Thinking…',

  'Fetching details…',

  'Processing your input…',

  'Analysing your request…',

  'Preparing response…',

  'Almost there…',

]
 
export default function TypingIndicator() {

  const [msgIndex, setMsgIndex] = useState(0)

  const [fade,     setFade]     = useState(true)
 
  useEffect(() => {

    // Cycle through messages every 2.5s with a fade transition

    const interval = setInterval(() => {

      setFade(false)

      setTimeout(() => {

        setMsgIndex(i => (i + 1) % MESSAGES.length)

        setFade(true)

      }, 300)

    }, 2500)

    return () => clearInterval(interval)

  }, [])
 
  return (
<div className="flex items-center gap-2">
<BotAvatar />
<div

        className="flex items-center gap-2.5 bg-white border border-gray-200 rounded-2xl rounded-tl-none px-4 py-2.5 shadow-sm"

        style={{ minWidth: 160 }}
>

        {/* Animated dots */}
<div className="flex items-center gap-1">

          {[0, 1, 2].map(i => (
<span

              key={i}

              className="block w-1.5 h-1.5 rounded-full bg-red-400"

              style={{

                animation: 'typingBounce 1.2s ease-in-out infinite',

                animationDelay: `${i * 180}ms`,

              }}

            />

          ))}
</div>
 
        {/* Rotating status text */}
<span

          className="text-xs text-gray-500 font-medium select-none"

          style={{

            opacity: fade ? 1 : 0,

            transition: 'opacity 0.3s ease',

          }}
>

          {MESSAGES[msgIndex]}
</span>
</div>
 
      <style>{`

        @keyframes typingBounce {

          0%, 60%, 100% { transform: translateY(0);    opacity: 0.35; }

          30%            { transform: translateY(-4px); opacity: 1;    }

        }

      `}</style>
</div>

  )

}
 