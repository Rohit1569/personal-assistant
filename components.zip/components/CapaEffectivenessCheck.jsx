// components/CapaEffectivenessCheck.jsx

"use client";

import FieldInput from "@/components/FieldInput";
import OnBehalfOfDropdown from "@/components/EmployeeSearchDropdown";

export default function CapaEffectivenessCheck({ values, setValue }) {
  // Compute warning visibility for timeline > 12 months
  const monthsRaw = values?.capaEcTimelineMonths ?? "";
  const monthsNum = Number(
    typeof monthsRaw === "number" ? monthsRaw : String(monthsRaw).trim()
  );
  const showTimelineWarning = Number.isFinite(monthsNum) && monthsNum > 12;

  const detailsFields = [
    {
      key: "capaEcDescription",
      label:
        "Detailed description/steps for the CAPA effectiveness check plan. Include criteria for success.",
      type: "textarea",
      required: true,
    },
    {
      key: "capaEcPersonResponsible",
      label: "Effectiveness Check Person Responsible",
      type: "personResponsibleSearch",
      required: true,
    },
    {
      key: "capaEcApprover",
      label: "Effectiveness Check Approver",
      type: "approverSearch",
      required: true,
    },
    {
      key: "capaEcTimelineMonths",
      label: "Effectiveness Check Timeline (Months)",
      type: "text",
      required: true,
      inputMode: "numeric", // helps mobile numeric keyboard
      pattern: "[0-9]*",    // restricts to numerals
      placeholder: "Enter months",
    },
  ];

  const completionFields = [
    {
      key: "capaEcDueDate",
      label: "Effectiveness Check Due Date",
      type: "date",
      required: false,
    },
    {
      key: "capaEcResultComments",
      label: "CAPA effectiveness check Result Comments",
      type: "textarea",
      required: false,
    },
    {
      key: "capaEcIsEffective",
      label: "CAPA(s) Effective?",
      type: "readonly",
      required: false,
    },
  ];

  const approvalFields = [
    {
      key: "capaEcApproverComments",
      label: "CAPA Effectiveness Check Approver Comments",
      type: "textarea",
      required: false,
    },
  ];

  // Helper function to render fields with dropdown support
  const renderField = (field) => {
    // Handle Person Responsible Search Dropdown
    if (field.type === "personResponsibleSearch") {
      return (
        <div
          key={field.key}
          className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start gap-4"
        >
          <div className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
            {field.label}
            {field.required && (
              <span className="ml-1 text-red-500">*</span>
            )}
          </div>
          <div className="px-2 py-1 min-w-0">
            <OnBehalfOfDropdown
              value={values[field.key] ?? ""}
              onSelect={(personName) => setValue(field.key, personName)}
            />
          </div>
        </div>
      );
    }

    // Handle Approver Search Dropdown
    if (field.type === "approverSearch") {
      return (
        <div
          key={field.key}
          className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start gap-4"
        >
          <div className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
            {field.label}
            {field.required && (
              <span className="ml-1 text-red-500">*</span>
            )}
          </div>
          <div className="px-2 py-1 min-w-0">
            <OnBehalfOfDropdown
              value={values[field.key] ?? ""}
              onSelect={(approverName) => setValue(field.key, approverName)}
            />
          </div>
        </div>
      );
    }

    // Special handling: timeline months field + warning below it
    if (field.key === "capaEcTimelineMonths") {
      return (
        <div key={field.key}>
          <FieldInput
            field={field}
            value={values[field.key] ?? ""}
            onChange={setValue}
          />
          {showTimelineWarning && (
            <div className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start">
              <span></span>
              <div className="px-2 py-1">
                <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
                  Please note that you are selecting a time to complete the CAPA effectiveness check &gt; 12 months. This is beyond the required CAPA Effectiveness check timeline. This should only be used when absolutely needed, it will be flagged in dashboards.
                </div>
              </div>
            </div>
          )}
        </div>
      );
    }

    // Handle all other field types via FieldInput
    return (
      <FieldInput
        key={field.key}
        field={field}
        value={values[field.key] ?? ""}
        onChange={setValue}
      />
    );
  };

  return (
    <div className="mt-8 space-y-6">
      {/* Header & Description */}
      <div className="border-t pt-6">
        <h3 className="text-base font-semibold text-gray-900 flex items-center gap-2">
          <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-blue-100 text-blue-600 text-xs font-bold">
            i
          </span>
        </h3>
        <p className="mt-2 text-sm text-gray-600 leading-relaxed">
          CAPA Effectiveness Check (CEC) is a process used to evaluate, confirm and document whether corrective actions taken were implemented effectively, and successfully resolved the root cause of an observed event, non-conformity, hazard, or undesirable situation and the likelihood of recurring/repeating were reduced and/or eliminated, measured over a defined period of time. This involves assessing the outcome of the actions implemented, analyzing data, and determining if the underlying root causes have been adequately addressed. The goal is to ensure that the corrective/preventive action(s) led to lasting improvements and compliance and did not introduce new hazard(s).
        </p>
      </div>

      {/* CAPA Effectiveness Check Details */}
      <div className="border rounded-lg p-4">
        <h4 className="text-sm font-semibold text-gray-900 flex items-center gap-2 mb-1">
          <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-blue-100 text-blue-600 text-xs font-bold">
            i
          </span>
          CAPA Effectiveness Check Details
        </h4>
        <p className="text-xs text-gray-500 mb-4">
          The below fields are required to be entered in the review stage, when no investigation is required/desired. If investigation is required/desired, those fields can be entered during the investigation stage.
        </p>
        <div className="space-y-4">
          {detailsFields.map((f) => renderField(f))}
        </div>
      </div>

      {/* CAPA Effectiveness Check Completion */}
      <div className="border rounded-lg p-4">
        <h4 className="text-sm font-semibold text-gray-900 flex items-center gap-2 mb-4">
          <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-blue-100 text-blue-600 text-xs font-bold">
            i
          </span>
          CAPA Effectiveness Check Completion
        </h4>
        <div className="space-y-4">
          {completionFields.map((f) => renderField(f))}
        </div>
      </div>

      {/* CAPA Effectiveness Check Approval */}
      <div className="border rounded-lg p-4">
        <h4 className="text-sm font-semibold text-gray-900 flex items-center gap-2 mb-4">
          <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-blue-100 text-blue-600 text-xs font-bold">
            i
          </span>
          CAPA Effectiveness Check Approval
        </h4>
        <div className="space-y-4">
          {approvalFields.map((f) => renderField(f))}
        </div>
      </div>
    </div>
  );
}
