export default function CheckboxGroups({ groups, selected, onToggle }) {
  return (
    <div className="space-y-6">
      {groups.map((g) => (
        <div key={g.group} className="grid grid-cols-1 gap-x-6 gap-y-3 sm:grid-cols-[minmax(0,220px)_1fr]">
          <p className="text-sm font-semibold text-jnj-ink/80">{g.group}</p>
          <div className="grid grid-cols-1 gap-x-6 gap-y-2 sm:grid-cols-2 lg:grid-cols-3">
            {g.items.map((item) => {
              const checked = selected.has(item);
              return (
                <label key={item} className="flex cursor-pointer items-start gap-2 text-sm text-jnj-ink/90">
                  <input type="checkbox" checked={checked} onChange={() => onToggle(item)} className="mt-0.5 h-4 w-4 flex-shrink-0 rounded accent-jnj-red" />
                  <span className={checked ? "font-medium text-jnj-ink" : ""}>{item}</span>
                </label>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
