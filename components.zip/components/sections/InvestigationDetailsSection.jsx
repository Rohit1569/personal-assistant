"use client";

import { useEffect, useMemo, useState } from "react";

import SectionCard from "@/components/SectionCard";
import FieldInput from "@/components/FieldInput";
import { getIncidentData } from "@/lib/intelApi";
import { useTranslation } from "@/lib/i18n";
import { datePart, toLocalDateString } from "@/lib/investigationValidation";

export default function InvestigationDetailsSection({
  index,
  values,
  setValue,
  eventId,
  preloadedData,
  errors = {},
}) {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const today = toLocalDateString();
  const eventDate = datePart(values?.dateOfEvent);

  const fields = useMemo(
    () => [
      {
        key: "invDueDate",
        label: t("investigation.fields.dueDate"),
        type: "readonly",
      },
      {
        key: "invStartDate",
        label: t("investigation.fields.startDate"),
        type: "date",
        required: true,
        min: eventDate || undefined,
        max: today,
      },
      {
        key: "invEndDate",
        label: t("investigation.fields.endDate"),
        type: "date",
        required: true,
        max: today,
      },
      {
        key: "investigatedBy",
        label: t("investigation.fields.investigatedBy"),
        type: "readonly",
      },
      {
        key: "invTeam",
        label: t("investigation.fields.team"),
         required: true,
        type: "textarea",
        rows: 2,
      },
      {
        key: "sequenceEvents",
        label: t("investigation.fields.sequenceOfEvents"),
         required: true,
        type: "textarea",
        rows: 3,
      },
      {
        key: "investigatorSummary",
        label: t("investigation.fields.investigatorSummary"),
         required: true,
        type: "textarea",
        rows: 3,
      },
      {
        key: "invComments",
        label: t("investigation.fields.comments"),
        type: "textarea",
        rows: 2,
      },
      {
        key: "defaultApprover",
        label: t("investigation.fields.defaultApprover"),
        type: "readonly",
      },
    ],
    [t, eventDate, today]
  );

  const formatDate = (value) => {
    if (!value) return "";

    try {
      return new Date(value)
        .toISOString()
        .split("T")[0];
    } catch {
      return value;
    }
  };

  const loadInvestigationDetails = async (recordOverride) => {
    try {
      setLoading(true);

      const record = recordOverride !== undefined
        ? recordOverride
        : await getIncidentData(eventId, [
          "InvestDueDate",
          "StartofInvest",
          "EndofInvest",
          "InveTeamMembers",
          "SequencofEvents",
          "InvstigtrSumary",
          "InvestComments",
        ],
        [
          "Investigator($select=Name)",
          "DefaultApprover($select=Value)",
        ]);

      if (!record) return;

      const fieldMap = {
        invDueDate: formatDate(
          record.InvestDueDate
        ),

        invStartDate: formatDate(
          record.StartofInvest
        ),

        invEndDate: formatDate(
          record.EndofInvest
        ),

        investigatedBy:
          record.Investigator?.Name ?? "",

        invTeam:
          record.InveTeamMembers ?? "",

        sequenceEvents:
          record.SequencofEvents ?? "",

        investigatorSummary:
          record.InvstigtrSumary ?? "",

        invComments:
          record.InvestComments ?? "",

        defaultApprover:
          record.DefaultApprover?.Value ?? "",
      };

      Object.entries(fieldMap).forEach(
        ([key, value]) => {
          setValue(key, value ?? "");
        }
      );
    } catch (error) {
      console.error(
        "Investigation Details Error:",
        error
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!eventId) return;

    loadInvestigationDetails(preloadedData);
  }, [eventId, preloadedData]);

  return (
    <SectionCard
      anchorId="investigation-details"
      index={index}
      title={t("investigation.title")}
      note={t("investigation.note")}
      status="complete"
    >
      {loading && (
        <div className="mb-4 text-sm text-slate-500">
          {t("investigation.loading")}
        </div>
      )}

      <div className="space-y-4">
        {fields.map((field) => (
          <FieldInput
            key={field.key}
            field={errors[field.key] ? { ...field, error: t(errors[field.key]) } : field}
            value={values[field.key] ?? ""}
            onChange={setValue}
          />
        ))}
      </div>
    </SectionCard>
  );
}
