"use client";

import { useEffect, useMemo, useState } from "react";

import SectionCard from "@/components/SectionCard";
import SubformTable from "@/components/SubformTable";
import { getRootCauses } from "@/lib/rootCauseApi";
import RootCauseModal from "@/components/modals/RootCauseModal";

export default function CausesSection({
  index,
  eventId,          // This should be Event.RecordNo
  preloadedData,
  onSectionDataChange,
}) {
  const [loading, setLoading] = useState(false);

  // Server rows mapped for table display
  const [rows, setRows] = useState([]);

  // Selection and archiving controls
  const [selectedKeys, setSelectedKeys] = useState(new Set());
  const [archivedKeys, setArchivedKeys] = useState(new Set());
  const [showAll, setShowAll] = useState(false);
  const [notice, setNotice] = useState(null);

  // Modal state + instance to force remount on open
  const [modal, setModal] = useState({ open: false, mode: "add", recordNo: null, instance: 0 });

  // Filters (only the displayed fields)
  const [filters, setFilters] = useState({
    recordNo: "",         // now filters by cause RecordNo
    behaviorCause: "",
    conditionCause: "",
    systemCause: "",
  });

  // Only these four columns in this exact order
  const columns = [
    { key: "recordNo", label: "Record No." },                      // cause RecordNo
    { key: "behaviorCause", label: "BASIC - Behaviors Causes" },
    { key: "conditionCause", label: "BASIC - Conditions Causes" },
    { key: "systemCause", label: "System Causes" },
  ];

  const getValues = (items = []) =>
    items
      .map((item) => item?.Value)
      .filter(Boolean)
      .join(", ");

  // Normalize OData/array responses
  const toArrayFromOData = (res) => {
    if (Array.isArray(res)) return res;
    if (res && Array.isArray(res.value)) return res.value;
    return [];
  };

  // Ensure filters are strings
  const sanitizeFilters = (f) => ({
    recordNo: String(f?.recordNo ?? "").trim(),
    behaviorCause: String(f?.behaviorCause ?? "").trim(),
    conditionCause: String(f?.conditionCause ?? "").trim(),
    systemCause: String(f?.systemCause ?? "").trim(),
  });

  const loadRootCauses = async (recordsOverride) => {
    if (!eventId) return;
    try {
      setLoading(true);

      const apiResult =
        recordsOverride !== undefined
          ? recordsOverride
          : await getRootCauses(eventId, sanitizeFilters(filters));

      const records = toArrayFromOData(apiResult);

      const mappedRows = (records || []).map((row, i) => {
        // Use cause RecordNo, not Event.RecordNo
        const causeRecordNo = String(row?.RecordNo ?? "");
        const _key = row?.["@odata.id"] || causeRecordNo || `row-${i}`;
        return {
          _key,
          recordNo: causeRecordNo,
          behaviorCause: getValues(row?.BehaviorsCauses),
          conditionCause: getValues(row?.ConditionCauses),
          systemCause: getValues(row?.SystemCauses),
          raw: row,
        };
      });

      setRows(mappedRows);
      setSelectedKeys(new Set()); // clear selection on reload
    } catch (error) {
      console.error("[CausesSection] Root Cause Error:", error);
      setRows([]);
      setNotice({ type: "error", text: "Failed to load causes." });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRootCauses(preloadedData);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId, preloadedData]);

  useEffect(() => {
    onSectionDataChange?.("causes", { rows });
  }, [rows, onSectionDataChange]);

  // Filters
  const handleFilterChange = (updatedFilters) => {
    setFilters(updatedFilters);
  };

  const handleFilterEnter = (e) => {
    if (e.key === "Enter") {
      loadRootCauses();
    }
  };

  // Selection helpers
  const toggleSelected = (keyOrRow) => {
    const key = typeof keyOrRow === "string" ? keyOrRow : keyOrRow?._key;
    if (!key) return;
    setSelectedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  // Visible rows (hide archived unless showAll)
  const visibleRows = useMemo(() => {
    if (showAll) return rows;
    return rows.filter((r) => !archivedKeys.has(r._key));
  }, [rows, showAll, archivedKeys]);

  const toggleSelectAll = (checked, maybeRows) => {
    const src = Array.isArray(maybeRows) ? maybeRows : visibleRows;
    if (checked) {
      setSelectedKeys(new Set(src.map((r) => r._key)));
    } else {
      setSelectedKeys(new Set());
    }
  };

  const archivedCount = archivedKeys.size;

  // Toolbar actions
  const openNewEntry = () => {
    setNotice(null);
    setModal((prev) => ({
      open: true,
      mode: "add",
      recordNo: null,
      instance: (prev.instance || 0) + 1,
    }));
  };

  const openExisting = (row) => {
    const rn = row?.recordNo ?? null; // cause RecordNo
    setNotice(null);
    setModal((prev) => ({
      open: true,
      mode: "edit",
      recordNo: rn,
      instance: (prev.instance || 0) + 1,
    }));
  };

  const handleArchive = () => {
    const count = selectedKeys.size;
    if (count === 0) {
      setNotice({ type: "error", text: "Select at least one record to archive." });
      return;
    }
    if (typeof window !== "undefined") {
      const ok = window.confirm(`Archive ${count} selected record(s)?`);
      if (!ok) return;
    }
    setArchivedKeys((prev) => {
      const next = new Set(prev);
      selectedKeys.forEach((k) => next.add(k));
      return next;
    });
    setSelectedKeys(new Set());
    setNotice({ type: "info", text: `Archived ${count} record(s).` });
  };

  const handleDelete = () => {
    const count = selectedKeys.size;
    if (count === 0) {
      setNotice({ type: "error", text: "Select at least one record to delete." });
      return;
    }
    if (typeof window !== "undefined") {
      const ok = window.confirm(`Delete ${count} selected record(s)? This cannot be undone.`);
      if (!ok) return;
    }
    setRows((prev) => prev.filter((r) => !selectedKeys.has(r._key)));
    setArchivedKeys((prev) => {
      const next = new Set(prev);
      selectedKeys.forEach((k) => next.delete(k));
      return next;
    });
    setSelectedKeys(new Set());
    setNotice({ type: "info", text: `Deleted ${count} record(s).` });
  };

  const handleAction = (actionId) => {
    if (actionId === "add") return openNewEntry();
    if (actionId === "archive") return handleArchive();
    if (actionId === "delete") return handleDelete();
    if (actionId === "listAll") return setShowAll((v) => !v);
    return undefined;
  };

  // Buttons in this exact order: Add Entry, Archive, Delete, List All
  const actions = [
    { id: "archive", label: "Archive" },
    { id: "delete", label: "Delete" },
    {
      id: "listAll",
      label: showAll
        ? "Show Active Only"
        : archivedCount > 0
        ? `List All (includes archived ${archivedCount})`
        : "List All",
      pressed: showAll,
    },
  ];

  return (
    <>
      <SectionCard
        anchorId="causes"
        index={index}
        title="Causes"
        note="Review identified causes."
        status="complete"
      >
        {loading && (
          <div className="mb-4 text-sm text-slate-500">Loading Causes...</div>
        )}

        <SubformTable
          addLabel="Add Entry"
          addId="add"
          actions={actions}
          onAdd={handleAction}
          onRowClick={openExisting}
          columns={columns}
          rows={visibleRows}
          emptyText="No causes found."
          selectable
          selectedKeys={selectedKeys}
          onToggleRow={toggleSelected}
          onToggleAll={toggleSelectAll}
          notice={notice}
          showFilters
          filters={filters}
          onFilterChange={handleFilterChange}
          onFilterEnter={handleFilterEnter}
        />
      </SectionCard>

      {modal.open && (
        <RootCauseModal
          key={modal.instance}
          mode={modal.mode}
          recordNo={modal.recordNo}  // cause RecordNo
          eventId={eventId}
          onClose={() =>
            setModal((prev) => ({ open: false, mode: "add", recordNo: null, instance: prev.instance }))
          }
          onSave={() => {
            setModal((prev) => ({ open: false, mode: "add", recordNo: null, instance: prev.instance }));
            // Optionally reload: loadRootCauses();
          }}
        />
      )}
    </>
  );
}
