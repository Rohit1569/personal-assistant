// components/sections/InitialReportSection.jsx

"use client";

import { useEffect, useMemo, useRef, useState, useCallback } from "react";

import SectionCard from "@/components/SectionCard";
import FieldInput from "@/components/FieldInput";
// File is components/Jnjsitedropdown.jsx — exact casing matters on Linux/CI builds.
import JnjSitesSearchDropdown from "@/components/Jnjsitedropdown";
import OnBehalfOfDropdown from "@/components/EmployeeSearchDropdown";
import { getIncidentData } from "@/lib/intelApi";
import { useTranslation } from "@/lib/i18n";
import { toLocalDateString } from "@/lib/investigationValidation";

import { getActiveCompanyKeysByLocation } from "@/lib/companyApi";
import { getRelatedConstructionProjectsBySite } from "@/lib/constructionProjectsApi";

// Static option lists
import * as INITIAL_REPORT_CONSTANTS from "@/app/constants/initialReport";
import {
  EVENT_TYPES,
  SITE_LOCATIONS,
  DEPARTMENTS,
  RESPONSIBLE_DEPARTMENTS,
  REVIEWERS,
  HIGH_RISK_ACTIVITIES,
  PHASE_OF_CONSTRUCTION,
  CONSTRUCTION_LOCATION_DETAILS,
  EQUIPMENT_INVOLVED,
} from "@/app/constants/initialReport";

// Not (yet) exported by app/constants/initialReport.js — read defensively so the
// import doesn't produce an "export not found" build warning.
const COMPANIES = INITIAL_REPORT_CONSTANTS.COMPANIES || [];
const SUB_SITE_BY_LOCATION = INITIAL_REPORT_CONSTANTS.SUB_SITE_BY_LOCATION || {};

// Base required keys (person responsible removed; replaced by conditional reviewers)
const REQUIRED_KEYS_BASE = [
  "recordNo",
  "eventType",
  "site",
  "company",
  "siteLocation",
  "department",
  "responsibleDepartment",
  "specificLocation",
  "dateOfEvent",
  "whatHappened",
  "execSummary",
  "reportedBehalf",
  "dateReported",
  "reportConfidence",
  // reviewer removed
];

// Robust ENPS/Off ENPS detection:
// - Matches tokens "enps"/"eps"
// - Matches "off enps"/"off eps"
// - Matches "E&PS" (Engineering & Property Services)
// - Matches "engineering & property services" and "engineering and property services"
function isEnpsOrOffEnps(values) {
  const raw = `${values?.company || ""} ${values?.site || ""} ${values?.siteLocation || ""}`.toLowerCase();
  const spaced = raw.replace(/[^a-z0-9]+/g, " "); // normalize delimiters to spaces

  const hasToken = /\b(enps|eps)\b/.test(spaced) || /\boff\s*(enps|eps)\b/.test(spaced);
  const hasEAndPS = /e\s*&\s*ps/.test(raw) || /\be\s*ps\b/.test(spaced);
  const hasFull = /\bengineering\s+(&|and)\s+property\s+services\b/.test(raw);

  return hasToken || hasEAndPS || hasFull;
}

function isIncidentType(eventType) {
  return String(eventType || "").toLowerCase().includes("incident");
}
function isGoodSaveType(eventType) {
  return String(eventType || "").toLowerCase().includes("good save");
}

export default function InitialReportSection({
  index,
  values,
  setValue,
  eventId,
  preloadedData,
  // Optional override: boolean or function(vals) => boolean
  enpsDetector,
  // Validation messages (i18n keys) keyed by field, computed by the page.
  errors = {},
}) {
  const { t, tl, toOptions } = useTranslation();
  const fetched = useRef(false);
  const [loading, setLoading] = useState(false);
  const today = toLocalDateString();

  // Dynamic Company options fetched from Intelex by selected J&J Site
  const [companyOptions, setCompanyOptions] = useState(COMPANIES || []);
  const [companyLoading, setCompanyLoading] = useState(false);
  const companyCacheRef = useRef(new Map()); // cache by site name

  // Dynamic Related Construction Project options fetched by selected J&J Site
  const [constructionProjectOptions, setConstructionProjectOptions] = useState([]);
  const [projectsLoading, setProjectsLoading] = useState(false);
  const projectsCacheRef = useRef(new Map()); // cache by site name

  const prevModeRef = useRef(null);

  const trimOrEmpty = (s) => (typeof s === "string" ? s.trim() : "");

  // Sub Site options depend on selected Site Location
  const subSiteOptions = useMemo(() => {
    const siteLoc = values?.siteLocation || "";
    return SUB_SITE_BY_LOCATION?.[siteLoc] || [];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values?.siteLocation]);

  // Convert API ISO datetime to HTML input formats (YYYY-MM-DD, HH:mm)
  const toInputDate = (val) => {
    if (!val) return "";
    return val.split("T")[0];
  };
  const toInputTime = (val) => {
    if (!val) return "";
    return val.substring(11, 16);
  };
  const formatDate = (value) => toInputDate(value);
  const formatTime = (value) => toInputTime(value);

  // Mode: ENPS or Off ENPS
  const enpsMode = useMemo(() => {
    if (typeof enpsDetector === "boolean") return enpsDetector;
    if (typeof enpsDetector === "function") return !!enpsDetector(values);
    return isEnpsOrOffEnps(values);
  }, [enpsDetector, values]);

  // Derived visibility conditions
  const isOtherResponsible =
    (values?.responsibleDepartment || "").trim().toLowerCase() === "other";

  // Additional derived rule: Specific Location required when Construction Location Details is "Other"
  const isConstructionLocationOther = useMemo(() => {
    return String(values?.constructionLocationDetails || "").trim().toLowerCase() === "other";
  }, [values?.constructionLocationDetails]);

  // Required keys dynamic computation
  const requiredKeys = useMemo(() => {
    const req = new Set(REQUIRED_KEYS_BASE);

    // Responsible Department = Other -> Describe Other required
    if (isOtherResponsible) req.add("describeOtherResponsible");

    // ENPS/Off ENPS mode: enforce required per spec (stars), and loosen Specific Location
    if (enpsMode) {
      // Add starred requirements
      req.add("constructionProject");
      req.add("phaseConstruction");
      req.add("hra");
      req.add("equipmentInvolved");
      req.add("constructionLocationDetails");

      // Specific Location is shown but not starred unless Construction Location Details is "Other"
      req.delete("specificLocation");
      if (isConstructionLocationOther) {
        req.add("specificLocation");
      }
    }

    return req;
  }, [enpsMode, isOtherResponsible, isConstructionLocationOther]);

  // Visibility logic
  const shouldShowField = useCallback(
    (key) => {
      // Conditional reviewers based on event type
      if (key === "currentGsReviewer") {
        return isGoodSaveType(values?.eventType);
      }
      if (key === "currentIncidentReviewer") {
        return isIncidentType(values?.eventType);
      }

      // ENPS/Off ENPS subform: show these fields when in enpsMode
      const enpsKeys = new Set([
        "constructionProject", // Related Construction Project
        "phaseConstruction", // Phase of Construction
        "hra", // High Risk Activity (HRA)
        "secondaryHra", // Secondary High Risk Activity (HRA)
        "equipmentInvolved", // Equipment Involved
        "constructionLocationDetails", // Construction Location Details
        "specificLocation", // Specific Location
      ]);
      if (enpsKeys.has(key)) {
        return enpsMode;
      }

      // Describe Other Responsible visible only when "Other"
      if (key === "describeOtherResponsible") {
        return isOtherResponsible;
      }

      // Default: show
      return true;
    },
    [enpsMode, isOtherResponsible, values?.eventType]
  );

  // Disable logic (dependent dropdowns)
  const isDisabledField = useCallback(
    (key) => {
      if (key === "subSiteLocation") {
        const siteLoc = values?.siteLocation || "";
        const hasOptions = (SUB_SITE_BY_LOCATION?.[siteLoc] || []).length > 0;
        return !siteLoc || !hasOptions;
      }
      if (key === "company") {
        // Company depends on selected Site and network request
        return !values?.site || companyLoading;
      }
      if (key === "constructionProject") {
        // Construction Project depends on selected Site and network request
        return !values?.site || projectsLoading;
      }
      return false;
    },
    [values?.site, values?.siteLocation, companyLoading, projectsLoading]
  );

  // Checkbox toggle logic for Equipment Involved (multi-select)
  const toggleEquipment = useCallback(
    (opt) => {
      const current = Array.isArray(values?.equipmentInvolved)
        ? values.equipmentInvolved
        : values?.equipmentInvolved && values.equipmentInvolved !== "Not Applicable"
        ? [values.equipmentInvolved]
        : [];

      // Special rule: "Not Applicable" is mutually exclusive
      if (opt === "Not Applicable") {
        setValue("equipmentInvolved", ["Not Applicable"]);
        return;
      }
      const next = current.includes("Not Applicable")
        ? [] // remove NA when selecting real item
        : [...current];

      if (next.includes(opt)) {
        setValue("equipmentInvolved", next.filter((x) => x !== opt));
      } else {
        setValue("equipmentInvolved", [...next, opt]);
      }
    },
    [values?.equipmentInvolved, setValue]
  );

  // Wrapper setValue with business rules
  const setValueWithLogic = useCallback(
    (key, val) => {
      setValue(key, val);

      // Clear dependent fields when parent conditions change
      if (key === "responsibleDepartment" && (val || "").toLowerCase() !== "other") {
        setValue("describeOtherResponsible", "");
      }

      if (key === "siteLocation") {
        // Clear subSiteLocation when siteLocation changes
        setValue("subSiteLocation", "");
      }

      if (key === "site") {
        // Clear company and construction project on site change; options will be repopulated via fetch
        setValue("company", "");
        setCompanyOptions([]);
        setValue("constructionProject", "");
        setConstructionProjectOptions([]);
      }
    },
    [setValue]
  );

  // Initialize ENPS/Off ENPS defaults when mode toggles on (without clobbering existing inputs)
  useEffect(() => {
    if (!enpsMode) return;

    if (!values?.constructionProject) {
      setValue("constructionProject", "");
    }
    if (!values?.phaseConstruction) {
      setValue("phaseConstruction", PHASE_OF_CONSTRUCTION[0]); // e.g., Design
    }
    if (!values?.hra) {
      const defaultHra = HIGH_RISK_ACTIVITIES.includes("No") ? "No" : HIGH_RISK_ACTIVITIES[0];
      setValue("hra", defaultHra);
    }
    if (!values?.secondaryHra) {
      const defaultSecondary = HIGH_RISK_ACTIVITIES.includes("No") ? "No" : HIGH_RISK_ACTIVITIES[0];
      setValue("secondaryHra", defaultSecondary);
    }
    if (!values?.equipmentInvolved) {
      // Start with nothing selected (array), UI will show all checkboxes
      setValue("equipmentInvolved", []);
    }
    if (!values?.constructionLocationDetails) {
      setValue("constructionLocationDetails", "Not Applicable");
    }
    if (!values?.specificLocation) {
      setValue("specificLocation", "");
    }
  }, [enpsMode, values, setValue]);

  // Clear ENPS subform fields when mode toggles off (keep base fields)
  useEffect(() => {
    if (prevModeRef.current === null) {
      prevModeRef.current = enpsMode;
      return;
    }
    if (prevModeRef.current && !enpsMode) {
      ["constructionProject", "phaseConstruction", "hra", "secondaryHra", "equipmentInvolved", "constructionLocationDetails"].forEach((k) =>
        setValue(k, "")
      );
      // specificLocation remains available in base form; leave as-is
    }
    prevModeRef.current = enpsMode;
  }, [enpsMode, setValue]);

  // Fetch dynamic Company list whenever Site changes (prefill dropdown options)
  useEffect(() => {
    const siteName = (values?.site || "").trim();
    let cancelled = false;

    async function fetchCompaniesForSite() {
      if (!siteName) {
        setCompanyOptions([]);
        return;
      }

      // Cache hit
      if (companyCacheRef.current.has(siteName)) {
        const cached = companyCacheRef.current.get(siteName);
        setCompanyOptions(cached);
        return;
      }

      setCompanyLoading(true);
      try {
        const companies = await getActiveCompanyKeysByLocation(siteName);
        if (cancelled) return;

        // Update cache and state
        companyCacheRef.current.set(siteName, companies);
        setCompanyOptions(companies);

        // Keep selected value if still valid; otherwise leave empty for user to choose
        const currentCompany = (values?.company || "").trim();
        if (currentCompany && !companies.includes(currentCompany)) {
          // do not auto-select; user will choose
          setValue("company", "");
        }
      } catch (err) {
        // On error, fall back to static options (if any)
        // eslint-disable-next-line no-console
        console.error("Company list fetch failed:", err);
        setCompanyOptions(COMPANIES || []);
      } finally {
        if (!cancelled) setCompanyLoading(false);
      }
    }

    fetchCompaniesForSite();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values?.site]);

  // Fetch dynamic Related Construction Projects whenever Site changes
  useEffect(() => {
    const siteName = (values?.site || "").trim();
    let cancelled = false;

    async function fetchProjectsForSite() {
      if (!siteName) {
        setConstructionProjectOptions([]);
        return;
      }

      // Cache hit
      if (projectsCacheRef.current.has(siteName)) {
        const cached = projectsCacheRef.current.get(siteName) || [];
        setConstructionProjectOptions(cached);
        return;
      }

      setProjectsLoading(true);
      try {
        const projects = await getRelatedConstructionProjectsBySite(siteName);
        if (cancelled) return;

        // Update cache and state
        projectsCacheRef.current.set(siteName, projects);
        setConstructionProjectOptions(projects);

        // Keep selected value if still valid; otherwise clear it
        const currentProject = (values?.constructionProject || "").trim();
        if (currentProject && !projects.includes(currentProject)) {
          setValue("constructionProject", "");
        }
      } catch (err) {
        // Non-blocking failure; keep options empty
        // eslint-disable-next-line no-console
        console.error("Related Construction Projects fetch failed:", err);
        setConstructionProjectOptions([]);
      } finally {
        if (!cancelled) setProjectsLoading(false);
      }
    }

    fetchProjectsForSite();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values?.site]);

  // All fields (base + ENPS/Off ENPS + conditional reviewers)
  const fields = [
    { key: "recordNo", label: "Record No.", type: "readonly" },

    { key: "eventType", label: "Event Type", type: "select", options: EVENT_TYPES },

    { key: "site", label: "J&J Site", type: "jnjSitesSearch" },

    // Company options are now dynamic: fetched by selected J&J Site
    { key: "company", label: "J&J Company", type: "select", options: companyOptions || [] },

    { key: "subdivId", label: "EH&S Subdiv ID", type: "readonly" },
    { key: "sector", label: "Sector", type: "readonly" },
    { key: "businessUnit", label: "EH&S Business Unit", type: "readonly" },
    { key: "subBusinessUnit", label: "EH&S Sub-Business Unit", type: "readonly" },

    { key: "siteLocation", label: "Site Location", type: "select", options: SITE_LOCATIONS || [] },
    {
      key: "subSiteLocation",
      label: "Sub Site Location",
      type: "select",
      options: subSiteOptions,
    },

    { key: "department", label: "Department", type: "select", options: DEPARTMENTS || [] },
    { key: "subDepartment", label: "Sub Department", type: "text" },

    {
      key: "responsibleDepartment",
      label: "Responsible Department",
      type: "select",
      options: RESPONSIBLE_DEPARTMENTS || [],
    },

    // Conditionally shown when Responsible Department = Other
    { key: "describeOtherResponsible", label: "Describe 'Other' Responsible Department", type: "textarea" },

    // ENPS or Off ENPS subform (visible in enpsMode)
    // Related Construction Project now dynamic from Intelex by selected Site
    { key: "constructionProject", label: "Related Construction Project", type: "select", options: constructionProjectOptions || [] },

    { key: "phaseConstruction", label: "Phase of Construction", type: "select", options: PHASE_OF_CONSTRUCTION },
    { key: "hra", label: "High Risk Activity (HRA)", type: "select", options: HIGH_RISK_ACTIVITIES },
    { key: "secondaryHra", label: "Secondary High Risk Activity (HRA)", type: "select", options: HIGH_RISK_ACTIVITIES, lookup: "hra" },
    { key: "equipmentInvolved", label: "Equipment Involved", type: "checkbox-multi", options: EQUIPMENT_INVOLVED },
    { key: "constructionLocationDetails", label: "Construction Location Details", type: "select", options: CONSTRUCTION_LOCATION_DETAILS },
    { key: "specificLocation", label: "Specific Location", type: "textarea" },

    // Conditional reviewers (replace "Person Responsible"):
    { key: "currentGsReviewer", label: "Current Good Save Reviewer", type: "readonly" },
    { key: "currentIncidentReviewer", label: "Current Incident Reviewer", type: "readonly" },

    { key: "dateOfEvent", label: "Date of Event", type: "date" },
    { key: "timeOfEvent", label: "Time of Event", type: "time" },

    { key: "whatHappened", label: "What happened?", type: "textarea" },
    { key: "execSummary", label: "English Executive Summary", type: "textarea" },
    { key: "causedIncident", label: "What do you think caused this incident?", type: "textarea" },
    { key: "actionTaken", label: "What action(s) did you take?", type: "textarea" },
    { key: "actionSuggest", label: "What action(s) do you suggest?", type: "textarea" },
    { key: "comments", label: "Comments", type: "textarea" },

    { key: "reportedBehalf", label: "Reported On Behalf Of", type: "employeeSearch" },

    { key: "dateReported", label: "Date Reported", type: "date" },
    { key: "timeReported", label: "Time Reported", type: "time" },

    { key: "reportConfidence", label: "Report in Confidence?", type: "readonly" },

    // Removed: Person Responsible field
    // { key: "reviewer", label: "Person Responsible", ... }

    { key: "tmrc", label: "TMRC", type: "readonly" },
    { key: "legalEntity", label: "Legal Entity", type: "readonly" },
  ];

  const loadInitialReport = async (incidentOverride) => {
    try {
      setLoading(true);

      const incident =
        incidentOverride !== undefined
          ? incidentOverride
          : await getIncidentData(
              eventId,
              [
                "RecordNo",
                "Date",
                "Description",
                "LocationDesc",
                "SuspectedCause",
                "ImmediateAction",
                "WhtActDoYouSgst",
                "Comments",
                "EngExecSummary",
                "DateReported",
                "TMRC",
                "TLegalEntity",
                "ReprtinConfdnce",
                "TFullName",
              ],
              [
                "Location($select=Name)",
                "CompanyKey($select=KeyName,SubdivID,BU,Sub0BU,Sector)",
                "EHSEventType($select=Value)",
                "SiteLocation($select=Name)",
                "LocalSiteLoc($select=SiteLocLocalN)",
                "Department($select=DepartmentName)",
                "LocalDepartment($select=LocalDeptName)",
                "RespoDepartment($select=RDepartmentName)",
                "HelpPersResp($select=Name)",
              ]
            );

      if (!incident) return;

      const eventTypeVal = incident.EHSEventType?.Value ?? "";
      const defaultReviewer = (incident.HelpPersResp?.Name || "").trim() || (REVIEWERS?.[0] ?? "");

      const fieldMap = {
        recordNo: incident.RecordNo ?? "",
        eventType: eventTypeVal,
        site: incident.Location?.Name ?? "",
        company: incident.CompanyKey?.KeyName ?? "",
        subdivId: incident.CompanyKey?.SubdivID ?? "",
        sector: incident.CompanyKey?.Sector ?? "",
        businessUnit: incident.CompanyKey?.BU ?? "",
        subBusinessUnit: incident.CompanyKey?.Sub0BU ?? "",
        siteLocation: incident.SiteLocation?.Name ?? "",
        subSiteLocation: incident.LocalSiteLoc?.SiteLocLocalN ?? "",
        department: incident.Department?.DepartmentName ?? "",
        subDepartment: incident.LocalDepartment?.LocalDeptName ?? "",
        responsibleDepartment: incident.RespoDepartment?.RDepartmentName ?? "",
        specificLocation: incident.LocationDesc ?? "",
        dateOfEvent: formatDate(incident.Date),
        timeOfEvent: formatTime(incident.Date),
        whatHappened: incident.Description ?? "",
        execSummary: incident.EngExecSummary ?? "",
        causedIncident: incident.SuspectedCause ?? "",
        actionTaken: incident.ImmediateAction ?? "",
        actionSuggest: incident.WhtActDoYouSgst ?? "",
        comments: incident.Comments ?? "",
        reportedBehalf: trimOrEmpty(incident.TFullName),
        dateReported: formatDate(incident.DateReported),
        timeReported: formatTime(incident.DateReported),
        reportConfidence: incident.ReprtinConfdnce ? "Yes" : "No",
        // Conditional reviewers populated here
        currentGsReviewer: isGoodSaveType(eventTypeVal) ? defaultReviewer : "",
        currentIncidentReviewer: isIncidentType(eventTypeVal) ? defaultReviewer : "",
        tmrc: incident.TMRC ?? "",
        legalEntity: incident.TLegalEntity ?? "",
      };

      Object.entries(fieldMap).forEach(([key, value]) => {
        setValue(key, value ?? "");
      });

      // After initial load, if Site exists, proactively fetch dynamic options for it.
      const loadedSite = (fieldMap.site || "").trim();
      if (loadedSite) {
        try {
          // Companies
          const companies = await getActiveCompanyKeysByLocation(loadedSite);
          companyCacheRef.current.set(loadedSite, companies);
          setCompanyOptions(companies);
        } catch (e) {
          // Non-blocking
          // eslint-disable-next-line no-console
          console.error("Prefetch company options after load failed:", e);
          setCompanyOptions(COMPANIES || []);
        }

        try {
          // Related Construction Projects
          const projects = await getRelatedConstructionProjectsBySite(loadedSite);
          projectsCacheRef.current.set(loadedSite, projects);
          setConstructionProjectOptions(projects);
          // If existing selection isn't in the newly fetched list, clear it
          const currentProject = (values?.constructionProject || "").trim();
          if (currentProject && !projects.includes(currentProject)) {
            setValue("constructionProject", "");
          }
        } catch (e) {
          // Non-blocking
          // eslint-disable-next-line no-console
          console.error("Prefetch construction projects after load failed:", e);
          setConstructionProjectOptions([]);
        }
      }
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error("Initial Report Load Error:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!eventId) return;
    if (fetched.current) return;
    fetched.current = true;
    loadInitialReport(preloadedData);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId, preloadedData]);

  // Render helper to match your section row theme
  const renderRow = (field, content, required) => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start" key={field.key}>
        <div className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
          {field.label}
          {required && <span className="ml-1 text-red-500">*</span>}
          {field.key === "company" && companyLoading ? (
            <span className="ml-2 text-xs text-gray-400">(loading...)</span>
          ) : null}
          {field.key === "constructionProject" && projectsLoading ? (
            <span className="ml-2 text-xs text-gray-400">(loading...)</span>
          ) : null}
        </div>
        <div className="px-2 py-1 min-w-0">{content}</div>
      </div>
    );
  };

  return (
    <SectionCard
      anchorId="initial-report"
      index={index}
      title={t("initialReport.title")}
      note={t("initialReport.note")}
      status="complete"
    >
      {loading ? <div className="mb-4 text-sm text-slate-500">{t("initialReport.loading")}</div> : null}

      <div className="space-y-4">
        {fields
          .filter((f) => shouldShowField(f.key))
          .map((rawField) => {
            // Translated label; option values stay canonical (only labels translate).
            const field = {
              ...rawField,
              label: t(`initialReport.fields.${rawField.key}`),
              ...(rawField.options ? { options: toOptions(rawField.lookup || rawField.key, rawField.options) } : {}),
              ...(rawField.type === "date" ? { max: today } : {}),
              ...(errors[rawField.key] ? { error: t(errors[rawField.key]) } : {}),
            };
            const required = requiredKeys.has(field.key);
            const disabled = isDisabledField(field.key);

            // J&J Sites Search Dropdown
            if (field.type === "jnjSitesSearch") {
              return renderRow(
                field,
                <JnjSitesSearchDropdown
                  value={values[field.key] ?? ""}
                  onSelect={(site) => setValueWithLogic(field.key, site)}
                />,
                required
              );
            }

            // Employee Search Dropdown
            if (field.type === "employeeSearch") {
              return renderRow(
                field,
                <OnBehalfOfDropdown
                  value={values[field.key] ?? ""}
                  onSelect={(employee) => setValueWithLogic(field.key, employee)}
                />,
                required
              );
            }

            // Equipment Involved — checkbox grid (ENPS)
            if (enpsMode && field.key === "equipmentInvolved") {
              const selected = Array.isArray(values.equipmentInvolved)
                ? values.equipmentInvolved
                : values?.equipmentInvolved && values.equipmentInvolved !== "Not Applicable"
                ? [values.equipmentInvolved]
                : [];

              return renderRow(
                field,
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-y-1 gap-x-6">
                  {EQUIPMENT_INVOLVED.map((opt) => (
                    <label key={opt} className="flex items-center gap-2 text-xs select-none">
                      <input
                        type="checkbox"
                        className="w-3 h-3 accent-red-500"
                        checked={selected.includes(opt)}
                        onChange={() => toggleEquipment(opt)}
                      />
                      <span className="text-gray-700">{tl("equipmentInvolved", opt)}</span>
                    </label>
                  ))}
                </div>,
                required
              );
            }

            // All other fields via FieldInput with dynamic required/disabled (keeps your theme)
            return (
              <FieldInput
                key={field.key}
                field={{ ...field, required, disabled }}
                value={values[field.key] ?? ""}
                onChange={setValueWithLogic}
              />
            );
          })}
      </div>
    </SectionCard>
  );
}
