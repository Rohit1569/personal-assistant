// components/sections/ErrorTrapsSection.jsx

"use client";

import { useEffect, useState } from "react";

import SectionCard from "@/components/SectionCard";
import SubformTable from "@/components/SubformTable";
import ErrorTrapModal from "@/components/modals/ErrorTrapModal";

import { getErrorTraps } from "@/lib/errorTrapApi";

export default function ErrorTrapsSection({
  index,
  eventId,
  preloadedData,
  onSectionDataChange,
}) {
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState([]);

  const [showErrorTrapModal, setShowErrorTrapModal] = useState(false);
  const [selectedRecordNo, setSelectedRecordNo] = useState(null);

  const columns = [
    { key: "recordNo", label: "Record No." },
    { key: "title", label: "Error Trap Title" },
    { key: "hopeAnalysis", label: "HOP Error Trap Analysis" },
    { key: "errorTrap", label: "Error Trap" },
    { key: "trapCategory", label: "Trap Category" },
    { key: "description", label: "Description" },
    { key: "capa", label: "CAPA" },
  ];

  // Render a vertical, numbered list
  const makeListNode = (items = []) => {
    const list = (items || []).filter((x) => x !== undefined && x !== null);
    return (
      <div className="space-y-1">
        {list.length > 0 ? (
          list.map((text, i) => (
            <div key={`${i}-${String(text).slice(0, 20)}`} className="text-xs text-gray-700 whitespace-pre-line">
              {`${i + 1}) ${String(text).trim() || "-"}`}
            </div>
          ))
        ) : (
          <span className="text-slate-400">-</span>
        )}
      </div>
    );
  };

  const loadErrorTraps = async (recordsOverride) => {
    try {
      setLoading(true);

      const records =
        recordsOverride !== undefined
          ? recordsOverride
          : await getErrorTraps(eventId);

      const mappedRows = (records || []).map((record) => {
        const causes = record?.IdentifieCauses ?? [];

        if (!causes.length) {
          // No causes: single summary row
          return {
            recordNo: record?.RecordNo ?? "",
            title: record?.ETTitle ?? "",
            hopeAnalysis: record?.HOPErrTrAnalys?.Name ?? "",
            errorTrap: makeListNode([]),
            trapCategory: makeListNode([]),
            description: makeListNode([]),
            capa: makeListNode([]),
          };
        }

        // Aggregate and show as vertical numbered lists
        const errorTrapList = causes.map((c) => c?.HErrorTrap ?? "");
        const trapCategoryList = causes.map((c) => c?.HTrapCategory ?? "");
        const descriptionList = causes.map((c) => c?.Description ?? "");
        const capaList = causes.map((c) => c?.CAPAsforDiagram ?? "");

        return {
          recordNo: record?.RecordNo ?? "",
          title: record?.ETTitle ?? "",
          hopeAnalysis: record?.HOPErrTrAnalys?.Name ?? "",
          errorTrap: makeListNode(errorTrapList),
          trapCategory: makeListNode(trapCategoryList),
          description: makeListNode(descriptionList),
          capa: makeListNode(capaList),
        };
      });

      setRows(mappedRows);
    } catch (error) {
      console.error("Error Trap Load Error:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!eventId) return;
    loadErrorTraps(preloadedData);
  }, [eventId, preloadedData]);

  useEffect(() => {
    onSectionDataChange?.("error-traps", { rows });
  }, [rows, onSectionDataChange]);

  const handleAdd = () => {
    setSelectedRecordNo(null);
    setShowErrorTrapModal(true);
  };

  const handleRowClick = (row) => {
    setSelectedRecordNo(row.recordNo);
    setShowErrorTrapModal(true);
  };

  return (
    <>
      <SectionCard
        anchorId="error-traps"
        index={index}
        title="Error Traps"
        note="Review HOP Error Trap Analysis records."
        status="complete"
      >
        {loading && (
          <div className="mb-4 text-sm text-slate-500">Loading Error Traps...</div>
        )}

        <SubformTable
          addLabel="Add Entry"
          actions={["List All"]}
          onAdd={(action) => {
            if (action === "Add Entry") {
              handleAdd();
            }
          }}
          onRowClick={handleRowClick}
          columns={columns}
          rows={rows}
          emptyText="No Error Trap records found."
        />
      </SectionCard>

      {showErrorTrapModal && (
        <ErrorTrapModal
          recordNo={selectedRecordNo}
          eventId={eventId}
          onClose={() => {
            setShowErrorTrapModal(false);
            setSelectedRecordNo(null);
          }}
          onSave={() => {
            setShowErrorTrapModal(false);
            setSelectedRecordNo(null);
            loadErrorTraps();
          }}
        />
      )}
    </>
  );
}
