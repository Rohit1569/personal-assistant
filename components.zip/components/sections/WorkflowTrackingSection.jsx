"use client";

import { useEffect, useState } from "react";
import SectionCard from "@/components/SectionCard";
import SubformTable from "@/components/SubformTable";
import { getWorkflowTracking } from "@/lib/workflowTrackingApi";

export default function WorkflowTrackingSection({
  index,
  eventId,
  onAdd,
  preloadedData,
  onSectionDataChange,
}) {
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState([]);

  // NEW: Add filters state
  const [filters, setFilters] = useState({
    stage: "",
    dateSubmitted: "",
    action: "",
    message: "",
    submittedBy: "",
  });

  // Define columns directly in component (no dependency on section config)
  const columns = [
    { key: "stage", label: "Stage" },
    { key: "dateSubmitted", label: "Date Submitted" },
    { key: "action", label: "Action" },
    { key: "message", label: "Message" },
    { key: "submittedBy", label: "Submitted By" },
  ];

  const formatDate = (value) => {
    if (!value) return "-";
    try {
      return new Date(value).toLocaleDateString("en-US");
    } catch {
      return value;
    }
  };

  const loadWorkflowTracking = async (recordsOverride) => {
    try {
      setLoading(true);

      console.log("Loading Workflow Tracking with filters:", filters);

      const records = recordsOverride !== undefined
        ? recordsOverride
        : await getWorkflowTracking(eventId, filters);

      const mappedRows = records.map((row) => ({
        stage: row.stage ?? "-",
        dateSubmitted: formatDate(row.dateSubmitted),
        action: row.action ?? "-",
        message: row.message ?? "-",
        submittedBy: row.submittedBy ?? "-",
        raw: row,
      }));

      setRows(mappedRows);
    } catch (error) {
      console.error("Workflow Tracking Load Error:", error);
      setRows([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!eventId) return;

    loadWorkflowTracking(preloadedData);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId, preloadedData]);

  useEffect(() => {
    onSectionDataChange?.("workflow-tracking", { rows });
  }, [rows, onSectionDataChange]);

  // NEW: Handle filter changes
  const handleFilterChange = (updatedFilters) => {
    setFilters(updatedFilters);
  };

  // NEW: Handle filter Enter key press to trigger search
  const handleFilterEnter = (e) => {
    if (e.key === "Enter") {
      loadWorkflowTracking();
    }
  };

  return (
    <SectionCard
      anchorId="workflow-tracking"
      index={index}
      title="Workflow Tracking"
      note="Review workflow history and tracking."
      status="complete"
    >
      {loading ? (
        <div className="text-sm text-slate-500">Loading Workflow Tracking...</div>
      ) : (
        <SubformTable
          addLabel="List All"
          actions={[]}
          columns={columns}
          rows={rows}
          emptyText="No workflow history yet."
          onAdd={onAdd}
          showFilters
          filters={filters}
          onFilterChange={handleFilterChange}
          onFilterEnter={handleFilterEnter}
        />
      )}
    </SectionCard>
  );
}
