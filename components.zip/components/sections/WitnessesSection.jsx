"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

import SectionCard from "@/components/SectionCard";
import SubformTable from "@/components/SubformTable";
import NewWitnessModal from "@/components/modals/NewWitnessModal";
import { getWitnesses } from "@/lib/witnessApi";
import { useTranslation } from "@/lib/i18n";
import { useSubformRecords, SAVE_MODES } from "@/lib/useSubformRecords";

const SECTION_ID = "witnesses";

const EMPTY_FILTERS = {
  recordNo: "",
  witnessType: "",
  witnessName: "",
  contactNumber: "",
  dateOfInterview: "",
  witnessStatement: "",
  selectFromJJEDS: "",
};

const formatDate = (value) => {
  if (!value) return "";
  const d = /^\d{4}-\d{2}-\d{2}$/.test(String(value)) ? new Date(`${value}T00:00`) : new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleDateString();
};

function mapServerRecord(row) {
  return {
    recordNo: row.RecordNo ?? "",
    witnessTypeValue: row.JJWitnessType?.Value ?? row.JJWitnessType?.Name ?? "",
    witnessName: row.WitnessNameEmp?.Name ?? row.WitnessName ?? "",
    contactNumber: row.WitContactNum ?? "",
    dateOfInterview: formatDate(row.DateofInterview),
    witnessStatement: row.WitnesStatement ?? "",
    selectFromJJEDSValue: row.SelectfromJJEDS ? "Yes" : "No",
    raw: row,
  };
}

export default function WitnessesSection({ index, eventId, preloadedData, onSectionDataChange }) {
  const { t, tl } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [serverRecords, setServerRecords] = useState([]);
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [notice, setNotice] = useState(null);
  const [modal, setModal] = useState(null);

  const serverRows = useMemo(
    () =>
      serverRecords.map((r) => ({
        ...r,
        witnessType: tl("witnessType", r.witnessTypeValue),
        selectFromJJEDS: tl("yesNo", r.selectFromJJEDSValue),
      })),
    [serverRecords, tl]
  );

  const buildRow = useCallback(
    (form, record) => ({
      ...(record?.localNo ? { recordNo: t("subform.newRecordNo", { n: record.localNo }) } : {}),
      witnessType: tl("witnessType", form.witnessType),
      witnessName: form.witnessName,
      contactNumber: form.contactInfo,
      dateOfInterview: formatDate(form.dateOfInterview),
      witnessStatement: form.witnessStatement,
      selectFromJJEDS: form.selectFromJJEDS ? tl("yesNo", form.selectFromJJEDS) : "",
    }),
    [t, tl]
  );

  const getServerId = useCallback((row) => row.recordNo, []);

  const records = useSubformRecords({
    eventId,
    sectionId: SECTION_ID,
    serverRows,
    getServerId,
    buildRow,
    filters,
  });

  useEffect(() => {
    onSectionDataChange?.(SECTION_ID, { rows: records.activeRows, draft: records.draftPayload });
  }, [records.activeRows, records.draftPayload, onSectionDataChange]);

  const loadWitnesses = async (recordsOverride) => {
    try {
      setLoading(true);
      const data = recordsOverride !== undefined ? recordsOverride : await getWitnesses(eventId, filters);
      setServerRecords((data || []).map(mapServerRecord));
    } catch (error) {
      console.error("Witness Load Error:", error);
      setServerRecords([]);
      setNotice({ type: "error", text: t("subform.loadFailed") });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!eventId) return;
    loadWitnesses(preloadedData);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId, preloadedData]);

  const nextInstance = (prev) => (prev?.instance ?? 0) + 1;

  const openNewEntry = () => {
    setNotice(null);
    setModal((prev) => ({
      key: null,
      serverRecordNo: null,
      initialForm: records.pending?.form ?? null,
      recordLabel: null,
      restoredDraft: Boolean(records.pending),
      instance: nextInstance(prev),
    }));
  };

  const openExisting = (row) => {
    setNotice(null);
    setModal((prev) => ({
      key: row._key,
      serverRecordNo: row._source === "server" ? row.raw?.RecordNo ?? row.recordNo : null,
      initialForm: row._form ?? null,
      recordLabel: row.recordNo,
      restoredDraft: false,
      instance: nextInstance(prev),
    }));
  };

  const handleArchive = () => {
    const count = records.selectedKeys.size;
    if (count === 0) {
      setNotice({ type: "error", text: t("subform.selectToArchive") });
      return;
    }
    if (typeof window !== "undefined" && !window.confirm(t("subform.archiveConfirm", { count }))) return;
    const archived = records.archiveSelected();
    setNotice({ type: "info", text: t("subform.archivedCount", { count: archived }) });
  };

  const handleAction = (actionId) => {
    if (actionId === "add") return openNewEntry();
    if (actionId === "archive") return handleArchive();
    if (actionId === "listAll") return records.toggleShowAll();
    return undefined;
  };

  const handleModalSave = (form, mode) => {
    records.saveRecord(form, { mode, key: modal?.key ?? null });
    if (mode === SAVE_MODES.SAVE) return;
    if (mode === SAVE_MODES.SAVE_AND_EXIT) {
      setModal(null);
      setNotice({ type: "info", text: t("subform.entrySaved") });
      return;
    }
    // SAVE_AND_ADD -> fresh blank entry
    setNotice({ type: "info", text: t("subform.entrySaved") });
    setModal((prev) => ({
      key: null,
      serverRecordNo: null,
      initialForm: null,
      recordLabel: null,
      restoredDraft: false,
      instance: nextInstance(prev),
    }));
  };

  const columns = [
    { key: "recordNo", label: t("witness.columns.recordNo") },
    { key: "witnessType", label: t("witness.columns.witnessType") },
    { key: "witnessName", label: t("witness.columns.witnessName") },
    { key: "contactNumber", label: t("witness.columns.contactNumber") },
    { key: "dateOfInterview", label: t("witness.columns.dateOfInterview") },
    { key: "witnessStatement", label: t("witness.columns.witnessStatement") },
    { key: "selectFromJJEDS", label: t("witness.columns.selectFromJJEDS") },
  ];

  const actions = [
    { id: "archive", label: t("actions.archive") },
    {
      id: "listAll",
      label: records.showAll
        ? t("subform.showActiveOnly")
        : records.archivedCount > 0
        ? t("subform.listAllWithArchived", { count: records.archivedCount })
        : t("subform.listAll"),
      pressed: records.showAll,
    },
  ];

  return (
    <>
      <SectionCard anchorId={SECTION_ID} index={index} title={t("witness.title")} note={t("witness.note")} status="complete">
        {loading && <div className="mb-4 text-sm text-slate-500">{t("witness.loading")}</div>}

        <SubformTable
          addLabel={t("actions.addEntry")}
          addId="add"
          actions={actions}
          onAdd={handleAction}
          onRowClick={openExisting}
          columns={columns}
          rows={records.visibleRows}
          emptyText={t("witness.empty")}
          selectable
          selectedKeys={records.selectedKeys}
          onToggleRow={records.toggleSelected}
          onToggleAll={records.toggleSelectAll}
          notice={notice}
          showFilters
          filters={filters}
          onFilterChange={setFilters}
          onFilterEnter={(e) => e.key === "Enter" && loadWitnesses()}
        />
      </SectionCard>

      {modal && (
        <NewWitnessModal
          key={modal.instance}
          eventId={eventId}
          serverRecordNo={modal.serverRecordNo}
          recordLabel={modal.recordLabel}
          initialForm={modal.initialForm}
          restoredDraft={modal.restoredDraft}
          onSave={handleModalSave}
          onDiscardDraft={records.discardPending}
          onClose={() => setModal(null)}
        />
      )}
    </>
  );
}
