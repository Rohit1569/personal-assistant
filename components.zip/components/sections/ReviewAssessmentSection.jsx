// components/sections/ReviewAssessmentSection.jsx
"use client";

import { useEffect, useState } from "react";

import SectionCard from "@/components/SectionCard";
import FieldInput from "@/components/FieldInput";
import OnBehalfOfDropdown from "@/components/EmployeeSearchDropdown";
import { getIncidentData } from "@/lib/intelApi";
import { useTranslation } from "@/lib/i18n";
import { YES, NO, isYes } from "@/lib/businessRules";
import { toLocalDateString } from "@/lib/investigationValidation";

const INVESTIGATION_DUE_DAYS = 30;

const formatDateForInput = (value) => {
  if (!value) return "";
  try {
    return new Date(value).toISOString().split("T")[0];
  } catch {
    return "";
  }
};

const formatDateTime = (value) => {
  if (!value) return "";
  try {
    return new Date(value).toLocaleString();
  } catch {
    return value;
  }
};

const toYesNo = (value) => (value === null || value === undefined ? "" : value ? YES : NO);
/** Accepts booleans or "Yes"/"No" strings from the API. */
const yesNoOrEmpty = (value) =>
  value === null || value === undefined || value === "" ? "" : value === true || isYes(value) ? YES : NO;

/**
 * `derived` comes from the page-level business rules:
 * {
 *   investigationRequired: { locked, reasons },
 *   escalation:            { locked, reasons },
 *   constructionProject:   { locked, reasons },
 * }
 */
export default function ReviewAssessmentSection({ index, values, setValue, eventId, preloadedData, derived = {} }) {
  const { t, tl, toOptions } = useTranslation();
  const [loading, setLoading] = useState(false);
  const yesNoOptions = toOptions("yesNo", [YES, NO]);

  const lockedHint = (rule) =>
    rule?.locked && rule.reasons?.length
      ? t("rules.lockedBecause", {
          reasons: rule.reasons.map((code) => t(`rules.reasons.${code}`)).join("; "),
        })
      : undefined;

  const loadReviewAssessment = async (recordOverride) => {
    try {
      setLoading(true);

      const record =
        recordOverride !== undefined
          ? recordOverride
          : await getIncidentData(
              eventId,
              [
                "tavalidincident",
                "InvestDueDate",
                "NewInvDueDate",
                "ConstrucProject",
                "ComuntyImpactng",
                "Escalation",
                "EscalationHelp",
                "EscaReqFinal",
                "CommentsJustifi",
                "ReviewComments",
                "SensitiveInfo",
                "DateTimeofRview",
              ],
              ["Investigator($select=Name)", "NewInvestigator($select=Name)", "ReviewedBy($select=Name)"]
            );

      if (!record) return;

      const fieldMap = {
        investigationRequired: toYesNo(record.tavalidincident),
        investigationDueDate: formatDateForInput(record.InvestDueDate),
        investigator: record.Investigator?.Name ?? "",
        newInvestigator: record.NewInvestigator?.Name ?? "",
        reviseDueDate: formatDateForInput(record.NewInvDueDate),
        // Renamed from `constructionProject` — that key is also used by the Initial
        // Report "Related Construction Project" dropdown and the two clashed.
        isConstructionProject: yesNoOrEmpty(record.ConstrucProject),
        communityMedia: record.ComuntyImpactng ? YES : NO,
        escalationSite: record.Escalation ? YES : NO,
        escalationDeviation: record.EscalationHelp ? YES : NO,
        escalationFinal: record.EscaReqFinal ? YES : NO,
        escalationDeviationJustification: record.CommentsJustifi ?? "",
        reviewComments: record.ReviewComments ?? record.CommentsJustifi ?? "",
        sensitiveIncluded: record.SensitiveInfo ? YES : NO,
        reviewedBy: record.ReviewedBy?.Name ?? "",
        dateOfReview: formatDateTime(record.DateTimeofRview),
      };

      Object.entries(fieldMap).forEach(([key, value]) => setValue(key, value ?? ""));
    } catch (error) {
      console.error("Review Assessment Load Error:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!eventId) return;
    loadReviewAssessment(preloadedData);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId, preloadedData]);

  const investigationYes = isYes(values.investigationRequired);

  // Investigation Due Date defaults to Today + 30 once an investigation is required.
  useEffect(() => {
    if (!investigationYes || values.investigationDueDate) return;
    const due = new Date();
    due.setDate(due.getDate() + INVESTIGATION_DUE_DAYS);
    setValue("investigationDueDate", toLocalDateString(due));
  }, [investigationYes, values.investigationDueDate, setValue]);

  const renderEmployeeField = (key, label, required) => (
    <div key={key} className="grid grid-cols-1 items-start md:grid-cols-[22%_1fr]">
      <div className="px-3 py-2 text-left text-xs font-semibold leading-snug text-gray-600 break-words md:text-right">
        {label}
        {required && <span className="ml-1 text-red-500">*</span>}
      </div>
      <div className="min-w-0 px-2 py-1">
        <OnBehalfOfDropdown value={values[key] ?? ""} onSelect={(name) => setValue(key, name)} />
      </div>
    </div>
  );

  const field = (config) => (
    <FieldInput key={config.key} field={config} value={values[config.key] ?? ""} onChange={setValue} />
  );

  return (
    <SectionCard
      anchorId="review-assessment"
      index={index}
      title={t("review.title")}
      note={t("review.note")}
      status="complete"
    >
      {loading && <div className="mb-4 text-sm text-slate-500">{t("review.loading")}</div>}

      <div className="space-y-4">
        {field({
          key: "investigationRequired",
          label: t("review.fields.investigationRequired"),
          type: "select",
          required: true,
          options: yesNoOptions,
          disabled: Boolean(derived.investigationRequired?.locked),
          hint: lockedHint(derived.investigationRequired),
        })}

        {investigationYes &&
          field({
            key: "investigationDueDate",
            label: t("review.fields.investigationDueDate"),
            type: "readonly",
          })}

        {investigationYes && renderEmployeeField("investigator", t("review.fields.investigator"), true)}

        {renderEmployeeField("newInvestigator", t("review.fields.newInvestigator"), false)}

        {field({ key: "reviseDueDate", label: t("review.fields.reviseDueDate"), type: "date" })}

        {field({
          key: "isConstructionProject",
          label: t("review.fields.constructionProject"),
          type: "select",
          required: true,
          options: yesNoOptions,
          disabled: Boolean(derived.constructionProject?.locked),
          hint: lockedHint(derived.constructionProject),
        })}

        {field({
          key: "communityMedia",
          label: t("review.fields.communityMedia"),
          type: "select",
          options: yesNoOptions,
        })}

        {field({
          key: "escalationSite",
          label: t("review.fields.escalationSite"),
          type: "select",
          options: yesNoOptions,
          disabled: Boolean(derived.escalation?.locked),
          hint: lockedHint(derived.escalation),
        })}

        {field({
          key: "escalationDeviation",
          label: t("review.fields.escalationDeviation"),
          type: "select",
          options: yesNoOptions,
        })}

        {isYes(values.escalationDeviation) &&
          field({
            key: "escalationDeviationJustification",
            label: t("review.fields.escalationDeviationJustification"),
            type: "textarea",
            required: true,
          })}

        {field({
          key: "escalationFinal",
          label: t("review.fields.escalationFinal"),
          type: "readonly",
          displayValue: tl("yesNo", values.escalationFinal) || "—",
        })}

        {field({ key: "reviewComments", label: t("review.fields.comments"), type: "textarea" })}

        {field({
          key: "sensitiveIncluded",
          label: t("review.fields.sensitiveIncluded"),
          type: "readonly",
          displayValue: tl("yesNo", values.sensitiveIncluded) || "—",
        })}

        {field({ key: "reviewedBy", label: t("review.fields.reviewedBy"), type: "readonly" })}

        {field({ key: "dateOfReview", label: t("review.fields.dateOfReview"), type: "readonly" })}
      </div>
    </SectionCard>
  );
}
