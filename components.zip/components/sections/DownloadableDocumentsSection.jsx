import SectionCard from "@/components/SectionCard";
import { getSection } from "@/lib/getSection";
import { sectionStatus } from "@/lib/status";
import SubformTable from "@/components/SubformTable";

const SECTION_ID = "downloadable-documents";

export default function DownloadableDocumentsSection({ index, rows, onAdd }) {
  const section = getSection(SECTION_ID);
  const status = sectionStatus(section, {});
  return (
    <SectionCard
      anchorId={section.id}
      index={index}
      title={section.title}
      note={section.note}
      status={status}
    >
      {section.subform && (
        <SubformTable
          addLabel={section.subform.addLabel}
          actions={section.subform.actions}
          columns={section.subform.columns}
          rows={rows}
          emptyText={section.subform.emptyText}
          onAdd={onAdd}
        />
      )}
    </SectionCard>
  );
}
