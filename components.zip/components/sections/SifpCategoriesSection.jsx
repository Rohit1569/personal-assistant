"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

import SectionCard from "@/components/SectionCard";
import SubformTable from "@/components/SubformTable";
import SifpCategoryModal from "@/components/modals/SifpCategoryModal";

import { getSifpCategories } from "@/lib/sifpApi";
import { useTranslation } from "@/lib/i18n";
import { useSubformRecords, SAVE_MODES } from "@/lib/useSubformRecords";
import { deriveWasSifp } from "@/lib/businessRules";

const SECTION_ID = "sif-p-categories";
/** Business rule: only one SIF-P category may be active on an event. */
const MAX_ACTIVE_SIFP = 1;

const EMPTY_FILTERS = {
  recordNo: "",
  sifpCategory: "",
  sifpSubCategory: "",
  workerType: "",
  managementSystem: "",
  failureMode: "",
  sifCategoryType: "",
};

/** API record -> grid row (canonical values kept in `_canonical` for editing). */
function mapServerRecord(row) {
  const canonical = {
    category: row.SelSIFPCategory ?? "",
    subCategory: row.SelSIFPSubCateg?.SISubCategList ?? "",
    workerType: row.InvolWorkerType?.EmployeeType ?? "",
    mgmtSystem: row.ManagemenSystem?.Value ?? "",
    failureMode: row.FailureMode?.Value ?? "",
  };
  return {
    recordNo: row.RecordNo ?? "",
    sifCategoryType: row.SIFCategoryType ?? "",
    _canonical: canonical,
  };
}

export default function SifpCategoriesSection({
  index,
  eventId,
  preloadedData,
  onSectionDataChange,
  onWasSifpChange,
  // added: we sync a synthetic value for required counting
  setValue,
}) {
  const { t, tl } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [serverRecords, setServerRecords] = useState([]);
  const [isTableCollapsed, setIsTableCollapsed] = useState(false);
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [notice, setNotice] = useState(null);
  // { key, initialForm, recordLabel, restoredDraft, instance } | null
  const [modal, setModal] = useState(null);

  // Display columns are built from canonical values -> translated labels.
  const toDisplay = useCallback(
    (form) => ({
      sifpCategory: tl("sifpCategory", form?.category),
      sifpSubCategory: tl("sifpSubCategory", form?.subCategory),
      workerType: tl("workerType", form?.workerType),
      managementSystem: tl("managementSystem", form?.mgmtSystem),
      failureMode: tl("failureMode", form?.failureMode),
    }),
    [tl]
  );

  const serverRows = useMemo(
    () => serverRecords.map((r) => ({ ...r, ...toDisplay(r._canonical) })),
    [serverRecords, toDisplay]
  );

  const buildRow = useCallback(
    (form, record) =>
      record?.localNo
        ? { recordNo: t("subform.newRecordNo", { n: record.localNo }), ...toDisplay(form), sifCategoryType: "" }
        : toDisplay(form), // edit of a server row: keep its record no. / category type
    [t, toDisplay]
  );

  const getServerId = useCallback((row) => row.recordNo, []);

  const records = useSubformRecords({
    eventId,
    sectionId: SECTION_ID,
    serverRows,
    getServerId,
    buildRow,
    filters,
    maxActive: MAX_ACTIVE_SIFP,
  });

  // ---------------------------------------------------------------------------
  // Rule 1: "Was this a SIF-P?" = Yes when at least one active entry exists.
  // Also sync a synthetic form value for sectionStatus: sifpActiveSelection (array).
  // ---------------------------------------------------------------------------
  const wasSifp = deriveWasSifp(records.activeRows);

  useEffect(() => {
    onWasSifpChange?.(wasSifp);
  }, [wasSifp, onWasSifpChange]);

  useEffect(() => {
    onSectionDataChange?.(SECTION_ID, {
      rows: records.activeRows,
      wasSifp,
      draft: records.draftPayload,
    });
  }, [records.activeRows, records.draftPayload, wasSifp, onSectionDataChange]);

  // Keep a synthetic array value in the main form to enable required counting in StepRail.
  useEffect(() => {
    // Use recordNo when available; fall back to an internal key if needed.
    const selection = records.activeRows.map((r) => r.recordNo || r._key || JSON.stringify(r));
    setValue?.("sifpActiveSelection", selection);
  }, [records.activeRows, setValue]);

  const loadSifpCategories = async (recordsOverride) => {
    if (!eventId) return;
    try {
      setLoading(true);
      const data = recordsOverride !== undefined ? recordsOverride : await getSifpCategories(eventId, filters);
      setServerRecords((data || []).map(mapServerRecord));
    } catch (error) {
      console.error("SIF-P Categories Error:", error);
      setNotice({ type: "error", text: t("subform.loadFailed") });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!eventId) return;
    loadSifpCategories(preloadedData);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId, preloadedData]);

  // ---------------------------------------------------------------------------
  // Toolbar actions
  // ---------------------------------------------------------------------------
  const openNewEntry = () => {
    if (!records.canAddMore) {
      setNotice({ type: "info", text: t("sifp.onlyOneAllowed") });
      return;
    }
    setNotice(null);
    setModal((prev) => ({
      key: null,
      initialForm: records.pending?.form ?? null,
      recordLabel: null,
      restoredDraft: Boolean(records.pending),
      instance: (prev?.instance ?? 0) + 1,
    }));
  };

  const openExisting = (row) => {
    setNotice(null);
    setModal((prev) => ({
      key: row._key,
      initialForm: row._form ?? row._canonical ?? null,
      recordLabel: row.recordNo,
      restoredDraft: false,
      instance: (prev?.instance ?? 0) + 1,
    }));
  };

  const handleArchive = () => {
    const count = records.selectedKeys.size;
    if (count === 0) {
      setNotice({ type: "error", text: t("subform.selectToArchive") });
      return;
    }
    if (typeof window !== "undefined" && !window.confirm(t("subform.archiveConfirm", { count }))) return;
    const archived = records.archiveSelected();
    setNotice({ type: "info", text: t("subform.archivedCount", { count: archived }) });
  };

  const handleAction = (actionId) => {
    if (actionId === "add") return openNewEntry();
    if (actionId === "archive") return handleArchive();
    if (actionId === "listAll") return records.toggleShowAll();
    return undefined;
  };

  // ---------------------------------------------------------------------------
  // Modal save handling
  // ---------------------------------------------------------------------------
  const handleModalSave = (form, mode) => {
    const result = records.saveRecord(form, { mode, key: modal?.key ?? null });

    if (mode === SAVE_MODES.SAVE) return; // stay open; nothing added to the grid for a new entry

    if (mode === SAVE_MODES.SAVE_AND_EXIT) {
      setModal(null);
      setNotice({ type: "info", text: t("subform.entrySaved") });
      return;
    }

    // SAVE_AND_ADD
    if (!result.canAddMore) {
      setModal(null);
      setNotice({ type: "info", text: t("sifp.savedButLimitReached") });
      return;
    }
    setModal((prev) => ({
      key: null,
      initialForm: null,
      recordLabel: null,
      restoredDraft: false,
      instance: (prev?.instance ?? 0) + 1,
    }));
  };

  const columns = [
    { key: "recordNo", label: t("sifp.columns.recordNo") },
    { key: "sifpCategory", label: t("sifp.columns.category") },
    { key: "sifpSubCategory", label: t("sifp.columns.subCategory") },
    { key: "workerType", label: t("sifp.columns.workerType") },
    { key: "managementSystem", label: t("sifp.columns.mgmtSystem") },
    { key: "failureMode", label: t("sifp.columns.failureMode") },
    { key: "sifCategoryType", label: t("sifp.columns.categoryType") },
  ];

  const actions = [
    { id: "archive", label: t("actions.archive") },
    {
      id: "listAll",
      label: records.showAll
        ? t("subform.showActiveOnly")
        : records.archivedCount > 0
        ? t("subform.listAllWithArchived", { count: records.archivedCount })
        : t("subform.listAll"),
      pressed: records.showAll,
    },
  ];

  // Missing state for in-card feedback: show a message if there are zero active entries
  const activeCount = records.activeRows.length;
  const missing = activeCount === 0;
  const cardStatus = missing ? "incomplete" : "complete";

  return (
    <>
      <SectionCard
        anchorId={SECTION_ID}
        index={index}
        title={t("sifp.title")}
        note={t("sifp.note")}
        status={cardStatus}
      >
        {/* Show an inline message instead of a numeric count when no entries exist */}
        {missing && (
          <div className="mb-3 rounded-lg bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-700 ring-1 ring-inset ring-red-200">
            Please add at least 1 entry
          </div>
        )}

        <div className="mb-2 flex justify-end">
          <button
            type="button"
            onClick={() => setIsTableCollapsed((v) => !v)}
            aria-label={isTableCollapsed ? t("actions.expand") : t("actions.collapse")}
            className="rounded p-1 text-slate-500 hover:bg-slate-100"
          >
            {isTableCollapsed ? <ChevronDown size={20} /> : <ChevronUp size={20} />}
          </button>
        </div>

        {!isTableCollapsed && (
          <>
            {loading && <div className="mb-4 text-sm text-slate-500">{t("sifp.loading")}</div>}

            <SubformTable
              addLabel={t("actions.addEntry")}
              addId="add"
              addDisabled={!records.canAddMore}
              addDisabledReason={t("sifp.onlyOneAllowed")}
              actions={actions}
              onAdd={handleAction}
              onRowClick={openExisting}
              columns={columns}
              rows={records.visibleRows}
              emptyText={t("sifp.empty")}
              selectable
              selectedKeys={records.selectedKeys}
              onToggleRow={records.toggleSelected}
              onToggleAll={records.toggleSelectAll}
              notice={notice}
              showFilters
              filters={filters}
              onFilterChange={setFilters}
              onFilterEnter={(e) => e.key === "Enter" && loadSifpCategories()}
            />
          </>
        )}

        <div className="mt-6 space-y-4 text-sm text-jnj-ink">
          <p>
            <span className="text-red-500">*</span> {t("sifp.definition")}
          </p>
          <p>{t("sifp.contactSupport")}</p>

          <div className="flex w-full flex-col items-center justify-center gap-1 py-6">
            <div className="flex items-center justify-center gap-3 text-center">
              <span className="text-sm font-medium">{t("sifp.wasThisSifp")}</span>
              <span
                className={`rounded-full px-3 py-0.5 text-lg font-semibold ${
                  wasSifp === "Yes" ? "bg-red-50 text-jnj-red" : "bg-slate-100 text-jnj-ink"
                }`}
              >
                {tl("yesNo", wasSifp)}
              </span>
            </div>
            <p className="max-w-xl text-center text-xs text-jnj-slate">{t("sifp.wasThisSifpHelp")}</p>
          </div>
        </div>
      </SectionCard>

      {modal && (
        <SifpCategoryModal
          key={modal.instance}
          initialForm={modal.initialForm}
          recordLabel={modal.recordLabel}
          restoredDraft={modal.restoredDraft}
          onSave={handleModalSave}
          onDiscardDraft={records.discardPending}
          onClose={() => setModal(null)}
        />
      )}
    </>
  );
}
