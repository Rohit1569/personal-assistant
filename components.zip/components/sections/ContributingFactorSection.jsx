import SectionCard from "@/components/SectionCard";
import { getSection } from "@/lib/getSection";
import { sectionStatus } from "@/lib/status";
import FieldInput from "@/components/FieldInput";

const SECTION_ID = "contributing-factor";

export default function ContributingFactorSection({ index, values, setValue }) {
  const section = getSection(SECTION_ID);
  const status = sectionStatus(section, values);
  return (
    <SectionCard
      anchorId={section.id}
      index={index}
      title={section.title}
      note={section.note}
      status={status}
    >
      {section.fields && (
        <div className="space-y-4">
          {section.fields.map((f) => (
            <FieldInput key={f.key} field={f} value={values[f.key] ?? ""} onChange={setValue} />
          ))}
        </div>
      )}
    </SectionCard>
  );
}
