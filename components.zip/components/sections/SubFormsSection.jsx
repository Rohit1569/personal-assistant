// components/sections/SubFormsSection.jsx
"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

import SectionCard from "@/components/SectionCard";
import SubformTable from "@/components/SubformTable";

import { getIncidentClassificationData } from "@/lib/subFormsApi";

import CreateEventDialog from "@/components/modals/CreateEventDialog";

import InjuryIllnessModal from "@/components/modals/Injury";
import PropertyEventModal from "@/components/modals/Property";
import RegulatoryEventModal from "@/components/modals/Regulatory";
import SpillReleaseModal from "@/components/modals/SpillReleaseModal";
import VehicleEventModal from "@/components/modals/VehicleEventModal";

import { useTranslation } from "@/lib/i18n";
import { useSubformRecords } from "@/lib/useSubformRecords";

const SECTION_ID = "sub-forms";

export default function SubFormsSection({ index, eventId, preloadedData, onSectionDataChange }) {
  const { t, tl } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState([]);
  const [notice, setNotice] = useState(null);

  const [selectedRow, setSelectedRow] = useState(null);
  const [showCreateEventDialog, setShowCreateEventDialog] = useState(false);

  // Filters
  const [filters, setFilters] = useState({
    incidentNo: "",
    incidentType: "",
    regulatoryReporting: "",
    nov: "",
    escalationRequired: "",
    sensitiveInfo: "",
    lwdc: "",
    sif: "",
  });

  const columns = [
    { key: "incidentNo", label: t("subForms.columns.incidentNo") },
    { key: "incidentType", label: t("subForms.columns.incidentType") },
    { key: "regulatoryReporting", label: t("subForms.columns.regulatoryReporting") },
    { key: "nov", label: t("subForms.columns.nov") },
    { key: "escalationRequired", label: t("subForms.columns.escalationRequired") },
    { key: "sensitiveInfo", label: t("subForms.columns.sensitiveInfo") },
    { key: "lwdc", label: t("subForms.columns.lwdc") },
    { key: "sif", label: t("subForms.columns.sif") },
  ];

  // Translate labels but preserve canonical values with *Value
  const serverRows = useMemo(
    () =>
      rows.map((r) => ({
        ...r,
        incidentTypeValue: r.incidentType,
        escalationRequiredValue: r.escalationRequired,
        incidentType: tl("incidentType", r.incidentType),
        regulatoryReporting: tl("yesNo", r.regulatoryReporting),
        nov: tl("yesNo", r.nov),
        escalationRequired: tl("yesNo", r.escalationRequired),
        sensitiveInfo: tl("yesNo", r.sensitiveInfo),
        lwdc: tl("yesNo", r.lwdc),
        sif: tl("yesNo", r.sif),
      })),
    [rows, tl]
  );

  const getServerId = useCallback((row) => `${row.incidentTypeValue}-${row.incidentNo}`, []);

  const records = useSubformRecords({
    eventId,
    sectionId: SECTION_ID,
    serverRows,
    getServerId,
    filters,
  });

  const loadSubForms = async (recordsOverride) => {
    if (!eventId) return;

    try {
      setLoading(true);
      const data =
        recordsOverride !== undefined
          ? recordsOverride
          : await getIncidentClassificationData(eventId, filters);
      setRows(data);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error("Sub Forms Error:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSubForms(preloadedData);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId, preloadedData]);

  // Report active (non-archived) sub-forms for escalation rule
  useEffect(() => {
    onSectionDataChange?.(SECTION_ID, {
      rows: records.activeRows.map((r) => ({
        incidentNo: r.incidentNo,
        incidentType: r.incidentTypeValue,
        escalationRequired: r.escalationRequiredValue,
        _archived: false,
      })),
      draft: records.draftPayload,
    });
  }, [records.activeRows, records.draftPayload, onSectionDataChange]);

  const handleArchive = () => {
    const count = records.selectedKeys.size;
    if (count === 0) {
      setNotice({ type: "error", text: t("subform.selectToArchive") });
      return;
    }
    if (typeof window !== "undefined" && !window.confirm(t("subForms.archiveConfirm", { count }))) return;
    const archived = records.archiveSelected();
    setNotice({ type: "info", text: t("subForms.archivedCount", { count: archived }) });
  };

  const handleAdd = (action) => {
    if (action === "add") return setShowCreateEventDialog(true);
    if (action === "archive") return handleArchive();
    if (action === "listAll") return records.toggleShowAll();
    return undefined;
  };

  const handleRowClick = (row) => {
    setSelectedRow({ ...row, incidentType: row.incidentTypeValue });
  };

  const closeModal = () => {
    setSelectedRow(null);
  };

  const closeCreateDialog = () => {
    setShowCreateEventDialog(false);
  };

  // Receive payload from Injury modal and optimistically update table
// replace only this function in SubFormsSection
const handleSave = (payload) => {
  // If modal didn’t pass payload (legacy), reload as before
  if (!payload) {
    closeModal();
    loadSubForms();
    return;
  }

  const incidentNo =
    payload.incidentNo ??
    payload.recordNo ??
    selectedRow?.incidentNo ??
    "";

  // Build canonical row shape for the table
  const newRow = {
    incidentNo,
    incidentType: "Injury / Illness",
    regulatoryReporting: payload.regulatoryReporting ?? "No",
    nov: payload.nov ?? "No",
    escalationRequired: payload.escalationRequired ?? "No",
    sensitiveInfo: payload.sensitiveInfo ?? "No",
    lwdc: payload.lwdc ?? (payload.jjRecordable ? "Yes" : "No"),
    sif: payload.sif ?? "No",
  };

  // Optimistically update local rows so table updates immediately
  setRows((prev) => {
    const idx = prev.findIndex(
      (r) => r.incidentNo === incidentNo && r.incidentType === "Injury / Illness"
    );
    if (idx >= 0) {
      const next = [...prev];
      next[idx] = { ...next[idx], ...newRow };
      return next;
    }
    return [...prev, newRow];
  });

  // Close modal
  closeModal();

  // Optional: if you also persist to backend and want to re-sync from server, uncomment:
  // loadSubForms();
};


  const handleCreateSave = () => {
    closeCreateDialog();
    loadSubForms();
  };

  const handleFilterEnter = (e) => {
    if (e.key === "Enter") {
      loadSubForms();
    }
  };

  return (
    <>
      <SectionCard
        anchorId="sub-forms"
        index={index}
        title={t("subForms.title")}
        note={t("subForms.note")}
        status="complete"
      >
        {loading && <div className="mb-4 text-sm text-slate-500">{t("subForms.loading")}</div>}

        <SubformTable
          addLabel={t("actions.addEntry")}
          addId="add"
          actions={[
            { id: "archive", label: t("subForms.detachAndArchive") },
            {
              id: "listAll",
              label: records.showAll
                ? t("subform.showActiveOnly")
                : records.archivedCount > 0
                ? t("subform.listAllWithArchived", { count: records.archivedCount })
                : t("subform.listAll"),
              pressed: records.showAll,
            },
          ]}
          columns={columns}
          rows={records.visibleRows}
          onAdd={handleAdd}
          onRowClick={handleRowClick}
          selectable
          selectedKeys={records.selectedKeys}
          onToggleRow={records.toggleSelected}
          onToggleAll={records.toggleSelectAll}
          notice={notice}
          showFilters
          filters={filters}
          onFilterChange={setFilters}
          onFilterEnter={handleFilterEnter}
        />
      </SectionCard>

      {/* Add Entry */}
      {showCreateEventDialog && (
        <CreateEventDialog
          eventId={eventId}
          onClose={closeCreateDialog}
          onSave={handleCreateSave}
        />
      )}

      {/* Injury / Illness */}
      {selectedRow?.incidentType === "Injury / Illness" && (
        <InjuryIllnessModal
          incidentMasterNo={eventId}
          incidentRecordNo={selectedRow.incidentNo}
          onClose={closeModal}
          onSave={handleSave} // receive payload, update table immediately
        />
      )}

      {/* Property Event */}
      {selectedRow?.incidentType === "Property Event" && (
        <PropertyEventModal
          recordNo={selectedRow.incidentNo}
          eventId={eventId}
          onClose={closeModal}
          onSave={() => {
            closeModal();
            loadSubForms();
          }}
        />
      )}

      {/* Regulatory Event */}
      {selectedRow?.incidentType === "Regulatory Event" && (
        <RegulatoryEventModal
          recordNo={selectedRow.incidentNo}
          eventId={eventId}
          onClose={closeModal}
          onSave={() => {
            closeModal();
            loadSubForms();
          }}
        />
      )}

      {/* Spill / Release */}
      {selectedRow?.incidentType === "Spill / Release" && (
        <SpillReleaseModal
          recordNo={selectedRow.incidentNo}
          eventId={eventId}
          onClose={closeModal}
          onSave={() => {
            closeModal();
            loadSubForms();
          }}
        />
      )}

      {/* Vehicle Event */}
      {selectedRow?.incidentType === "Vehicle Event" && (
        <VehicleEventModal
          recordNo={selectedRow.incidentNo}
          eventId={eventId}
          onClose={closeModal}
          onSave={() => {
            closeModal();
            loadSubForms();
          }}
        />
      )}
    </>
  );
}
