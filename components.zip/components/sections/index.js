// // Registry: maps each section id to its dedicated component, in wizard order.
// import InitialReportSection from "@/components/sections/InitialReportSection";
// import SubFormsSection from "@/components/sections/SubFormsSection";
// import WitnessesSection from "@/components/sections/WitnessesSection";
// import RiskEvaluationSection from "@/components/sections/RiskEvaluationSection";
// import SifpCategoriesSection from "@/components/sections/SifpCategoriesSection";
// import PsmDetailsSection from "@/components/sections/PsmDetailsSection";
// import ReviewAssessmentSection from "@/components/sections/ReviewAssessmentSection";
// import ProgramCategorySection from "@/components/sections/ProgramCategorySection";
// import ContributingFactorSection from "@/components/sections/ContributingFactorSection";
// import InvestigationDetailsSection from "@/components/sections/InvestigationDetailsSection";
// import ErrorTrapsSection from "@/components/sections/ErrorTrapsSection";
// import CausesSection from "@/components/sections/CausesSection";
// import CapaSection from "@/components/sections/CapaSection";
// import PicturesSection from "@/components/sections/PicturesSection";
// import WorkflowTrackingSection from "@/components/sections/WorkflowTrackingSection";
// import DownloadableDocumentsSection from "@/components/sections/DownloadableDocumentsSection";

// // Keyed by section id (matches lib/sections.js ids).
// export const SECTION_COMPONENTS = {
//   "initial-report": InitialReportSection,
//   "sub-forms": SubFormsSection,
//   "witnesses": WitnessesSection,
//   "risk-evaluation": RiskEvaluationSection,
//   "sif-p-categories": SifpCategoriesSection,
//   "psm-details": PsmDetailsSection,
//   "review-assessment": ReviewAssessmentSection,
//   "program-category": ProgramCategorySection,
//   "contributing-factor": ContributingFactorSection,
//   "investigation-details": InvestigationDetailsSection,
//   "error-traps": ErrorTrapsSection,
//   "causes": CausesSection,
//   "capa": CapaSection,
//   "pictures": PicturesSection,
//   "workflow-tracking": WorkflowTrackingSection,
//   "downloadable-documents": DownloadableDocumentsSection,
// };
// components/sections/index.js (or wherever your registry lives)
'use client';

import InitialReportSection from "@/components/sections/InitialReportSection";
import SubFormsSection from "@/components/sections/SubFormsSection";
import WitnessesSection from "@/components/sections/WitnessesSection";
import RiskEvaluationSection from "@/components/sections/RiskEvaluationSection";
import SifpCategoriesSection from "@/components/sections/SifpCategoriesSection";
import PsmDetailsSection from "@/components/sections/PsmDetailsSection";
import ReviewAssessmentSection from "@/components/sections/ReviewAssessmentSection";
import ProgramCategorySection from "@/components/sections/ProgramCategorySection";
import ContributingFactorSection from "@/components/sections/ContributingFactorSection";
import InvestigationDetailsSection from "@/components/sections/InvestigationDetailsSection";
import ErrorTrapsSection from "@/components/sections/ErrorTrapsSection";
import CausesSection from "@/components/sections/CausesSection";
import CapaSection from "@/components/sections/CapaSection";
import PicturesSection from "@/components/sections/PicturesSection";
import WorkflowTrackingSection from "@/components/sections/WorkflowTrackingSection";
import DownloadableDocumentsSection from "@/components/sections/DownloadableDocumentsSection";

// Import the WIP component (default import)
import WorkInProgress from "@/components/WorkInProgress";

// Simple wrappers to show WIP for specific sections.
// They ignore the section props passed by the wizard, which is fine.
const SubFormsWIP = () => (
  <WorkInProgress
    title="Sub-Forms — Work in progress"
    message="This section is under active development and will be available soon."
  />
);

const ErrorTrapsSectionWIP = () => (
  <WorkInProgress
    title="ErrorTrapsSection — Work in progress"
    message="Corrective and Preventive Actions module is coming soon."
  />
);

const WorkflowTrackingSectionWIP = () => (
  <WorkInProgress
    title="Work Flow — Work in progress"
    message="Corrective and Preventive Actions module is coming soon."
  />
);

const CausesWIP = () => (
  <WorkInProgress
    title="Causes — Work in progress"
    message="Corrective and Preventive Actions module is coming soon."
  />
);

const CapaWIP = () => (
  <WorkInProgress
    title="CAPA — Work in progress"
    message="Corrective and Preventive Actions module is coming soon."
  />
);

const DownloadableDocumentsSectionWIP = () => (
  <WorkInProgress
    title="DownloadableDocumentsSection — Work in progress"
    message="Corrective and Preventive Actions module is coming soon."
  />
);

const PicturesSectionWIP = () => (
  <WorkInProgress
    title="Picture Section — Work in progress"
    message="Corrective and Preventive Actions module is coming soon."
  />
);
// Keyed by section id (matches lib/sections.js ids).
export const SECTION_COMPONENTS = {
  "initial-report": InitialReportSection,
  // Replace SubFormsSection with WIP for now
  "sub-forms": SubFormsSection,

  "witnesses": WitnessesSection,
  "risk-evaluation": RiskEvaluationSection,
  "sif-p-categories": SifpCategoriesSection,
  "psm-details": PsmDetailsSection,
  "review-assessment": ReviewAssessmentSection,
  "program-category": ProgramCategorySection,
  "contributing-factor": ContributingFactorSection,
  "investigation-details": InvestigationDetailsSection,
  "error-traps": ErrorTrapsSection,
  "causes": CausesSection,

  // Replace CapaSection with WIP for now
  "capa": CapaSection,

  "pictures": PicturesSectionWIP,
  "workflow-tracking": WorkflowTrackingSection,
  "downloadable-documents": DownloadableDocumentsSectionWIP,
};
