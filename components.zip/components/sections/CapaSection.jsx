// components/CapaSection.jsx
"use client";

import { useEffect, useRef, useState } from "react";

import SectionCard from "@/components/SectionCard";
import FieldInput from "@/components/FieldInput";
import SubformTable from "@/components/SubformTable";
import CapaEffectivenessCheck from "@/components/CapaEffectivenessCheck";
import CapaModal from "@/components/modals/CapaModal";
import { getIncidentData } from "@/lib/intelApi";
import { getCapaActions } from "@/lib/capaApi";
import { getSifpCategories } from "@/lib/sifpApi"; // SIF-P API (if available)
import { getIncidentClassificationData } from "@/lib/subFormsApi"; // Subforms API

export default function CapaSection({
  index,
  values,
  setValue,
  eventId,
  preloadedData,
  onSectionDataChange,
  onAdd,
  onWasSifpChange, // optional parent callback
  // "Was this a SIF-P?" derived from the SIF-P grid (includes unsaved drafts and
  // excludes archived rows). When provided it overrides the API-only calculation.
  wasSifp: wasSifpFromGrid,
}) {
  const fetched = useRef(false);
  const [loading, setLoading] = useState(false);
  const [tableLoading, setTableLoading] = useState(false);
  const [ecLoaded, setEcLoaded] = useState(false);

  const [rows, setRows] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedActionId, setSelectedActionId] = useState(null);

  // SIF-P and Subforms-derived flags
  const [sifpRows, setSifpRows] = useState([]);
  const [wasSifp, setWasSifp] = useState("No");
  const [hasJJSiicOrSif, setHasJJSiicOrSif] = useState(false);

  // Filters for CAPA table
  const [filters, setFilters] = useState({
    actionNo: "",
    actionRequired: "",
    actionOwner: "",
    originalDueDate: "",
    currentDueDate: "",
    completionDate: "",
    priority: "",
    controlType: "",
    workflowStatus: "",
  });

  const capaField = {
    key: "capaEffectiveness",
    label: "CAPA effectiveness check Required / Desired",
    type: "radio",
    options: ["Yes", "No"],
  };

  const subformColumns = [
    { key: "actionNo", label: "Action No." },
    { key: "actionRequired", label: "Action Required" },
    { key: "actionOwner", label: "Action Owner" },
    { key: "originalDueDate", label: "Original Due Date" },
    { key: "currentDueDate", label: "Current Due Date" },
    { key: "completionDate", label: "Completion Date" },
    { key: "priority", label: "Priority" },
    { key: "controlType", label: "CAPA Control Type" },
    { key: "workflowStatus", label: "Workflow Status" },
  ];

  const formatDate = (value) => {
    if (!value) return "-";
    try {
      return new Date(value).toLocaleDateString("en-US");
    } catch {
      return value;
    }
  };

  const loadCapaTableData = async (recordsOverride) => {
    try {
      setTableLoading(true);

      const records = recordsOverride !== undefined
        ? recordsOverride
        : await getCapaActions(eventId, filters);

      const mapped = records.map((record) => ({
        id: record.Id ?? "",
        actionNo: record.ActionNo ?? "-",
        actionRequired: record.CPARActionReq ?? "-",
        actionOwner: record.PersonResp0?.Name ?? "-",
        originalDueDate: formatDate(record.OTargetDate),
        currentDueDate: formatDate(record.DueDate),
        completionDate: formatDate(record.CompletionDate),
        priority: record.Priority0?.Value ?? record.Priority0?.Name ?? "-",
        controlType: record.CAPAControlType?.Name ?? "-",
        workflowStatus: record.CurrentStageACA ?? "-",
        raw: record,
      }));

      setRows(mapped);
    } catch (error) {
      console.error("CAPA Table Load Error:", error);
      setRows([]);
    } finally {
      setTableLoading(false);
    }
  };

  const loadCapaEffectivenessData = async (dataOverride) => {
    try {
      setLoading(true);

      const data = dataOverride !== undefined
        ? dataOverride
        : await getIncidentData(eventId, [
          "RequiredDesired",
          "criteforsuccess",
          "CTimelineMonths",
          "EffCheckDueDate",
          "cResultComments",
          "CAPAsEffective",
          "ApproveComments",
        ],
        ["EffPersRespo($select=Name)", "EfCheckApprover($select=Name)"]);

      if (!data) return;

      const displayValue = (val) => val || "-";

      const fieldMap = {
        capaEcDescription: displayValue(data.criteforsuccess),
        capaEcTimelineMonths: displayValue(data.CTimelineMonths),
        capaEcDueDate: displayValue(data.EffCheckDueDate),
        capaEcResultComments: displayValue(data.cResultComments),
        capaEcIsEffective: displayValue(data.CAPAsEffective),
        capaEcApproverComments: displayValue(data.ApproveComments),
        capaEcPersonResponsible: displayValue(data.EffPersRespo?.Name),
        capaEcApprover: displayValue(data.EfCheckApprover?.Name),
      };

      Object.entries(fieldMap).forEach(([key, value]) => {
        setValue(key, value);
      });

      setEcLoaded(true);
    } catch (error) {
      console.error("CAPA Effectiveness Load Error:", error);
    } finally {
      setLoading(false);
    }
  };

  // Load SIF-P categories and set wasSifp (Yes if any record)
  const loadSifpCategories = async (recordsOverride) => {
    if (!eventId) return;

    try {
      setLoading(true);

      const records = recordsOverride !== undefined
        ? recordsOverride
        : await getSifpCategories(eventId, {});

      const mappedRows = (records || []).map((row) => ({
        recordNo: row.RecordNo ?? "",
        sifpCategory: row.SelSIFPCategory ?? "",
        sifpSubCategory: row.SelSIFPSubCateg?.SISubCategList ?? "",
        workerType: row.InvolWorkerType?.EmployeeType ?? "",
        managementSystem: row.ManagemenSystem?.Value ?? "",
        failureMode: row.FailureMode?.Value ?? "",
        sifCategoryType: row.SIFCategoryType ?? "",
      }));

      setSifpRows(mappedRows);

      const newWasSifp = mappedRows.length > 0 ? "Yes" : "No";
      setWasSifp(newWasSifp);

      if (typeof onWasSifpChange === "function") {
        onWasSifpChange(newWasSifp);
      }
    } catch (error) {
      console.error("SIF-P Categories Error:", error);
    } finally {
      setLoading(false);
    }
  };

  // Load Subforms and set hasJJSiicOrSif if any record has J&J (SIC) or (SIF)? = Yes
  const loadSubformsFlag = async (recordsOverride) => {
    if (!eventId) return;

    try {
      // No UI blocking needed; lightweight flag fetch
      const subformRecords = recordsOverride !== undefined
        ? recordsOverride
        : await getIncidentClassificationData(eventId, {});

      // Normalize Yes detection
      const isYes = (val) => {
        const s = (val ?? "").toString().trim().toLowerCase();
        return s === "yes" || s === "y" || s === "true" || s === "1";
      };

      const foundYes =
        Array.isArray(subformRecords) &&
        subformRecords.some((r) => isYes(r?.sif));

      setHasJJSiicOrSif(Boolean(foundYes));
    } catch (error) {
      console.error("Subforms flag load error:", error);
      setHasJJSiicOrSif(false);
    }
  };

  const handleActionRowClick = (row) => {
    setSelectedActionId(row.actionNo);
    setModalOpen(true);
  };

  const handleAddEntry = () => {
    setSelectedActionId(null);
    setModalOpen(true);
  };

  const handleModalClose = () => {
    setModalOpen(false);
    setSelectedActionId(null);
  };

  const handleModalSave = async () => {
    await loadCapaTableData();
    handleModalClose();
  };

  const handleFilterChange = (updatedFilters) => {
    setFilters(updatedFilters);
  };

  const handleFilterEnter = (e) => {
    if (e.key === "Enter") {
      loadCapaTableData();
    }
  };

  useEffect(() => {
    if (!eventId) return;
    if (fetched.current) return;

    fetched.current = true;
    loadCapaTableData(preloadedData?.actions);
    // Initial loads for disabling logic
    loadSifpCategories(preloadedData?.sifpCategories);
    loadSubformsFlag(preloadedData?.subForms);
  }, [eventId, preloadedData]);

  useEffect(() => {
    onSectionDataChange?.("capa", {
      rows,
      sifpRows,
      wasSifp,
      hasJJSiicOrSif,
    });
  }, [rows, sifpRows, wasSifp, hasJJSiicOrSif, onSectionDataChange]);

  useEffect(() => {
    if (wasSifpFromGrid === "Yes" || wasSifpFromGrid === "No") setWasSifp(wasSifpFromGrid);
  }, [wasSifpFromGrid]);

  // Optionally refresh disabling flags if needed when filters change or on demand
  useEffect(() => {
    if (!eventId) return;
    // If you want this to react to filters, uncomment:
    // loadSifpCategories();
    // loadSubformsFlag();
  }, [eventId /*, filters */]);

  const effectivenessDisabled = wasSifp === "Yes" || hasJJSiicOrSif === true;

  const handleRadioChange = (key, value) => {
    if (effectivenessDisabled) {
      // Force value to "No" and block interaction
      setValue(key, "No");
      return;
    }
    setValue(key, value);

    if (value === "Yes" && !ecLoaded) {
      loadCapaEffectivenessData(preloadedData?.effectiveness);
    }
  };

  // Keep value "No" if disabled flag turns on
  useEffect(() => {
    if (effectivenessDisabled && values[capaField.key] !== "No") {
      setValue(capaField.key, "No");
    }
  }, [effectivenessDisabled]);

  const isEffectivenessCheckEnabled = values["capaEffectiveness"] === "Yes";

  return (
    <>
      <SectionCard
        anchorId="capa"
        index={index}
        title="CAPA"
        status={isEffectivenessCheckEnabled ? "in-progress" : "not-started"}
      >
        {/* Radio Field */}
        <div className="space-y-4">
          <div className={effectivenessDisabled ? "opacity-60 pointer-events-none" : ""}>
            <FieldInput
              field={capaField}
              value={values[capaField.key] ?? "No"}
              onChange={handleRadioChange}
            />
          </div>
          {effectivenessDisabled && (
            <p className="text-xs text-gray-600">
              CAPA Effectiveness Check is disabled because either SIF-P was identified or subforms indicate
              J&J (SIC) or (SIF) = Yes for this event.
            </p>
          )}
        </div>

        {/* Conditional note */}
        {isEffectivenessCheckEnabled && (
          <p className="mt-3 text-sm text-gray-600 italic">
            If CAPA Effectiveness Check = Yes, please ensure at least 1 CAPA is
            added during the review and assessment stage or investigation stage.
          </p>
        )}

        {/* CAPA Subform Table */}
        <div className="mt-6">
          {tableLoading ? (
            <div className="text-sm text-slate-500">Loading CAPA actions...</div>
          ) : (
            <SubformTable
              addLabel="Add Entry"
              actions={["List All"]}
              columns={subformColumns}
              rows={rows}
              emptyText="No records to display."
              onAdd={handleAddEntry}
              onRowClick={handleActionRowClick}
              showFilters
              filters={filters}
              onFilterChange={handleFilterChange}
              onFilterEnter={handleFilterEnter}
            />
          )}
        </div>

        {/* CAPA Effectiveness Check - only when Yes */}
        {isEffectivenessCheckEnabled && (
          <>
            {loading ? (
              <div className="mt-6 text-sm text-slate-500">
                Loading CAPA Effectiveness Check data...
              </div>
            ) : (
              <CapaEffectivenessCheck values={values} setValue={setValue} />
            )}
          </>
        )}
      </SectionCard>

      {/* CAPA Modal */}
      {modalOpen && (
        <CapaModal
          onClose={handleModalClose}
          onSave={handleModalSave}
          actionId={selectedActionId}
          eventId={eventId}
        />
      )}
    </>
  );
}
