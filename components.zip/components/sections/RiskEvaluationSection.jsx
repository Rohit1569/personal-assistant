"use client";

import { useEffect, useState, useCallback } from "react";

import SectionCard from "@/components/SectionCard";
import FieldInput from "@/components/FieldInput";
import { getIncidentData } from "@/lib/intelApi";
import { useTranslation } from "@/lib/i18n";

import { RISK_SEVERITY_OPTIONS, RISK_LIKELIHOOD_OPTIONS } from "@/app/constants/initialReport";

export default function RiskEvaluationSection({
  index,
  values,
  setValue,
  eventId,
  preloadedData,
  onRiskScoreChange, // optional callback: (score: number) => void
}) {
  const { t, toOptions } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [riskScoreValue, setRiskScoreValue] = useState(
    values?.riskScore ?? ""
  );

  const fields = [
    {
      key: "riskLikelihood",
      label: t("risk.fields.likelihood"),
      type: "select",
      options: toOptions("riskLikelihood", RISK_LIKELIHOOD_OPTIONS),
    },
    {
      key: "riskSeverity",
      label: t("risk.fields.severity"),
      type: "select",
      options: toOptions("riskSeverity", RISK_SEVERITY_OPTIONS),
    },
    {
      key: "riskScore",
      label: t("risk.fields.score"),
      // Calculated from Likelihood x Severity and drives business rules, so not editable.
      type: "readonly",
    },
  ];

  // Parse numeric prefix from option string like "02-Very Unlikely" -> 2
  const parseOptionNumeric = (option) => {
    if (!option || typeof option !== "string") return 0;
    const prefix = option.split("-")[0];
    const parsed = parseInt(prefix, 10);
    return Number.isFinite(parsed) ? parsed : 0;
  };

  const computeScore = useCallback((likelihoodOption, severityOption) => {
    const l = parseOptionNumeric(likelihoodOption);
    const s = parseOptionNumeric(severityOption);
    return l * s;
  }, []);

  // Centralized handler for field changes so we can recalc score when needed
  const handleFieldChange = (key, value) => {
    // update the form field
    setValue(key, value);

    // If either likelihood or severity changed, recompute risk score
    if (key === "riskLikelihood" || key === "riskSeverity") {
      const likelihood = key === "riskLikelihood" ? value : values?.riskLikelihood;
      const severity = key === "riskSeverity" ? value : values?.riskSeverity;

      const score = computeScore(likelihood, severity);
      // store score in form as string (consistent with other fields)
      setValue("riskScore", String(score));
      setRiskScoreValue(score);
      if (typeof onRiskScoreChange === "function") {
        onRiskScoreChange(score);
      }
    }
  };

  const loadRiskEvaluation = async (recordOverride) => {
    try {
      setLoading(true);

      const record = recordOverride !== undefined
        ? recordOverride
        : await getIncidentData(
            eventId,
            ["RiskScore"],
            ["PRiskLikelihood($select=Name)", "PRiskSeverity($select=Name)"]
          );

      if (!record) return;

      const fieldMap = {
        riskLikelihood: record.PRiskLikelihood?.Name || record.PRiskLikelihood?.Value || "",
        riskSeverity: record.PRiskSeverity?.Name || record.PRiskSeverity?.Value || "",
        // if backend provided RiskScore we'll set it, otherwise it'll be recalculated below
        riskScore: record.RiskScore ?? "",
      };

      // Set the fetched values into the form
      Object.entries(fieldMap).forEach(([key, value]) => {
        setValue(key, value);
      });

      // If both likelihood/severity available, compute score from their prefixes
      const computedScore = computeScore(fieldMap.riskLikelihood, fieldMap.riskSeverity);

      // Prefer computed score when both select values exist; otherwise keep backend RiskScore
      const finalScore =
        (fieldMap.riskLikelihood && fieldMap.riskSeverity) ? computedScore : fieldMap.riskScore;

      // normalize to string for the form field
      setValue("riskScore", String(finalScore ?? ""));
      setRiskScoreValue(finalScore ?? "");
      if (typeof onRiskScoreChange === "function") {
        onRiskScoreChange(finalScore ?? 0);
      }
    } catch (error) {
      console.error("Risk Evaluation Load Error:", error);
    } finally {
      setLoading(false);
    }
  };

  // Recompute score if values change externally (guard to avoid unnecessary updates)
  useEffect(() => {
    const likelihood = values?.riskLikelihood;
    const severity = values?.riskSeverity;
    const computed = computeScore(likelihood, severity);
    const existing = values?.riskScore ?? "";

    if (String(computed) !== String(existing)) {
      setValue("riskScore", String(computed));
      setRiskScoreValue(computed);
      if (typeof onRiskScoreChange === "function") {
        onRiskScoreChange(computed);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values?.riskLikelihood, values?.riskSeverity]); // intentionally only depend on these two

  useEffect(() => {
    if (!eventId) return;
    loadRiskEvaluation(preloadedData);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId, preloadedData]);

  return (
    <SectionCard
      anchorId="risk-evaluation"
      index={index}
      title={t("risk.title")}
      note={t("risk.note")}
      status="complete"
    >
      {loading && (
        <div className="mb-4 text-sm text-slate-500">
          {t("risk.loading")}
        </div>
      )}

      <div className="space-y-4">
        {fields.map((field) => (
          <FieldInput
            key={field.key}
            field={field}
            value={values[field.key] ?? ""}
            onChange={handleFieldChange}
          />
        ))}
      </div>
    </SectionCard>
  );
}
