"use client";

import { useEffect, useState } from "react";
import { AlertTriangle } from "lucide-react";
import SectionCard from "@/components/SectionCard";
import FieldInput from "@/components/FieldInput";
import { getIncidentData } from "@/lib/intelApi";
import { useTranslation } from "@/lib/i18n";
import { PROGRAM_CATEGORY_OTHER, SECTION_ERROR } from "@/lib/investigationValidation";

export const STATIC_CHECKBOX_GROUPS = [
  {
    group: "Biological, Chemical, Physical agents",
    items: [
      "Biological agents & materials",
      "Chemical agents",
      "Chemical Registration & Restriction",
      "Noise",
      "Controlled substances",
      "Hazard Communication",
      "Industrial hygiene",
      "Transport: Dangerous Goods",
      "Radiation Safety",
      "RoHS",
      "Storage",
      "Pesticides",
    ],
  },
  {
    group: "Environment",
    items: [
      "Air (outdoor)",
      "Energy",
      "Waste",
      "Soil",
      "Water: Storm water",
      "Noise (environment)",
      "Responsible Sourcing",
      "Extended Producer Responsibility",
      "Water: Waste water",
      "Sustainable Design and Labeling",
      "Tank Systems (environment)",
      "Water: Drinking water",
      "Water",
    ],
  },
  {
    group: "Ergonomics",
    items: [
      "Computer work station",
      "Manual Handling (Lifting, Push/Pull, Carrying)",
      "Posture (Overexertion, Bending, Rotation, Extension)",
      "Repetitive Motion",
      "Static Posture",
    ],
  },
  {
    group: "Occupational Safety",
    items: [
      "Animal Handling",
      "Boiler / Pressure vessel",
      "Confined Space",
      "Critical lift / rigging",
      "Electrical Safety",
      "Elevator",
      "Excavation",
      "Explosion safety",
      "PSM Tier 1 / Tier 2",
      "Covid Work Practices",
      "Fire safety (incl. life safety)",
      "Hot work",
      "Lock Out Tag Out",
      "Line breaking",
      "Machine safety",
      "Office safety",
      "Pedestrian Safety",
      "Powered Industrial Vehicles",
      "Transport: Load Securing",
      "Safety bypassing",
      "Slip Trip & Falls",
      "Uncontrolled ignition sources",
      "Vehicles",
      "Warehouse safety",
      "Work at Heights",
      "Work permits",
      "Falling objects",
      "Transportation Safety",
    ],
  },
  {
    group: "General or EHS&S Management System",
    items: [
      "Audits & inspections",
      "Building deficiencies",
      "Communication",
      "Contractor Management",
      "Documentation",
      "EHS&S Design (incl. pre startup safety review)",
      "Emergency preparedness & response",
      "Operating procedures",
      "Competency",
      "Maintenance",
      "Food",
      "Hazard / Risk Assessment",
      "Human factors",
      "Management of Change",
      "Mechanical or system failure",
      "Non-routine work",
      "Occupational Health",
      "Magnets",
      "Procedures",
      "Other (specify)",
      "Personal Protective Equipment",
      "Procurement",
      "Regulatory compliance / regulatory permits",
      "Roles & responsibilities",
      "Tank Systems",
      "Training",
      "Employee Wellbeing",
      "Permit to Work",
      "CAPA Management",
    ],
  },
  {
    group: "Facilities Management",
    items: [
      "Environmental Conditions/Monitoring",
      "Qualification/Validation",
      "Supplier",
      "Pest Control",
      "Calibration",
      "Housekeeping",
    ],
  },
];

// Local storage helpers to persist selection so CAPA modal can mirror it
const storageKey = (eventId) => `program_categories:${eventId || "new"}`;

const saveSelected = (eventId, set) => {
  try {
    const arr = Array.from(set);
    window.localStorage.setItem(storageKey(eventId), JSON.stringify(arr));
  } catch {
    // ignore storage failures
  }
};

const loadSelected = (eventId) => {
  try {
    const raw = window.localStorage.getItem(storageKey(eventId));
    if (!raw) return new Set();
    const arr = JSON.parse(raw);
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
};

export default function ProgramCategorySection({
  index,
  eventId,
  values = {},
  setValue,
  preloadedData,
  onSectionDataChange,
  errors = {},
}) {
  const { t, tl } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(new Set());

  const syncToFormValues = (setRef) => {
    const arr = Array.from(setRef);
    // Keep values.programCategorySelection in sync so sectionStatus can count required
    setValue?.("programCategorySelection", arr);
  };

  const toggleCategory = (value) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(value)) {
        next.delete(value);
      } else {
        next.add(value);
      }
      saveSelected(eventId, next);
      syncToFormValues(next);
      return next;
    });
  };

  const loadProgramCategories = async (recordOverride) => {
    try {
      setLoading(true);

      const response =
        recordOverride !== undefined
          ? recordOverride
          : await getIncidentData(eventId, [], [
              "Macandequipment($select=Value)",
              "General($select=Value)",
              "CPhysicalagents($select=Value)",
              "Environment($select=Value)",
              "Ergonomics($select=Value)",
              "MstrFaclMngmnt($select=Value)",
            ]);

      const record = response?.value?.[0] || response;
      if (!record) return;

      const selectedValues = [
        ...(record.Macandequipment?.map((x) => x.Value) || []),
        ...(record.General?.map((x) => x.Value) || []),
        ...(record.CPhysicalagents?.map((x) => x.Value) || []),
        ...(record.Environment?.map((x) => x.Value) || []),
        ...(record.Ergonomics?.map((x) => x.Value) || []),
        ...(record.MstrFaclMngmnt?.map((x) => x.Value) || []),
      ];

      const next = new Set(selectedValues);
      setSelected(next);
      saveSelected(eventId, next);
      syncToFormValues(next);
    } catch (error) {
      console.error("Program Category Load Error:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Hydrate from storage immediately (avoid flicker), then refresh from API if eventId exists.
    const stored = loadSelected(eventId);
    if (stored.size) {
      setSelected(stored);
      syncToFormValues(stored);
    } else {
      // ensure values has an empty array on first load for consistent counting
      syncToFormValues(new Set());
    }

    if (eventId) {
      loadProgramCategories(preloadedData);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId, preloadedData]);

  useEffect(() => {
    onSectionDataChange?.("program-category", {
      selected: Array.from(selected),
    });
  }, [selected, onSectionDataChange]);

  // "Please Specify Other Program Category" only applies while "Other (specify)" is checked.
  const otherSelected = selected.has(PROGRAM_CATEGORY_OTHER);
  useEffect(() => {
    if (!otherSelected && values.programCategoryOther) setValue?.("programCategoryOther", "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [otherSelected]);

  const sectionError = errors[SECTION_ERROR];

  // Dynamically set card status to reflect missing selection for user feedback in-card
  const selectedCount = Array.isArray(values.programCategorySelection)
    ? values.programCategorySelection.length
    : 0;
  const hasMissingSelection = selectedCount === 0;
  const cardStatus = hasMissingSelection ? "incomplete" : "complete";

  return (
    <SectionCard
      anchorId="program-category"
      index={index}
      title={t("programCategory.title")}
      note={t("programCategory.note")}
      status={cardStatus}
    >
      {loading && <div className="text-sm text-slate-500">{t("programCategory.loading")}</div>}

      {sectionError && (
        <div
          role="alert"
          className="mb-4 flex items-start gap-2 rounded-lg bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-700 ring-1 ring-inset ring-red-200"
        >
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 flex-shrink-0" />
          {t(sectionError)}
        </div>
      )}

      {!loading && (
        <div className="space-y-4">
          {STATIC_CHECKBOX_GROUPS.map((group) => (
            <div key={group.group} className="grid grid-cols-1 md:grid-cols-[22%_1fr]">
              <div className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug">
                {tl("programCategoryGroup", group.group)}
              </div>

              <div className="px-2 py-1">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2">
                  {group.items.map((item) => (
                    <label
                      key={item}
                      className="flex items-start gap-2 rounded px-1 py-1 text-sm text-gray-700 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selected.has(item)}
                        onChange={() => toggleCategory(item)}
                        className="mt-0.5 h-4 w-4 accent-red-700"
                      />
                      <span>{tl("programCategory", item)}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          ))}

          {otherSelected && (
            <FieldInput
              field={{
                key: "programCategoryOther",
                label: t("programCategory.otherSpecify"),
                type: "text",
                required: true,
                error: errors.programCategoryOther ? t(errors.programCategoryOther) : undefined,
              }}
              value={values.programCategoryOther ?? ""}
              onChange={(key, value) => setValue?.(key, value)}
            />
          )}
        </div>
      )}
    </SectionCard>
  );
}
