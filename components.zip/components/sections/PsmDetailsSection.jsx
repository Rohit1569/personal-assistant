"use client";

import { useEffect, useMemo, useState } from "react";

import SectionCard from "@/components/SectionCard";
import FieldInput from "@/components/FieldInput";
import { getIncidentData } from "@/lib/intelApi";
import { useTranslation } from "@/lib/i18n";
import {
  CHECKBOX_OPTIONS,
  PSM_QUANTITY_OPTIONS,
  HIGH_ENERGY_SUB,
  FIRE_DAMAGE_SUB,
  MODE_OF_OPERATION_OPTIONS,
  MATERIAL_OPTIONS,
  MAIN_CHECKBOX_PSE_LEVEL,
  PSE_LEVEL_MAP,
} from "@/app/constants/psmDetails";

export default function PsmDetailsSection({
  index,
  values = {},
  setValue,
  eventId,
  preloadedData,
  wasSifp = "No",
  communityMedia = "No",
  errors = {},
}) {
  const { t, tl, toOptions } = useTranslation();
  const [loading, setLoading] = useState(false);

  const fields = [
    {
      key: "psmTier",
      label: t("psm.fields.psmTier"),
      type: "readonly",
    },
  ];

  const loadPsmDetails = async (recordOverride) => {
    try {
      setLoading(true);

      const record =
        recordOverride !== undefined
          ? recordOverride
          : await getIncidentData(eventId, [], ["PSMTIER($select=PSMTierName)"]);

      if (!record) return;

      setValue("psmTier", record.PSMTIER?.PSMTierName ?? "N/A");

      if (typeof record.PSMCoveredArPr === "boolean") {
        setValue("psmCoveredArea", record.PSMCoveredArPr ? "Yes" : "No");
      } else if (!values.psmCoveredArea) {
        setValue("psmCoveredArea", "");
      }
    } catch (error) {
      console.error("PSM Details Error:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!eventId) return;
    loadPsmDetails(preloadedData);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId, preloadedData]);

  const psmTierVal = values?.psmTier ?? "";
  const showPsmCovered =
    typeof psmTierVal === "string" &&
    (psmTierVal.toUpperCase().includes("PSM TIER 1") ||
      psmTierVal.toUpperCase().includes("PSM TIER 2"));

  useEffect(() => {
    if (!showPsmCovered) {
      setValue("psmCoveredArea", "");
      setValue("psmSelections", []);
      setValue("pseLevelConclusion", "");
      setValue("releasedMaterialType", "");
      setValue("releasedMaterialOther", "");
      setValue("modeOfOperation", "");
      setValue("modeOfOperationOther", "");
      setValue("psmQuantityOptions", []);
      setValue("fireSubOptions", []);
      setValue("highEnergySubOptions", []);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showPsmCovered]);

  // Auto-check SIF-P checkbox when wasSifp is "Yes"
  useEffect(() => {
    if (wasSifp === "Yes" && showPsmCovered) {
      const sifpCheckbox = CHECKBOX_OPTIONS[4]; // SIF-P
      const currentSelections = Array.isArray(values.psmSelections) ? [...values.psmSelections] : [];
      if (!currentSelections.includes(sifpCheckbox)) {
        setValue("psmSelections", [...currentSelections, sifpCheckbox]);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wasSifp, showPsmCovered]);

  // Auto-check Offsite community impact checkbox when communityMedia is "Yes"
  useEffect(() => {
    if (communityMedia === "Yes" && showPsmCovered) {
      const offsiteCheckbox = CHECKBOX_OPTIONS[5];
      const currentSelections = Array.isArray(values.psmSelections) ? [...values.psmSelections] : [];
      if (!currentSelections.includes(offsiteCheckbox)) {
        setValue("psmSelections", [...currentSelections, offsiteCheckbox]);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [communityMedia, showPsmCovered]);

  const PSM_SUB_OPTIONS_MAP = {
    [CHECKBOX_OPTIONS[0]]: PSM_QUANTITY_OPTIONS,
    [CHECKBOX_OPTIONS[1]]: HIGH_ENERGY_SUB,
    [CHECKBOX_OPTIONS[2]]: FIRE_DAMAGE_SUB,
  };

  const psmSelectionsSet = useMemo(() => {
    const arr = Array.isArray(values.psmSelections) ? values.psmSelections : [];
    return new Set(arr);
  }, [values.psmSelections]);

  // Calculate PSE Level
  useEffect(() => {
    if (!Array.isArray(values.psmSelections) || values.psmSelections.length === 0) {
      setValue("pseLevelConclusion", "");
      return;
    }

    const pseLevels = [];

    values.psmSelections.forEach((selection) => {
      const mainLevel = MAIN_CHECKBOX_PSE_LEVEL[selection];

      if (mainLevel === "quantity") {
        if (values.psmQuantityOptions && values.psmQuantityOptions.length > 0) {
          values.psmQuantityOptions.forEach((subOpt) => {
            const subLevel = PSE_LEVEL_MAP[subOpt];
            if (subLevel) pseLevels.push(subLevel);
          });
        }
      } else if (mainLevel === "highEnergy") {
        if (values.highEnergySubOptions && values.highEnergySubOptions.length > 0) {
          values.highEnergySubOptions.forEach((subOpt) => {
            const subLevel = PSE_LEVEL_MAP[subOpt];
            if (subLevel) pseLevels.push(subLevel);
          });
        }
      } else if (mainLevel === "fire") {
        if (values.fireSubOptions && values.fireSubOptions.length > 0) {
          values.fireSubOptions.forEach((subOpt) => {
            const subLevel = PSE_LEVEL_MAP[subOpt];
            if (subLevel) pseLevels.push(subLevel);
          });
        }
      } else if (typeof mainLevel === "number") {
        pseLevels.push(mainLevel);
      }
    });

    if (pseLevels.length === 0) {
      setValue("pseLevelConclusion", "");
      return;
    }

    const minLevel = Math.min(...pseLevels);
    setValue("pseLevelConclusion", `PSE Level ${minLevel}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    values.psmSelections,
    values.psmQuantityOptions,
    values.fireSubOptions,
    values.highEnergySubOptions,
  ]);

  const handleToggleSelection = (option) => {
    const currentArr = Array.isArray(values.psmSelections) ? [...values.psmSelections] : [];
    const set = new Set(currentArr);

    if (set.has(option)) {
      set.delete(option);
    } else {
      set.add(option);
    }

    const newArr = Array.from(set);
    setValue("psmSelections", newArr);

    if (option === CHECKBOX_OPTIONS[0] && !newArr.includes(option)) {
      setValue("psmQuantityOptions", []);
    }
    if (option === CHECKBOX_OPTIONS[1] && !newArr.includes(option)) {
      setValue("highEnergySubOptions", []);
    }
    if (option === CHECKBOX_OPTIONS[2] && !newArr.includes(option)) {
      setValue("fireSubOptions", []);
    }
  };

  const handleToggleQuantityOption = (subOption) => {
    const current = Array.isArray(values.psmQuantityOptions) ? [...values.psmQuantityOptions] : [];
    const set = new Set(current);

    const INDOOR_INDICES = [0, 2];
    const OUTDOOR_INDICES = [1, 3];
    const LESS_THAN_INDEX = 4;

    const subIndex = PSM_QUANTITY_OPTIONS.indexOf(subOption);
    const isLessThanOption = subIndex === LESS_THAN_INDEX;
    const isIndoorOption = INDOOR_INDICES.includes(subIndex);
    const isOutdoorOption = OUTDOOR_INDICES.includes(subIndex);

    if (set.has(subOption)) {
      set.delete(subOption);
    } else {
      if (isLessThanOption) {
        set.clear();
        set.add(subOption);
      } else {
        const lessThanOption = PSM_QUANTITY_OPTIONS[LESS_THAN_INDEX];
        if (lessThanOption && set.has(lessThanOption)) {
          set.delete(lessThanOption);
        }

        if (isIndoorOption) {
          const otherIndoorIndex = INDOOR_INDICES.find((idx) => idx !== subIndex);
          const otherIndoorOption = PSM_QUANTITY_OPTIONS[otherIndoorIndex];
          if (otherIndoorOption && set.has(otherIndoorOption)) {
            set.delete(otherIndoorOption);
          }
        }

        if (isOutdoorOption) {
          const otherOutdoorIndex = OUTDOOR_INDICES.find((idx) => idx !== subIndex);
          const otherOutdoorOption = PSM_QUANTITY_OPTIONS[otherOutdoorIndex];
          if (otherOutdoorOption && set.has(otherOutdoorOption)) {
            set.delete(otherOutdoorOption);
          }
        }

        set.add(subOption);
      }
    }

    setValue("psmQuantityOptions", Array.from(set));
  };

  const handleToggleHighEnergySubOption = (subOption) => {
    const current = Array.isArray(values.highEnergySubOptions) ? [...values.highEnergySubOptions] : [];
    const set = new Set(current);

    if (set.has(subOption)) {
      set.delete(subOption);
    } else {
      set.add(subOption);
    }

    setValue("highEnergySubOptions", Array.from(set));
  };

  const handleToggleFireSubOption = (subOption) => {
    const current = Array.isArray(values.fireSubOptions) ? [...values.fireSubOptions] : [];
    const set = new Set(current);

    if (set.has(subOption)) {
      set.delete(subOption);
    } else {
      set.add(subOption);
    }

    setValue("fireSubOptions", Array.from(set));
  };

  const isCoveredYes = String(values?.psmCoveredArea ?? "").trim().toLowerCase() === "yes";

  const handlePsmCoveredChange = (newVal) => {
    setValue("psmCoveredArea", newVal);
    if (String(newVal).trim().toLowerCase() === "yes") {
      if (!Array.isArray(values.psmSelections)) {
        setValue("psmSelections", []);
      }
    } else {
      setValue("psmSelections", []);
      setValue("pseLevelConclusion", "");
      setValue("releasedMaterialType", "");
      setValue("releasedMaterialOther", "");
      setValue("modeOfOperation", "");
      setValue("modeOfOperationOther", "");
      setValue("psmQuantityOptions", []);
      setValue("fireSubOptions", []);
      setValue("highEnergySubOptions", []);
    }
  };

  const isReleasedOther = values.releasedMaterialType === "Others (describe)";
  const isModeOther = values.modeOfOperation === "Others (describe)";

  useEffect(() => {
    if (!isReleasedOther && values.releasedMaterialOther) {
      setValue("releasedMaterialOther", "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values.releasedMaterialType]);

  useEffect(() => {
    if (!isModeOther && values.modeOfOperationOther) {
      setValue("modeOfOperationOther", "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values.modeOfOperation]);

  const pseLevelNumber = values.pseLevelConclusion
    ? parseInt(values.pseLevelConclusion.match(/\d+/)?.[0] || "")
    : null;

  const showMaterialType = pseLevelNumber === 1 || pseLevelNumber === 2;
  const showModeOfOperation = pseLevelNumber !== null;

  const hasVisibleErrors = errors && Object.keys(errors).length > 0;

  const selectBase =
    "h-10 w-full rounded-lg border bg-white px-3 text-sm text-gray-900 shadow-sm outline-none hover:border-slate-400 focus:ring-2";
  const selectOk = "border-slate-300 focus:border-red-600 focus:ring-red-100";
  const selectError = "border-red-500 focus:border-red-600 focus:ring-red-100";

  return (
    <SectionCard
      anchorId="psm-details"
      index={index}
      title={t("psm.title")}
      status={hasVisibleErrors ? "incomplete" : "complete"}
    >
      {loading && <div className="mb-4 text-sm text-slate-500">{t("psm.loading")}</div>}

      <div className="space-y-4">
        {fields.map((field) => (
          <FieldInput
            key={field.key}
            field={field}
            value={values[field.key] ?? ""}
            onChange={setValue}
            error={errors?.[field.key]}
          />
        ))}

        {showPsmCovered && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start gap-4">
              <div className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
                {t("psm.fields.coveredArea")}
                <span className="ml-1 text-red-500">*</span>
              </div>

              <div className="px-2 py-1 min-w-0">
                <select
                  value={values.psmCoveredArea ?? ""}
                  onChange={(e) => handlePsmCoveredChange(e.target.value)}
                  className={`${selectBase} ${errors?.psmCoveredArea ? selectError : selectOk}`}
                >
                  <option value="">{t("common.selectPlaceholder")}</option>
                  <option value="Yes">{tl("yesNo", "Yes")}</option>
                  <option value="No">{tl("yesNo", "No")}</option>
                </select>
                {!!errors?.psmCoveredArea && (
                  <p className="mt-1 text-xs text-red-600">{errors.psmCoveredArea}</p>
                )}
              </div>
            </div>

            {isCoveredYes && (
              <div className="space-y-4">
                <div className="px-3 py-2 text-xs text-gray-700 bg-blue-50 rounded-lg border border-blue-200">
                  {t("psm.questionnaireHelp")}
                </div>

                <FieldInput
                  field={{
                    key: "psmSelections",
                    type: "checkbox-group",
                    options: CHECKBOX_OPTIONS,
                    onToggle: handleToggleSelection,
                    subOptionsMap: PSM_SUB_OPTIONS_MAP,
                    subKey: "psmQuantityOptions",
                    subValue: values.psmQuantityOptions || [],
                    onToggleSub: handleToggleQuantityOption,
                    checkboxContainerClass:
                      "md:-ml-[22%] md:w-[calc(100%+22%)] grid grid-cols-1 gap-2",
                    checkboxClass:
                      "h-5 w-5 mt-0.5 accent-red-600 bg-white border-2 border-red-200 rounded shadow-sm",
                    checkboxLabelClass:
                      "grid grid-cols-[28px_1fr] items-start gap-3 text-sm cursor-pointer bg-white p-2 rounded-md hover:bg-red-50",
                    subCheckboxClass:
                      "h-4 w-4 mt-0.5 accent-red-600 bg-white border border-gray-300 rounded",
                    getPSELevel: (option) => MAIN_CHECKBOX_PSE_LEVEL[option],
                    getOptionLabel: (option) => tl("psmCriteria", option),
                    getPSELevelForSub: (subOption) => PSE_LEVEL_MAP[subOption],
                  }}
                  value={psmSelectionsSet}
                  onChange={setValue}
                  error={errors?.psmSelections}
                />

                {/* PSE Level Conclusion */}
                <div className="grid grid-cols-1 md:grid-cols-[22%_1fr] items-start gap-4">
                  <div className="px-3 py-2 text-left md:text-right text-xs font-semibold text-gray-600 leading-snug break-words">
                    {t("psm.fields.pseLevelConclusion")}
                  </div>
                  <div className="px-2 py-1 min-w-0">
                    <div className="flex min-h-[40px] items-center rounded-lg border border-gray-200 bg-gray-100 px-3 text-sm text-gray-600 font-semibold">
                      {values["pseLevelConclusion"] || "—"}
                    </div>
                  </div>
                </div>

                {/* Conditional Fields Based on PSE Level */}
                {showMaterialType && (
                  <FieldInput
                    field={{
                      key: "releasedMaterialType",
                      label: t("psm.fields.releasedMaterialType"),
                      type: "select",
                      options: toOptions("psmMaterial", MATERIAL_OPTIONS),
                      required: true,
                    }}
                    value={values["releasedMaterialType"] ?? ""}
                    onChange={setValue}
                    error={errors?.releasedMaterialType}
                  />
                )}

                {isReleasedOther && showMaterialType && (
                  <FieldInput
                    field={{
                      key: "releasedMaterialOther",
                      label: t("psm.fields.releasedMaterialOther"),
                      type: "text",
                      required: true,
                    }}
                    value={values["releasedMaterialOther"] ?? ""}
                    onChange={setValue}
                    error={errors?.releasedMaterialOther}
                  />
                )}

                {showModeOfOperation && (
                  <FieldInput
                    field={{
                      key: "modeOfOperation",
                      label: t("psm.fields.modeOfOperation"),
                      type: "select",
                      options: toOptions("psmModeOfOperation", MODE_OF_OPERATION_OPTIONS),
                      required: true,
                    }}
                    value={values["modeOfOperation"] ?? ""}
                    onChange={setValue}
                    error={errors?.modeOfOperation}
                  />
                )}

                {isModeOther && showModeOfOperation && (
                  <FieldInput
                    field={{
                      key: "modeOfOperationOther",
                      label: t("psm.fields.modeOfOperationOther"),
                      type: "text",
                      required: true,
                    }}
                    value={values["modeOfOperationOther"] ?? ""}
                    onChange={setValue}
                    error={errors?.modeOfOperationOther}
                  />
                )}
              </div>
            )}
          </>
        )}
      </div>
    </SectionCard>
  );
}
