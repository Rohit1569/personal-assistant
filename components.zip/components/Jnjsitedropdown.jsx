// // components/JnjSitesSearchDropdown.jsx

// "use client";

// import { useCallback, useEffect, useRef, useState } from "react";
// import { Search, X, AlertCircle } from "lucide-react";
// import { getJnjSitesPage } from "@/lib/getAllLocationsApi";

// function CircularSpinner({ size = 16 }) {
//   return (
//     <div
//       className="animate-spin"
//       style={{
//         width: size,
//         height: size,
//         border: `2px solid #E5E7EB`,
//         borderTop: `2px solid #B91C1C`,
//         borderRadius: "50%",
//       }}
//     />
//   );
// }

// function HighlightMatch({ text, query }) {
//   if (!query.trim()) return text;

//   const parts = text.split(
//     new RegExp(`(${query})`, "gi")
//   );
//   return (
//     <>
//       {parts.map((part, i) =>
//         part.toLowerCase() === query.toLowerCase() ? (
//           <mark
//             key={i}
//             className="bg-yellow-100 font-semibold no-underline"
//           >
//             {part}
//           </mark>
//         ) : (
//           part
//         )
//       )}
//     </>
//   );
// }

// export default function JnjSitesSearchDropdown({
//   value,
//   onSelect,
//   disabled = false,
//   dropUp = false,
// }) {
//   const [query, setQuery] = useState(value || "");
//   const [results, setResults] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [open, setOpen] = useState(false);
//   const [error, setError] = useState("");
//   const [hovered, setHovered] = useState(false);
//   const [focused, setFocused] = useState(false);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [totalCount, setTotalCount] = useState(0);
//   const [hasMore, setHasMore] = useState(false);
//   const [searching, setSearching] = useState(false);

//   const debounceRef = useRef(null);
//   const containerRef = useRef(null);
//   const listRef = useRef(null);
//   const abortRef = useRef(null);

//   useEffect(() => {
//     if (!focused) setQuery(value || "");
//   }, [value, focused]);

//   useEffect(() => {
//     const handler = (e) => {
//       if (
//         containerRef.current &&
//         !containerRef.current.contains(e.target)
//       ) {
//         setOpen(false);
//         setFocused(false);
//         setQuery(value || "");
//       }
//     };
//     document.addEventListener("mousedown", handler);
//     return () =>
//       document.removeEventListener("mousedown", handler);
//   }, [value]);

//   const doSearch = useCallback(
//     async (text, page = 1) => {
//       if (!text || text.trim().length < 1) {
//         setResults([]);
//         setOpen(false);
//         setLoading(false);
//         return;
//       }

//       if (abortRef.current) abortRef.current.abort();
//       abortRef.current = new AbortController();

//       setLoading(true);
//       setError("");

//       try {
//         const response = await getJnjSitesPage(
//           page,
//           text.trim()
//         );

//         if (page === 1) {
//           setResults(response.sites);
//         } else {
//           setResults((prev) => [...prev, ...response.sites]);
//         }

//         setTotalCount(response.totalCount);
//         setHasMore(response.hasMore);
//         setCurrentPage(page);
//         setOpen(true);
//         setLoading(false);
//       } catch (err) {
//         if (err.name !== "AbortError") {
//           setError(
//             "Could not load sites. Check connection."
//           );
//           setLoading(false);
//           setOpen(true);
//         }
//       }
//     },
//     []
//   );

//   const handleChange = (e) => {
//     const val = e.target.value;
//     setQuery(val);
//     setCurrentPage(1);
//     setResults([]);
//     setHasMore(false);

//     clearTimeout(debounceRef.current);

//     if (!val.trim()) {
//       setResults([]);
//       setOpen(false);
//       setLoading(false);
//       return;
//     }

//     setLoading(true);
//     debounceRef.current = setTimeout(() => {
//       doSearch(val, 1);
//     }, 350);
//   };

//   const handleSelect = (site) => {
//     setQuery(site.label);
//     setOpen(false);
//     setFocused(false);
//     onSelect(site.label);
//   };

//   const handleLoadMore = () => {
//     if (hasMore && !loading) {
//       doSearch(query, currentPage + 1);
//     }
//   };

//   const handleScroll = (e) => {
//     const container = e.target;
//     const isAtBottom =
//       container.scrollHeight - container.scrollTop <=
//       container.clientHeight + 50;

//     if (isAtBottom && hasMore && !loading) {
//       handleLoadMore();
//     }
//   };

//   const borderColor = disabled
//     ? "#E5E7EB"
//     : focused
//     ? "#B91C1C"
//     : hovered
//     ? "#B91C1C"
//     : "#D1D5DB";
//   const boxShadow = disabled
//     ? "none"
//     : focused
//     ? "0 0 0 3px rgba(185,28,28,0.1)"
//     : hovered
//     ? "0 0 0 2px rgba(185,28,28,0.06)"
//     : "none";

//   return (
//     <div ref={containerRef} className="relative w-full">
//       <div
//         className="flex items-center gap-2 rounded-lg px-2.5 py-1.5 transition-all duration-150"
//         style={{
//           background: disabled
//             ? "#F3F4F6"
//             : focused || hovered
//             ? "#ffffff"
//             : "#F7F8FA",
//           border: `${focused ? "2px" : "1.5px"} ${
//             focused ? "solid" : "dashed"
//           } ${borderColor}`,
//           boxShadow,
//         }}
//         onMouseEnter={() => !disabled && setHovered(true)}
//         onMouseLeave={() => setHovered(false)}
//       >
//         <Search className="w-3 h-3 text-gray-400 shrink-0" />
//         <input
//           type="text"
//           value={query}
//           onChange={handleChange}
//           onFocus={() => {
//             if (!disabled) {
//               setFocused(true);
//               if (query.trim()) doSearch(query, 1);
//             }
//           }}
//           disabled={disabled}
//           placeholder="Type a site name to search…"
//           className="flex-1 text-xs text-gray-900 bg-transparent outline-none placeholder-gray-400 disabled:cursor-not-allowed"
//           autoComplete="off"
//         />
//         {query && !disabled && (
//           <button
//             onMouseDown={(e) => {
//               e.preventDefault();
//               setQuery("");
//               setResults([]);
//               setOpen(false);
//               onSelect("");
//             }}
//             className="text-gray-400 hover:text-gray-600 bg-transparent border-none cursor-pointer p-0 leading-none"
//             title="Clear"
//           >
//             <X className="w-2.5 h-2.5" />
//           </button>
//         )}
//       </div>

//       {(open || loading) && focused && (
//         <div
//           className="absolute z-50 left-0 right-0 rounded-2xl bg-white overflow-hidden"
//           style={{
//             boxShadow:
//               "0 8px 32px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.08)",
//             border: "1px solid #F1F1F1",
//             ...(dropUp
//               ? { bottom: "calc(100% + 8px)" }
//               : { top: "calc(100% + 8px)" }),
//           }}
//         >
//           <div className="flex items-center justify-between px-3 py-2 border-b border-gray-100">
//             <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-widest">
//               {loading && results.length === 0
//                 ? "Searching…"
//                 : `${results.length} of ${totalCount} site${
//                     totalCount !== 1 ? "s" : ""
//                   } found`}
//             </span>
//             {loading && results.length === 0 && (
//               <CircularSpinner size={12} />
//             )}
//           </div>

//           {loading && results.length === 0 ? (
//             <div className="px-3 py-2 flex flex-col gap-2">
//               {[90, 70, 80].map((w, i) => (
//                 <div key={i} className="flex items-center gap-2.5 py-1">
//                   <div className="w-7 h-7 rounded-full bg-gray-100 animate-pulse shrink-0" />
//                   <div className="flex flex-col gap-1 flex-1">
//                     <div
//                       className="h-2.5 rounded-full bg-gray-100 animate-pulse"
//                       style={{ width: `${w}%` }}
//                     />
//                     <div
//                       className="h-2 rounded-full bg-gray-50 animate-pulse"
//                       style={{ width: `${w - 20}%` }}
//                     />
//                   </div>
//                 </div>
//               ))}
//             </div>
//           ) : error ? (
//             <div className="flex items-center gap-2 px-4 py-3 text-xs text-red-500">
//               <AlertCircle size={13} className="shrink-0" />{" "}
//               {error}
//             </div>
//           ) : results.length === 0 ? (
//             <div className="flex flex-col items-center gap-1.5 px-4 py-5">
//               <Search className="w-7 h-7 text-gray-300" />
//               <span className="text-xs text-gray-400">
//                 No sites found for{" "}
//                 <strong className="text-gray-500">
//                   &ldquo;{query}&rdquo;
//                 </strong>
//               </span>
//             </div>
//           ) : (
//             <>
//               <ul
//                 ref={listRef}
//                 className="overflow-y-auto"
//                 style={{ maxHeight: 260 }}
//                 onScroll={handleScroll}
//               >
//                 {results.map((site, i) => (
//                   <li key={`${site.value}-${i}`}>
//                     <button
//                       onMouseDown={(e) => {
//                         e.preventDefault();
//                         handleSelect(site);
//                       }}
//                       className="w-full flex items-center gap-3 px-3 py-2.5 text-left border-none bg-transparent cursor-pointer group transition-all duration-100"
//                       style={{ background: "transparent" }}
//                       onMouseEnter={(e) =>
//                         (e.currentTarget.style.background =
//                           "#FEF2F2")
//                       }
//                       onMouseLeave={(e) =>
//                         (e.currentTarget.style.background =
//                           "transparent")
//                       }
//                     >
//                       <div
//                         className="w-7 h-7 shrink-0 rounded-full flex items-center justify-center text-[10px] font-bold"
//                         style={{
//                           background: `hsl(${
//                             (site.label.charCodeAt(0) * 37) %
//                             360
//                           }, 55%, 92%)`,
//                           color: `hsl(${
//                             (site.label.charCodeAt(0) * 37) %
//                             360
//                           }, 55%, 35%)`,
//                         }}
//                       >
//                         {site.label
//                           .split(" ")
//                           .map((w) => w[0])
//                           .slice(0, 2)
//                           .join("")
//                           .toUpperCase()}
//                       </div>
//                       <div className="flex flex-col min-w-0 flex-1">
//                         <span className="text-xs font-semibold text-gray-800 truncate leading-snug">
//                           <HighlightMatch
//                             text={site.label}
//                             query={query}
//                           />
//                         </span>
//                         {site.description ? (
//                           <span className="text-[10px] text-gray-400 truncate leading-snug">
//                             {site.description}
//                           </span>
//                         ) : site.parentLocation ? (
//                           <span className="text-[10px] text-gray-400 truncate leading-snug flex items-center gap-1">
//                             <svg
//                               width="9"
//                               height="9"
//                               viewBox="0 0 24 24"
//                               fill="none"
//                               stroke="currentColor"
//                               strokeWidth="2.5"
//                               strokeLinecap="round"
//                               strokeLinejoin="round"
//                               className="shrink-0"
//                             >
//                               <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
//                               <circle cx="9" cy="7" r="4" />
//                               <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
//                               <path d="M16 3.13a4 4 0 0 1 0 7.75" />
//                             </svg>
//                             {site.parentLocation}
//                           </span>
//                         ) : (
//                           <span className="text-[10px] text-gray-300 truncate leading-snug">
//                             No parent location
//                           </span>
//                         )}
//                       </div>
//                       <svg
//                         width="13"
//                         height="13"
//                         viewBox="0 0 24 24"
//                         fill="none"
//                         stroke="#B91C1C"
//                         strokeWidth="3"
//                         strokeLinecap="round"
//                         strokeLinejoin="round"
//                         className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
//                       >
//                         <polyline points="20 6 9 17 4 12" />
//                       </svg>
//                     </button>
//                   </li>
//                 ))}
//               </ul>

//               {hasMore && (
//                 <div className="px-3 py-2 border-t border-gray-100 text-center">
//                   {loading ? (
//                     <div className="flex items-center justify-center gap-2">
//                       <CircularSpinner size={12} />
//                       <span className="text-xs text-gray-500">
//                         Loading more...
//                       </span>
//                     </div>
//                   ) : (
//                     <button
//                       onClick={handleLoadMore}
//                       className="text-xs text-red-600 hover:text-red-700 font-medium transition-colors"
//                     >
//                       Load more sites
//                     </button>
//                   )}
//                 </div>
//               )}
//             </>
//           )}
//         </div>
//       )}
//     </div>
//   );
// }

// components/JnjSitesSearchDropdown.jsx

"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Search, X, ChevronDown, AlertCircle } from "lucide-react";
import { getJnjSitesPage } from "@/lib/getAllLocationsApi";

function CircularSpinner({ size = 16 }) {
  return (
    <div
      className="animate-spin"
      style={{
        width: size,
        height: size,
        border: `2px solid #E5E7EB`,
        borderTop: `2px solid #B91C1C`,
        borderRadius: "50%",
      }}
    />
  );
}

function HighlightMatch({ text, query }) {
  if (!query.trim()) return text;

  const parts = text.split(
    new RegExp(`(${query})`, "gi")
  );
  return (
    <>
      {parts.map((part, i) =>
        part.toLowerCase() === query.toLowerCase() ? (
          <mark
            key={i}
            className="bg-yellow-100 font-semibold no-underline"
          >
            {part}
          </mark>
        ) : (
          part
        )
      )}
    </>
  );
}

export default function JnjSitesSearchDropdown({
  value,
  onSelect,
  disabled = false,
  dropUp = false,
}) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const [displayValue, setDisplayValue] = useState(
    value || ""
  );
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [hasMore, setHasMore] = useState(false);

  const debounceRef = useRef(null);
  const containerRef = useRef(null);
  const listRef = useRef(null);
  const abortRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    setDisplayValue(value || "");
  }, [value]);

  useEffect(() => {
    const handler = (e) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target)
      ) {
        setOpen(false);
        setQuery("");
      }
    };
    document.addEventListener("mousedown", handler);
    return () =>
      document.removeEventListener("mousedown", handler);
  }, []);

  const doSearch = useCallback(
    async (text, page = 1) => {
      if (!text || text.trim().length < 1) {
        setResults([]);
        setOpen(false);
        setLoading(false);
        return;
      }

      if (abortRef.current) abortRef.current.abort();
      abortRef.current = new AbortController();

      setLoading(true);
      setError("");

      try {
        const response = await getJnjSitesPage(
          page,
          text.trim()
        );

        if (page === 1) {
          setResults(response.sites);
        } else {
          setResults((prev) => [...prev, ...response.sites]);
        }

        setTotalCount(response.totalCount);
        setHasMore(response.hasMore);
        setCurrentPage(page);
        setOpen(true);
        setLoading(false);
      } catch (err) {
        if (err.name !== "AbortError") {
          setError(
            "Could not load sites. Check connection."
          );
          setLoading(false);
          setOpen(true);
        }
      }
    },
    []
  );

  const handleChange = (e) => {
    const val = e.target.value;
    setQuery(val);
    setCurrentPage(1);
    setResults([]);
    setHasMore(false);

    clearTimeout(debounceRef.current);

    if (!val.trim()) {
      setResults([]);
      setOpen(false);
      setLoading(false);
      return;
    }

    setLoading(true);
    debounceRef.current = setTimeout(() => {
      doSearch(val, 1);
    }, 350);
  };

  const handleSelect = (site) => {
    setDisplayValue(site.label);
    setOpen(false);
    setQuery("");
    onSelect(site.label);
  };

  const handleClear = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDisplayValue("");
    setQuery("");
    setResults([]);
    setOpen(false);
    onSelect("");
  };

  const handleLoadMore = () => {
    if (hasMore && !loading) {
      doSearch(query, currentPage + 1);
    }
  };

  const handleScroll = (e) => {
    const container = e.target;
    const isAtBottom =
      container.scrollHeight - container.scrollTop <=
      container.clientHeight + 50;

    if (isAtBottom && hasMore && !loading) {
      handleLoadMore();
    }
  };

  return (
    <div ref={containerRef} className="w-full relative">
      {/* Main Display Button */}
      <button
        type="button"
        disabled={disabled}
        onClick={() => {
          if (!disabled) {
            setOpen(!open);
            if (!open) {
              setQuery("");
              setResults([]);
              setTimeout(() => inputRef.current?.focus(), 0);
            }
          }
        }}
        className={`
          flex
          h-10
          w-full
          items-center
          gap-2
          rounded-lg
          px-3
          text-left
          transition-all
          ${
            disabled
              ? "cursor-not-allowed border border-gray-200 bg-gray-100 opacity-60"
              : open
              ? "border-2 border-red-700 bg-white shadow-[0_0_0_3px_rgba(185,28,28,0.1)]"
              : "border border-slate-300 bg-white hover:border-slate-400"
          }
        `}
      >
        <span
          className={`flex-1 truncate text-sm ${
            displayValue
              ? "font-medium text-gray-900"
              : "text-gray-400"
          }`}
        >
          {displayValue || "Select..."}
        </span>

        {displayValue && !disabled && (
          <div
            onMouseDown={handleClear}
            className="flex h-5 w-5 items-center justify-center rounded-full bg-gray-100 hover:bg-red-100 cursor-pointer"
            title="Clear"
          >
            <X className="h-3 w-3 text-gray-500" />
          </div>
        )}

        <ChevronDown
          className={`h-4 w-4 text-gray-500 transition-transform flex-shrink-0 ${
            open ? "rotate-180" : ""
          }`}
        />
      </button>

      {/* Dropdown Menu */}
      {open && (
        <div
          className="
            absolute
            top-full
            left-0
            right-0
            mt-2
            overflow-hidden
            rounded-xl
            border
            border-gray-200
            bg-white
            shadow-xl
            z-50
          "
        >
          {/* Search Input */}
          <div className="border-b border-gray-100 bg-gray-50 p-2 sticky top-0 z-10">
            <div
              className="
                flex
                items-center
                gap-2
                rounded-lg
                border
                border-gray-200
                bg-white
                px-3
                py-2
              "
            >
              <Search className="h-4 w-4 text-gray-400 flex-shrink-0" />
              <input
                ref={inputRef}
                value={query}
                onChange={handleChange}
                placeholder="Search..."
                className="
                  flex-1
                  bg-transparent
                  text-sm
                  outline-none
                  placeholder:text-gray-400
                "
                autoComplete="off"
              />
            </div>
          </div>

          {/* Results */}
          <div
            ref={listRef}
            className="max-h-64 overflow-y-auto"
            onScroll={handleScroll}
          >
            {loading && results.length === 0 ? (
              <div className="px-4 py-6 text-center text-sm text-gray-400">
                <div className="flex items-center justify-center gap-2">
                  <CircularSpinner size={14} />
                  <span>Loading...</span>
                </div>
              </div>
            ) : error ? (
              <div className="flex items-center gap-2 px-4 py-3 text-xs text-red-500">
                <AlertCircle size={13} className="shrink-0" />{" "}
                {error}
              </div>
            ) : results.length === 0 ? (
              <div className="px-4 py-6 text-center text-sm text-gray-400">
                No sites found
              </div>
            ) : (
              <ul>
                {results.map((site, i) => (
                  <li key={`${site.value}-${i}`}>
                    <div
                      onClick={() => handleSelect(site)}
                      className={`
                        flex
                        w-full
                        items-center
                        gap-3
                        px-3
                        py-2.5
                        text-left
                        text-sm
                        transition-colors
                        bg-white
                        cursor-pointer
                        hover:bg-gray-50
                        border-b
                        border-gray-100
                        last:border-b-0
                      `}
                    >
                      <div
                        className="w-7 h-7 shrink-0 rounded-full flex items-center justify-center text-[10px] font-bold"
                        style={{
                          background: `hsl(${
                            (site.label.charCodeAt(0) * 37) %
                            360
                          }, 55%, 92%)`,
                          color: `hsl(${
                            (site.label.charCodeAt(0) * 37) %
                            360
                          }, 55%, 35%)`,
                        }}
                      >
                        {site.label
                          .split(" ")
                          .map((w) => w[0])
                          .slice(0, 2)
                          .join("")
                          .toUpperCase()}
                      </div>
                      <div className="flex flex-col min-w-0 flex-1">
                        <span className="text-xs font-medium text-gray-800 truncate">
                          <HighlightMatch
                            text={site.label}
                            query={query}
                          />
                        </span>
                        {site.description ? (
                          <span className="text-[10px] text-gray-400 truncate">
                            {site.description}
                          </span>
                        ) : site.parentLocation ? (
                          <span className="text-[10px] text-gray-400 truncate flex items-center gap-1">
                            <svg
                              width="9"
                              height="9"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2.5"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="shrink-0"
                            >
                              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                              <circle cx="9" cy="7" r="4" />
                              <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                            </svg>
                            {site.parentLocation}
                          </span>
                        ) : (
                          <span className="text-[10px] text-gray-300 truncate">
                            No parent location
                          </span>
                        )}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Footer */}
          <div
            className="
              border-t
              border-gray-100
              bg-gray-50
              px-3
              py-1
              text-right
              text-xs
              text-gray-400
            "
          >
            {results.length} option
            {results.length !== 1 ? "s" : ""}
            {hasMore && (
              <button
                onClick={handleLoadMore}
                className="ml-2 text-red-600 hover:text-red-700 font-medium"
              >
                Load more
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
