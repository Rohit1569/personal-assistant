import { BotAvatar, UserAvatar } from './Avatars'
 
function Time({ t, right }) {
  return <div className={`text-[10px] text-gray-400 mt-1 ${right ? 'text-right' : 'pl-0.5'}`}>{t}</div>
}
 
export function BotBubble({ html, time }) {
  return (
    <div className="flex items-start gap-2 animate-fade-up w-full">
      <BotAvatar />
      <div style={{ flex: '1 1 0', minWidth: 0 }}>
        <div className="inline-block bg-white border border-red-200 rounded-2xl rounded-tl-none px-3.5 py-2.5 shadow-sm text-[13px] leading-relaxed text-gray-900" style={{ maxWidth: '75%', wordBreak: 'break-word' }}>
          <div dangerouslySetInnerHTML={{ __html: html }} />
        </div>
        {time && <Time t={time} />}
      </div>
    </div>
  )
}
 
export function UserBubble({ text, imageUrl, fileName, fileUrl, s3Key, time }) {
  return (
    <div className="flex items-start gap-2 flex-row-reverse animate-fade-up w-full">
      <UserAvatar />
      <div style={{ flex: '1 1 0', minWidth: 0 }}>
        <div className="flex flex-col items-end gap-1.5">

          {/* Image preview */}
          {imageUrl && (
            <div className="rounded-2xl rounded-tr-none overflow-hidden border border-red-200 shadow-sm" style={{ maxWidth: '60%' }}>
              <img src={imageUrl} alt={fileName || 'uploaded'} className="block w-full max-h-56 object-cover" />
            </div>
          )}

          {/* File preview */}
          {fileUrl && (
            <div className="rounded-2xl rounded-tr-none overflow-hidden border border-red-200 shadow-sm bg-red-50 p-3" style={{ maxWidth: '60%' }}>
              <div className="flex items-center gap-2">
                <div className="flex-shrink-0 w-8 h-8 bg-red-200 rounded flex items-center justify-center">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/>
                    <polyline points="13 2 13 9 20 9"/>
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[12px] font-medium text-gray-900 truncate">{fileName}</p>
                  {s3Key && (
                    <p className="text-[10px] text-gray-600">Uploaded to S3</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Text bubble — only shown if there's text */}
          {text && (
            <div className="bg-white border border-red-300 rounded-2xl rounded-tr-none px-3.5 py-2.5 shadow-sm text-[13px] leading-relaxed text-gray-900 whitespace-pre-wrap" style={{ maxWidth: '72%', wordBreak: 'break-word' }}>
              {text}
            </div>
          )}
        </div>

        {time && <Time t={time} right />}
      </div>
    </div>
  )
}
