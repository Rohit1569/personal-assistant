// components/LanguageSelector.jsx
'use client';

import { useState, useEffect, useRef } from 'react';

const DEFAULT_LANGUAGES = [
  "Arabic",
  "Chinese",
  "Czech (Czechia)",
  "Dutch (Belgium)",
  "Dutch",
  "English",
  "French (France)",
  "German (Germany)",
  "Indonesian (Indonesia)",
  "Italian (Italy)",
  "Japanese (Japan)",
  "Korean (Korea)",
  "Malay",
  "Polish (Poland)",
  "Portuguese (Brazil)",
  "Russian (Russia)",
  "Spanish (Mexico)",
  "Swedish (Sweden)",
  "Thai (Thailand)"
];

export default function LanguageSelector({
  onLanguageSelect,
  isModal = false,
  languages = DEFAULT_LANGUAGES,
  selectedLanguage: selectedFromProps,
}) {
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const [searchTerm, setSearchTerm] = useState('');
  const [highlightedIndex, setHighlightedIndex] = useState(0);
  const listRef = useRef(null);
  const searchRef = useRef(null);

  useEffect(() => {
    // Initialize selection: prop -> localStorage -> default
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('selectedLanguage');
      if (selectedFromProps) {
        setSelectedLanguage(selectedFromProps);
      } else if (saved) {
        setSelectedLanguage(saved);
      }
    } else if (selectedFromProps) {
      setSelectedLanguage(selectedFromProps);
    }
  }, [selectedFromProps]);

  useEffect(() => {
    // reset highlight when search results change
    setHighlightedIndex(0);
  }, [searchTerm]);

  const filtered = languages.filter((l) =>
    l.toLowerCase().includes(searchTerm.trim().toLowerCase())
  );

  const persistAndNotify = (lang) => {
    setSelectedLanguage(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('selectedLanguage', lang);
    }
    if (onLanguageSelect) onLanguageSelect(lang);
  };

  // keyboard navigation for the list
  const onListKeyDown = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightedIndex((i) => Math.min(i + 1, Math.max(0, filtered.length - 1)));
      scrollIntoView(highlightedIndex + 1);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightedIndex((i) => Math.max(i - 1, 0));
      scrollIntoView(highlightedIndex - 1);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const choice = filtered[highlightedIndex];
      if (choice) persistAndNotify(choice);
    } else if (e.key === 'Escape') {
      // blur search input to close if parent closes it; we don't manage parent state here
      searchRef.current?.blur();
    }
  };

  const scrollIntoView = (index) => {
    const el = listRef.current;
    if (!el) return;
    const items = el.querySelectorAll('[data-lang-item]');
    const item = items[index];
    if (item) item.scrollIntoView({ block: 'nearest' });
  };

  if (isModal) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-2xl p-6 max-w-lg w-full mx-4">
          <h2 className="text-xl font-semibold text-gray-900 mb-1">Select Language</h2>
          <p className="text-sm text-gray-600 mb-4">Choose your preferred language</p>

          <div className="mb-3">
            <input
              ref={searchRef}
              type="search"
              placeholder="Search languages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-red-400"
              aria-label="Search languages"
            />
          </div>

          <div
            ref={listRef}
            tabIndex={0}
            onKeyDown={onListKeyDown}
            className="space-y-2 max-h-64 overflow-y-auto mb-4"
            role="listbox"
            aria-activedescendant={`lang-${highlightedIndex}`}
          >
            {filtered.length === 0 ? (
              <div className="text-sm text-gray-500 p-3">No languages found</div>
            ) : (
              filtered.map((lang, idx) => {
                const isHighlighted = idx === highlightedIndex;
                const isSelected = lang === selectedLanguage;
                return (
                  <button
                    key={lang}
                    data-lang-item
                    id={`lang-${idx}`}
                    onClick={() => persistAndNotify(lang)}
                    onMouseEnter={() => setHighlightedIndex(idx)}
                    className={`w-full text-left px-3 py-2 rounded-md flex items-center justify-between text-sm transition ${
                      isHighlighted ? 'bg-red-50' : 'hover:bg-gray-50'
                    } ${isSelected ? 'font-semibold text-red-600' : 'text-gray-800'}`}
                    role="option"
                    aria-selected={isSelected}
                  >
                    <div>
                      <div className="truncate">{lang}</div>
                    </div>

                    {isSelected && (
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    )}
                  </button>
                );
              })
            )}
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => persistAndNotify(selectedLanguage)}
              className="flex-1 bg-red-500 text-white py-2 rounded-md text-sm font-semibold hover:bg-red-600"
            >
              Continue
            </button>
            <button
              onClick={() => {
                // just close - parent should decide how to hide modal; here we persist current selection
                persistAndNotify(selectedLanguage);
              }}
              className="flex-1 border border-gray-300 py-2 rounded-md text-sm"
            >
              Save
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Inline/dropdown style (for use inside a popover/header)
  return (
    <div className="w-full">
      <label className="block text-sm font-medium text-gray-700 mb-2">Language</label>

      <div className="border rounded-lg bg-white">
        <div className="p-2">
          <input
            ref={searchRef}
            type="search"
            placeholder="Search languages..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown') {
                e.preventDefault();
                setHighlightedIndex(0);
                // move focus to list container for consistent nav
                listRef.current?.focus();
              }
            }}
            className="w-full px-3 py-2 text-sm rounded-md border border-gray-200 focus:outline-none focus:ring-1 focus:ring-red-400"
            aria-label="Search languages"
          />
        </div>

        <div
          ref={listRef}
          tabIndex={0}
          onKeyDown={onListKeyDown}
          className="max-h-48 overflow-y-auto p-1"
          role="listbox"
          aria-activedescendant={`lang-${highlightedIndex}`}
        >
          {filtered.length === 0 ? (
            <div className="p-3 text-sm text-gray-500">No languages found</div>
          ) : (
            filtered.map((lang, idx) => {
              const isHighlighted = idx === highlightedIndex;
              const isSelected = lang === selectedLanguage;
              return (
                <button
                  key={lang}
                  data-lang-item
                  id={`lang-${idx}`}
                  onClick={() => persistAndNotify(lang)}
                  onMouseEnter={() => setHighlightedIndex(idx)}
                  className={`w-full text-left px-3 py-2 rounded-md flex items-center justify-between text-sm transition ${
                    isHighlighted ? 'bg-red-50' : 'hover:bg-gray-50'
                  } ${isSelected ? 'font-semibold text-red-600' : 'text-gray-800'}`}
                  role="option"
                  aria-selected={isSelected}
                >
                  <div>
                    <div className="truncate">{lang}</div>
                  </div>

                  {isSelected && (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
