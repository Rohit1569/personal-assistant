"use client";

import { useEffect, useMemo, useState, useRef, useCallback } from "react";
import {
  AlertCircle,
  RotateCcw,
  Search,
  ChevronsLeft,
  ChevronLeft,
  ChevronRight,
  ChevronsRight,
  ShieldAlert,
  Filter,
  X,
  Check,
} from "lucide-react";
import { useRouter } from "next/navigation";
import Header from "@/components/Header";
import { fetchIncidents } from "@/lib/incidentsApi";
import { fetchEmployeeNumberByEmail } from "@/lib/getWwidApi";

/* ================================================================== */
/* Config / helpers                                                    */
/* ================================================================== */

const PAGE_SIZE = 50;

const SEVERITY_STYLES = {
  Low: "bg-emerald-50 text-emerald-700 ring-emerald-600/20",
  Medium: "bg-amber-50 text-amber-700 ring-amber-600/20",
  High: "bg-orange-50 text-orange-700 ring-orange-600/20",
  Critical: "bg-red-50 text-red-700 ring-red-600/20",
};
const STATUS_STYLES = {
  Open: "bg-sky-50 text-sky-700 ring-sky-600/20",
  "Under Review": "bg-violet-50 text-violet-700 ring-violet-600/20",
  Closed: "bg-slate-100 text-slate-600 ring-slate-500/20",
  "Pending Approval": "bg-amber-50 text-amber-700 ring-amber-600/20",
};

const prettify = (key) =>
  key
    .replace(/[_-]+/g, " ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/\b\w/g, (c) => c.toUpperCase());

/* ================================================================== */
/* Small Circular Spinner                                              */
/* ================================================================== */

function Spinner() {
  return (
    <div className="flex flex-1 items-center justify-center">
      <div className="h-8 w-8 animate-spin rounded-full border-4 border-slate-200 border-t-red-600" />
    </div>
  );
}

/* ================================================================== */
/* Hooks                                                               */
/* ================================================================== */

function useIncidents(page, filters, owner) {
  const [incidents, setIncidents] = useState([]);
  const [columns, setColumns] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [hasLoaded, setHasLoaded] = useState(false);

  const filterKey = JSON.stringify(filters);
  const fetchIdRef = useRef(0);

  useEffect(() => {
    const controller = new AbortController();
    const currentFetchId = ++fetchIdRef.current;

    const doFetch = async () => {
      // If owner is not ready yet, skip fetch but keep UI state consistent
      if (!owner || owner.trim() === "") {
        setLoading(false);
        setHasLoaded(false);
        setIncidents([]);
        setTotal(0);
        return;
      }

      setLoading(true);
      setError(null);

      try {
        const data = await fetchIncidents({
          page,
          size: PAGE_SIZE,
          filters,
          owner,
          signal: controller.signal,
        });

        if (currentFetchId !== fetchIdRef.current) return;

        const list = data?.data || [];

        setIncidents(list);
        setTotal(data.total ?? list.length);
        setHasLoaded(true);

        if (list.length > 0) {
          setColumns(
            Object.keys(list[0]).map((key) => ({
              key,
              label: prettify(key),
            }))
          );
        } else {
          setColumns([]);
        }
      } catch (err) {
        if (err?.name === "AbortError") return;
        if (currentFetchId !== fetchIdRef.current) return;
        setError("Couldn't load incidents.");
        setIncidents([]);
        setTotal(0);
        setHasLoaded(true);
      } finally {
        if (currentFetchId === fetchIdRef.current) {
          setLoading(false);
        }
      }
    };

    doFetch();
    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, filterKey, owner]);

  const retry = useCallback(() => {
    setLoading(true);
    setError(null);
    const currentFetchId = ++fetchIdRef.current;

    const doFetch = async () => {
      try {
        const data = await fetchIncidents({
          page,
          size: PAGE_SIZE,
          filters,
          owner,
        });

        if (currentFetchId !== fetchIdRef.current) return;

        const list = data?.data || [];
        setIncidents(list);
        setTotal(data.total ?? list.length);
        setHasLoaded(true);

        if (list.length > 0) {
          setColumns(
            Object.keys(list[0]).map((key) => ({
              key,
              label: prettify(key),
            }))
          );
        } else {
          setColumns([]);
        }
      } catch (err) {
        if (currentFetchId !== fetchIdRef.current) return;
        setError("Couldn't load incidents.");
        setIncidents([]);
        setTotal(0);
        setHasLoaded(true);
      } finally {
        if (currentFetchId === fetchIdRef.current) {
          setLoading(false);
        }
      }
    };

    doFetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, filterKey, owner]);

  return { incidents, columns, total, loading, error, retry, hasLoaded };
}

/* ================================================================== */
/* Presentational components                                           */
/* ================================================================== */

function Badge({ value, styles }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${
        styles[value] || "bg-slate-100 text-slate-600 ring-slate-500/20"
      }`}
    >
      {value}
    </span>
  );
}

function Toolbar({ activeCount, onApply, onReset }) {
  const router = useRouter();
  return (
    <div className="flex items-center justify-between gap-3 border-b border-slate-200 bg-white px-6 py-3">
      <div className="flex items-center gap-2 text-sm text-slate-500">
        <Filter className="h-4 w-4" />
        <span>
          {activeCount > 0
            ? `${activeCount} filter${activeCount > 1 ? "s" : ""} applied`
            : "No filters applied"}
        </span>
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={onReset}
          disabled={activeCount === 0}
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600 transition hover:bg-slate-50 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-40"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          Reset
        </button>
        <button
          onClick={onApply}
          className="inline-flex items-center gap-1.5 rounded-lg bg-red-600 px-4 py-1.5 text-xs font-semibold text-white shadow-sm transition hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-300"
        >
          <Check className="h-3.5 w-3.5" />
          Apply Filters
        </button>
        <button
          onClick={() => router.push("https://curve-agent-qa.jnj.com/curve-chatbot")}
          className="inline-flex items-center gap-1.5 rounded-lg bg-red-600 px-4 py-1.5 text-xs font-semibold text-white shadow-sm transition hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-300"
        >
          + New Incident
        </button>
      </div>
    </div>
  );
}

function FilterChips({ filters, columnLabels, onRemove, onClear }) {
  const entries = Object.entries(filters).filter(([, v]) => v && v.trim() !== "");
  if (entries.length === 0) return null;

  return (
    <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 bg-slate-50 px-6 py-2.5">
      <span className="text-xs font-medium text-slate-500">Applied:</span>
      {entries.map(([key, value]) => (
        <span
          key={key}
          className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white py-1 pl-2.5 pr-1 text-xs text-slate-700 shadow-sm"
        >
          <span className="text-slate-400">{columnLabels[key] || prettify(key)}:</span>
          <span className="font-medium">{value}</span>
          <button
            onClick={() => onRemove(key)}
            className="flex h-4 w-4 items-center justify-center rounded-full text-slate-400 transition hover:bg-red-100 hover:text-red-600"
            aria-label={`Remove ${columnLabels[key] || key} filter`}
          >
            <X className="h-3 w-3" />
          </button>
        </span>
      ))}
      {entries.length > 1 && (
        <button onClick={onClear} className="text-xs font-medium text-red-600 hover:underline">
          Clear all
        </button>
      )}
    </div>
  );
}

function FilterInput({ value, onChange, applySignal }) {
  const [local, setLocal] = useState(value);

  useEffect(() => {
    setLocal(value);
  }, [value]);

  const firstRun = useRef(true);
  useEffect(() => {
    if (firstRun.current) {
      firstRun.current = false;
      return;
    }
    onChange(local);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [applySignal]);

  const commit = () => onChange(local);

  return (
    <div className="relative">
      <Search className="pointer-events-none absolute left-2 top-1/2 h-3 w-3 -translate-y-1/2 text-slate-400" />
      <input
        value={local}
        onChange={(e) => setLocal(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            commit();
          }
        }}
        onBlur={commit}
        placeholder="Filter"
        className="w-full min-w-[120px] rounded-md border border-slate-200 bg-slate-50 py-1 pl-7 pr-2 text-xs text-slate-700 transition placeholder:text-slate-400 focus:border-red-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-100"
      />
    </div>
  );
}

function TableCell({ col, row, isFirst }) {
  const router = useRouter();
  const value = row[col.key];
  const keyLower = col.key.toLowerCase();

  const handleClick = () => {
    router.push(`/investigation/${encodeURIComponent(String(value))}?section=initial-report`);
  };

  const isRecordNo = col.key === "Record No.";

  const content = (() => {
    if (isRecordNo) {
      return (
        <button onClick={handleClick} className="font-semibold text-blue-600 hover:underline">
          {value ?? "--"}
        </button>
      );
    }

    if (keyLower.includes("severity")) return <Badge value={value} styles={SEVERITY_STYLES} />;
    if (keyLower.includes("status")) return <Badge value={value} styles={STATUS_STYLES} />;

    if (isFirst) {
      return <span className="font-semibold text-slate-900">{value ?? "--"}</span>;
    }

    if (keyLower.includes("description")) {
      return (
        <div className="max-w-[500px] whitespace-normal break-words" title={String(value ?? "")}>
          {value ?? "--"}
        </div>
      );
    }

    return value ?? "--";
  })();

  return (
    <td
      className={`whitespace-nowrap border-b border-slate-100 px-4 py-2.5 text-slate-700 ${
        isFirst ? "sticky left-0 z-10 bg-white font-medium text-slate-900 group-hover:bg-red-50/40" : ""
      }`}
    >
      {content}
    </td>
  );
}

function TableRow({ row, columns }) {
  return (
    <tr className="group transition hover:bg-red-50/40">
      {columns.map((col, i) => (
        <TableCell key={col.key} col={col} row={row} isFirst={i === 0} />
      ))}
    </tr>
  );
}

function EmptyState({ colSpan, onClear }) {
  return (
    <tr>
      <td colSpan={colSpan} className="py-16">
        <div className="flex flex-col items-center gap-2 text-slate-400">
          <Search className="h-6 w-6" />
          <p className="text-sm font-medium text-slate-600">No incidents match your filters</p>
          <button onClick={onClear} className="text-xs font-medium text-red-600 hover:underline">
            Clear all filters
          </button>
        </div>
      </td>
    </tr>
  );
}

function IncidentTable({ columns, rows, filters, onFilterChange, onClear, applySignal }) {
  return (
    <div className="custom-scroll flex-1 overflow-auto">
      <table className="min-w-max border-separate border-spacing-0 text-sm">
        <thead>
          <tr>
            {columns.map((col, i) => (
              <th
                key={col.key}
                className={`whitespace-nowrap border-b border-slate-200 bg-slate-50/95 px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500 backdrop-blur ${
                  i === 0 ? "sticky left-0 top-0 z-30" : "sticky top-0 z-20"
                }`}
              >
                {col.label}
              </th>
            ))}
          </tr>
          <tr>
            {columns.map((col, i) => (
              <th
                key={col.key}
                className={`border-b border-slate-200 bg-white px-3 py-2 ${
                  i === 0 ? "sticky left-0 top-[41px] z-30" : "sticky top-[41px] z-20"
                }`}
              >
                <FilterInput
                  value={filters[col.key] || ""}
                  onChange={(v) => onFilterChange(col.key, v)}
                  applySignal={applySignal}
                />
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <TableRow key={i} row={row} columns={columns} />
          ))}
          {rows.length === 0 && <EmptyState colSpan={columns.length} onClear={onClear} />}
        </tbody>
      </table>
    </div>
  );
}

function PagerBtn({ children, onClick, disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="flex h-7 w-7 items-center justify-center rounded-md text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-30"
    >
      {children}
    </button>
  );
}

function Pagination({ page, totalPages, total, startRecord, endRecord, onGo, loading }) {
  const pageNumbers = useMemo(() => {
    const out = [];
    const win = 1;
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || (i >= page - win && i <= page + win)) {
        out.push(i);
      } else if (out[out.length - 1] !== "...") {
        out.push("...");
      }
    }
    return out;
  }, [totalPages, page]);

  return (
    <footer className="flex flex-col items-center justify-between gap-3 border-t border-slate-200 bg-white px-6 py-3 sm:flex-row">
      <p className="text-xs text-slate-500">
        {loading ? (
          "Loading..."
        ) : total > 0 ? (
          <>
            Showing{" "}
            <span className="font-medium text-slate-700">
              {startRecord}-{endRecord}
            </span>{" "}
            of <span className="font-medium text-slate-700">{total.toLocaleString()}</span>
          </>
        ) : (
          "No records"
        )}
      </p>

      <div className="flex items-center gap-1">
        <PagerBtn onClick={() => onGo(1)} disabled={loading || page === 1}>
          <ChevronsLeft className="h-4 w-4" />
        </PagerBtn>
        <PagerBtn onClick={() => onGo(page - 1)} disabled={loading || page === 1}>
          <ChevronLeft className="h-4 w-4" />
        </PagerBtn>

        {pageNumbers.map((p, idx) =>
          p === "..." ? (
            <span key={`e${idx}`} className="px-1.5 text-xs text-slate-400">
              ...
            </span>
          ) : (
            <button
              key={p}
              onClick={() => onGo(p)}
              disabled={loading}
              className={`min-w-[30px] rounded-md px-2 py-1 text-xs font-medium transition ${
                p === page
                  ? "bg-red-600 text-white shadow-sm"
                  : "text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed"
              }`}
            >
              {p}
            </button>
          )
        )}

        <PagerBtn onClick={() => onGo(page + 1)} disabled={loading || page === totalPages}>
          <ChevronRight className="h-4 w-4" />
        </PagerBtn>
        <PagerBtn onClick={() => onGo(totalPages)} disabled={loading || page === totalPages}>
          <ChevronsRight className="h-4 w-4" />
        </PagerBtn>
      </div>
    </footer>
  );
}

function ErrorState({ message, onRetry }) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-3 py-20">
      <AlertCircle className="h-6 w-6 text-red-500" />
      <p className="text-sm text-slate-600">{message}</p>
      <button
        onClick={onRetry}
        className="inline-flex items-center gap-1.5 rounded-lg bg-red-600 px-4 py-1.5 text-xs font-semibold text-white shadow-sm transition hover:bg-red-700"
      >
        <RotateCcw className="h-3.5 w-3.5" />
        Retry
      </button>
    </div>
  );
}

/* ================================================================== */
/* Container                                                           */
/* ================================================================== */

export default function IncidentsPage() {
  const [filters, setFilters] = useState({});
  const [page, setPage] = useState(1);
  const [applySignal, setApplySignal] = useState(0);

  // Owner auto-derived from cookie (/api/me) + WWID via Intelex lookup
  const [owner, setOwner] = useState("");
  const [ownerLoading, setOwnerLoading] = useState(true);
  const [ownerError, setOwnerError] = useState(null);

  // Load profile from cookie and WWID from API, then compose owner
  useEffect(() => {
    let cancelled = false;

    async function loadOwner() {
      setOwnerLoading(true);
      setOwnerError(null);
      try {
        const res = await fetch("/api/me", { credentials: "include" });
        if (!res.ok) throw new Error("Unauthorized");

        const user = await res.json();

        // Avoid logging PII (email) in consoles
        let id = "";
        try {
          id = await fetchEmployeeNumberByEmail(user.email);
        } catch {
          id = "";
        }

        if (cancelled) return;

        const first = (user.firstName || "").trim();
        const last = (user.lastName || "").trim();
        const wwid = (id || "").trim();

        if (first && last && wwid) {
          setOwner(`${first.toUpperCase()} ${last.toUpperCase()} (${wwid})`);
        } else {
          setOwner("");
        }
      } catch (e) {
        if (!cancelled) {
          setOwner("");
          setOwnerError("Unable to resolve owner from session.");
        }
      } finally {
        if (!cancelled) setOwnerLoading(false);
      }
    }

    loadOwner();
    return () => {
      cancelled = true;
    };
  }, []);

  const {
    incidents,
    columns,
    total,
    loading,
    error,
    retry,
    hasLoaded,
  } = useIncidents(page, filters, owner);

  const columnLabels = useMemo(
    () => Object.fromEntries(columns.map((c) => [c.key, c.label])),
    [columns]
  );

  const totalPages = total ? Math.max(1, Math.ceil(total / PAGE_SIZE)) : 1;
  const startRecord = total === 0 ? 0 : (page - 1) * PAGE_SIZE + 1;
  const endRecord = Math.min(page * PAGE_SIZE, total);

  const activeCount = useMemo(
    () => Object.values(filters).filter((v) => v && v.trim() !== "").length,
    [filters]
  );

  const setFilter = useCallback((key, value) => {
    const clean = value && value.trim() !== "" ? value : "";
    setFilters((prev) => {
      const current = prev[key] || "";
      if (clean === current) return prev;
      setPage(1);
      const next = { ...prev };
      if (clean) next[key] = clean;
      else delete next[key];
      return next;
    });
  }, []);

  const removeFilter = useCallback((key) => {
    setPage(1);
    setFilters((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  }, []);

  const clearFilters = useCallback(() => {
    setPage(1);
    setFilters({});
  }, []);

  const applyFilters = useCallback(() => setApplySignal((n) => n + 1), []);

  const goToPage = useCallback(
    (target) => {
      if (target < 1 || target > totalPages) return;
      setPage(target);
    },
    [totalPages]
  );

  const showLoader = ownerLoading || loading || !hasLoaded;
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/me', { credentials: 'include' });
        if (!res.ok) return;
        const user = await res.json();
        if (cancelled) return;
        setProfile({
          firstName: user.firstName || '',
          lastName: user.lastName || '',
          email: user.email || '',
          displayName: user.displayName || '',
        });
      } catch {}
    })();
    return () => { cancelled = true; };
  }, []);

  const handleLogout = () => {
    try { sessionStorage.setItem('justLoggedOut', '1'); } catch {}
    window.location.replace('/api/logout');
  };
  return (
    <main className="flex h-screen flex-col bg-slate-100 font-sans text-slate-800 antialiased">
      <Header  hideActions profile={profile} onLogout={handleLogout} />

      <div className="border-b border-slate-200 bg-white px-6 py-3.5">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-600/10">
            <ShieldAlert className="h-5 w-5 text-red-600" />
          </div>
          <div>
            <h1 className="text-base font-semibold leading-tight text-slate-900">
              Incident Register
            </h1>
            <p className="text-xs text-slate-500">
              EHS events
              {!showLoader && total ? ` · ${total.toLocaleString()} records` : ""}
            </p>
            {/* {owner ? (
              <p className="mt-1 text-[11px] text-slate-400">
                Owner: <span className="font-medium text-slate-600">{owner}</span>
              </p>
            ) : ownerError ? (
              <p className="mt-1 text-[11px] text-red-600">{ownerError}</p>
            ) : null} */}
          </div>
        </div>
      </div>

      <Toolbar activeCount={activeCount} onApply={applyFilters} onReset={clearFilters} />

      <FilterChips
        filters={filters}
        columnLabels={columnLabels}
        onRemove={removeFilter}
        onClear={clearFilters}
      />

      <div className="flex-1 overflow-hidden px-6 py-4">
        <div className="flex h-full flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
          {error && !loading ? (
            <ErrorState message={error} onRetry={retry} />
          ) : showLoader ? (
            <Spinner />
          ) : (
            <IncidentTable
              columns={columns}
              rows={incidents}
              filters={filters}
              onFilterChange={setFilter}
              onClear={clearFilters}
              applySignal={applySignal}
            />
          )}
        </div>
      </div>

      <Pagination
        page={page}
        totalPages={totalPages}
        total={total}
        startRecord={startRecord}
        endRecord={endRecord}
        onGo={goToPage}
        loading={showLoader}
      />

      <style>{`
        .custom-scroll::-webkit-scrollbar { height: 10px; width: 10px; }
        .custom-scroll::-webkit-scrollbar-track { background: #f1f5f9; }
        .custom-scroll::-webkit-scrollbar-thumb {
          background: #cbd5e1; border-radius: 9999px; border: 2px solid #f1f5f9;
        }
        .custom-scroll::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
      `}</style>
    </main>
  );
}
