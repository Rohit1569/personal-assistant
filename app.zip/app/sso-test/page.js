"use client";

export default function SSOTestPage() {
  const startSSO = () => {
    window.location.href = "/api/saml/login";
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100">
      <div className="bg-white p-8 rounded-xl shadow-lg">
        <h1 className="text-2xl font-bold mb-6">
          Curve Chatbot SSO Test
        </h1>

        <button
          onClick={startSSO}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg"
        >
          Sign In with Microsoft
        </button>
      </div>
    </div>
  );
}