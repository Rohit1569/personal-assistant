'use client';

import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { fetchEmployeeNumberByEmail } from '@/lib/getWwidApi';
import { createSession, clearSession } from '@/lib/websocket';

export const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [profile, setProfile] = useState(null);
  const [wwid, setWwid] = useState('');
  const [session, setSession] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const [timezone, setTimezone] = useState('');
  const [loading, setLoading] = useState(true);

  // Timezone
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const now = new Date();
    const offset = -now.getTimezoneOffset(); // minutes east of UTC
    const sign = offset >= 0 ? '+' : '-';
    const hours = Math.floor(Math.abs(offset) / 60);
    const minutes = Math.abs(offset) % 60;
    const gmtOffset = `GMT${sign}${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
    setTimezone(gmtOffset);
  }, []);

  // Language from localStorage
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const saved = localStorage.getItem('selectedLanguage');
    if (saved) setSelectedLanguage(saved);
  }, []);

  // Session
  useEffect(() => {
    (async () => {
      try {
        const res = await createSession();
        if (res?.session_id) setSession(res.session_id);
      } catch {
        // ignore
      }
    })();
  }, []);

  // Profile + WWID
  useEffect(() => {
    (async () => {
      try {
        const response = await fetch('/api/me', { credentials: 'include' });
        if (!response.ok) {
          setLoading(false);
          return;
        }
        const user = await response.json();
        setProfile({
          firstName: user.firstName || '',
          lastName: user.lastName || '',
          email: user.email || '',
          displayName: user.displayName || '',
        });

        try {
          const number = await fetchEmployeeNumberByEmail(user.email);
          setWwid(number || '');
        } catch {
          // ignore
        }
      } catch {
        // ignore
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const onLanguageChange = (lang) => {
    setSelectedLanguage(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('selectedLanguage', lang);
    }
    clearSession();
    window.location.reload();
  };

  const onReset = async () => {
    await clearSession();
    window.location.reload();
  };

  const onLogout = () => {
    try {
      sessionStorage.setItem('justLoggedOut', '1');
    } catch {}
    window.location.replace('/api/logout');
  };

  const value = useMemo(
    () => ({
      loading,
      profile,
      wwid,
      session,
      selectedLanguage,
      timezone,
      onLanguageChange,
      onReset,
      onLogout,
    }),
    [loading, profile, wwid, session, selectedLanguage, timezone]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export const useApp = () => useContext(AppContext);
