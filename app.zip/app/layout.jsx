import './globals.css'
import { AppProvider } from './context/AppContext'
export const metadata = {
  title: 'Curve EHS&S Assistant',
  description: 'Enterprise EHS&S Event Reporting Chatbot',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="h-full">
      <body className="h-full bg-warm-50 antialiased">
               <AppProvider>
          {children}
        </AppProvider>

      </body>
    </html>
  )
}
