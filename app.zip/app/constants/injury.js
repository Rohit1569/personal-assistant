export const YES_NO_OPTIONS = [
  "Yes",
  "No",
];

export const WORKER_TYPES = [
 "J&J Employee",
 "Visitor/other",
 "Agency worker supervised by J&J (Non-J&J Employee)",
 "Contractor (Embedded)",
 "Contractor (Non-Embedded)"
];

export const PRIMARY_SEVERITY = [
  "J&J First Aid",
  "J&J Minor Injury/Illness Case",
  "J&J Serious Injury/Illness Case (SIIC)",
  "J&J Severe Injury or Fatality (SIF)",
  "Local regulatory injury/illness ONLY",
];

export const ADDITIONAL_SEVERITY = [
  "J&J Lost Workday Case (LWDC)",
  "J&J Restricted work activity or work adaptation",
  "Local regulatory injury/illness",
];

export const MECHANISM_GENERAL = [
  "Animal/Insect",
  "Ergonomics",
  "Mental Illness",
  "Slip/Trip/Fall same level",
  "Travel Related Illness",
  "Caught between",
  "Fall from Height",
  "Sharp injuries / needle stick",
  "Struck-by or against",
  "Violence",
  "Other",
];

export const EXPOSURE_TYPES = [
  "Biohazard",
  "Electrical",
  "Noise",
  "Thermal (heat/cold)",
  "Chemicals",
  "Fire / Explosion",
  "Radiation",
  "Other",
];

export const VEHICLE_ACCIDENT_TYPES = [
  "Facility",
  "Fleet",
  "Other",
];

export const BODY_PART_OPTIONS = [
  "Back",
  "Eye(s)",
  "Lower extremities",
  "Not Otherwise Specified",
  "Trunk, except back/spine",
  "Wrist(s)/Hand(s)/Finger(s)",
  "Body system(s)",
  "Head, excluding eye(s)",
  "Neck",
  "Other body part",
  "Upper extremities, excluding hands/fingers",
];

export const INJURY_OUTCOMES = [
  "Acute Internal Organ Damage",
  "Amputation",
  "Allergy",
  "Bite/sting",
  "Blister",
  "Burn (chemical/thermal)",
  "Carpal tunnel",
  "Circulatory/Cardiovascular",
  "Chronic Internal Organ Damage",
  "Contusion",
  "Crush",
  "Cut / laceration / abrasion / avulsion / puncture",
  "Dermatitis / Rash",
  "Dislocation",
  "Electrocution",
  "Exposure to toxic material",
  "Fatality",
  "Food borne illness (Hep A, salmonella, etc)",
  "Fracture - hairline",
  "Fracture - other than hairline",
  "Hearing - Tinnitus",
  "Hearing Cat 3 - Noise induced hearing loss",
  "Hearing Cat 4 - Rapid hearing loss",
  "Hyperthermia / Hypothermia",
  "Infection",
  "Medical Condition not work related",
  "Muscular/tendon/Ligament injury",
  "Nosebleed",
  "Paralysis",
  "Respiratory Damage / Problem",
  "Stress",
  "Tooth injury",
  "Traumatic brain injury - concussion",
  "Vision loss",
  "Other",
];