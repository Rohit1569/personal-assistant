export const CHECKBOX_OPTIONS = [
  "An unplanned or uncontrolled release of flammable/ toxic material?",
  "An unplanned or uncontrolled release of high energy material (e.g. steam, hot water, nitrogen, compressed CO2 or compressed air)?",
  "Fire / Explosion with significant Plant damage",
  "The occurrence of a SIF (Serious Injury/Fatality) – which includes the gravest types of injuries, illnesses, environmental impacts and fatalities (reference TV-TEC-155024)",
  "The occurrence of a SIF-P (Serious Injury/Fatality Potential) – A high-risk situation in which management controls are either absent, ineffective, or not complied with, which could plausibly and realistically result in a Severe Injury Impact or Fatality or limited environmental impacts (reference TV-TEC-155024)",
  "Offsite community impact- An officially declared community evacuation or community shelter-in-place, including precautionary community evacuation or community shelter-in-place. ( consider abbreviating to any offsite/community impact)",
  "Challenge of a safeguard",
  "Failure of a safeguard​",
  "Processing conditions outside of acceptable limits",
  "Management System Failures",
  "Process Hazards Analysis (PHA) Breakdown",
  "Mechanical Integrity Issues",
];

export const PSM_QUANTITY_OPTIONS = [
  "Is the quantity greater than the following: indoor (> 50kg) in any one-hour period",
  "Is the quantity greater than the following: outdoor (> 500kg) in any one-hour period",
  "Is the quantity greater than the following: indoor (> 25kg) in any one-hour period",
  "Is the quantity greater than the following: outdoor (> 100kg) in any one-hour period",
  "Is the quantity less than either of above options?",
];

export const HIGH_ENERGY_SUB = [
  "With the result in SIF harm",
  "With the potential for SIF harm",
];

export const FIRE_DAMAGE_SUB = [
  "Is the damage resulting in direct cost > $200,000?",
  "Is the damage resulting in direct cost > $20,000 and less than $200,000?",
];

export const MODE_OF_OPERATION_OPTIONS = [
  "Cleaning",
  "Emergency Shutdown",
  "Normal Operation",
  "Planned Shutdown",
  "Start-up",
  "Others (describe)",
];

export const MATERIAL_OPTIONS = [
  "Combustible dust",
  "Flammable substances",
  "High energy substances (e.g. steam, hot water, nitrogen, compressed CO2, or compressed air)",
  "Toxic/Corrosive Substances or acids/bases",
  "Others (describe)",
];

// PSE Level Mapping for sub-options
export const PSE_LEVEL_MAP = {
  // PSM_QUANTITY_OPTIONS levels
  [PSM_QUANTITY_OPTIONS[0]]: 1,
  [PSM_QUANTITY_OPTIONS[1]]: 1,
  [PSM_QUANTITY_OPTIONS[2]]: 2,
  [PSM_QUANTITY_OPTIONS[3]]: 2,
  [PSM_QUANTITY_OPTIONS[4]]: 3,

  // HIGH_ENERGY_SUB levels
  [HIGH_ENERGY_SUB[0]]: 1,
  [HIGH_ENERGY_SUB[1]]: 2,

  // FIRE_DAMAGE_SUB levels
  [FIRE_DAMAGE_SUB[0]]: 1,
  [FIRE_DAMAGE_SUB[1]]: 2,
};

// PSE Level for main checkbox options
export const MAIN_CHECKBOX_PSE_LEVEL = {
  [CHECKBOX_OPTIONS[0]]: "quantity",
  [CHECKBOX_OPTIONS[1]]: "highEnergy",
  [CHECKBOX_OPTIONS[2]]: "fire",
  [CHECKBOX_OPTIONS[3]]: 1,
  [CHECKBOX_OPTIONS[4]]: 2,
  [CHECKBOX_OPTIONS[5]]: 1,
  [CHECKBOX_OPTIONS[6]]: 3,
  [CHECKBOX_OPTIONS[7]]: 3,
  [CHECKBOX_OPTIONS[8]]: 3,
  [CHECKBOX_OPTIONS[9]]: 4,
  [CHECKBOX_OPTIONS[10]]: 4,
  [CHECKBOX_OPTIONS[11]]: 4,
};
