// lib/errorTrapCategories.js

export const ERROR_TRAP_CATEGORIES = [
  {
    id: "01",
    label: "01. Human: Procedures / work instructions / Permit To Work",
    orderMin: 1,
    orderMax: 9,
  },
  {
    id: "02",
    label: "02. Human: Training and competency",
    orderMin: 11,
    orderMax: 19,
  },
  {
    id: "03",
    label: "03. Human: Time",
    orderMin: 21,
    orderMax: 29,
  },
  {
    id: "04",
    label: "04. Human: Information",
    orderMin: 31,
    orderMax: 39,
  },
  {
    id: "05",
    label: "05. Human: People",
    orderMin: 41,
    orderMax: 49,
  },
  {
    id: "06",
    label: "06. Human: Supervision",
    orderMin: 51,
    orderMax: 59,
  },
  {
    id: "07",
    label: "07. Human: Change",
    orderMin: 61,
    orderMax: 69,
  },
  {
    id: "08",
    label: "08. Human: Planning",
    orderMin: 71,
    orderMax: 79,
  },
  {
    id: "09",
    label: "09. Human: Communication",
    orderMin: 81,
    orderMax: 89,
  },
  {
    id: "10",
    label: "10. Human: Fatigue",
    orderMin: 91,
    orderMax: 99,
  },
  {
    id: "11",
    label: "11. Human: Task and Workplace design (Physical Ergonomics)",
    orderMin: 101,
    orderMax: 109,
  },
  {
    id: "12",
    label: "12. Conditional: Interface Design and / or condition",
    orderMin: 111,
    orderMax: 129,
    conditional: true,
  },
  {
    id: "13",
    label: "13. Conditional: Equipment / Installation - Design and / or Condition",
    orderMin: 131,
    orderMax: 149,
    conditional: true,
  },
  {
    id: "14",
    label: "14. Conditional: Ambient Environment",
    orderMin: 151,
    orderMax: 159,
    conditional: true,
  },
  {
    id: "15",
    label: "15. Conditional: Tools & PPE",
    orderMin: 161,
    orderMax: 169,
    conditional: true,
  },
];
