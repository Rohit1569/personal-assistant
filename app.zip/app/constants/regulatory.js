export const YES_NO_OPTIONS = [
  "Yes",
  "No",
];

export const IDENTIFIED_BY_OPTIONS = [
  "Self-Identified/Inspection",
  "Regulatory Authority Identified/Inspection",
];

export const COMPANY_OPTIONS = [
  "J&J",
  "Contractor Company",
];

export const AGENCY_TYPES = [
  "International",
  "National",
  "State/Province",
  "Local (County/City)",
  "Other (Please Specify)",
];

export const OUTCOME_OPTIONS = [
  "Penalty or Fine",
  "ISO 14001/45001 assessment: ≥ 1 Major Weakness",
  "Legal Citation",
  "Loss of ISO 14001/45001 Certification",
  "Consent order",
  "Loss of Other Certification(s)",
  "None",
  "Other (specify)",
];

export const PENALTY_STATUS_OPTIONS = [
  "Rescinded",
  "Paid",
  "Under negotiation",
];