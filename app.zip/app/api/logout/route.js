import { cookies } from "next/headers";

export async function GET() {
  const cookieStore = await cookies();

  cookieStore.delete("curveUser");

  return Response.redirect(
    "https://awsdjynval000a.jnj.com:8080/curve-chatbot/",
    302
  );
}