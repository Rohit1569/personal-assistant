import { cookies } from "next/headers";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const cookieStore = await cookies();
    const curveUser = cookieStore.get("curveUser");
    console.log(cookieStore.getAll(),">>>>><<<<");
    if (!curveUser?.value) {
      return NextResponse.json(
        { message: "User not authenticated" },
        { status: 401 }
      );
    }

    const user = JSON.parse(decodeURIComponent(curveUser.value));

    return NextResponse.json({
      firstName: user.firstName || user.firstname || "",
      lastName: user.lastName || user.lastname || "",
      email: user.email || user.Email || "",
      displayName:
        user.displayName ||
        user.display_name ||
        `${user.firstName || ""} ${user.lastName || ""}`.trim(),
    });
  } catch (error) {
    console.error("Error reading user cookie:", error);

    return NextResponse.json(
      { message: "Failed to retrieve user profile" },
      { status: 500 }
    );
  }
}