import { saml } from "@/lib/saml";

export async function GET() {
  const loginUrl = await saml.getAuthorizeUrlAsync(
    {},
    "",
    ""
  );

  return Response.redirect(loginUrl);
}