// app/api/intelex-employee/route.js
import { NextResponse } from 'next/server';

const BASE_URL = 'https://curve-qa.jnj.com/IntelexLogin/Intelex/api/v2/object/SysEmployeeEntity';

export async function POST(req) {
  try {
    const { filter, email } = await req.json();

    // Prefer server-side construction to avoid OData injection
    const filterClause = filter || (email ? `Email eq '${email}'` : null);
    if (!filterClause) {
      return NextResponse.json({ error: 'Missing filter or email' }, { status: 400 });
    }

    // Build OData URL: select Number, apply filter, limit to 1
    const url = `${BASE_URL}?$select=Number&$filter=${encodeURIComponent(filterClause)}&$top=1`;

    const upstream = await fetch(url, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        Authorization:'APIKey 25e1422637ea41d7aa101b8f7e9b7591'
      },
      cache: 'no-store',
    });

    if (!upstream.ok) {
      const text = await upstream.text().catch(() => '');
      return NextResponse.json(
        { error: `Upstream error ${upstream.status}`, details: text.slice(0, 300) },
        { status: 502 }
      );
    }

    const data = await upstream.json();
    const number = data?.value?.[0]?.Number ?? null;

    // Avoid logging PII. If needed, redact:
    // console.log('Intelex lookup complete for [REDACTED EMAIL], number:', number);

    return NextResponse.json({ number });
  } catch (err) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
