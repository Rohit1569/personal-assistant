import { NextResponse } from "next/server";
import axios from "axios";
import https from "https";

const BASE_URL =
  "https://curve-qa.jnj.com/IntelexLogin/Intelex/api/v2/object/EHSIncidentMang_MasterObject";

const httpsAgent = new https.Agent({
  rejectUnauthorized: false,
});


const FILTER_MAPPING = {
  "Record No.": "RecordNo",

  "J&J Site": "Location/Name",

  Company: "CompanyKey/KeyName",

  "Event Type":
    "EHSEventType/Value",

  "Event Description":
    "Description",

  "Due Date":
    "Workflow/DueDate",

  "Current Stage":
    "OpenWorkStage",

  "Person Responsible":
    "HelpPersResp/Name",

  "Date of Event":
    "Date",

  "Site Location":
    "SiteLocation/Name",

  "Sub Site Location":
    "LocalSiteLoc/SiteLocLocalN",

  Department:
    "Department/DepartmentName",

  "Sub Department":
    "LocalDepartment/LocalDeptName",

  "Constr. Project ID/Name":
    "ConstrucProject",

  "Was this a SIF-P?":
    "WasThisaSIFP",

  "EH&S Business Unit":
    "CompanyKey/BU",

  "EH&S Sub-Business Unit":
    "CompanyKey/Sub0BU",

  Sector:
    "CompanyKey/Sector",
};

function safeGet(obj, key) {
  return obj?.[key] ?? null;
}

function escapeOData(value) {
  return String(value).replace(/'/g, "''");
}

function formatDate(dateStr) {
  if (!dateStr) return null;

  try {
    const dt = new Date(dateStr);

    return `${dt.getMonth() + 1}/${dt.getDate()}/${dt.getFullYear()}`;
  } catch {
    return dateStr;
  }
}

function buildFilter(filters) {
  const clauses = [];

  Object.entries(filters).forEach(([key, value]) => {
    if (!value?.trim()) return;

    const field = FILTER_MAPPING[key];

    if (!field) return;

    const searchValue = escapeOData(value.trim());

    if (
      key === "Record No."&&
      !isNaN(searchValue)
    ) {
      clauses.push(`${field} eq ${searchValue}`);
      return;
    }

    if (
      key === "Was this a SIF-P?" ||
      key ===
        "CAPA effectiveness check Required/Desired"
    ) {
      const lower = searchValue.toLowerCase();

      if (lower === "yes") {
        clauses.push(`${field} eq true`);
      } else if (lower === "no") {
        clauses.push(`${field} eq false`);
      }

      return;
    }

    clauses.push(`${field} eq '${searchValue}'`);
  });

  return clauses.join(" and ");
}

function transformRecord(rec) {
  return {
    "Record No.":
      rec.RecordNo,

    "J&J Site":
      safeGet(rec.Location, "Name"),

    Company:
      safeGet(rec.CompanyKey, "KeyName"),

    "Event Type":
      safeGet(
        rec.EHSEventType,
        "Value"
      ),

    "Reported By":
  safeGet(
    rec.ReportedBy,
    "Name"
  ),

    "Event Description":
      rec.Description,

    "Due Date":
      safeGet(rec.Workflow, "DueDate")
        ? formatDate(
            rec.Workflow.DueDate
          )
        : null,

    "Current Stage":
      rec.OpenWorkStage ??
      safeGet(
        rec.Workflow?.CurrentStage,
        "Name"
      ),

    "Person Responsible":
      safeGet(
        rec.HelpPersResp,
        "Name"
      ),

    "Date of Event":
      formatDate(
        rec.Date
      ),

    "Site Location":
      safeGet(
        rec.SiteLocation,
        "Name"
      ),

    "Sub Site Location":
      safeGet(
        rec.LocalSiteLoc,
        "SiteLocLocalN"
      ),

    Department:
      safeGet(
        rec.Department,
        "DepartmentName"
      ),

    "Sub Department":
      safeGet(
        rec.LocalDepartment,
        "LocalDeptName"
      ),

    "Constr. Project ID/Name":
      rec.ConstrucProject,

    "Was this a SIF-P?":
      rec.WasThisaSIFP,

    "EH&S Business Unit":
      safeGet(
        rec.CompanyKey,
        "BU"
      ),

    "EH&S Sub-Business Unit":
      safeGet(
        rec.CompanyKey,
        "Sub0BU"
      ),

    Sector:
      safeGet(
        rec.CompanyKey,
        "Sector"
      ),
  };
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);

    const page = Number(
      searchParams.get("page") || 1
    );

    const size = Number(
      searchParams.get("size") || 50
    );

    const skip = (page - 1) * size;

    const owner =
      searchParams.get("owner");

    const filters = {};

    searchParams.forEach((value, key) => {
      if (
        key !== "page" &&
        key !== "size" &&
        key !== "owner"
      ) {
        filters[key] = value;
      }
    });

    const params = new URLSearchParams();

    params.append("$count", "true");
    params.append("$skip", String(skip));
    params.append("$top", String(size));

    params.append(
      "$select",
      [
        "RecordNo",
        "HelperResult2",
        "OpenWorkStage",
        "ConstrucRelated",
        "ConstrucProject",
        "ReportingYear",
        "Date",
        "Description",
        "DateApproved",
        "EndDate",
        "WasThisaSIFP",
        "RequiredDesired",
      ].join(",")
    );

    params.append(
      "$expand",
      [
        "Location($select=Name)",
        "CompanyKey($select=KeyName,SubdivID,BU,Sub0BU,Sector)",
        "EHSEventType($select=Value)",
        "SiteLocation($select=Name)",
        "ReportedBy($select=Name)",
        "LocalSiteLoc($select=SiteLocLocalN)",
        "Department($select=DepartmentName)",
        "LocalDepartment($select=LocalDeptName)",
        "RespoDepartment($select=RDepartmentName)",
        "HelpPersResp($select=Name)",
        "Workflow($select=DueDate,WorkflowStatus;$expand=CurrentStage($select=Name))",
        "SIFPCategories",
      ].join(",")
    );

    let finalFilter =
      buildFilter(filters);

    if (owner) {
     const ownerFilter =
  `ReportedBy/Name eq '${escapeOData(owner)}'`;

      finalFilter = finalFilter
        ? `${finalFilter} and ${ownerFilter}`
        : ownerFilter;
    }

    if (finalFilter) {
      params.append(
        "$filter",
        finalFilter
      );
    }

    const url =
      `${BASE_URL}?${params.toString()}`;

  console.log("Owner:", owner);
4
console.log("Final URL:");
5
console.log(decodeURIComponent(url));

    const response = await axios.get(
      url,
      {
        httpsAgent,
        headers: {
          Authorization: `ApiKey ${process.env.CURVE_API_KEY}`,
          Accept: "application/json",
        },
        timeout: 30000,
      }
    );

    const result = response.data;
    const records = result.value || [];

    return NextResponse.json({
      page,
      size,
      count: records.length,
      total:
        result["@odata.count"] || 0,
      data: records.map(
        transformRecord
      ),
    });
  } catch (error) {
    console.error(
      "Intelex API Error:",
      error.response?.data ||
      error.message
    );

    return NextResponse.json(
      {
        message: error.message,
        details:
          error.response?.data ||
          null,
      },
      {
        status: 500,
      }
    );
  }
}