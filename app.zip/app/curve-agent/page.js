'use client'
 
import { useState, useRef, useCallback, useEffect } from 'react'
 
import Header               from '@/components/Header'
 
import ChatInput            from '@/components/ChatInput'
 
import ChainOfThoughtLoader from '@/components/ChainOfThoughtLoader'
 
import TypingIndicator       from '@/components/TypingIndicator'
 
import { BotAvatar }        from '@/components/Avatars'
 
import { UserBubble }       from '@/components/ChatBubble'
 
import EventForm            from '@/components/EventForm'
 
import ReportPreview        from '@/components/ReportPreview'
 
import ConfirmationCard     from '@/components/ConfirmationCard'

import { fetchEmployeeNumberByEmail } from '@/lib/getWwidApi';

import LanguageSelector from '@/components/LanguageSelector';
 
// import { createSocket, sendMessage, clearSession, parseReportText } from '@/lib/websocket'
import { createSocket, sendMessage, clearSession, parseReportText,createSession } from '@/lib/websocket'
 
import { detectPii } from '@/lib/piiApi'
// ─── DEBUG LOGGER ─────────────────────────────
 
const DEBUG = true
 
const log = (...args) => { if (DEBUG) console.log('[CHAT]', ...args) }
 
// ─── helpers ─────────────────
 
let _id = 0
 
const uid = () => ++_id
 
const now = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
 
// ─── Step tracking ───────────────────────────
 
const STEP = { IDLE: 'idle', DESCRIBE: 'describe', OTHER: 'other' }
 
const DESCRIBE_KEYWORDS = [
 
  'describe the event',
 
  'describe the situation',
 
  'please describe',
 
  'what type of ehs'
 
]


 
function isDescribePrompt(text) {
 
  const lc = (text || '').toLowerCase()
 
  return DESCRIBE_KEYWORDS.some(k => lc.includes(k))
 
}
 
// ─── UI Components ───────────────────────────
 
function ReportTable({ parsed }) {
 
  return (
<div>
 
      {parsed.intro && <div className="mb-2 text-[13.5px] font-semibold">{parsed.intro}</div>}
<table className="w-full border-collapse">
<tbody>
 
          {parsed.rows.map((row, i) => (
<tr key={i}>
<td className="font-bold pr-3">{row.key}</td>
<td className="text-blue-800">{row.value || ''}</td>
</tr>
 
          ))}
</tbody>
</table>
</div>
 
  )
 
}
 
function BotMessage({ text, time }) {
 
  const parsed = parseReportText(text)
 
  log('📊 PARSED REPORT:', parsed)
 
  return (
<div className="flex gap-2">
<BotAvatar />
<div>
<div className="bg-white border rounded-2xl px-3 py-2">
 
          {parsed
 
            ? <ReportTable parsed={parsed} />
 
            : <div dangerouslySetInnerHTML={{ __html: text.replace(/\n/g, '<br/>') }} />}
</div>
 
        {time && <div className="text-xs mt-1 text-gray-400">{time}</div>}
</div>
</div>
 
  )
 
}
 

// ── CHANGE 1: added onFormSave prop, passed to EventForm as onSave ──
function MessageItem({ msg, onFormSubmit, email, onFormSave,wwid, onReset ,handleLanguageChange, session}) {
 
  switch (msg.type) {
 
    case 'user':         return <UserBubble text={msg.text} imageUrl={msg.imageUrl} time={msg.time} />
 
    case 'bot':          return <BotMessage text={msg.text} time={msg.time} />
 
    case 'form':         return <EventForm fields={msg.fields} introHtml={msg.intro} onSubmit={onFormSubmit} onSave={onFormSave} locked={msg.locked || false} piiCheck={msg.piiCheck || null} onLanguageChange={handleLanguageChange} wwid={wwid} session={session}/>
 
    case 'report':       return <ReportPreview report={msg.report} time={msg.time} />
 
    case 'confirmation': return <ConfirmationCard refId={msg.refId} rawText={msg.rawText} onReset={onReset} time={msg.time} />
 
    default:             return null
 
  }
 
}
 
// ─── MAIN ───────────────────────────────────
 
// export default function Page() {
 
//   const [messages,         setMessages]         = useState([])
 
//   const [awaitingResponse, setAwaitingResponse] = useState(false)
 
//   const [wsStatus,         setWsStatus]         = useState('connecting')
 
//   const [session,setSession]=useState("")

//   // ── Single loader flag — true while waiting for ANY backend response ──
 
//   const [loading, setLoading] = useState(false)
 
//   const [isFirstMsg,       setIsFirstMsg]       = useState(true)
//   const [showChainLoader,  setShowChainLoader]  = useState(false)
 
//   const [step,             setStep]             = useState(STEP.IDLE)
 
//   const [isJsonMode,       setIsJsonMode]       = useState(false)
 
//   const wsRef     = useRef(null)
 
//   const bottomRef = useRef(null)
 
//   const bootedRef = useRef(false)
 
//   const [wwid,setWwid]=useState("");

//   const [authChecked, setAuthChecked] = useState(false);
// const [isAuthenticated, setIsAuthenticated] = useState(false);


//   // ── CHANGE 2: ref to store last saved form fields (no re-render) ──
//   const savedFieldsRef = useRef(null)
//   const lastUserInputRef = useRef(null)
//     const [profile, setProfile] = useState(null); 
//   const [open, setOpen] = useState(false);
//   const containerRef = useRef(null);
//   const [profileLoading, setProfileLoading] = useState(true);
 

// const handleLogout = () => {
//   try {
//     sessionStorage.setItem('justLoggedOut', '1');
//   } catch (_) {}

//   window.location.replace('/api/logout');
// };


// // useEffect(() => {
// //   // Skip auto-login once after logout
// //   if (
// //     typeof window !== "undefined" &&
// //     sessionStorage.getItem("justLoggedOut")
// //   ) {
// //     sessionStorage.removeItem("justLoggedOut");
// //     setAuthChecked(true);
// //     setIsAuthenticated(false);
// //     return;
// //   }

// //   const loadProfile = async () => {
// //     try {
// //       const response = await fetch("/api/me", {
// //         credentials: "include",
// //       });

// //       // Cookie missing / session expired
// //       if (!response.ok) {
// //         setIsAuthenticated(false);
// //         setAuthChecked(true);
// //         return;
// //       }

// //       const user = await response.json();

// //       setProfile({
// //         firstName: user.firstName || "",
// //         lastName: user.lastName || "",
// //         email: user.email || "",
// //         displayName: user.displayName || "",
// //       });

// //       setIsAuthenticated(true);
// //       setAuthChecked(true);
// //     } catch (error) {
// //       console.error("Failed to load profile:", error);
// //       setIsAuthenticated(false);
// //       setAuthChecked(true);
// //     }
// //   };

// //   loadProfile();
// // }, []);

// useEffect(() => {
//   // Skip auto-login once after logout
//   if (
//     typeof window !== "undefined" &&
//     sessionStorage.getItem("justLoggedOut")
//   ) {
//     sessionStorage.removeItem("justLoggedOut");
//     setAuthChecked(true);
//     setIsAuthenticated(false);
//     setProfileLoading(false);
//     return;
//   }
 
//   const loadProfile = async () => {
//     try {
//       const response = await fetch("/api/me", {
//         credentials: "include",
//       });
 
//       // Cookie missing / session expired
//       if (!response.ok) {
//         setIsAuthenticated(false);
//         setAuthChecked(true);
//         return;
//       }
 
//       const user = await response.json();
 
//       let employeeNumber = "";
 
//       try {
//         employeeNumber = await fetchEmployeeNumberByEmail(
//           user.email
//         );
//       } catch (err) {
//         console.error("WWID lookup failed", err);
//       }
 
//       setWwid(employeeNumber || "");
 
//       setProfile({
//         firstName: user.firstName || "",
//         lastName: user.lastName || "",
//         email: user.email || "",
//         displayName: user.displayName || "",
//       });
 
//       setIsAuthenticated(true);
//       setAuthChecked(true);
//     } catch (error) {
//       console.error("Failed to load profile:", error);
//       setIsAuthenticated(false);
//       setAuthChecked(true);
//     } finally {
//       // Loader disappears only after profile + WWID processing completes
//       setProfileLoading(false);
//     }
//   };
 
//   loadProfile();
// }, []);
 
 
// const handleSSOLogin = () => {
//   window.location.reload();

//   // OR redirect to login endpoint
//   // window.location.href = "/api/login";
// };

// // useEffect(() => {
// //   if (!profile?.email) return;

// //   const ac = new AbortController();

// //   fetchEmployeeNumberByEmail(profile.email, { signal: ac.signal })
// //     .then((number) => {
// //       setWwid(number);
// //     })
// //     .catch((err) => {
// //       // Avoid logging PII (like the email). Show generic error.
// //       console.error('Intelex lookup failed');
// //     });

// //   return () => ac.abort();
// // }, [profile?.email]);

//   const scrollDown = () =>
 
//     setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 80)
 
//   const addMsg = useCallback((msg) => {
 
//     setMessages(prev => [...prev, { id: uid(), ...msg }])
 
//     scrollDown()
 
//   }, [])


 
//   // ── CONNECT ─────────────────
 
//   const connect = useCallback(() => {
 
//     log('🔌 Creating WebSocket connection...')
 
//     const ws = createSocket({
 
//       onOpen: () => {
 
//         log('✅ WS OPEN')
 
//         setWsStatus('open')
 
//         addMsg({ type: 'bot', text: 'System: Connected to server.', time: now() })
 
//       },
 
//       onMessage: async ({ kind, message, fields, text }) => {

//         log('📩 RAW BACKEND MESSAGE:', { kind, message, fields, text })

//         // ── Stop loader as soon as backend responds ──

//         setAwaitingResponse(false)

//         setLoading(false)
//         setShowChainLoader(false)

//         // ── Form message ──

//         if (kind === 'form') {

//           log('🧾 FORM RECEIVED:', { fields, intro: message })

//           // ── PII: resolve the check for the text that led to this form ──
//           let piiCheck = null
//           const pending = lastUserInputRef.current
//           lastUserInputRef.current = null
//           if (pending) {
//             try {
//               const result = await pending.promise
//               piiCheck = { text: pending.text, result }
//             } catch {
//               piiCheck = null
//             }
//           }

//           addMsg({

//             type:   'form',

//             fields: fields || [],

//             intro:  message || '',

//             time:   now(),

//             piiCheck,

//           })

//           return

//         }

 
//         const raw = text || message || ''
 
//         log('🤖 BOT TEXT:', raw)
 
//         if (!isJsonMode && isDescribePrompt(raw)) {
 
//           log('✅ JSON MODE ENABLED')
 
//           setIsJsonMode(true)
 
//         }
 
//         if (isDescribePrompt(raw)) {
 
//           log('🧭 STEP → DESCRIBE')
 
//           setStep(STEP.DESCRIBE)
 
//           setIsFirstMsg(true)
 
//         }
 
//         addMsg({ type: 'bot', text: raw, time: now() })
 
//       },
 
//       onClose: (e) => {
 
//         log('❌ WS CLOSED:', e.code)
 
//         setWsStatus('closed')
 
//         setLoading(false)
 
//         setAwaitingResponse(false)
 
//         addMsg({ type: 'bot', text: `Connection closed (${e.code})`, time: now() })
 
//       },
 
//       onError: (e) => {
 
//         log('🔥 WS ERROR:', e)
 
//         setWsStatus('error')
 
//         setLoading(false)
 
//         setAwaitingResponse(false)
 
//       }
 
//     })
 
//     wsRef.current = ws
 
//   }, [addMsg, isJsonMode])
 
//   useEffect(() => {
 
//     if (bootedRef.current) return
 
//     bootedRef.current = true
 
//     connect()
 
//   }, [connect])
 
//   const resetChat = useCallback(async () => {
 
//     log('♻️ RESET CHAT')
 
//     await clearSession()
//  window.location.reload();
//     bootedRef.current = false
 
//     // ── CHANGE 3: clear saved fields on reset ──
//     savedFieldsRef.current = null
//     lastUserInputRef.current = null
//     setIsJsonMode(false)
 
//     setLoading(false)
 
//     setAwaitingResponse(false)
 
//     connect()
 
//     bootedRef.current = true
 
//   }, [connect])
 
//   // ── SEND TEXT ─────────────────
 
//   const handleSend = useCallback((payload) => {
 
//     if (awaitingResponse || wsStatus !== 'open') return
 
//     const isObj    = typeof payload === 'object' && payload !== null
 
//     const text     = isObj ? payload.text : payload
 
//     const imageUrl = isObj ? payload.imageUrl : null
 
//     log('👤 USER INPUT:', { text, imageUrl })
 
//     addMsg({ type: 'user', text, imageUrl, time: now() })
 
//     setIsFirstMsg(false)
//     setShowChainLoader(true)
//     setLoading(true)
 
//     setAwaitingResponse(true)
 
//     setStep(STEP.OTHER)
 
//  if (!imageUrl && text) {

//       // No saved form — normal chat: fields always {}
//       const payloadToSend = isJsonMode ? { message: text, fields: {} } : text

//       log('🚀 SENDING TO BACKEND:', payloadToSend)

//       sendMessage(wsRef.current, payloadToSend)

//       // ── PII: background check — never delays or blocks sending ──
//       const piiPromise = detectPii(text)
//       piiPromise.catch(() => {}) // avoid noisy unhandled-rejection warnings
//       lastUserInputRef.current = { text, promise: piiPromise }

//     }

//   }, [awaitingResponse, wsStatus, isFirstMsg, addMsg, isJsonMode])
 
//   // ── IMAGE RESULT ─────────────
 
//   const handleImageResult = useCallback((whatHappened, userText, errorMsg) => {
 
//     log('🖼 IMAGE RESULT:', { whatHappened, userText, errorMsg })
 
//     if (errorMsg) { addMsg({ type: 'bot', text: errorMsg, time: now() }); return }
 
//     if (!whatHappened) return
 
//     setAwaitingResponse(true)
 
//     setShowChainLoader(true)
//     setLoading(true)
 
//     const payload = { message: whatHappened, fields: {} }
 
//     log('🚀 IMAGE SEND:', payload)
 
//     sendMessage(wsRef.current, payload)
 
//   }, [addMsg])
 
//   // ── FORM SUBMIT ─────────────
 
//   // EventForm now always sends: { message: string, fields: { key: value, ... } }
 
//   // • Submit button  → { message: '',          fields: { all current field values } }
 
//   // • Change button  → { message: 'user text', fields: { all current field values } }
 
//   // • SimpleForm     → plain answers object (early steps)
 
//   const handleFormSubmit = useCallback((data) => {
 
//     log('📝 FORM SUBMITTED:', data)
 
//     // ── ReportStyleForm payload: { message, fields } ──
 
//     const isReportPayload = data &&
 
//       typeof data === 'object' &&
 
//       'message' in data &&
 
//       'fields' in data &&
 
//       typeof data.fields === 'object' &&
 
//       !Array.isArray(data.fields)
 
//     if (isReportPayload) {
 
//       // Show user message in chat
 
//       const displayText = data.message
 
//         ? data.message
 
//         : Object.entries(data.fields)
 
//             .filter(([, v]) => v)
 
//             .map(([k, v]) => `${k}: ${v}`)
 
//             .join('\n')
 
//       addMsg({ type: 'user', text: displayText, time: now() })
 
//       setAwaitingResponse(true)
 
//       setShowChainLoader(true)
//       setLoading(true)
 
//       log('🚀 FORM SEND (REPORT):', data)
 
//       sendMessage(wsRef.current, data)
 
//       return
 
//     }
 
//     // ── SimpleForm — plain answers object ──
 
//     const answers     = data
 
//     // Filter out silent fields (like Timezone) — sent to backend but not shown in chat
//     const SILENT_DISPLAY_FIELDS = new Set(['Timezone','WWID','Session_Id'])
 
//     const displayText = Object.entries(answers)
 
//       .filter(([k]) => !SILENT_DISPLAY_FIELDS.has(k))
 
//       .map(([k, v]) => `${k}: ${v}`)
 
//       .join('\n')
 
//     addMsg({ type: 'user', text: displayText, time: now() })
 
//     setAwaitingResponse(true)
 
//     setShowChainLoader(true)
//     setLoading(true)
 
//     if (!isJsonMode) {
 
//       log('🚀 FORM SEND (NON JSON):', answers)
 
//       sendMessage(wsRef.current, answers)
//       setIsJsonMode(true)
//       return
 
//     }
 
//     const payload = { message: displayText, fields: answers }
 
//     log('🚀 FORM SEND (JSON MODE):', payload)
 
//     sendMessage(wsRef.current, payload)
 
//   }, [addMsg, isJsonMode])

//   // ── CHANGE 5: Save button — auto-sends message to chat + backend, locks form ──
//   const handleFormSave = useCallback(({ message, displayMessage, fields }) => {
//     if (awaitingResponse || wsStatus !== 'open') return
//     log('💾 FORM SAVE → AUTO SEND:', { message, fields })

//     // Show human-readable (local time) version in chat bubble
//     addMsg({ type: 'user', text: displayMessage || message, time: now() })

//     // Send raw backend-format message (UTC datetime) to backend
//     setShowChainLoader(true)
//     setLoading(true)
//     setAwaitingResponse(true)
//     sendMessage(wsRef.current, { message, fields })

//     // Lock all form messages so user can't edit after saving
//     setMessages(prev => prev.map(msg =>
//       msg.type === 'form' ? { ...msg, locked: true } : msg
//     ))

//     // Clear savedFieldsRef — no longer needed since we sent immediately
//     savedFieldsRef.current = null
//   }, [awaitingResponse, wsStatus, addMsg])
 
//   // Chain loader done → hide it (backend message will arrive and show TypingIndicator if needed)
//   // onDone not used — loader stays until backend responds (hidden via onMessage)
//   const handleChainDone = useCallback(() => {}, [])

//   const inputDisabled = wsStatus !== 'open' || awaitingResponse || loading
 
//   // ✅ ONLY CHANGE FROM ORIGINAL: always show image upload when input is enabled
 
//   const allowImage = !inputDisabled
//    const [selectedLanguage, setSelectedLanguage] = useState('English');
//   const handleLanguageChange = (lang) => {
//   setSelectedLanguage(lang);
// };
// // if (!isAuthenticated) {
// //   return (
// //     <div className="min-h-screen bg-[#ef1400] flex items-center justify-center">
// //       <div className="bg-[#f3f3f3] w-[620px] h-[320px] flex flex-col items-center justify-center">

// //         <h1
// //           className="text-[64px] leading-none text-[#d81f0f] mb-12"
// //           style={{
// //             fontFamily: '"Times New Roman", serif'
// //           }}
// //         >
// //           Johnson&Johnson
// //         </h1>

// //         <button
// //           onClick={handleSSOLogin}
// //           className="bg-[#4a4a4a] hover:bg-[#3a3a3a] text-white text-[18px] w-[480px] py-3 transition-colors"
// //         >
// //           Sign in via SSO
// //         </button>

// //       </div>
// //     </div>
// //   );
// // }

// const  createNewSession= async ()=>{
//   const res=await createSession();
 
//    setSession(res.session_id);
// }
 
// useEffect(() => {
//   // const hasCurveUser = document.cookie.includes("curveUser=");
 
//   // if (hasCurveUser) {
//   createNewSession()
//   // }
// }, []);

// const isPageReady =
//   !profileLoading &&
//   profile &&
//   wwid &&
//   session;

// // if (!isPageReady) {
// //   return (
// //     <div
// //       className="fixed inset-0 flex items-center justify-center bg-white"
// //       style={{ zIndex: 99999 }}
// //     >
// //       <div
// //         className="animate-spin rounded-full"
// //         style={{
// //           width: "60px",
// //           height: "60px",
// //           border: "6px solid #e5e7eb",
// //           borderTop: "6px solid #EF1400",
// //         }}
// //       />
// //     </div>
// //   );
// // }
 
 
//   return (
// <div className="flex flex-col h-full bg-white">
  
//  <Header
//       onReset={resetChat}
//       profile={profile}
//       open={open}
//       setOpen={setOpen}
//       containerRef={containerRef}
//       onLogout={handleLogout}
//       session={session}
//     />
// <div className="flex-1 overflow-y-auto">
// <div className="p-4 space-y-4">
 
//           {messages.map(msg => (
// <MessageItem
 
//               key={msg.id}
 
//               msg={msg}
//               email={profile?.email ?? ''}
//               onFormSubmit={handleFormSubmit}
//               onFormSave={handleFormSave}
//               wwid={wwid}
//               onReset={resetChat}
//               handleLanguageChange={handleLanguageChange}
//               session={session}
//             />
 
//           ))}
 
//           {/* Chain-of-thought loader */}
 
//           {showChainLoader && <ChainOfThoughtLoader onDone={handleChainDone} />}
 
//           {/* TypingIndicator commented out — ChainOfThoughtLoader handles full wait */}
// <div ref={bottomRef} />
// </div>
// </div>
// <ChatInput
 
//         onSend={handleSend}
 
//         onImageResult={handleImageResult}
 
//         disabled={inputDisabled}
 
//         allowImage={allowImage}
//          selectedLanguage={selectedLanguage}
//       />
// </div>
 
//   )
 
// }

export default function Page() {
  const [messages, setMessages] = useState([]);
  const [awaitingResponse, setAwaitingResponse] = useState(false);
  const [wsStatus, setWsStatus] = useState('connecting');
  const [loading, setLoading] = useState(false);
  const [isFirstMsg, setIsFirstMsg] = useState(true);
  const [showChainLoader, setShowChainLoader] = useState(false);
  const [step, setStep] = useState(STEP.IDLE);
  const [isJsonMode, setIsJsonMode] = useState(false);
 
  const wsRef = useRef(null);
  const bottomRef = useRef(null);
  const bootedRef = useRef(false);
  const initialPayloadSentRef = useRef(false);
  const wsReadyRef = useRef(false);
 
  const [wwid, setWwid] = useState('');
  // const [wwid, setWwid] = useState('702506073');
  const [session, setSession] = useState('');
  const [authChecked, setAuthChecked] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
 
  const savedFieldsRef = useRef(null);
  const lastUserInputRef = useRef(null);
 
  const [profile, setProfile] = useState(null);
  const [open, setOpen] = useState(false);
  const containerRef = useRef(null);
  const [profileLoading, setProfileLoading] = useState(true);
 
  // Language state
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const [languageSelected, setLanguageSelected] = useState(false);
  const [isCheckingLanguage, setIsCheckingLanguage] = useState(true);
 
  // Timezone state
  const [timezone, setTimezone] = useState('');
 
  // WWID loading state
  const [wwidLoading, setWwidLoading] = useState(true);
 
  // Session loading state
  const [sessionLoading, setSessionLoading] = useState(true);
 
  // Uploaded files state
  const [uploadedFiles, setUploadedFiles] = useState([]);
 
  // Track if initial payload was sent
  const [initialPayloadSent, setInitialPayloadSent] = useState(false);
 
  const handleLogout = () => {
    try {
      sessionStorage.setItem('justLoggedOut', '1');
    } catch (_) {}
    window.location.replace('/api/logout');
  };
 
  // Get timezone on component mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const now = new Date();
      const offset = -now.getTimezoneOffset();
      const hours = Math.floor(Math.abs(offset) / 60);
      const minutes = Math.abs(offset) % 60;
      const sign = offset >= 0 ? '+' : '-';
      const gmtOffset = `GMT${sign}${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
      setTimezone(gmtOffset);
      console.log('🕐 Timezone detected:', gmtOffset);
    }
  }, []);
 
  // CREATE SESSION FIRST
  useEffect(() => {
    const createNewSession = async () => {
      try {
        console.log('📝 Creating new session...');
        const res = await createSession();
 
        if (res?.session_id) {
          console.log('✅ Session created:', res.session_id);
          setSession(res.session_id);
        }
      } catch (err) {
        console.error('❌ Failed to create session', err);
      } finally {
        setSessionLoading(false);
      }
    };
 
    createNewSession();
  }, []);
 
  // Load profile SECOND
  useEffect(() => {
    if (
      typeof window !== 'undefined' &&
      sessionStorage.getItem('justLoggedOut')
    ) {
      sessionStorage.removeItem('justLoggedOut');
      setAuthChecked(true);
      setIsAuthenticated(false);
      setProfileLoading(false);
      setWwidLoading(false);
      setIsCheckingLanguage(false);
      return;
    }
 
    const loadProfile = async () => {
      try {
        const response = await fetch('/api/me', {
          credentials: 'include',
        });
 
        if (!response.ok) {
          setIsAuthenticated(false);
          setAuthChecked(true);
          setWwidLoading(false);
          setIsCheckingLanguage(false);
          return;
        }
 
        const user = await response.json();
 
        let employeeNumber = '';
 
        try {
          console.log('📥 Fetching WWID for email:', user.email);
          employeeNumber = await fetchEmployeeNumberByEmail(user.email);
          console.log('✅ WWID fetched:', employeeNumber);
        } catch (err) {
          console.error('❌ WWID lookup failed', err);
        }
 
        setWwid(employeeNumber || '');
        setWwidLoading(false);
 
        setProfile({
          firstName: user.firstName || '',
          lastName: user.lastName || '',
          email: user.email || '',
          displayName: user.displayName || '',
        });
 
        setIsAuthenticated(true);
        setAuthChecked(true);
      } catch (error) {
        console.error('Failed to load profile:', error);
        setIsAuthenticated(false);
        setAuthChecked(true);
        setWwidLoading(false);
      } finally {
        setProfileLoading(false);
      }
    };
 
    loadProfile();
  }, []);
 
  // Check language only after profile is loaded
  useEffect(() => {
    if (profileLoading) {
      setIsCheckingLanguage(true);
      return;
    }
 
    setIsCheckingLanguage(true);
 
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('selectedLanguage');
      console.log('🔍 Checking localStorage for language:', saved);
 
      if (saved) {
        console.log('✅ Language found in localStorage:', saved);
        setSelectedLanguage(saved);
        setLanguageSelected(true);
      } else {
        console.log('❌ No language in localStorage, using default: English');
        setSelectedLanguage('English');
        setLanguageSelected(true);
      }
    }
 
    setIsCheckingLanguage(false);
  }, [profileLoading]);
 
  const handleLanguageSelect = (lang) => {
    console.log('🌍 Language selected:', lang);
 
    if (typeof window !== 'undefined') {
      localStorage.setItem('selectedLanguage', lang);
      console.log('💾 Saved to localStorage:', lang);
    }
 
    clearSession();
    console.log('🔄 Refreshing page with new language...');
    window.location.reload();
  };
 
  const handleSSOLogin = () => {
    window.location.reload();
  };
 
  const scrollDown = () =>
    setTimeout(
      () => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }),
      80
    );
 
  const addMsg = useCallback((msg) => {
    setMessages((prev) => [...prev, { id: uid(), ...msg }]);
    scrollDown();
  }, []);
 
  // Handle file upload
  const handleFileUpload = useCallback(
    (fileData) => {
      console.log('[File Upload Success]', fileData);
 
      const { fileName, s3Key, uploadUrl } = fileData;
 
      // Store file info
      setUploadedFiles((prev) => [...prev, fileData]);
 
      // Add message to chat
      const fileMessage = `📎 File uploaded: ${fileName}`;
      addMsg({
        type: 'bot',
        text: fileMessage,
        time: now(),
        fileData: fileData,
      });
    },
    [addMsg]
  );
 
  // ── SEND INITIAL PAYLOAD (FIRST CHAT) ──
  const sendInitialPayload = useCallback(() => {
    console.log('📤 sendInitialPayload called');
    console.log('   initialPayloadSentRef.current:', initialPayloadSentRef.current);
    console.log('   wsReadyRef.current:', wsReadyRef.current);
    console.log('   wwid:', wwid);
    console.log('   session:', session);
    console.log('   selectedLanguage:', selectedLanguage);
    console.log('   timezone:', timezone);
    console.log('   wwidLoading:', wwidLoading);
    console.log('   sessionLoading:', sessionLoading);
 
    if (initialPayloadSentRef.current) {
      console.log('⚠️ Initial payload already sent, skipping');
      return;
    }
 
    if (!wsReadyRef.current) {
      console.log('⚠️ WebSocket not ready yet');
      return;
    }
 
    if (wwidLoading) {
      console.log('⏳ WWID still loading, waiting...');
      return;
    }
 
    if (sessionLoading) {
      console.log('⏳ Session still loading, waiting...');
      return;
    }
 
    if (!wwid || !session || !selectedLanguage || !timezone) {
      console.log('⚠️ Missing required data for initial payload', {
        wwid: wwid ? '✓' : '✗',
        session: session ? '✓' : '✗',
        selectedLanguage: selectedLanguage ? '✓' : '✗',
        timezone: timezone ? '✓' : '✗',
      });
      return;
    }
 
    initialPayloadSentRef.current = true;
    setInitialPayloadSent(true);
 
    // ✅ Enable JSON mode immediately
    setIsJsonMode(true);
 
    // ✅ FIRST CHAT: Send WITHOUT message field (as is)
    const initialPayload = {
      Language: selectedLanguage,
      Timezone: timezone,
      WWID: wwid,
      Session_Id: session,
    };
 
    console.log('🚀 Sending initial payload (FIRST CHAT - NO MESSAGE FIELD):', initialPayload);
    setAwaitingResponse(true);
    setShowChainLoader(true);
    setLoading(true);
 
    sendMessage(wsRef.current, initialPayload);
  }, [wwid, session, selectedLanguage, timezone, wwidLoading, sessionLoading]);
 
  // ── CONNECT ─────────────────
  const connect = useCallback(() => {
    console.log('🔌 Creating WebSocket connection...');
    wsReadyRef.current = false;
    setWsStatus('connecting');
    setLoading(true);
    setShowChainLoader(true);
    setAwaitingResponse(true);
 
    const ws = createSocket({
      onOpen: () => {
        console.log('✅ WS OPEN - Setting wsReadyRef.current = true');
        wsReadyRef.current = true;
        setWsStatus('open');
        addMsg({ type: 'bot', text: 'System: Connected to server.', time: now() });
 
        console.log('📤 Calling sendInitialPayload from onOpen');
        sendInitialPayload();
      },
 
      onMessage: async ({ kind, message, fields, text }) => {
        log('📩 RAW BACKEND MESSAGE:', { kind, message, fields, text });
 
        setAwaitingResponse(false);
        setLoading(false);
        setShowChainLoader(false);
 
        if (
          kind === 'form' &&
          message &&
          message.toLowerCase().includes('please select a language')
        ) {
          console.log('🤐 Intercepting language selection form - NOT showing to user');
          return;
        }
 
        if (kind === 'form') {
          log('🧾 FORM RECEIVED:', { fields, intro: message });
 
          let piiCheck = null;
          const pending = lastUserInputRef.current;
          lastUserInputRef.current = null;
          if (pending) {
            try {
              const result = await pending.promise;
              piiCheck = { text: pending.text, result };
            } catch {
              piiCheck = null;
            }
          }
 
          addMsg({
            type: 'form',
            fields: fields || [],
            intro: message || '',
            time: now(),
            piiCheck,
          });
 
          return;
        }
 
        const raw = text || message || '';
        log('🤖 BOT TEXT:', raw);
 
        // ✅ Ensure JSON mode stays enabled
        if (!isJsonMode && isDescribePrompt(raw)) {
          log('✅ JSON MODE ENABLED');
          setIsJsonMode(true);
        }
 
        if (isDescribePrompt(raw)) {
          log('🧭 STEP → DESCRIBE');
          setStep(STEP.DESCRIBE);
          setIsFirstMsg(true);
        }
 
        addMsg({ type: 'bot', text: raw, time: now() });
      },
 
      onClose: (e) => {
        console.log('❌ WS CLOSED:', e.code);
        wsReadyRef.current = false;
        setWsStatus('closed');
        setLoading(false);
        setAwaitingResponse(false);
        addMsg({
          type: 'bot',
          text: `Connection closed (${e.code})`,
          time: now(),
        });
      },
 
      onError: (e) => {
        console.log('🔥 WS ERROR:', e);
        wsReadyRef.current = false;
        setWsStatus('error');
        setLoading(false);
        setAwaitingResponse(false);
      },
    });
 
    wsRef.current = ws;
  }, [addMsg, isJsonMode, sendInitialPayload]);
 
  // Try to send initial payload whenever dependencies change
  useEffect(() => {
    if (wsReadyRef.current && !initialPayloadSentRef.current) {
      console.log('🔄 Retrying sendInitialPayload due to dependency change');
      sendInitialPayload();
    }
  }, [wwid, selectedLanguage, timezone, wwidLoading, sessionLoading, sendInitialPayload]);
 
  // Connect WebSocket ONLY after language is selected and all data is ready
  useEffect(() => {
    if (bootedRef.current) return;
 
    if (!languageSelected || !selectedLanguage) {
      console.log('⏳ Waiting for language selection before connecting WebSocket');
      return;
    }
 
    if (wwidLoading || sessionLoading || !timezone) {
      console.log('⏳ Waiting for WWID, session, or timezone...');
      return;
    }
 
    console.log('✅ All data ready, now connecting WebSocket');
    bootedRef.current = true;
    connect();
  }, [languageSelected, selectedLanguage, wwidLoading, sessionLoading, timezone, connect]);
 
  const resetChat = useCallback(async () => {
    console.log('🔄 Resetting chat...');
    await clearSession();
    window.location.reload();
  }, []);
 
  // ── SEND TEXT ───────────────── (SECOND CHAT ONWARDS)
  const handleSend = useCallback(
    (payload) => {
      if (awaitingResponse || wsStatus !== 'open') return;
 
      const isObj = typeof payload === 'object' && payload !== null;
 
      const text = isObj ? payload.text : payload;
 
      const imageUrl = isObj ? payload.imageUrl : null;
 
      log('👤 USER INPUT:', { text, imageUrl });
 
      addMsg({ type: 'user', text, imageUrl, time: now() });
 
      setIsFirstMsg(false);
      setShowChainLoader(true);
      setLoading(true);
 
      setAwaitingResponse(true);
 
      setStep(STEP.OTHER);
 
      if (!imageUrl && text) {
        // ✅ SECOND CHAT ONWARDS: Send with message field
        const payloadToSend = { message: text, fields: {} };
 
        log('🚀 SENDING TO BACKEND (SECOND CHAT ONWARDS):', payloadToSend);
 
        sendMessage(wsRef.current, payloadToSend);
 
        const piiPromise = detectPii(text);
        piiPromise.catch(() => {});
        lastUserInputRef.current = { text, promise: piiPromise };
      }
    },
    [awaitingResponse, wsStatus, isFirstMsg, addMsg]
  );
 
  // ── IMAGE RESULT ─────────────
  const handleImageResult = useCallback(
    (whatHappened, userText, errorMsg) => {
      log('🖼 IMAGE RESULT:', { whatHappened, userText, errorMsg });
 
      if (errorMsg) {
        addMsg({ type: 'bot', text: errorMsg, time: now() });
        return;
      }
 
      if (!whatHappened) return;
 
      setAwaitingResponse(true);
 
      setShowChainLoader(true);
      setLoading(true);
 
      const payload = { message: whatHappened, fields: {} };
 
      log('🚀 IMAGE SEND:', payload);
 
      sendMessage(wsRef.current, payload);
    },
    [addMsg]
  );
 
  // ── FORM SUBMIT ───────────────
  const handleFormSubmit = useCallback(
    (data) => {
      log('📝 FORM SUBMITTED:', data);
 
      const isReportPayload =
        data &&
        typeof data === 'object' &&
        'message' in data &&
        'fields' in data &&
        typeof data.fields === 'object' &&
        !Array.isArray(data.fields);
 
      if (isReportPayload) {
        const displayText = data.message
          ? data.message
          : Object.entries(data.fields)
              .filter(([, v]) => v)
              .map(([k, v]) => `${k}: ${v}`)
              .join('\n');
 
        addMsg({ type: 'user', text: displayText, time: now() });
 
        setAwaitingResponse(true);
 
        setShowChainLoader(true);
        setLoading(true);
 
        log('🚀 FORM SEND (REPORT):', data);
 
        sendMessage(wsRef.current, data);
 
        return;
      }
 
      const answers = data;
 
      const SILENT_DISPLAY_FIELDS = new Set(['Timezone', 'WWID', 'Session_Id']);
 
      const displayText = Object.entries(answers)
        .filter(([k]) => !SILENT_DISPLAY_FIELDS.has(k))
        .map(([k, v]) => `${k}: ${v}`)
        .join('\n');
 
      addMsg({ type: 'user', text: displayText, time: now() });
 
      setAwaitingResponse(true);
 
      setShowChainLoader(true);
      setLoading(true);
 
      // ✅ Send with message field
      const payload = { message: displayText, fields: answers };
 
      log('🚀 FORM SEND (JSON MODE):', payload);
 
      sendMessage(wsRef.current, payload);
    },
    [addMsg]
  );
 
  // ── FORM SAVE ──
  const handleFormSave = useCallback(
    ({ message, displayMessage, fields }) => {
      if (awaitingResponse || wsStatus !== 'open') return;
      log('💾 FORM SAVE → AUTO SEND:', { message, fields });
 
      addMsg({ type: 'user', text: displayMessage || message, time: now() });
 
      setShowChainLoader(true);
      setLoading(true);
      setAwaitingResponse(true);
      sendMessage(wsRef.current, { message, fields });
 
      setMessages((prev) =>
        prev.map((msg) =>
          msg.type === 'form' ? { ...msg, locked: true } : msg
        )
      );
 
      savedFieldsRef.current = null;
    },
    [awaitingResponse, wsStatus, addMsg]
  );
 
  // Chain loader done
  const handleChainDone = useCallback(() => {}, []);
 
  const inputDisabled = wsStatus !== 'open' || awaitingResponse || loading;
 
  const allowImage = !inputDisabled;
 
  const isPageReady =
    !profileLoading &&
    !isCheckingLanguage &&
    !wwidLoading &&
    !sessionLoading &&
    profile &&
    wwid &&
    session &&
    languageSelected &&
    selectedLanguage !== null &&
    timezone !== '';
 
  // if (!isPageReady) {
  //   return (
  //     <div
  //       className="fixed inset-0 flex items-center justify-center bg-white"
  //       style={{ zIndex: 99999 }}
  //     >
  //       <div
  //         className="animate-spin rounded-full"
  //         style={{
  //           width: '60px',
  //           height: '60px',
  //           border: '6px solid #e5e7eb',
  //           borderTop: '6px solid #EF1400',
  //         }}
  //       />
  //     </div>
  //   );
  // }
 
  return (
    <div className="flex flex-col h-full bg-white">
      <Header
        onReset={resetChat}
        profile={profile}
        open={open}
        setOpen={setOpen}
        containerRef={containerRef}
        session={session}
        onLogout={handleLogout}
        selectedLanguage={selectedLanguage}
        onLanguageChange={handleLanguageSelect}
        onFileUpload={handleFileUpload}
      />
 
      <div className="flex-1 overflow-y-auto">
        <div className="p-4 space-y-4">
          {messages.map((msg) => (
            <MessageItem
              key={msg.id}
              msg={msg}
              email={profile?.email ?? ''}
              onFormSubmit={handleFormSubmit}
              onFormSave={handleFormSave}
              wwid={wwid}
              onReset={resetChat}
              handleLanguageChange={handleLanguageSelect}
              selectedLanguage={selectedLanguage}
              session={session}
              onFileUpload={handleFileUpload}
            />
          ))}
 
          {showChainLoader && <ChainOfThoughtLoader onDone={handleChainDone} />}
          <div ref={bottomRef} />
        </div>
      </div>
 
      <ChatInput
        onSend={handleSend}
        onImageResult={handleImageResult}
        disabled={inputDisabled}
        allowImage={allowImage}
        selectedLanguage={selectedLanguage}
      />
    </div>
  );
}
 
 
 
 