"use client";

// InvestigationForm — page orchestrator.

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, CheckCircle2, AlertTriangle, X } from "lucide-react";
import { useRouter, useParams } from "next/navigation";

import { sections } from "@/lib/sections";
import { sectionStatus } from "@/lib/status";
import StepRail from "@/components/StepRail";
import { SECTION_COMPONENTS } from "@/components/sections";
import Header from "@/components/Header";
import { getInvestigationPageData } from "@/lib/investigationDataApi";
import { useTranslation } from "@/lib/i18n";

import {
  YES,
  NO,
  countSubFormsWithEscalation,
  evaluateConstructionProject,
  evaluateEscalation,
  evaluateInvestigationRequired,
  getVisibleSections,   // NEW
  isGoodSaveEvent,      // NEW
  resolveDerivedValue,
} from "@/lib/businessRules";
import { validateInvestigation, visibleErrors } from "@/lib/investigationValidation";

const TOP_ACTIONS = [
  { id: "complete", labelKey: "actions.completeInvestigation", variant: "primary" },
  { id: "submitToNewInvestigator", labelKey: "actions.submitToNewInvestigator" },
  { id: "decline", labelKey: "actions.declineInvestigation", variant: "danger" },
  { id: "reviseDueDate", labelKey: "actions.reviseDueDate" },
  { id: "saveDraft", labelKey: "actions.saveAsDraft" },
  { id: "cancel", labelKey: "actions.cancel", variant: "danger" },
];

const BTN = {
  primary:
    "rounded-lg bg-jnj-red px-3.5 py-2 text-xs font-semibold text-white shadow-sm transition hover:bg-jnj-red-dark active:scale-[0.98]",
  danger: "rounded-lg border border-jnj-line px-3.5 py-2 text-xs font-medium text-jnj-red transition hover:bg-red-50",
  default:
    "rounded-lg border border-jnj-line px-3.5 py-2 text-xs font-medium text-jnj-slate transition hover:border-slate-300 hover:text-jnj-ink",
};

const hasErrors = (errs) => Boolean(errs) && Object.keys(errs).length > 0;

export default function InvestigationForm() {
  const params = useParams();
  const eventId = params?.id;
  const router = useRouter();
  const { t } = useTranslation();

  const initialValues = useMemo(() => {
    const v = {};
    sections.forEach((s) =>
      s.fields?.forEach((f) => {
        v[f.key] = f.value ?? "";
      })
    );
    return v;
  }, []);

  const [values, setValues] = useState(initialValues);
  const [wasSifp, setWasSifp] = useState(NO);
  const [categories, setCategories] = useState(() => new Set());
  const [toast, setToast] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [sectionData, setSectionData] = useState(null);
  const [sectionDrafts, setSectionDrafts] = useState({});
  const [preloadErrors, setPreloadErrors] = useState({});
  const [isPreloading, setIsPreloading] = useState(true);
  const [attemptedSections, setAttemptedSections] = useState(() => new Set());
  const [profile, setProfile] = useState(null);

  const setValue = useCallback((key, value) => setValues((prev) => ({ ...prev, [key]: value })), []);

    // Visible sections: "Good Save Primary Contributing Factor" only for Good Saves.
  // Everything below (section list, form, numbering, summary, validation) uses this list.
  const isGoodSave = isGoodSaveEvent(values.eventType);
  const visibleSections = useMemo(() => getVisibleSections(sections, values), [isGoodSave]); // eslint-disable-line react-hooks/exhaustive-deps

  // Keep the same section selected when the list changes; clamp if it disappeared.
  const currentSectionIdRef = useRef(null);
  useEffect(() => {
    const index = visibleSections.findIndex((s) => s.id === currentSectionIdRef.current);
    setCurrentStep((step) => (index >= 0 ? index : Math.min(step, visibleSections.length - 1)));
  }, [visibleSections]);

  // A hidden section must not keep (or submit) a value.
  useEffect(() => {
    if (!isGoodSave && values.primaryFactor) setValue("primaryFactor", "");
  }, [isGoodSave, values.primaryFactor, setValue]);
  const toggleCategory = useCallback(
    (item) =>
      setCategories((prev) => {
        const next = new Set(prev);
        next.has(item) ? next.delete(item) : next.add(item);
        return next;
      }),
    []
  );

  const handleSectionDataChange = useCallback((sectionId, data) => {
    setSectionDrafts((previous) => ({ ...previous, [sectionId]: data }));
  }, []);

  const handleWasSifpChange = useCallback((value) => setWasSifp(value === YES ? YES : NO), []);

  const handleRiskScoreChange = useCallback(
    (score) => setValue("riskScore", score == null || score === "" ? "" : String(score)),
    [setValue]
  );

  // ---------------------------------------------------------------------------
  // Business rules
  // ---------------------------------------------------------------------------
  const subFormEscalationCount = countSubFormsWithEscalation(sectionDrafts["sub-forms"]?.rows);

  const derived = useMemo(
    () => ({
      investigationRequired: evaluateInvestigationRequired({
        riskScore: values.riskScore,
        wasSifp,
        pseLevelConclusion: values.pseLevelConclusion,
      }),
      escalation: evaluateEscalation({
        communityMedia: values.communityMedia,
        wasSifp,
        riskScore: values.riskScore,
        subFormEscalationCount,
      }),
      constructionProject: evaluateConstructionProject(values.siteLocation),
    }),
    [values.riskScore, values.pseLevelConclusion, values.communityMedia, values.siteLocation, wasSifp, subFormEscalationCount]
  );

  const [rulesReady, setRulesReady] = useState(false);
  const previousLocksRef = useRef({});

  useEffect(() => {
    if (!isPreloading) setRulesReady(true);
  }, [isPreloading]);

  useEffect(() => {
    if (!rulesReady) return;

    const apply = (field, rule, unlockedValue) => {
      const next = resolveDerivedValue({
        current: values[field],
        locked: rule.locked,
        lockedValue: YES,
        unlockedValue,
        previousLocked: previousLocksRef.current[field],
      });
      if (next !== undefined) setValue(field, next);
      previousLocksRef.current[field] = rule.locked;
    };

    apply("investigationRequired", derived.investigationRequired, undefined);
    apply("escalationSite", derived.escalation, NO);
    apply("isConstructionProject", derived.constructionProject, NO);
  }, [rulesReady, derived, values.investigationRequired, values.escalationSite, values.isConstructionProject, setValue]); // eslint-disable-line react-hooks/exhaustive-deps

  // ---------------------------------------------------------------------------
  // Validation
  // ---------------------------------------------------------------------------
  const validationErrors = useMemo(
    () =>
      validateInvestigation({
        values,
        programCategories: sectionDrafts["program-category"]?.selected,
      }),
    [values, sectionDrafts]
  );

  const errorsFor = (sectionId) => visibleErrors(validationErrors[sectionId] || {}, attemptedSections.has(sectionId));

  const markAttempted = (ids) =>
    setAttemptedSections((prev) => {
      const next = new Set(prev);
      ids.forEach((id) => next.add(id));
      return next;
    });

  const canProceedFrom = (fromIndex) => {
    const id = visibleSections[fromIndex]?.id;;
    if (!hasErrors(validationErrors[id])) return true;
    markAttempted([id]);
    setToast(t("validation.fixErrorsToProceed"));
    return false;
  };

  const formSummary = useMemo(() => {
     const stats = visibleSections.map((s) => sectionStatus(s, values));
    const totalMissing = stats.reduce((n, st) => n + st.missing.length, 0);
    const sectionsWithMissing = stats.filter((st) => st.missing.length > 0).length;
    return { totalMissing, sectionsWithMissing, allDone: totalMissing === 0 };
  }, [values,visibleSections]);

  // ---------------------------------------------------------------------------
  // Navigation & actions
  // ---------------------------------------------------------------------------
  const goToStep = (i) => {
     const target = Math.max(0, Math.min(visibleSections.length - 1, i));
    if (target > currentStep && !canProceedFrom(currentStep)) return;
    setCurrentStep(target);
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleComplete = () => {
     const invalid = visibleSections
      .map((s, i) => ({ id: s.id, i }))
      .filter(({ id }) => hasErrors(validationErrors[id]));
    if (invalid.length > 0) {
      markAttempted(invalid.map((x) => x.id));
      setCurrentStep(invalid[0].i);
      setToast(t("validation.fixErrorsBeforeComplete", { count: invalid.length }));
      return;
    }
    setToast(t("toast.demoAction", { action: t("actions.completeInvestigation") }));
  };

  const handleSaveDraft = () => {
    const draft = {
      eventId,
      savedAt: new Date().toISOString(),
      values: { ...values },
      categories: Array.from(categories),
      derivedRules: derived,
      sections: { ...(sectionData || {}), ...sectionDrafts },
      mandatoryFields: formSummary,
      validationErrors,
    };
    console.log("Investigation draft:", draft);
    setToast(t("toast.draftPrepared"));
  };

  const handleTopAction = (actionId) => {
    if (actionId === "complete") return handleComplete();
    if (actionId === "saveDraft") return handleSaveDraft();
    const action = TOP_ACTIONS.find((a) => a.id === actionId);
    return setToast(t("toast.demoAction", { action: t(action?.labelKey ?? actionId) }));
  };

  const handleAdd = (label) => setToast(t("toast.comingSoon", { label }));

  // ---------------------------------------------------------------------------
  // Data loading
  // ---------------------------------------------------------------------------
  useEffect(() => {
    if (!eventId) return;

    let cancelled = false;
    setCurrentStep(0);
    setValues(initialValues);
    setWasSifp(NO);
    setIsPreloading(true);
    setRulesReady(false);
    previousLocksRef.current = {};
    setAttemptedSections(new Set());
    setSectionData(null);
    setSectionDrafts({});
    setPreloadErrors({});

    (async () => {
      const result = await getInvestigationPageData(eventId);
      if (cancelled) return;
      setSectionData(result.data);
      setPreloadErrors(result.errors);
      setIsPreloading(false);
    })();

    return () => {
      cancelled = true;
    };
  }, [eventId, initialValues]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/me", { credentials: "include" });
        if (!res.ok) return;
        const user = await res.json();
        if (cancelled) return;
        setProfile({
          firstName: user.firstName || "",
          lastName: user.lastName || "",
          email: user.email || "",
          displayName: user.displayName || "",
        });
      } catch {}
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const handleLogout = () => {
    try {
      sessionStorage.setItem("justLoggedOut", "1");
    } catch {}
    window.location.replace("/api/logout");
  };

  const sectionProps = (sectionId) => {
    switch (sectionId) {
      case "initial-report":
      case "investigation-details":
      case "program-category":
        return { errors: errorsFor(sectionId) };
      case "risk-evaluation":
        return { onRiskScoreChange: handleRiskScoreChange };
      case "sif-p-categories":
        return { onWasSifpChange: handleWasSifpChange };
      case "psm-details":
        return {
          wasSifp,
          communityMedia: values.communityMedia ?? NO,
          errors: errorsFor(sectionId),
        };
      case "review-assessment":
        return { derived };
      case "capa":
        return { wasSifp };
      default:
        return {};
    }
  };

  const isFirst = currentStep === 0;
 const isLast = currentStep === visibleSections.length - 1;
  currentSectionIdRef.current = visibleSections[currentStep]?.id ?? null;

  return (
    <main className="min-h-screen bg-jnj-mist pb-24">
      <div className="sticky top-0 z-40">
        <Header hideActions profile={profile} onLogout={handleLogout} />
      </div>

      <div className="sticky top-12 z-30 border-b border-jnj-line bg-white/95 backdrop-blur">
        <div className="mx-auto flex w-full flex-wrap items-center gap-2 px-4 py-3 sm:px-6 lg:px-10">
          <button onClick={() => router.push("/incidents")} className={BTN.default}>
            {t("page.incidentsList")}
          </button>

          {TOP_ACTIONS.map((a) => (
            <button key={a.id} onClick={() => handleTopAction(a.id)} className={BTN[a.variant] || BTN.default}>
              {t(a.labelKey)}
            </button>
          ))}
        </div>
      </div>

      <div className="mx-auto w-full px-4 pt-8 sm:px-6 lg:px-10">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-jnj-red">{t("page.eyebrow")}</p>
        <h1 className="mt-1 text-2xl font-extrabold tracking-tight text-jnj-ink sm:text-3xl">{t("page.title")}</h1>

        <div
          className="mt-4 flex items-center gap-2.5 rounded-lg px-4 py-3 text-sm font-medium"
          style={
            formSummary.allDone
              ? { background: "#ECFDF5", color: "#047857", boxShadow: "inset 0 0 0 1px #A7F3D0" }
              : { background: "#FFFBEB", color: "#B45309", boxShadow: "inset 0 0 0 1px #FDE68A" }
          }
        >
          {formSummary.allDone ? (
            <CheckCircle2 className="h-[18px] w-[18px] flex-shrink-0" />
          ) : (
            <AlertTriangle className="h-[18px] w-[18px] flex-shrink-0" />
          )}
          <span>
            {formSummary.allDone
              ? t("page.allRequiredFilled")
              : t(formSummary.totalMissing === 1 ? "page.missingRequiredOne" : "page.missingRequiredMany", {
                  count: formSummary.totalMissing,
                  sections: formSummary.sectionsWithMissing,
                })}
          </span>
        </div>
      </div>

      {Object.keys(preloadErrors).length > 0 && (
        <div className="mx-auto mt-4 w-full px-4 text-sm text-amber-700 sm:px-6 lg:px-10">{t("page.preloadPartial")}</div>
      )}

      <div className="mx-auto mt-6 grid w-full grid-cols-1 gap-6 px-4 sm:px-6 lg:grid-cols-[340px_1fr] lg:gap-8 lg:px-10">
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <StepRail
               sections={visibleSections}
            invalidSections={Object.fromEntries(visibleSections.map((s) => [s.id, errorsFor(s.id)]))}
            values={values}
            currentStep={currentStep}
            onJump={goToStep}

          />
        </aside>

        <div className="min-w-0">
          {isPreloading ? (
            <div className="rounded-xl border border-jnj-line bg-white p-8 text-sm text-jnj-slate shadow-sm">
              {t("page.loadingSections")}
            </div>
          ) : (
               visibleSections.map((section, sectionIndex) => {
              const SectionComponent = SECTION_COMPONENTS[section.id];
              return (
                <div key={`${eventId}-${section.id}`} hidden={sectionIndex !== currentStep}>
                  <SectionComponent
                    index={sectionIndex + 1}
                    values={values}
                    setValue={setValue}
                    categories={categories}
                    toggleCategory={toggleCategory}
                    rows={[]}
                    eventId={eventId}
                    preloadedData={sectionData?.[section.id]}
                    onSectionDataChange={handleSectionDataChange}
                    onAdd={handleAdd}
                    {...sectionProps(section.id)}
                  />
                </div>
              );
            })
          )}

          {!isPreloading && (
            <div className="mt-5 flex items-center justify-between gap-3">
              <button
                onClick={() => goToStep(currentStep - 1)}
                disabled={isFirst}
                className="inline-flex items-center gap-2 rounded-lg border border-jnj-line bg-white px-4 py-2.5 text-sm font-semibold text-jnj-ink transition hover:border-slate-300 disabled:cursor-not-allowed disabled:opacity-40"
              >
                <ChevronLeft className="h-4 w-4" /> {t("actions.previous")}
              </button>

              {isLast ? (
                <button
                  onClick={handleComplete}
                  className="inline-flex items-center gap-2 rounded-lg bg-jnj-red px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-jnj-red-dark active:scale-[0.99]"
                >
                  <CheckCircle2 className="h-4 w-4" /> {t("actions.completeInvestigation")}
                </button>
              ) : (
                <button
                  onClick={() => goToStep(currentStep + 1)}
                  className="inline-flex items-center gap-2 rounded-lg bg-jnj-red px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-jnj-red-dark active:scale-[0.99]"
                >
                  {t("actions.next")} <ChevronRight className="h-4 w-4" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {toast && (
        <div className="fixed bottom-6 left-1/2 z-[60] flex -translate-x-1/2 items-center gap-3 rounded-xl bg-jnj-ink px-4 py-3 text-sm text-white shadow-float">
          <span>{toast}</span>
          <button
            onClick={() => setToast(null)}
            aria-label={t("actions.dismiss")}
            className="grid h-6 w-6 place-items-center rounded-md text-white/70 transition hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
    </main>
  );
}
