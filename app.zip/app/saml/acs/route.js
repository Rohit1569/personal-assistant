import { saml } from "@/lib/saml";
import { cookies } from "next/headers";

export async function POST(request) {
  try {
    console.log("========== ACS HIT ==========");

    const formData = await request.formData();

    const samlResponse =
      formData.get("SAMLResponse");

    if (!samlResponse) {
      throw new Error("SAMLResponse missing");
    }

    const result =
      await saml.validatePostResponseAsync({
        SAMLResponse: samlResponse,
      });

    const claims = result.profile;

    const email =
      claims[
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"
      ];

    const firstName =
      claims[
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname"
      ];

    const lastName =
      claims[
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname"
      ];

    const displayName =
      claims[
        "http://schemas.microsoft.com/identity/claims/displayname"
      ];

    console.log("========== LOGIN SUCCESS ==========");
    console.log({
      email,
      firstName,
      lastName,
      displayName,
    });

    const cookieStore = await cookies();

    cookieStore.set(
      "curveUser",
      JSON.stringify({
        email,
        firstName,
        lastName,
        displayName,
      }),
      {
        httpOnly: true,
        secure: true,
        path: "/",
        sameSite: "lax",
      }
    );

    console.log(
      "Cookie created successfully"
    );

    return Response.redirect(
      "https://awsdjynval000a.jnj.com:8080/curve-chatbot/",
      302
    );

  } catch (err) {
    console.error(
      "========== ACS ERROR =========="
    );

    console.error(err);

    return Response.json(
      {
        success: false,
        error: err?.message,
      },
      {
        status: 500,
      }
    );
  }
}
